# Build information

- Resource: `pixel_enterprises`
- Product: Criminal Enterprise Network
- Version: `1.1.0`
- Release stage: Phase 2 complete / development-server candidate
- Built: 2026-08-04
- Required runtime validation: `docs/RUNTIME_TEST_PLAN.md`
- Database upgrade: migrations `008_phase2_organizations_conflict.sql` and `009_phase2_hardening.sql`
- External audit status: deferred until the complete Phase 2 package has passed development-server tests
