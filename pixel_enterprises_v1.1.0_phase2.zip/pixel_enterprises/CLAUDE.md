# Claude Review Role

Act as an independent reviewer unless the issue explicitly assigns implementation.
Prioritize authorization bypasses, client-trusted state, duplicate rewards, race conditions, SQL integrity, unsafe dynamic queries, event spoofing, inventory/money exploits, privacy leaks and cross-enterprise data exposure.
Do not make broad rewrites merely for style.
