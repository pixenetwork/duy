CENServer = CENServer or {}

function CENServer.NotifySource(source, message, kind)
    if type(source) ~= 'number' or source <= 0 or type(message) ~= 'string' then return false end
    TriggerClientEvent('pixel_enterprises:client:notification', source, {
        message = message:sub(1, 500),
        kind = kind or 'info'
    })
    return true
end

function CENServer.NotifyIdentifier(identifier, message, kind)
    local source = CENServer.Identity.GetSourceByIdentifier(identifier)
    if not source then return false end
    return CENServer.NotifySource(source, message, kind)
end
