CENServer = CENServer or {}
CENServer.Territory = CENServer.Territory or {}
local Territory = CENServer.Territory
local Repository = CENServer.ZoneRepository

local function countOnlineInside(enterpriseId, center, radius)
    if not enterpriseId then return 0 end
    local members = Repository.GetActiveMemberIdentifiers(enterpriseId)
    if not members then return 0 end
    local count = 0
    local target = vector3(center.x, center.y, center.z)
    for i = 1, #members do
        local source = CENServer.Identity.GetSourceByIdentifier(members[i].identifier)
        if source then
            local ped = GetPlayerPed(source)
            if ped and ped ~= 0 then
                local coords = GetEntityCoords(ped)
                if #(coords - target) <= radius then count = count + 1 end
            end
        end
    end
    return count
end

function Territory.IsPlayerInside(source, zone)
    local ped = GetPlayerPed(source)
    if not ped or ped == 0 then return false end
    local coords = GetEntityCoords(ped)
    return #(coords - vector3(zone.center.x, zone.center.y, zone.center.z)) <= zone.radius
end

function Territory.OnlineMembers(enterpriseId)
    local members = Repository.GetActiveMemberIdentifiers(enterpriseId)
    if not members then return 0 end
    local total = 0
    for i = 1, #members do
        if CENServer.Identity.GetSourceByIdentifier(members[i].identifier) then total = total + 1 end
    end
    return total
end

local function scoreContests()
    local contests = Repository.ListActiveContests()
    if not contests then return end
    for i = 1, #contests do
        local contest = contests[i]
        local center = { x = tonumber(contest.centerX), y = tonumber(contest.centerY), z = tonumber(contest.centerZ) }
        local radius = tonumber(contest.radius) or Config.Zones.defaultRadius
        local attackers = countOnlineInside(tonumber(contest.attackerEnterpriseId), center, radius)
        local defenders = countOnlineInside(tonumber(contest.defenderEnterpriseId), center, radius)
        local attackerPoints = attackers * math.max(1, Config.Zones.attackerPresencePoints)
        local defenderPoints = defenders * math.max(1, Config.Zones.defenderPresencePoints)
        if attackers > 0 and defenders == 0 then attackerPoints = attackerPoints + Config.Zones.uncontestedPresenceBonus end
        if defenders > 0 and attackers == 0 then defenderPoints = defenderPoints + Config.Zones.uncontestedPresenceBonus end
        if attackerPoints > 0 or defenderPoints > 0 then
            Repository.AddScore(contest.contestId, attackerPoints, defenderPoints)
        end
    end
end

local function resolveDue()
    local contests = Repository.ListDueContests()
    if not contests then return end
    for i = 1, #contests do
        local contest = contests[i]
        CENServer.WithMutationLocks(0, { ('zone:%s'):format(contest.zoneId) }, 'system', function()
            local attacker = tonumber(contest.attackerScore) or 0
            local defender = tonumber(contest.defenderScore) or 0
            local winner = attacker > defender and tonumber(contest.attackerEnterpriseId)
                or tonumber(contest.defenderEnterpriseId)
            if not winner then winner = tonumber(contest.attackerEnterpriseId) end
            if Repository.Resolve(contest, winner) then
                local award = contest.zoneType == 'turf' and Config.Progression.awards.turfWin
                    or Config.Progression.awards.territoryWin
                if winner then
                    CENServer.Progression.AddXp(winner, nil, award, 'zone_contest_win', { zoneId = contest.zoneId })
                    local loser = winner == tonumber(contest.attackerEnterpriseId)
                        and tonumber(contest.defenderEnterpriseId) or tonumber(contest.attackerEnterpriseId)
                    local warPoints = contest.zoneType == 'turf' and Config.Wars.points.turfWin
                        or Config.Wars.points.territoryWin
                    if loser then CENServer.Wars.RecordEvent(winner, loser, contest.zoneType .. '_win', warPoints, {
                        zoneId = contest.zoneId, contestId = contest.contestId
                    }) end
                end
                CENServer.Audit('zone_contest_completed', 0, {
                    enterpriseId = winner,
                    zoneId = contest.zoneId,
                    contestId = contest.contestId,
                    attackerScore = attacker,
                    defenderScore = defender,
                    winnerEnterpriseId = winner
                }, 'system')
            end
            return true
        end)
    end
end

CreateThread(function()
    while true do
        Wait(math.max(5, tonumber(Config.Zones.scoreIntervalSeconds) or 10) * 1000)
        if Config.Zones.enabled then scoreContests() end
    end
end)

CreateThread(function()
    while true do
        Wait(math.max(5, tonumber(Config.Zones.evaluationIntervalSeconds) or 5) * 1000)
        if Config.Zones.enabled then resolveDue() end
    end
end)
