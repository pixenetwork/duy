CENServer = CENServer or {}
CENServer.CreationPolicy = CENServer.CreationPolicy or {}

local Policy = CENServer.CreationPolicy

local function hasFrameworkGroup(source)
    local group = CENServer.Identity.GetFrameworkGroup(source)
    if not group then return false end
    for i = 1, #(Config.Creation.allowedFrameworkGroups or {}) do
        if Config.Creation.allowedFrameworkGroups[i] == group then return true end
    end
    return false
end

function Policy.IsAdmin(source)
    return source == 0 or IsPlayerAceAllowed(source, Config.Creation.adminAce)
end

function Policy.Resolve(enterpriseType)
    if not Config.Creation.enabled then return 'disabled' end
    local perType = Config.Creation.typePolicies[enterpriseType] or 'admin_only'
    -- A per-type disabled/admin-only rule is an unconditional ceiling. Global
    -- convenience modes can never open higher-tier enterprise types.
    if perType == 'disabled' or perType == 'admin_only' then return perType end
    if Config.Creation.mode == 'per_type' then return perType end
    if Config.Creation.mode == 'public' then return 'public_founding' end
    if Config.Creation.mode == 'ace' then return 'ace_founding' end
    if Config.Creation.mode == 'framework_group' then return 'framework_founding' end
    if Config.Creation.mode == 'admin_only' or Config.Creation.mode == 'disabled' then
        return Config.Creation.mode
    end
    return perType
end

function Policy.CanStart(source, enterpriseType)
    if not CEN.EnterpriseTypes[enterpriseType] then
        return false, CEN.Errors.INVALID_ENTERPRISE_TYPE
    end

    if Policy.IsAdmin(source) and Config.Creation.adminBypassFoundingRequirements then
        return true, nil, 'admin'
    end

    local policy = Policy.Resolve(enterpriseType)
    if policy == 'disabled' then return false, CEN.Errors.CREATION_DISABLED end
    if policy == 'admin_only' then return false, CEN.Errors.CREATION_NOT_ALLOWED end
    if policy == 'public_founding' then return true, nil, 'free' end
    if policy == 'ace_founding' then
        if IsPlayerAceAllowed(source, Config.Creation.creatorAce) then return true, nil, 'free' end
        return false, CEN.Errors.CREATION_NOT_ALLOWED
    end
    if policy == 'framework_founding' then
        if hasFrameworkGroup(source) then return true, nil, 'free' end
        return false, CEN.Errors.CREATION_NOT_ALLOWED
    end

    return false, CEN.Errors.CREATION_NOT_ALLOWED
end
