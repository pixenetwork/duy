CENServer = CENServer or {}
CENServer.Progression = CENServer.Progression or {}
local Progression = CENServer.Progression
local Repository = CENServer.ProgressionRepository

function Progression.RequiredXpForLevel(level)
    level = math.max(1, math.floor(tonumber(level) or 1))
    if level <= 1 then return 0 end
    local base = math.max(1, tonumber(Config.Progression.baseXp) or 1000)
    local growth = math.max(1.0, tonumber(Config.Progression.growth) or 1.35)
    local total = 0
    for current = 2, level do
        total = total + math.floor(base * (growth ^ (current - 2)))
    end
    return total
end

function Progression.LevelForXp(xp)
    xp = math.max(0, math.floor(tonumber(xp) or 0))
    local maxLevel = math.max(1, tonumber(Config.Progression.maxLevel) or 50)
    local level = 1
    for candidate = 2, maxLevel do
        if xp < Progression.RequiredXpForLevel(candidate) then break end
        level = candidate
    end
    return level
end

function Progression.Summary(enterpriseId)
    local data, errorCode = Repository.Get(enterpriseId, 25)
    if not data then return nil, errorCode end
    local level = tonumber(data.level) or 1
    local xp = tonumber(data.xp) or 0
    data.currentLevelXp = Progression.RequiredXpForLevel(level)
    data.nextLevelXp = level >= Config.Progression.maxLevel and nil or Progression.RequiredXpForLevel(level + 1)
    data.progress = data.nextLevelXp and math.max(0, math.min(1,
        (xp - data.currentLevelXp) / math.max(1, data.nextLevelXp - data.currentLevelXp))) or 1
    return data
end

function Progression.AddXp(enterpriseId, memberId, amount, reason, metadata)
    amount = math.floor(tonumber(amount) or 0)
    if amount <= 0 then return false, CEN.Errors.INVALID_AMOUNT end
    local row, errorCode = Repository.Add(enterpriseId, memberId, amount, reason, metadata)
    if not row then return false, errorCode end
    local calculated = Progression.LevelForXp(row.xp)
    local previous = tonumber(row.level) or 1
    if calculated > previous then
        if Repository.SetLevel(enterpriseId, calculated) then
            CENServer.Audit('enterprise_level_up', 0, {
                enterpriseId = enterpriseId,
                previousLevel = previous,
                newLevel = calculated,
                xp = tonumber(row.xp) or 0
            }, 'system')
        end
    end
    return true, calculated
end
