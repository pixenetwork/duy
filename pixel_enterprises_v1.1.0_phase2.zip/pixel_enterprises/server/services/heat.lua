CENServer = CENServer or {}
CENServer.Heat = CENServer.Heat or {}
local Heat = CENServer.Heat

function Heat.Add(enterpriseId, amount, reason)
    amount = math.floor(tonumber(amount) or 0)
    if amount == 0 then return true end
    local maximum = math.max(1, tonumber(Config.Operations.heatMaximum) or 1000)
    local ok, affected = pcall(function()
        return MySQL.update.await([[UPDATE cen_enterprises
          SET heat = LEAST(?, GREATEST(0, heat + ?))
          WHERE id = ? AND status = 'active']], { maximum, amount, enterpriseId })
    end)
    if not ok or tonumber(affected) ~= 1 then return false, CEN.Errors.DATABASE_UNAVAILABLE end
    if reason then
        CENServer.Audit('enterprise_heat_changed', 0, {
            enterpriseId = enterpriseId, amount = amount, reason = tostring(reason):sub(1, 80)
        }, 'system')
    end
    return true
end

function Heat.Reduce(enterpriseId, amount, reason)
    return Heat.Add(enterpriseId, -math.abs(math.floor(tonumber(amount) or 0)), reason)
end

CreateThread(function()
    local decay = math.max(0, tonumber(Config.Operations.heatDecayPerHour) or 0)
    while true do
        Wait(60 * 60 * 1000)
        if decay > 0 then
            local ok, errorValue = pcall(function()
                MySQL.update.await([[UPDATE cen_enterprises
                  SET heat = GREATEST(0, heat - ?)
                  WHERE status = 'active' AND heat > 0]], { decay })
            end)
            if not ok then print(('[pixel_enterprises] heat decay failed: %s'):format(tostring(errorValue))) end
        end
    end
end)
