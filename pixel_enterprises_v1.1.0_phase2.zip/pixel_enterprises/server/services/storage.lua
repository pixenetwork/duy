CENServer = CENServer or {}
CENServer.Storage = CENServer.Storage or {}
local Storage = CENServer.Storage
local registered = {}
local authorizedOpens = {}
local hookRegistered = false

local function stashId(enterpriseId)
    return ('cen_enterprise_%s'):format(enterpriseId)
end

local function registerHook()
    if hookRegistered or GetResourceState('ox_inventory') ~= 'started' then return end
    local ok = pcall(function()
        exports.ox_inventory:registerHook('openInventory', function(payload)
            local grant = authorizedOpens[payload.source]
            local valid = grant and grant.expiresAt >= GetGameTimer()
                and grant.stashId == tostring(payload.inventoryId)
                and CENServer.Identity.GetIdentifier(payload.source) == grant.identifier
            if valid then
                authorizedOpens[payload.source] = nil
                return true
            end
            return false
        end, { inventoryFilter = { '^cen_enterprise_' } })
    end)
    hookRegistered = ok
end

function Storage.Register(enterpriseId, enterpriseName)
    if not Config.Storage.enabled or registered[enterpriseId] then return true end
    if GetResourceState('ox_inventory') ~= 'started' then return false end
    registerHook()
    local ok = pcall(function()
        exports.ox_inventory:RegisterStash(
            stashId(enterpriseId),
            ('%s Storage'):format(enterpriseName or 'Enterprise'),
            Config.Storage.slots,
            Config.Storage.maxWeight,
            Config.Storage.owner
        )
    end)
    if ok then registered[enterpriseId] = true end
    return ok
end

function Storage.Open(source, enterpriseId, enterpriseName)
    if not Storage.Register(enterpriseId, enterpriseName) then return false end
    local identifier = CENServer.Identity.GetIdentifier(source)
    if not identifier then return false end
    local id = stashId(enterpriseId)
    authorizedOpens[source] = { stashId = id, identifier = identifier, expiresAt = GetGameTimer() + 3000 }
    local ok = pcall(function()
        exports.ox_inventory:forceOpenInventory(source, 'stash', id)
    end)
    if not ok then authorizedOpens[source] = nil end
    return ok
end

AddEventHandler('playerDropped', function() authorizedOpens[source] = nil end)

CreateThread(function()
    Wait(2000)
    if not Config.Storage.enabled or GetResourceState('ox_inventory') ~= 'started' then return end
    registerHook()
    local ok, rows = pcall(function()
        return MySQL.query.await("SELECT id, name FROM cen_enterprises WHERE status = 'active'")
    end)
    if ok and rows then
        for i = 1, #rows do Storage.Register(rows[i].id, rows[i].name) end
    end
end)
