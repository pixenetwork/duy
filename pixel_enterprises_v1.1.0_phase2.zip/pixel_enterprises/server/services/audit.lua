CENServer = CENServer or {}

local function safeEncode(value)
    local ok, encoded = pcall(json.encode, value)
    return ok and encoded or '"<encode_failed>"'
end

local function consoleRecord(record)
    local copy = {
        event = record.event,
        source = record.source,
        at = record.at,
        enterpriseId = type(record.payload) == 'table' and record.payload.enterpriseId or nil
    }
    return safeEncode(copy)
end

function CENServer.Audit(eventName, source, payload, actorIdentifier)
    local record = {
        event = eventName,
        source = source,
        at = os.time(),
        payload = payload or {}
    }

    if Config.Debug then
        print(('[pixel_enterprises][audit] %s'):format(consoleRecord(record)))
    end

    if GetResourceState('oxmysql') ~= 'started' then
        print(('[pixel_enterprises] audit persistence unavailable for event %s'):format(tostring(eventName)))
        return false
    end

    if actorIdentifier == nil and source and source ~= 0 then
        actorIdentifier = CENServer.Identity and CENServer.Identity.GetIdentifier(source) or nil
    elseif source == 0 and actorIdentifier == nil then
        actorIdentifier = 'system'
    end

    local enterpriseId = type(payload) == 'table' and payload.enterpriseId or nil
    local encodedPayload = safeEncode(payload or {})

    MySQL.insert([[INSERT INTO cen_audit_logs
        (enterprise_id, actor_identifier, event_name, payload)
        VALUES (?, ?, ?, ?)]], {
        enterpriseId,
        actorIdentifier,
        tostring(eventName):sub(1, 80),
        encodedPayload
    }, function(insertId)
        if not insertId then
            print(('[pixel_enterprises] failed to persist audit event %s'):format(tostring(eventName)))
        end
    end)
    return true
end
