CENServer = CENServer or {}
CENServer.Retention = CENServer.Retention or {}

local Retention = CENServer.Retention
local Activity = CENServer.ActivityRepository

local function timeTable(timestamp)
    if Config.Retention.useUtc then return os.date('!*t', timestamp) end
    return os.date('*t', timestamp)
end

function Retention.CycleStart(timestamp)
    local parts = timeTable(timestamp or os.time())
    return ('%04d-%02d-01'):format(parts.year, parts.month)
end

function Retention.PreviousCycleStart(timestamp)
    local parts = timeTable(timestamp or os.time())
    local month = parts.month - 1
    local year = parts.year
    if month == 0 then month, year = 12, year - 1 end
    return ('%04d-%02d-01'):format(year, month)
end

local function createdBeforeOrOnCycle(createdAt, cycleStart)
    if type(createdAt) ~= 'string' then return false end
    local normalized = createdAt:gsub('T', ' '):sub(1, 19)
    return normalized <= (cycleStart .. ' 00:00:00')
end

local heartbeatState = {}

local function heartbeat()
    local cycle = Retention.CycleStart()
    local interval = math.max(1, tonumber(Config.Retention.activityHeartbeatMinutes) or 5)
    local identifiers, sourcesByIdentifier = {}, {}
    for _, playerId in ipairs(GetPlayers()) do
        local source = tonumber(playerId)
        local playerIdentifier = source and CENServer.Identity.GetIdentifier(source) or nil
        if playerIdentifier then
            identifiers[#identifiers + 1] = playerIdentifier
            sourcesByIdentifier[playerIdentifier] = source
        end
    end
    local memberships, errorCode = CENServer.Repository.GetActiveMembershipsByIdentifiers(identifiers)
    if not memberships then
        CENServer.Audit('retention_heartbeat_skipped', 0, { error = errorCode }, 'retention')
        return
    end
    local records, stillOnline = {}, {}
    for i = 1, #memberships do
        local member = memberships[i]
        local source = sourcesByIdentifier[member.playerIdentifier]
        if source then
            local ped = GetPlayerPed(source)
            if ped and ped ~= 0 then
                local coords = GetEntityCoords(ped)
                local key = tostring(member.memberId)
                stillOnline[key] = true
                local previous = heartbeatState[key]
                heartbeatState[key] = { x = coords.x, y = coords.y, z = coords.z }
                if previous then
                    local distance = #(coords - vector3(previous.x, previous.y, previous.z))
                    local inVehicle = GetVehiclePedIsIn(ped, false) ~= 0
                    if distance >= 3.0 or inVehicle then
                        records[#records + 1] = {
                            enterpriseId = member.enterpriseId,
                            memberId = member.memberId
                        }
                    end
                end
            end
        end
    end
    for key in pairs(heartbeatState) do
        if not stillOnline[key] then heartbeatState[key] = nil end
    end
    if #records > 0 then Activity.RecordHeartbeats(records, cycle, interval) end
end

local function notifyOwner(row, message, kind)
    if row.ownerIdentifier then CENServer.NotifyIdentifier(row.ownerIdentifier, message, kind) end
end

local function evaluateEnterprise(row, now, current, previous, day)
    local currentRow, rowError = Activity.GetRetentionEnterprise(row.enterpriseId)
    if not currentRow then
        if rowError ~= CEN.Errors.INVALID_ENTERPRISE then
            CENServer.Audit('retention_evaluation_skipped', 0, {
                enterpriseId = row.enterpriseId,
                cycle = current,
                error = rowError or CEN.Errors.DATABASE_UNAVAILABLE
            }, 'retention')
        end
        return true
    end
    row = currentRow

    local currentCount, currentCountError = Activity.QualifiedCount(row.enterpriseId, current)
    if currentCount == nil then
        CENServer.Audit('retention_evaluation_skipped', 0, {
            enterpriseId = row.enterpriseId,
            cycle = current,
            error = currentCountError or CEN.Errors.DATABASE_UNAVAILABLE
        }, 'retention')
        return true
    end

    if day >= Config.Retention.warningDay
        and createdBeforeOrOnCycle(row.createdAt, current)
        and currentCount < Config.Retention.minimumActiveMembers
        and tostring(row.retentionWarningCycle or ''):sub(1, 10) ~= current then
        if Activity.MarkWarning(row.enterpriseId, current) then
            local message = ('%s has only %d/%d active members this month. Reach the minimum before month end or the enterprise will enter deletion review.'):format(
                row.name, currentCount, Config.Retention.minimumActiveMembers)
            notifyOwner(row, message, 'warning')
            CENServer.Audit('retention_week_three_warning', 0, {
                enterpriseId = row.enterpriseId,
                cycle = current,
                qualifiedMembers = currentCount,
                requiredMembers = Config.Retention.minimumActiveMembers
            }, 'retention')
            row.retentionStatus = 'warning'
        end
    end

    if createdBeforeOrOnCycle(row.createdAt, previous)
        and tostring(row.retentionFailureCycle or ''):sub(1, 10) ~= previous then
        local previousCount, previousCountError = Activity.QualifiedCount(row.enterpriseId, previous)
        if previousCount == nil then
            CENServer.Audit('retention_evaluation_skipped', 0, {
                enterpriseId = row.enterpriseId,
                cycle = previous,
                error = previousCountError or CEN.Errors.DATABASE_UNAVAILABLE
            }, 'retention')
            return true
        end
        if previousCount < Config.Retention.minimumActiveMembers then
            if Activity.ScheduleDisband(row.enterpriseId, previous) then
                notifyOwner(row, ('%s failed the monthly activity requirement (%d/%d). It is scheduled for deletion in %d day(s).'):format(
                    row.name, previousCount, Config.Retention.minimumActiveMembers, Config.Retention.deletionGraceDays), 'error')
                CENServer.Audit('retention_disband_scheduled', 0, {
                    enterpriseId = row.enterpriseId,
                    cycle = previous,
                    qualifiedMembers = previousCount,
                    requiredMembers = Config.Retention.minimumActiveMembers,
                    graceDays = Config.Retention.deletionGraceDays
                }, 'retention')
                row.retentionStatus = 'pending_disband'
                row.disbandScheduledAt = true
            end
        else
            Activity.MarkHealthy(row.enterpriseId, previous)
            row.retentionStatus = 'healthy'
        end
    end

    if row.retentionStatus == 'pending_disband' and row.disbandScheduledAt then
        if Config.Retention.allowRecoveryDuringGrace
            and currentCount >= Config.Retention.minimumActiveMembers then
            if Activity.CancelDisband(row.enterpriseId) then
                notifyOwner(row, ('%s recovered and is no longer scheduled for deletion.'):format(row.name), 'success')
                CENServer.Audit('retention_disband_cancelled', 0, {
                    enterpriseId = row.enterpriseId,
                    cycle = current,
                    qualifiedMembers = currentCount
                }, 'retention')
            end
        elseif Activity.DisbandDue(row.enterpriseId) then
            notifyOwner(row, ('%s was disbanded for failing the monthly activity requirement.'):format(row.name), 'error')
            CENServer.Audit('retention_enterprise_disbanded', 0, {
                enterpriseId = row.enterpriseId,
                hardDelete = false
            }, 'retention')
        end
    end

    return true
end

function Retention.Evaluate()
    if not Config.Retention.enabled then return end
    local rows = Activity.ListRetentionEnterprises()
    if not rows then return end

    local now = os.time()
    local current = Retention.CycleStart(now)
    local previous = Retention.PreviousCycleStart(now)
    local day = timeTable(now).day

    for i = 1, #rows do
        local row = rows[i]
        CENServer.WithMutationLocks(0, {
            ('enterprise:%s'):format(row.enterpriseId)
        }, 'retention', function()
            return evaluateEnterprise(row, now, current, previous, day)
        end)
    end
end

function Retention.Start()
    if not Config.Retention.enabled then return end
    CreateThread(function()
        Wait(5000)
        while true do
            heartbeat()
            Wait(math.max(1, Config.Retention.activityHeartbeatMinutes) * 60000)
        end
    end)
    CreateThread(function()
        Wait(10000)
        while true do
            pcall(Retention.Evaluate)
            Wait(math.max(5, Config.Retention.evaluationIntervalMinutes) * 60000)
        end
    end)
end
