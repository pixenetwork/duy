CENServer = CENServer or {}


local function moduleEnabled(moduleName)
    local checks = {
        [CEN.Modules.CREWS] = function() return Config.Crews and Config.Crews.enabled == true end,
        [CEN.Modules.DIPLOMACY] = function() return Config.Diplomacy and Config.Diplomacy.enabled == true end,
        [CEN.Modules.WARS] = function() return Config.Wars and Config.Wars.enabled == true end,
        [CEN.Modules.FRONTS] = function() return Config.Fronts and Config.Fronts.enabled == true end,
        [CEN.Modules.RACKETS] = function() return Config.Rackets and Config.Rackets.enabled == true end,
        [CEN.Modules.CORRUPTION] = function() return Config.Corruption and Config.Corruption.enabled == true end,
        [CEN.Modules.TURFS] = function() return Config.Zones and Config.Zones.enabled == true end,
        [CEN.Modules.TERRITORIES] = function() return Config.Zones and Config.Zones.enabled == true end,
        [CEN.Modules.LABS] = function() return Config.Operations and Config.Operations.enabled == true end,
        [CEN.Modules.ARMS] = function() return Config.Operations and Config.Operations.enabled == true end,
        [CEN.Modules.WHOLESALE] = function() return Config.Market and Config.Market.enabled == true end,
        [CEN.Modules.STREET_DISTRIBUTION] = function() return Config.StreetSales and Config.StreetSales.enabled == true end,
        [CEN.Modules.SMUGGLING] = function() return Config.Shipments and Config.Shipments.enabled ~= false end,
        [CEN.Modules.AIRDROPS] = function() return Config.Shipments and Config.Shipments.enabled ~= false end
    }
    local check = checks[moduleName]
    return not check or check()
end

function CENServer.IsModuleEnabled(moduleName)
    return moduleEnabled(moduleName)
end

local function hasValue(values, target)
    if type(values) ~= 'table' then return false end
    for i = 1, #values do
        if values[i] == target then return true end
    end
    return false
end

function CENServer.HasPermission(member, permission)
    if type(member) ~= 'table' or member.status ~= 'active' then
        return false
    end

    local definition = CEN.PermissionDefinitions[permission]
    if not definition then return false end

    if member.isOwner == true or member.isOwner == 1 then
        return true
    end

    if definition.ownerOnly then return false end
    return hasValue(member.permissions, permission)
end

function CENServer.CanAccessModule(enterpriseType, moduleName)
    local definition = CEN.EnterpriseTypes[enterpriseType]
    return definition ~= nil and moduleEnabled(moduleName) and hasValue(definition.modules, moduleName)
end

function CENServer.Authorize(member, permission, moduleName)
    if type(member) ~= 'table' or member.status ~= 'active' then
        return false, CEN.Errors.NOT_MEMBER
    end

    if moduleName and not CENServer.CanAccessModule(member.enterpriseType, moduleName) then
        return false, CEN.Errors.INVALID_MODULE
    end

    if not CENServer.HasPermission(member, permission) then
        return false, CEN.Errors.FORBIDDEN
    end

    return true
end

function CENServer.CanManageMember(actor, target)
    if not actor or not target or actor.enterpriseId ~= target.enterpriseId then
        return false, CEN.Errors.TARGET_NOT_MEMBER
    end

    if target.isOwner == true or target.isOwner == 1 then
        return false, CEN.Errors.CANNOT_MANAGE_OWNER
    end

    if actor.isOwner == true or actor.isOwner == 1 then
        return true
    end

    if tonumber(actor.rankPriority) <= tonumber(target.rankPriority) then
        return false, CEN.Errors.CANNOT_MANAGE_EQUAL_OR_HIGHER
    end

    return true
end

function CENServer.CanAssignRank(actor, rank)
    if not actor or not rank or actor.enterpriseId ~= rank.enterpriseId then
        return false, CEN.Errors.INVALID_RANK
    end

    if actor.isOwner == true or actor.isOwner == 1 then
        return true
    end

    if tonumber(actor.rankPriority) <= tonumber(rank.priority) then
        return false, CEN.Errors.CANNOT_ASSIGN_EQUAL_OR_HIGHER
    end

    return true
end

function CENServer.FilterPermissionsForEnterprise(enterpriseType, permissions)
    local filtered = {}
    for i = 1, #permissions do
        local permission = permissions[i]
        local definition = CEN.PermissionDefinitions[permission]
        if definition and not definition.ownerOnly then
            if not definition.module or CENServer.CanAccessModule(enterpriseType, definition.module) then
                filtered[#filtered + 1] = permission
            end
        end
    end
    return filtered
end

function CENServer.CanGrantPermissions(actor, permissions)
    if actor.isOwner == true or actor.isOwner == 1 then
        return true
    end

    for i = 1, #permissions do
        local permission = permissions[i]
        local definition = CEN.PermissionDefinitions[permission]
        if not definition or definition.ownerOnly or not CENServer.HasPermission(actor, permission) then
            return false, CEN.Errors.FORBIDDEN
        end
    end

    return true
end

function CENServer.EnabledModulesForEnterprise(enterpriseType)
    local definition = CEN.EnterpriseTypes[enterpriseType]
    local result = {}
    if not definition then return result end
    for i = 1, #definition.modules do
        if moduleEnabled(definition.modules[i]) then result[#result + 1] = definition.modules[i] end
    end
    return result
end
