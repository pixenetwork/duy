CENServer = CENServer or {}
CENServer.Wars = CENServer.Wars or {}
local Wars = CENServer.Wars
local Repository = CENServer.WarRepository

function Wars.RecordEvent(scoringEnterpriseId, opposingEnterpriseId, eventType, points, metadata)
    scoringEnterpriseId = tonumber(scoringEnterpriseId)
    opposingEnterpriseId = tonumber(opposingEnterpriseId)
    points = math.max(0, math.floor(tonumber(points) or 0))
    if not Config.Wars.enabled or not scoringEnterpriseId or not opposingEnterpriseId or points <= 0 then return false end
    local war = Repository.FindActiveBetween(scoringEnterpriseId, opposingEnterpriseId)
    if not war then return false end
    local result, errorCode = Repository.AddScore(war.warId, scoringEnterpriseId, eventType, points, metadata)
    if result then
        CENServer.Audit('war_score_added', 0, {
            enterpriseId = scoringEnterpriseId,
            opposingEnterpriseId = opposingEnterpriseId,
            warId = war.warId,
            eventType = eventType,
            points = points
        }, 'war-system')
    else
        CENServer.Audit('war_score_failed', 0, {
            enterpriseId = scoringEnterpriseId, opposingEnterpriseId = opposingEnterpriseId,
            warId = war.warId, eventType = eventType, error = errorCode
        }, 'war-system')
    end
    return result ~= nil
end

local function finalize(row)
    local attackerScore = tonumber(row.attackerScore) or 0
    local defenderScore = tonumber(row.defenderScore) or 0
    local result, errorCode = Repository.Finalize(row.warId, Config.Wars.postWarCeasefireHours or 0)
    if not result then
        CENServer.Audit('war_finalize_failed', 0, { warId = row.warId, error = errorCode }, 'war-system')
        return false
    end
    local winner = result.winnerEnterpriseId
    if winner then
        local loser = winner == row.attackerEnterpriseId and row.defenderEnterpriseId or row.attackerEnterpriseId
        CENServer.Progression.AddXp(winner, nil, Config.Wars.winnerXp, 'war_victory', { warId = row.warId })
        CENServer.Progression.AddXp(loser, nil, Config.Wars.loserXp, 'war_participation', { warId = row.warId })
    end
    CENServer.Audit('war_completed', 0, {
        enterpriseId = winner,
        warId = row.warId,
        attackerEnterpriseId = row.attackerEnterpriseId,
        defenderEnterpriseId = row.defenderEnterpriseId,
        attackerScore = attackerScore,
        defenderScore = defenderScore,
        winnerEnterpriseId = winner
    }, 'war-system')
    return true
end

local function evaluate()
    if not Config.Wars.enabled then return end
    local due = Repository.ListDue()
    if due then
        for i = 1, #due do
            local row = due[i]
            CENServer.WithMutationLocks(0, {
                ('enterprise:%s'):format(row.attackerEnterpriseId),
                ('enterprise:%s'):format(row.defenderEnterpriseId),
                ('war:%s'):format(row.warId)
            }, 'war-system', function()
                local current = Repository.Get(row.warId)
                if current and current.status == 'active' then finalize(current) end
                return true
            end)
        end
    end
    local expired = Repository.ExpireProposals()
    if expired then
        for i = 1, #expired do
            local row = expired[i]
            CENServer.WithMutationLocks(0, {
                ('enterprise:%s'):format(row.attackerEnterpriseId),
                ('war:%s'):format(row.warId)
            }, 'war-system', function()
                local result = Repository.Cancel(row.warId, row.attackerEnterpriseId)
                if result then
                    pcall(function()
                        MySQL.update.await("UPDATE cen_wars SET status = 'expired' WHERE id = ? AND status = 'cancelled'", { row.warId })
                    end)
                    CENServer.Audit('war_proposal_expired', 0, {
                        enterpriseId = row.attackerEnterpriseId, warId = row.warId
                    }, 'war-system')
                end
                return true
            end)
        end
    end
end

CreateThread(function()
    Wait(15000)
    while true do
        pcall(evaluate)
        Wait(15000)
    end
end)

exports('AddWarScore', function(scoringEnterpriseId, opposingEnterpriseId, eventType, points, metadata)
    return Wars.RecordEvent(scoringEnterpriseId, opposingEnterpriseId, eventType, points, metadata)
end)
