local requestWindows = {}
local requestCooldowns = {}
local mutationLocks = {}
local queuedMutations = {}
local denialAuditTimes = {}
local connectionStates = {}
local connectionSequence = 0
local tabletSessions = {}

local function isValidRequestId(requestId)
    return type(requestId) == 'string'
        and #requestId > 0
        and #requestId <= Config.Security.maxRequestIdLength
end

local function isValidAction(action)
    return type(action) == 'string'
        and #action > 0
        and #action <= 64
        and action:match('^[%a][%w_]*$') ~= nil
        and CENServer.Router.IsKnownAction(action)
end

local function getConnectionState(source, identifier)
    local state = connectionStates[source]
    if state and state.identifier == identifier then return state end
    connectionSequence = connectionSequence + 1
    state = {
        identifier = identifier,
        token = ('%s:%s:%s'):format(source, connectionSequence, GetGameTimer())
    }
    connectionStates[source] = state
    return state
end

local function sameConnection(source, expectedIdentifier, connectionToken)
    local state = connectionStates[source]
    return expectedIdentifier ~= nil
        and state ~= nil
        and state.identifier == expectedIdentifier
        and state.token == connectionToken
        and CENServer.Identity.GetIdentifier(source) == expectedIdentifier
end

local function sameRequester(source, expectedIdentifier)
    return expectedIdentifier ~= nil
        and CENServer.Identity.GetIdentifier(source) == expectedIdentifier
end

local function modeAllowsStandalone()
    local mode = Config.Tablet.mode
    return Config.Tablet.standalone.enabled == true
        and (mode == 'standalone' or mode == 'both'
            or (mode == 'auto' and GetResourceState(Config.Tablet.lbTablet.resource) ~= 'started'))
end

local function modeAllowsLBTablet()
    local mode = Config.Tablet.mode
    return mode == 'lb-tablet' or mode == 'both' or mode == 'auto'
end

local function hasConfiguredItem(source, itemNames)
    if GetResourceState('ox_inventory') ~= 'started' then return false end
    if type(itemNames) == 'string' then itemNames = { itemNames } end
    if type(itemNames) ~= 'table' or #itemNames == 0 then return false end
    for i = 1, #itemNames do
        local ok, count = pcall(function()
            return exports.ox_inventory:Search(source, 'count', itemNames[i])
        end)
        if ok and (tonumber(count) or 0) > 0 then return true end
    end
    return false
end

local function hostAllowed(host)
    if host == 'standalone' then return modeAllowsStandalone() end
    return host == 'lb-tablet' and modeAllowsLBTablet()
        and GetResourceState(Config.Tablet.lbTablet.resource) == 'started'
end

local function hasTabletAccess(source, host)
    if not hostAllowed(host) then return false end
    if host == 'standalone' then
        local settings = Config.Tablet.standalone
        return settings.requireItem ~= true or hasConfiguredItem(source, { settings.itemName })
    end
    local settings = Config.Tablet.lbTablet
    return settings.requireItem ~= true or hasConfiguredItem(source, settings.itemNames)
end

local function issueTabletSession(source, identifier, host)
    if not hasTabletAccess(source, host) then return nil end
    local state = getConnectionState(source, identifier)
    local idleTtl = math.max(30, tonumber(Config.Security.standaloneSessionSeconds) or 120)
    local absoluteTtl = math.max(idleTtl, tonumber(Config.Security.tabletSessionAbsoluteSeconds) or 900)
    local now = os.time()
    local token = ('cen:%s:%s:%s'):format(state.token, now, math.random(100000, 999999))
    tabletSessions[state.token] = {
        identifier = identifier,
        token = token,
        host = host,
        expiresAt = now + idleTtl,
        absoluteExpiresAt = now + absoluteTtl,
        lastItemCheckAt = now
    }
    return token, idleTtl, absoluteTtl
end

local function validateRequestAccess(source, identifier, connectionToken, request)
    local session = tabletSessions[connectionToken]
    local now = os.time()
    if not session or session.identifier ~= identifier or session.token ~= request.accessToken
        or session.expiresAt <= now or session.absoluteExpiresAt <= now then
        return false
    end
    if not hostAllowed(session.host) then return false end
    local recheck = math.max(1, tonumber(Config.Security.recheckTabletItemEverySeconds) or 20)
    if now - (session.lastItemCheckAt or 0) >= recheck then
        if not hasTabletAccess(source, session.host) then
            tabletSessions[connectionToken] = nil
            return false
        end
        session.lastItemCheckAt = now
    end
    session.expiresAt = math.min(session.absoluteExpiresAt,
        now + math.max(30, tonumber(Config.Security.standaloneSessionSeconds) or 120))
    return true
end

local function allowRequestWindow(connectionKey)
    local now = GetGameTimer()
    local windowMs = math.max(250, tonumber(Config.Security.requestWindowMs) or 2000)
    local maxRequests = math.max(1, tonumber(Config.Security.maxRequestsPerWindow) or 12)
    local state = requestWindows[connectionKey]

    if not state or now - state.startedAt >= windowMs then
        requestWindows[connectionKey] = { startedAt = now, count = 1 }
        return true
    end

    state.count = state.count + 1
    return state.count <= maxRequests
end

local function isCoolingDown(connectionKey, mutation)
    local now = GetGameTimer()
    local bucket = mutation and 'mutation' or 'read'
    local key = ('%s:%s'):format(connectionKey, bucket)
    local previous = requestCooldowns[key] or 0
    local cooldown = mutation and Config.Security.mutationCooldownMs or Config.Security.requestCooldownMs
    requestCooldowns[key] = now
    if previous == 0 then return false end
    return now - previous < math.max(0, tonumber(cooldown) or 0)
end

local function reply(source, expectedIdentifier, connectionToken, requestId, ok, data, errorCode)
    if not sameConnection(source, expectedIdentifier, connectionToken) then return end
    TriggerClientEvent('pixel_enterprises:client:response', source, {
        requestId = requestId,
        ok = ok,
        data = data,
        error = errorCode
    })
end

local function normalizeLockKeys(keys, requesterIdentifier)
    if type(keys) ~= 'table' then keys = {} end
    local unique = {}
    local normalized = {}
    for i = 1, #keys do
        local key = tostring(keys[i] or '')
        if key ~= '' and #key <= 160 and not unique[key] then
            unique[key] = true
            normalized[#normalized + 1] = key
        end
    end
    if #normalized == 0 then
        normalized[1] = ('requester:%s'):format(requesterIdentifier)
    end
    table.sort(normalized)
    return normalized
end

local function releaseLocks(acquired)
    for i = #acquired, 1, -1 do
        mutationLocks[acquired[i]] = nil
    end
end

local function acquireLocks(keys, source, expectedIdentifier, connectionToken)
    local acquired = {}
    local timeoutMs = math.max(250, tonumber(Config.Security.mutationLockTimeoutMs) or 5000)
    local deadline = GetGameTimer() + timeoutMs

    for i = 1, #keys do
        local key = keys[i]
        while mutationLocks[key] do
            if GetGameTimer() >= deadline then
                releaseLocks(acquired)
                return nil, CEN.Errors.CONFLICT
            end
            if source ~= 0 and not sameConnection(source, expectedIdentifier, connectionToken) then
                releaseLocks(acquired)
                return nil, CEN.Errors.CONFLICT
            end
            Wait(10)
        end
        mutationLocks[key] = source
        acquired[#acquired + 1] = key
    end

    return acquired
end

function CENServer.WithMutationLocks(source, keys, requesterIdentifier, callback)
    if type(callback) ~= 'function' then return nil, CEN.Errors.BAD_REQUEST end
    requesterIdentifier = requesterIdentifier or (source == 0 and 'console' or CENServer.Identity.GetIdentifier(source))
    if not requesterIdentifier then return nil, CEN.Errors.LICENSE_MISSING end
    local connectionToken
    if source ~= 0 then
        connectionToken = getConnectionState(source, requesterIdentifier).token
    end

    local acquired, lockError = acquireLocks(
        normalizeLockKeys(keys, requesterIdentifier), source, requesterIdentifier, connectionToken)
    if not acquired then return nil, lockError end
    local ok, value, errorCode, extra = xpcall(callback, debug.traceback)
    releaseLocks(acquired)
    if not ok then
        print(('[pixel_enterprises] locked mutation failed: %s'):format(tostring(value)))
        return nil, CEN.Errors.INTERNAL_ERROR
    end
    return value, errorCode, extra
end

local function auditDenied(source, connectionKey, actorIdentifier, action, errorCode)
    if not Config.Security.auditDenials then return end
    local now = GetGameTimer()
    local key = ('%s:%s:%s'):format(connectionKey, tostring(action), tostring(errorCode))
    local previous = denialAuditTimes[key] or 0
    if previous ~= 0 and now - previous < 5000 then return end
    denialAuditTimes[key] = now
    CENServer.Audit('request_denied', source, {
        action = action,
        error = errorCode
    }, actorIdentifier)
end

RegisterNetEvent('pixel_enterprises:server:requestTabletSession', function(requestedHost)
    local source = source
    local identifier = CENServer.Identity.GetIdentifier(source)
    local host = requestedHost == 'lb-tablet' and 'lb-tablet' or 'standalone'
    if not identifier then
        TriggerClientEvent('pixel_enterprises:client:tabletSession', source, { ok = false, host = host })
        return
    end
    local token, idleTtl, absoluteTtl = issueTabletSession(source, identifier, host)
    TriggerClientEvent('pixel_enterprises:client:tabletSession', source, {
        ok = token ~= nil,
        host = host,
        token = token,
        expiresIn = idleTtl,
        absoluteExpiresIn = absoluteTtl
    })
end)

RegisterNetEvent('pixel_enterprises:server:request', function(request)
    local source = source
    local requesterIdentifier = CENServer.Identity.GetIdentifier(source)
    if not requesterIdentifier then return end
    local connectionState = getConnectionState(source, requesterIdentifier)
    local connectionToken = connectionState.token
    local connectionKey = connectionToken

    -- This limit intentionally runs before json.encode and all database work.
    if not allowRequestWindow(connectionKey) then
        if type(request) == 'table' and isValidRequestId(request.requestId) then
            reply(source, requesterIdentifier, connectionToken, request.requestId, false, nil, CEN.Errors.RATE_LIMITED)
        end
        return
    end

    if type(request) ~= 'table'
        or not isValidRequestId(request.requestId)
        or not isValidAction(request.action)
        or (request.payload ~= nil and type(request.payload) ~= 'table')
        or not CEN.Validation.PayloadWithinLimit(request.payload) then
        if type(request) == 'table' and isValidRequestId(request.requestId) then
            reply(source, requesterIdentifier, connectionToken, request.requestId, false, nil, CEN.Errors.BAD_REQUEST)
        end
        return
    end

    if not validateRequestAccess(source, requesterIdentifier, connectionToken, request) then
        reply(source, requesterIdentifier, connectionToken, request.requestId, false, nil, CEN.Errors.FORBIDDEN)
        return
    end

    if not CENServer.Repository.IsReady() then
        reply(source, requesterIdentifier, connectionToken, request.requestId, false, nil, CEN.Errors.DATABASE_UNAVAILABLE)
        return
    end

    local action = request.action
    local mutation = CENServer.Router.IsMutation(action)
    if isCoolingDown(connectionKey, mutation) then
        reply(source, requesterIdentifier, connectionToken, request.requestId, false, nil, CEN.Errors.RATE_LIMITED)
        return
    end

    local maxQueued = math.max(1, tonumber(Config.Security.maxMutationQueuePerSource) or 4)
    if mutation then
        local queued = queuedMutations[connectionKey] or 0
        if queued >= maxQueued then
            reply(source, requesterIdentifier, connectionToken, request.requestId, false, nil, CEN.Errors.RATE_LIMITED)
            return
        end
        queuedMutations[connectionKey] = queued + 1
    end

    CreateThread(function()
        local acquired
        local function finishQueue()
            if not mutation then return end
            queuedMutations[connectionKey] = math.max(0, (queuedMutations[connectionKey] or 1) - 1)
            if queuedMutations[connectionKey] == 0 then queuedMutations[connectionKey] = nil end
        end

        if mutation then
            local keys, keyError = CENServer.Router.GetMutationKeys(
                source, action, request.payload, requesterIdentifier)
            if not keys then
                finishQueue()
                auditDenied(source, connectionKey, requesterIdentifier, action, keyError or CEN.Errors.CONFLICT)
                reply(source, requesterIdentifier, connectionToken, request.requestId, false, nil, keyError or CEN.Errors.CONFLICT)
                return
            end

            acquired, keyError = acquireLocks(normalizeLockKeys(keys, requesterIdentifier), source, requesterIdentifier, connectionToken)
            if not acquired then
                finishQueue()
                reply(source, requesterIdentifier, connectionToken, request.requestId, false, nil, keyError or CEN.Errors.CONFLICT)
                return
            end
        end

        if not sameConnection(source, requesterIdentifier, connectionToken) then
            if acquired then releaseLocks(acquired) end
            finishQueue()
            return
        end

        local ok, data, errorCode = xpcall(function()
            return CENServer.Router.Handle(
                source, action, request.payload, requesterIdentifier)
        end, debug.traceback)

        if acquired then releaseLocks(acquired) end
        finishQueue()

        if not ok then
            print(('[pixel_enterprises] request %s failed: %s'):format(action, tostring(data)))
            CENServer.Audit('request_failed', source, {
                action = action,
                error = tostring(data):sub(1, 2000)
            }, requesterIdentifier)
            reply(source, requesterIdentifier, connectionToken, request.requestId, false, nil, CEN.Errors.INTERNAL_ERROR)
            return
        end

        if data == nil then
            local deniedError = errorCode or CEN.Errors.INTERNAL_ERROR
            auditDenied(source, connectionKey, requesterIdentifier, action, deniedError)
            reply(source, requesterIdentifier, connectionToken, request.requestId, false, nil, deniedError)
            return
        end

        reply(source, requesterIdentifier, connectionToken, request.requestId, true, data)
    end)
end)


AddEventHandler('pixel_enterprises:server:executeCommandAction', function(commandSource, action, payload, callback)
    if type(callback) ~= 'function' then return end
    local requesterIdentifier = CENServer.Identity.GetIdentifier(commandSource)
    if not requesterIdentifier or not isValidAction(action) or type(payload or {}) ~= 'table' then
        callback(nil, CEN.Errors.BAD_REQUEST)
        return
    end
    local commandConnection = getConnectionState(commandSource, requesterIdentifier)
    local commandToken = commandConnection.token
    local commandKey = commandToken
    if not CENServer.Repository.IsReady() then
        callback(nil, CEN.Errors.DATABASE_UNAVAILABLE)
        return
    end
    if not allowRequestWindow(commandKey) or isCoolingDown(commandKey, CENServer.Router.IsMutation(action)) then
        callback(nil, CEN.Errors.RATE_LIMITED)
        return
    end

    CreateThread(function()
        local mutation = CENServer.Router.IsMutation(action)
        local acquired
        if mutation then
            local keys, keyError = CENServer.Router.GetMutationKeys(
                commandSource, action, payload or {}, requesterIdentifier)
            if not keys then callback(nil, keyError or CEN.Errors.CONFLICT) return end
            acquired, keyError = acquireLocks(normalizeLockKeys(keys, requesterIdentifier), commandSource, requesterIdentifier, commandToken)
            if not acquired then callback(nil, keyError or CEN.Errors.CONFLICT) return end
        end

        if not sameConnection(commandSource, requesterIdentifier, commandToken) then
            if acquired then releaseLocks(acquired) end
            callback(nil, CEN.Errors.CONFLICT)
            return
        end

        local ok, data, errorCode = xpcall(function()
            return CENServer.Router.Handle(
                commandSource, action, payload or {}, requesterIdentifier)
        end, debug.traceback)
        if acquired then releaseLocks(acquired) end

        if not ok then
            CENServer.Audit('command_action_failed', commandSource, {
                action = action,
                error = tostring(data):sub(1, 2000)
            }, requesterIdentifier)
            callback(nil, CEN.Errors.INTERNAL_ERROR)
            return
        end
        if data == nil then auditDenied(commandSource, commandKey, requesterIdentifier, action, errorCode) end
        callback(data, errorCode)
    end)
end)

AddEventHandler('playerDropped', function()
    local source = source
    local state = connectionStates[source]
    connectionStates[source] = nil
    if not state then return end
    local key = state.token
    requestWindows[key] = nil
    requestCooldowns[('%s:read'):format(key)] = nil
    requestCooldowns[('%s:mutation'):format(key)] = nil
    tabletSessions[key] = nil
    local prefix = tostring(key) .. ':'
    for auditKey in pairs(denialAuditTimes) do
        if auditKey:sub(1, #prefix) == prefix then denialAuditTimes[auditKey] = nil end
    end
end)

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end
    mutationLocks = {}
    queuedMutations = {}
    denialAuditTimes = {}
    connectionStates = {}
    tabletSessions = {}
end)

CreateThread(function()
    Wait(1000)
    local ready, reason = CENServer.Repository.VerifySchema()
    if not ready then
        print(('[pixel_enterprises] SECURITY STOP: database schema verification failed: %s'):format(tostring(reason)))
        return
    end

    CENServer.FoundingRepository.ExpireOld()
    CENServer.MembershipInviteRepository.ExpireOld()
    CENServer.Retention.Start()

    while true do
        Wait(3600000)
        pcall(CENServer.FoundingRepository.ExpireOld)
        pcall(CENServer.MembershipInviteRepository.ExpireOld)
    end
end)
