CENServer = CENServer or {}

local function joinArgs(args, startAt)
    local values = {}
    for i = startAt, #args do values[#values + 1] = args[i] end
    return table.concat(values, ' ')
end

local function respond(source, ok, data, errorCode)
    if source == 0 then
        print(('[pixel_enterprises] %s'):format(ok and json.encode(data or {}) or ('error: ' .. tostring(errorCode))))
    else
        CENServer.NotifySource(source, ok and 'Enterprise command completed.' or ('Enterprise error: ' .. tostring(errorCode)), ok and 'success' or 'error')
    end
end

local function runPlayerAction(source, action, payload)
    TriggerEvent('pixel_enterprises:server:executeCommandAction', source, action, payload or {}, function(data, errorCode)
        respond(source, data ~= nil, data, errorCode)
    end)
end

RegisterCommand('cenfound', function(source, args)
    if source == 0 then return print('[pixel_enterprises] cenfound must be used by a player') end
    runPlayerAction(source, 'startFounding', {
        enterpriseType = args[1],
        name = joinArgs(args, 2)
    })
end, false)

RegisterCommand('cenfoundinvite', function(source, args)
    if source == 0 then return end
    runPlayerAction(source, 'inviteFoundingMember', { targetServerId = tonumber(args[1]) })
end, false)

RegisterCommand('cenfoundaccept', function(source, args)
    if source == 0 then return end
    runPlayerAction(source, 'acceptFoundingInvite', { proposalId = tonumber(args[1]) })
end, false)

RegisterCommand('cenfounddecline', function(source, args)
    if source == 0 then return end
    runPlayerAction(source, 'declineFoundingInvite', { proposalId = tonumber(args[1]) })
end, false)


RegisterCommand('cenjoinaccept', function(source, args)
    if source == 0 then return end
    runPlayerAction(source, 'acceptMembershipInvite', { inviteId = tonumber(args[1]) })
end, false)

RegisterCommand('cenjoindecline', function(source, args)
    if source == 0 then return end
    runPlayerAction(source, 'declineMembershipInvite', { inviteId = tonumber(args[1]) })
end, false)

RegisterCommand('cenleave', function(source)
    if source == 0 then return end
    runPlayerAction(source, 'leaveEnterprise', {})
end, false)

RegisterCommand('cendisband', function(source, args)
    if source == 0 then return end
    runPlayerAction(source, 'disbandEnterprise', { confirm = joinArgs(args, 1) })
end, false)

RegisterCommand('cenfoundapprove', function(source, args)
    if not CENServer.CreationPolicy.IsAdmin(source) then
        return respond(source, false, nil, CEN.Errors.CREATION_NOT_ALLOWED)
    end
    if not CENServer.Repository.IsReady() then
        return respond(source, false, nil, CEN.Errors.DATABASE_UNAVAILABLE)
    end

    local proposalId = tonumber(args[1])
    if not CEN.Validation.IsPositiveInteger(proposalId) then
        return respond(source, false, nil, CEN.Errors.PROPOSAL_NOT_FOUND)
    end
    local proposal, proposalError = CENServer.FoundingRepository.GetProposal(proposalId)
    if not proposal then return respond(source, false, nil, proposalError) end
    if proposal.status ~= 'awaiting_approval' then
        return respond(source, false, nil, CEN.Errors.PROPOSAL_NOT_READY)
    end

    local adminIdentifier = source == 0 and 'console' or CENServer.Identity.GetIdentifier(source)
    local result, lockError = CENServer.WithMutationLocks(source, {
        ('founding-proposal:%s'):format(proposalId)
    }, adminIdentifier, function()
        if source ~= 0 and CENServer.Identity.GetIdentifier(source) ~= adminIdentifier then
            return nil, CEN.Errors.CONFLICT
        end
        local current, currentError = CENServer.FoundingRepository.GetProposal(proposalId)
        if not current then return nil, currentError end
        if current.status ~= 'awaiting_approval' then return nil, CEN.Errors.PROPOSAL_NOT_READY end

        local finalizing, finalizingError = CENServer.FoundingRepository.MarkFinalizing(proposalId, 'awaiting_approval')
        if not finalizing then return nil, finalizingError end
        local enterpriseId, finalizeError, acceptedMembers = CENServer.FoundingRepository.FinalizeProposal(proposalId)
        if not enterpriseId then
            CENServer.FoundingRepository.ResetFinalizing(proposalId, 'awaiting_approval')
            return nil, finalizeError
        end
        return {
            enterpriseId = enterpriseId,
            enterpriseName = current.name,
            founderIdentifier = current.founderIdentifier,
            acceptedMembers = acceptedMembers or {}
        }
    end)

    if not result then return respond(source, false, nil, lockError) end
    CENServer.Audit('enterprise_founding_approved', source, {
        enterpriseId = result.enterpriseId,
        proposalId = proposalId
    }, adminIdentifier)
    CENServer.Progression.AddXp(result.enterpriseId, nil,
        Config.Progression.awards.foundingCompleted or 0,
        'enterprise_founded', { proposalId = proposalId, approved = true })
    CENServer.NotifyIdentifier(result.founderIdentifier,
        ('%s was approved and created.'):format(result.enterpriseName), 'success')
    for i = 1, #result.acceptedMembers do
        CENServer.NotifyIdentifier(result.acceptedMembers[i].identifier,
            ('%s was approved and created.'):format(result.enterpriseName), 'success')
    end
    respond(source, true, {
        enterpriseId = result.enterpriseId,
        name = result.enterpriseName,
        proposalId = proposalId
    })
end, false)

RegisterCommand('cenenterprisecreate', function(source, args)
    if not CENServer.CreationPolicy.IsAdmin(source) then
        return respond(source, false, nil, CEN.Errors.CREATION_NOT_ALLOWED)
    end
    if not CENServer.Repository.IsReady() then
        return respond(source, false, nil, CEN.Errors.DATABASE_UNAVAILABLE)
    end

    local enterpriseType = args[1]
    local ownerSource = tonumber(args[2])
    local name = joinArgs(args, 3)
    if not CEN.EnterpriseTypes[enterpriseType] or not ownerSource or not GetPlayerName(ownerSource) then
        return respond(source, false, nil, CEN.Errors.BAD_REQUEST)
    end
    if not CEN.Validation.ValidEnterpriseName(name) then
        return respond(source, false, nil, CEN.Errors.INVALID_ENTERPRISE_NAME)
    end

    local slug = CEN.Validation.Slugify(name)
    local ownerIdentifier = CENServer.Identity.GetIdentifier(ownerSource)
    local adminIdentifier = source == 0 and 'console' or CENServer.Identity.GetIdentifier(source)
    if not ownerIdentifier or not adminIdentifier then
        return respond(source, false, nil, CEN.Errors.LICENSE_MISSING)
    end

    local result, lockError = CENServer.WithMutationLocks(source, {
        ('identity:%s'):format(ownerIdentifier),
        ('founding-name:%s'):format(slug)
    }, adminIdentifier, function()
        if source ~= 0 and CENServer.Identity.GetIdentifier(source) ~= adminIdentifier then
            return nil, CEN.Errors.CONFLICT
        end
        if not GetPlayerName(ownerSource)
            or CENServer.Identity.GetIdentifier(ownerSource) ~= ownerIdentifier then
            return nil, CEN.Errors.TARGET_UNAVAILABLE
        end

        local existing, membershipError = CENServer.Repository.GetMembershipAnyStatus(ownerIdentifier)
        if existing and existing.status ~= 'removed' then
            return nil, CEN.Errors.TARGET_ALREADY_MEMBER
        end
        if not existing and membershipError ~= CEN.Errors.NOT_MEMBER then
            return nil, membershipError
        end

        local founderProposal, founderError = CENServer.FoundingRepository.GetActiveProposalByFounder(ownerIdentifier)
        if founderProposal then return nil, CEN.Errors.ALREADY_HAS_PROPOSAL end
        if founderError then return nil, founderError end
        local support, supportError = CENServer.FoundingRepository.GetActiveSupportByIdentifier(ownerIdentifier)
        if support then return nil, CEN.Errors.ALREADY_SUPPORTING_PROPOSAL end
        if supportError then return nil, supportError end

        local taken, takenError = CENServer.FoundingRepository.IsNameOrSlugTaken(name, slug)
        if taken == nil then return nil, takenError end
        if taken then return nil, CEN.Errors.ENTERPRISE_NAME_EXISTS end

        local enterpriseId, createError = CENServer.FoundingRepository.CreateEnterpriseDirect(
            name, slug, enterpriseType, 'admin', ownerIdentifier,
            CENServer.Identity.GetDisplayName(ownerSource))
        if not enterpriseId then return nil, createError end
        return { enterpriseId = enterpriseId, name = name }
    end)

    if not result then return respond(source, false, nil, lockError) end
    CENServer.Audit('enterprise_admin_created', source, {
        enterpriseId = result.enterpriseId,
        enterpriseType = enterpriseType,
        ownerSource = ownerSource
    }, source == 0 and 'console' or CENServer.Identity.GetIdentifier(source))
    if CENServer.Identity.GetIdentifier(ownerSource) == ownerIdentifier then
        TriggerClientEvent('pixel_enterprises:client:membershipChanged', ownerSource, {
            enterpriseName = name,
            joined = true
        })
    end
    respond(source, true, result)
end, false)

local function tebexAllowed(source)
    if source == 0 then return true end
    if Config.Tebex.consoleOnly then return false end
    return IsPlayerAceAllowed(source, Config.Tebex.adminAce)
end

RegisterCommand('cen_tebex_slots_grant', function(source, args)
    if not tebexAllowed(source) then return respond(source, false, nil, CEN.Errors.FORBIDDEN) end
    if not CENServer.Repository.IsReady() then
        return respond(source, false, nil, CEN.Errors.DATABASE_UNAVAILABLE)
    end
    local packageKey, enterpriseReference, grantKey, purchaserIdentifier = args[1], args[2], args[3], args[4]
    if not CEN.Validation.ValidGrantKey(grantKey) then
        return respond(source, false, nil, CEN.Errors.INVALID_GRANT_KEY)
    end

    local enterprise, resolveError = CENServer.EntitlementRepository.ResolveEnterprise(enterpriseReference)
    if not enterprise then return respond(source, false, nil, resolveError) end
    local requesterIdentifier = source == 0 and 'console' or CENServer.Identity.GetIdentifier(source)
    local result, lockError = CENServer.WithMutationLocks(source, {
        ('tebex-grant:%s'):format(grantKey),
        ('enterprise:%s'):format(enterprise.id)
    }, requesterIdentifier, function()
        local current, currentError = CENServer.EntitlementRepository.ResolveEnterprise(enterprise.id)
        if not current then return nil, currentError end
        local granted, grantError, slots = CENServer.EntitlementRepository.GrantSlots(
            current.id, packageKey, grantKey, purchaserIdentifier, { commandSource = source })
        if not granted then return nil, grantError end
        return { enterpriseId = current.id, extraSlots = slots, grantKey = grantKey }
    end)

    if not result then return respond(source, false, nil, lockError) end
    CENServer.Audit('tebex_member_slots_granted', source, {
        enterpriseId = result.enterpriseId,
        packageKey = packageKey,
        grantKey = grantKey,
        slots = result.extraSlots
    }, requesterIdentifier)
    respond(source, true, result)
end, false)

RegisterCommand('cen_tebex_slots_revoke', function(source, args)
    if not tebexAllowed(source) then return respond(source, false, nil, CEN.Errors.FORBIDDEN) end
    if not CENServer.Repository.IsReady() then
        return respond(source, false, nil, CEN.Errors.DATABASE_UNAVAILABLE)
    end
    local grantKey = args[1]
    if not CEN.Validation.ValidGrantKey(grantKey) then
        return respond(source, false, nil, CEN.Errors.INVALID_GRANT_KEY)
    end

    local existing, existingError = CENServer.EntitlementRepository.GetGrant(grantKey)
    if not existing then return respond(source, false, nil, existingError) end
    local requesterIdentifier = source == 0 and 'console' or CENServer.Identity.GetIdentifier(source)
    local result, revokeError = CENServer.WithMutationLocks(source, {
        ('tebex-grant:%s'):format(grantKey),
        ('enterprise:%s'):format(existing.enterpriseId)
    }, requesterIdentifier, function()
        local current, currentError = CENServer.EntitlementRepository.GetGrant(grantKey)
        if not current then return nil, currentError end
        if tonumber(current.enterpriseId) ~= tonumber(existing.enterpriseId) then
            return nil, CEN.Errors.CONFLICT
        end
        local revoked, errorCode, enterpriseId, alreadyRevoked = CENServer.EntitlementRepository.RevokeGrant(grantKey)
        if not revoked then return nil, errorCode end
        return {
            grantKey = grantKey,
            revoked = true,
            enterpriseId = enterpriseId,
            alreadyRevoked = alreadyRevoked == true
        }
    end)
    if not result then return respond(source, false, nil, revokeError) end
    CENServer.Audit('tebex_member_slots_revoked', source, {
        enterpriseId = result.enterpriseId,
        grantKey = grantKey,
        alreadyRevoked = result.alreadyRevoked
    }, requesterIdentifier)
    respond(source, true, result)
end, false)

local function coreAdminAllowed(source, ace)
    return source == 0 or IsPlayerAceAllowed(source, ace or Config.Admin.ace)
end

RegisterCommand('cenzonecreate', function(source, args)
    if not coreAdminAllowed(source, Config.Zones.adminAce) then return respond(source, false, nil, CEN.Errors.FORBIDDEN) end
    if source == 0 then return print('[pixel_enterprises] cenzonecreate must be used in-game') end
    local zoneType = args[1]
    if zoneType ~= 'turf' and zoneType ~= 'territory' then return respond(source, false, nil, CEN.Errors.BAD_REQUEST) end
    local radius = tonumber(args[2]) or Config.Zones.defaultRadius
    local requiredLevel = tonumber(args[3]) or (zoneType == 'turf' and Config.Zones.turfMinimumLevel or Config.Zones.territoryMinimumLevel)
    local name = joinArgs(args, 4)
    if #name < 3 or #name > 80 or radius < 5 or radius > 1000 then return respond(source, false, nil, CEN.Errors.BAD_REQUEST) end
    local ped = GetPlayerPed(source)
    if not ped or ped == 0 then return respond(source, false, nil, CEN.Errors.BAD_REQUEST) end
    local coords = GetEntityCoords(ped)
    local adminIdentifier = CENServer.Identity.GetIdentifier(source)
    local zoneId, errorCode = CENServer.WithMutationLocks(source, { ('zone-name:%s'):format(name:lower()) }, adminIdentifier, function()
        return CENServer.ZoneRepository.Create(zoneType, name, coords, radius, requiredLevel,
            Config.Zones.defaultContestSeconds, Config.Zones.defaultCooldownSeconds, {})
    end)
    if not zoneId then return respond(source, false, nil, errorCode) end
    CENServer.Audit('zone_created', source, { zoneId = zoneId, zoneType = zoneType, name = name }, adminIdentifier)
    respond(source, true, { zoneId = zoneId, name = name })
end, false)

RegisterCommand('cenzonedelete', function(source, args)
    if not coreAdminAllowed(source, Config.Zones.adminAce) then return respond(source, false, nil, CEN.Errors.FORBIDDEN) end
    local zoneId = tonumber(args[1])
    if not CEN.Validation.IsPositiveInteger(zoneId) then return respond(source, false, nil, CEN.Errors.ZONE_NOT_FOUND) end
    local adminIdentifier = source == 0 and 'console' or CENServer.Identity.GetIdentifier(source)
    local deleted, errorCode = CENServer.WithMutationLocks(source, { ('zone:%s'):format(zoneId) }, adminIdentifier, function()
        return CENServer.ZoneRepository.Delete(zoneId)
    end)
    if not deleted then return respond(source, false, nil, errorCode) end
    CENServer.Audit('zone_deleted', source, { zoneId = zoneId }, adminIdentifier)
    respond(source, true, { zoneId = zoneId })
end, false)

RegisterCommand('cenzoneowner', function(source, args)
    if not coreAdminAllowed(source, Config.Zones.adminAce) then return respond(source, false, nil, CEN.Errors.FORBIDDEN) end
    local zoneId, enterpriseId = tonumber(args[1]), tonumber(args[2])
    if not CEN.Validation.IsPositiveInteger(zoneId) then return respond(source, false, nil, CEN.Errors.ZONE_NOT_FOUND) end
    if enterpriseId == 0 then enterpriseId = nil elseif not CEN.Validation.IsPositiveInteger(enterpriseId) then return respond(source, false, nil, CEN.Errors.INVALID_ENTERPRISE) end
    local adminIdentifier = source == 0 and 'console' or CENServer.Identity.GetIdentifier(source)
    local updated, errorCode = CENServer.WithMutationLocks(source, { ('zone:%s'):format(zoneId) }, adminIdentifier, function()
        if enterpriseId then
            local enterprise, resolveError = CENServer.Repository.GetEnterprise(enterpriseId)
            if not enterprise then return nil, resolveError end
        end
        return CENServer.ZoneRepository.SetOwner(zoneId, enterpriseId)
    end)
    if not updated then return respond(source, false, nil, errorCode) end
    CENServer.Audit('zone_owner_changed', source, { zoneId = zoneId, enterpriseId = enterpriseId }, adminIdentifier)
    respond(source, true, { zoneId = zoneId, enterpriseId = enterpriseId })
end, false)

RegisterCommand('cenxp', function(source, args)
    if not coreAdminAllowed(source) then return respond(source, false, nil, CEN.Errors.FORBIDDEN) end
    local enterpriseId, amount = tonumber(args[1]), tonumber(args[2])
    if not CEN.Validation.IsPositiveInteger(enterpriseId) or not CEN.Validation.IsPositiveInteger(amount) then return respond(source, false, nil, CEN.Errors.BAD_REQUEST) end
    local adminIdentifier = source == 0 and 'console' or CENServer.Identity.GetIdentifier(source)
    local result, errorCode = CENServer.WithMutationLocks(source, { ('enterprise:%s'):format(enterpriseId) }, adminIdentifier, function()
        local ok, addError = CENServer.Progression.AddXp(enterpriseId, nil, amount, joinArgs(args, 3) ~= '' and joinArgs(args, 3) or 'admin_award', { admin = true })
        if not ok then return nil, addError end
        return CENServer.Progression.Summary(enterpriseId)
    end)
    if not result then return respond(source, false, nil, errorCode) end
    respond(source, true, result)
end, false)

RegisterCommand('cenrestore', function(source, args)
    if not coreAdminAllowed(source) then return respond(source, false, nil, CEN.Errors.FORBIDDEN) end
    local enterpriseId = tonumber(args[1])
    if not CEN.Validation.IsPositiveInteger(enterpriseId) then return respond(source, false, nil, CEN.Errors.INVALID_ENTERPRISE) end
    local adminIdentifier = source == 0 and 'console' or CENServer.Identity.GetIdentifier(source)
    local restored, errorCode = CENServer.WithMutationLocks(source, { ('enterprise:%s'):format(enterpriseId) }, adminIdentifier, function()
        return CENServer.Repository.RestoreEnterprise(enterpriseId)
    end)
    if not restored then return respond(source, false, nil, errorCode) end
    CENServer.Audit('enterprise_restored', source, { enterpriseId = enterpriseId }, adminIdentifier)
    respond(source, true, { enterpriseId = enterpriseId, restored = true })
end, false)

RegisterCommand('cenfacilitycreate', function(source, args)
    if not coreAdminAllowed(source) then return respond(source, false, nil, CEN.Errors.FORBIDDEN) end
    if source == 0 then return print('[pixel_enterprises] cenfacilitycreate must be used in-game') end
    local enterpriseId = tonumber(args[1])
    local facilityType = tostring(args[2] or '')
    local subtype = tostring(args[3] or '')
    local radius = tonumber(args[4]) or Config.Operations.facilityUseDistance
    local name = joinArgs(args, 5)
    if not CEN.Validation.IsPositiveInteger(enterpriseId)
        or (facilityType ~= 'lab' and facilityType ~= 'warehouse' and facilityType ~= 'front')
        or not subtype:match('^[%w_%-]+$') or #name < 3 or #name > 80 or radius < 2 or radius > 100 then
        return respond(source, false, nil, CEN.Errors.BAD_REQUEST)
    end
    local enterprise, enterpriseError = CENServer.Repository.GetEnterprise(enterpriseId)
    if not enterprise then return respond(source, false, nil, enterpriseError) end
    local ped = GetPlayerPed(source); if ped <= 0 then return respond(source, false, nil, CEN.Errors.BAD_REQUEST) end
    local coords = GetEntityCoords(ped)
    local adminIdentifier = CENServer.Identity.GetIdentifier(source)
    local facilityId, errorCode = CENServer.WithMutationLocks(source, {
        ('enterprise:%s'):format(enterpriseId), ('facility-name:%s:%s'):format(enterpriseId, name:lower())
    }, adminIdentifier, function()
        return CENServer.FacilityRepository.Create(enterpriseId, facilityType, subtype, name, coords, radius)
    end)
    if not facilityId then return respond(source, false, nil, errorCode) end
    CENServer.Audit('facility_created', source, {
        enterpriseId = enterpriseId, facilityId = facilityId, facilityType = facilityType, subtype = subtype, name = name
    }, adminIdentifier)
    respond(source, true, { facilityId = facilityId, enterpriseId = enterpriseId, name = name })
end, false)

RegisterCommand('cenfacilitydelete', function(source, args)
    if not coreAdminAllowed(source) then return respond(source, false, nil, CEN.Errors.FORBIDDEN) end
    local facilityId = tonumber(args[1])
    if not CEN.Validation.IsPositiveInteger(facilityId) then return respond(source, false, nil, CEN.Errors.FACILITY_NOT_FOUND) end
    local adminIdentifier = source == 0 and 'console' or CENServer.Identity.GetIdentifier(source)
    local deleted, errorCode = CENServer.WithMutationLocks(source, { ('facility:%s'):format(facilityId) }, adminIdentifier, function()
        if CENServer.FacilityRepository.Delete(facilityId) then return true end
        return nil, CEN.Errors.FACILITY_NOT_FOUND
    end)
    if not deleted then return respond(source, false, nil, errorCode) end
    CENServer.Audit('facility_disabled', source, { facilityId = facilityId }, adminIdentifier)
    respond(source, true, { facilityId = facilityId, disabled = true })
end, false)

RegisterCommand('cenheat', function(source, args)
    if not coreAdminAllowed(source) then return respond(source, false, nil, CEN.Errors.FORBIDDEN) end
    local enterpriseId, amount = tonumber(args[1]), tonumber(args[2])
    if not CEN.Validation.IsPositiveInteger(enterpriseId) or not CEN.Validation.IsInteger(amount) then
        return respond(source, false, nil, CEN.Errors.BAD_REQUEST)
    end
    local adminIdentifier = source == 0 and 'console' or CENServer.Identity.GetIdentifier(source)
    local changed, errorCode = CENServer.WithMutationLocks(source, { ('enterprise:%s'):format(enterpriseId) }, adminIdentifier, function()
        return CENServer.Heat.Add(enterpriseId, amount, 'admin_adjustment')
    end)
    if not changed then return respond(source, false, nil, errorCode) end
    respond(source, true, { enterpriseId = enterpriseId, amount = amount })
end, false)

RegisterCommand('centreasury', function(source, args)
    if not coreAdminAllowed(source) then return respond(source, false, nil, CEN.Errors.FORBIDDEN) end
    local enterpriseId, amount = tonumber(args[1]), tonumber(args[2])
    if not CEN.Validation.IsPositiveInteger(enterpriseId) or not CEN.Validation.IsInteger(amount) or amount == 0 then
        return respond(source, false, nil, CEN.Errors.BAD_REQUEST)
    end
    local adminIdentifier = source == 0 and 'console' or CENServer.Identity.GetIdentifier(source)
    local result, errorCode = CENServer.WithMutationLocks(source, { ('enterprise:%s'):format(enterpriseId) }, adminIdentifier, function()
        local enterprise, enterpriseError = CENServer.Repository.GetEnterprise(enterpriseId)
        if not enterprise then return nil, enterpriseError end
        local current = tonumber(enterprise.treasuryBalance) or 0
        local updated = current + amount
        if updated < 0 or updated > Config.Economy.maximumTreasuryBalance then return nil, CEN.Errors.TREASURY_LIMIT end
        local affected = MySQL.update.await([[UPDATE cen_enterprises SET treasury_balance = ? WHERE id = ? AND status = 'active']], { updated, enterpriseId })
        if tonumber(affected) ~= 1 then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
        MySQL.insert.await([[INSERT INTO cen_treasury_transactions
          (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
          VALUES (?, NULL, 'admin_adjustment', ?, ?, ?)]], {
            enterpriseId, math.abs(amount), updated, ('Admin adjustment: %+d'):format(amount)
        })
        return { enterpriseId = enterpriseId, balance = updated, adjustment = amount }
    end)
    if not result then return respond(source, false, nil, errorCode) end
    CENServer.Audit('treasury_admin_adjusted', source, result, adminIdentifier)
    respond(source, true, result)
end, false)

RegisterCommand('cencorruptaccept', function(source, args)
    if source == 0 then return end
    runPlayerAction(source, 'acceptCorruptionOffer', { offerId = tonumber(args[1]) })
end, false)

RegisterCommand('cencorruptdecline', function(source, args)
    if source == 0 then return end
    runPlayerAction(source, 'declineCorruptionOffer', { offerId = tonumber(args[1]) })
end, false)
