CENServer = CENServer or {}
CENServer.TreasuryRepository = CENServer.TreasuryRepository or {}
local Repository = CENServer.TreasuryRepository

local function findResultRow(value)
    if type(value) ~= 'table' then return nil end
    if value.ok ~= nil or value.errorCode ~= nil or value.balance ~= nil then return value end
    for i = 1, #value do
        local found = findResultRow(value[i])
        if found then return found end
    end
    return nil
end

local function call(name, values)
    local placeholders = {}
    for i = 1, #values do placeholders[i] = '?' end
    local ok, result = pcall(function()
        return MySQL.query.await(('CALL %s(%s)'):format(name, table.concat(placeholders, ',')), values)
    end)
    if not ok or result == nil then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local row = findResultRow(result)
    if not row then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    if tonumber(row.ok) ~= 1 then return nil, row.errorCode or CEN.Errors.CONFLICT end
    return row
end

function Repository.GetSummary(enterpriseId, pageSize)
    local ok, result = pcall(function()
        local balance = MySQL.scalar.await('SELECT treasury_balance FROM cen_enterprises WHERE id = ? AND status = \'active\'', { enterpriseId })
        if balance == nil then return nil end
        local rows = MySQL.query.await([[SELECT id, transaction_type AS transactionType, amount,
            balance_after AS balanceAfter, note, created_at AS createdAt,
            COALESCE(m.display_name, 'System') AS actorDisplayName
          FROM cen_treasury_transactions t
          LEFT JOIN cen_members m ON m.id = t.actor_member_id
          WHERE t.enterprise_id = ? ORDER BY t.id DESC LIMIT ?]], {
            enterpriseId, math.max(1, math.min(100, tonumber(pageSize) or 25))
        })
        local withdrawnToday = MySQL.scalar.await([[SELECT COALESCE(SUM(amount), 0)
          FROM cen_treasury_transactions
          WHERE enterprise_id = ? AND transaction_type = 'withdrawal'
            AND created_at >= UTC_DATE()]], { enterpriseId })
        return { balance = tonumber(balance) or 0, transactions = rows or {}, withdrawnToday = tonumber(withdrawnToday) or 0 }
    end)
    if not ok or not result then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    return result
end

function Repository.Deposit(enterpriseId, memberId, amount, note, maximumBalance)
    return call('cen_treasury_deposit', { enterpriseId, memberId, amount, note, maximumBalance })
end

function Repository.Withdraw(enterpriseId, memberId, amount, note, dailyLimit)
    return call('cen_treasury_withdraw', { enterpriseId, memberId, amount, note, dailyLimit })
end

function Repository.Reverse(enterpriseId, memberId, amount, transactionType, note)
    local ok, success = pcall(function()
        return MySQL.transaction.await({
            { query = [[UPDATE cen_enterprises SET treasury_balance = treasury_balance + ?
                WHERE id = ? AND status = 'active']], values = { amount, enterpriseId } },
            { query = [[INSERT INTO cen_treasury_transactions
                (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
                SELECT ?, ?, ?, ABS(?), treasury_balance, ? FROM cen_enterprises WHERE id = ?]],
              values = { enterpriseId, memberId, transactionType, amount, note, enterpriseId } }
        })
    end)
    return ok and success == true
end
