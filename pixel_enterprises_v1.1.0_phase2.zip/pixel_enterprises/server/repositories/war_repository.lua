CENServer = CENServer or {}
CENServer.WarRepository = CENServer.WarRepository or {}
local Repository = CENServer.WarRepository

local function findResultRow(value)
    if type(value) ~= 'table' then return nil end
    if value.ok ~= nil or value.errorCode ~= nil or value.warId ~= nil then return value end
    for i = 1, #value do
        local found = findResultRow(value[i])
        if found then return found end
    end
    return nil
end

local function call(name, values)
    local placeholders = {}
    for i = 1, #values do placeholders[i] = '?' end
    local ok, result = pcall(function()
        return MySQL.query.await(('CALL %s(%s)'):format(name, table.concat(placeholders, ',')), values)
    end)
    if not ok or result == nil then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local row = findResultRow(result)
    if not row or tonumber(row.ok) ~= 1 then return nil, row and row.errorCode or CEN.Errors.CONFLICT end
    for _, key in ipairs({ 'warId', 'attackerScore', 'defenderScore', 'winnerEnterpriseId' }) do
        if row[key] ~= nil then row[key] = tonumber(row[key]) end
    end
    return row
end

function Repository.List(enterpriseId)
    local ok, rows = pcall(function()
        return MySQL.query.await([[SELECT w.id AS warId, w.attacker_enterprise_id AS attackerEnterpriseId,
          attacker.name AS attackerName, w.defender_enterprise_id AS defenderEnterpriseId,
          defender.name AS defenderName, w.status, w.reason, w.target_score AS targetScore,
          w.attacker_score AS attackerScore, w.defender_score AS defenderScore,
          w.attacker_stake AS attackerStake, w.defender_stake AS defenderStake,
          w.winner_enterprise_id AS winnerEnterpriseId, winner.name AS winnerName,
          w.proposal_expires_at AS proposalExpiresAt, w.starts_at AS startsAt,
          w.ends_at AS endsAt, w.completed_at AS completedAt, w.created_at AS createdAt
        FROM cen_wars w
        JOIN cen_enterprises attacker ON attacker.id = w.attacker_enterprise_id
        JOIN cen_enterprises defender ON defender.id = w.defender_enterprise_id
        LEFT JOIN cen_enterprises winner ON winner.id = w.winner_enterprise_id
        WHERE w.attacker_enterprise_id = ? OR w.defender_enterprise_id = ?
        ORDER BY FIELD(w.status, 'active','proposed','completed','declined','cancelled','expired'), w.id DESC
        LIMIT 100]], { enterpriseId, enterpriseId })
    end)
    if not ok or rows == nil then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    for i = 1, #rows do
        for _, key in ipairs({ 'warId', 'attackerEnterpriseId', 'defenderEnterpriseId', 'targetScore', 'attackerScore', 'defenderScore', 'attackerStake', 'defenderStake', 'winnerEnterpriseId' }) do
            if rows[i][key] ~= nil then rows[i][key] = tonumber(rows[i][key]) end
        end
    end
    return rows
end

function Repository.Get(warId)
    local ok, row = pcall(function()
        return MySQL.single.await([[SELECT id AS warId, attacker_enterprise_id AS attackerEnterpriseId,
          defender_enterprise_id AS defenderEnterpriseId, status, target_score AS targetScore,
          attacker_score AS attackerScore, defender_score AS defenderScore,
          attacker_stake AS attackerStake, defender_stake AS defenderStake, ends_at AS endsAt
        FROM cen_wars WHERE id = ? LIMIT 1]], { warId })
    end)
    if not ok then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    if not row then return nil, CEN.Errors.WAR_NOT_FOUND end
    for _, key in ipairs({ 'warId', 'attackerEnterpriseId', 'defenderEnterpriseId', 'targetScore', 'attackerScore', 'defenderScore', 'attackerStake', 'defenderStake' }) do
        if row[key] ~= nil then row[key] = tonumber(row[key]) end
    end
    return row
end

function Repository.Propose(attackerId, defenderId, memberId, reason, targetScore, stake, duration, expiryHours)
    return call('cen_propose_war', { attackerId, defenderId, memberId, reason, targetScore, stake, duration, expiryHours })
end

function Repository.Respond(warId, defenderId, memberId, accepted, duration)
    return call('cen_respond_war', { warId, defenderId, memberId, accepted and 1 or 0, duration })
end

function Repository.Cancel(warId, attackerId)
    return call('cen_cancel_war', { warId, attackerId })
end

function Repository.Finalize(warId, postCeasefireHours)
    return call('cen_finalize_war', { warId, postCeasefireHours or 0 })
end

function Repository.FindActiveBetween(a, b)
    local ok, row = pcall(function()
        return MySQL.single.await([[SELECT id AS warId, attacker_enterprise_id AS attackerEnterpriseId,
          defender_enterprise_id AS defenderEnterpriseId, target_score AS targetScore,
          attacker_score AS attackerScore, defender_score AS defenderScore, ends_at AS endsAt
        FROM cen_wars WHERE status = 'active'
          AND ((attacker_enterprise_id = ? AND defender_enterprise_id = ?)
            OR (attacker_enterprise_id = ? AND defender_enterprise_id = ?))
        LIMIT 1]], { a, b, b, a })
    end)
    if not ok or not row then return nil end
    for _, key in ipairs({ 'warId', 'attackerEnterpriseId', 'defenderEnterpriseId', 'targetScore', 'attackerScore', 'defenderScore' }) do
        row[key] = tonumber(row[key])
    end
    return row
end

function Repository.AddScore(warId, scoringEnterpriseId, eventType, points, metadata)
    return call('cen_add_war_score', {
        warId, scoringEnterpriseId, eventType, points, json.encode(metadata or {})
    })
end

function Repository.ListDue()
    local ok, rows = pcall(function()
        return MySQL.query.await([[SELECT id AS warId, attacker_enterprise_id AS attackerEnterpriseId,
          defender_enterprise_id AS defenderEnterpriseId, attacker_score AS attackerScore,
          defender_score AS defenderScore, target_score AS targetScore
        FROM cen_wars WHERE status = 'active'
          AND (ends_at <= UTC_TIMESTAMP() OR attacker_score >= target_score OR defender_score >= target_score)]])
    end)
    if not ok or rows == nil then return nil end
    for i = 1, #rows do
        for _, key in ipairs({ 'warId', 'attackerEnterpriseId', 'defenderEnterpriseId', 'attackerScore', 'defenderScore', 'targetScore' }) do
            rows[i][key] = tonumber(rows[i][key])
        end
    end
    return rows
end

function Repository.ExpireProposals()
    local ok, rows = pcall(function()
        return MySQL.query.await([[SELECT id AS warId, attacker_enterprise_id AS attackerEnterpriseId
          FROM cen_wars WHERE status = 'proposed' AND proposal_expires_at <= UTC_TIMESTAMP()]])
    end)
    if not ok or rows == nil then return nil end
    return rows
end
