CENServer = CENServer or {}
CENServer.ProgressionRepository = CENServer.ProgressionRepository or {}
local Repository = CENServer.ProgressionRepository

function Repository.Get(enterpriseId, limit)
    local ok, result = pcall(function()
        local enterprise = MySQL.single.await([[SELECT id AS enterpriseId, level, xp
          FROM cen_enterprises WHERE id = ? AND status = 'active']], { enterpriseId })
        if not enterprise then return nil end
        enterprise.events = MySQL.query.await([[SELECT id, amount, reason, created_at AS createdAt,
            COALESCE(m.display_name, 'System') AS actorDisplayName
          FROM cen_xp_events x LEFT JOIN cen_members m ON m.id = x.actor_member_id
          WHERE x.enterprise_id = ? ORDER BY x.id DESC LIMIT ?]], {
            enterpriseId, math.max(1, math.min(100, tonumber(limit) or 25))
        }) or {}
        return enterprise
    end)
    if not ok or not result then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    return result
end

function Repository.Add(enterpriseId, memberId, amount, reason, metadata)
    local ok, result = pcall(function()
        local changed = MySQL.update.await([[UPDATE cen_enterprises SET xp = xp + ?
          WHERE id = ? AND status = 'active']], { amount, enterpriseId })
        if tonumber(changed) ~= 1 then return nil end
        local row = MySQL.single.await('SELECT level, xp FROM cen_enterprises WHERE id = ?', { enterpriseId })
        if not row then return nil end
        MySQL.insert.await([[INSERT INTO cen_xp_events
          (enterprise_id, actor_member_id, amount, reason, metadata)
          VALUES (?, ?, ?, ?, ?)]], {
            enterpriseId, memberId, amount, tostring(reason):sub(1, 80), json.encode(metadata or {})
        })
        return row
    end)
    if not ok or not result then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    return result
end

function Repository.SetLevel(enterpriseId, level)
    local ok, affected = pcall(function()
        return MySQL.update.await('UPDATE cen_enterprises SET level = ? WHERE id = ? AND status = \'active\'', { level, enterpriseId })
    end)
    return ok and tonumber(affected) == 1
end
