CENServer = CENServer or {}
CENServer.ActivityRepository = CENServer.ActivityRepository or {}

local Repository = CENServer.ActivityRepository

local function databaseReady()
    return GetResourceState('oxmysql') == 'started'
end

local function safeScalar(query, values)
    local ok, result = pcall(function() return MySQL.scalar.await(query, values or {}) end)
    if not ok or result == nil then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    return result
end

function Repository.RecordHeartbeat(enterpriseId, memberId, cycleStart, minutes)
    if not databaseReady() then return false end
    local credit = math.max(1, math.min(tonumber(minutes) or 1,
        math.max(1, tonumber(Config.Retention.activityHeartbeatMinutes) or 5) + 1))
    local ok = pcall(function()
        MySQL.insert.await([[INSERT INTO cen_member_activity
          (enterprise_id, member_id, activity_cycle, active_minutes, last_seen_at)
          VALUES (?, ?, ?, ?, UTC_TIMESTAMP())
          ON DUPLICATE KEY UPDATE active_minutes = active_minutes + VALUES(active_minutes),
            last_seen_at = UTC_TIMESTAMP()]], { enterpriseId, memberId, cycleStart, credit })
    end)
    return ok
end

function Repository.RecordHeartbeats(records, cycleStart, minutes)
    if not databaseReady() or type(records) ~= 'table' or #records == 0 then return false end
    local credit = math.max(1, math.min(tonumber(minutes) or 1,
        math.max(1, tonumber(Config.Retention.activityHeartbeatMinutes) or 5) + 1))
    local values, groups = {}, {}
    for i = 1, #records do
        groups[#groups + 1] = '(?, ?, ?, ?, UTC_TIMESTAMP())'
        values[#values + 1] = records[i].enterpriseId
        values[#values + 1] = records[i].memberId
        values[#values + 1] = cycleStart
        values[#values + 1] = credit
    end
    local query = [[INSERT INTO cen_member_activity
      (enterprise_id, member_id, activity_cycle, active_minutes, last_seen_at) VALUES ]]
      .. table.concat(groups, ',') .. [[ ON DUPLICATE KEY UPDATE
      active_minutes = active_minutes + VALUES(active_minutes), last_seen_at = UTC_TIMESTAMP()]]
    local ok = pcall(function() MySQL.insert.await(query, values) end)
    return ok
end

function Repository.QualifiedCount(enterpriseId, cycleStart)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local count, errorCode = safeScalar([[SELECT COUNT(*) FROM cen_member_activity a
      WHERE a.enterprise_id = ? AND a.activity_cycle = ?
        AND a.active_minutes >= ?]], {
            enterpriseId, cycleStart, Config.Retention.minimumMinutesPerMember
        })
    if count == nil then return nil, errorCode end
    return tonumber(count)
end

function Repository.GetRetentionEnterprise(enterpriseId)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local ok, row = pcall(function()
        return MySQL.single.await([[SELECT e.id AS enterpriseId, e.name,
            e.owner_member_id AS ownerMemberId, e.retention_status AS retentionStatus,
            DATE_FORMAT(e.retention_warning_cycle, '%Y-%m-%d') AS retentionWarningCycle,
            DATE_FORMAT(e.retention_failure_cycle, '%Y-%m-%d') AS retentionFailureCycle,
            DATE_FORMAT(e.disband_scheduled_at, '%Y-%m-%d %H:%i:%s') AS disbandScheduledAt,
            DATE_FORMAT(e.created_at, '%Y-%m-%d %H:%i:%s') AS createdAt,
            m.player_identifier AS ownerIdentifier
          FROM cen_enterprises e
          LEFT JOIN cen_members m ON m.id = e.owner_member_id AND m.enterprise_id = e.id
          WHERE e.id = ? AND e.status = 'active' AND e.retention_required = 1
          LIMIT 1]], { enterpriseId })
    end)
    if not ok then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    if not row then return nil, CEN.Errors.INVALID_ENTERPRISE end
    return row
end

function Repository.ListRetentionEnterprises()
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local ok, rows = pcall(function()
        return MySQL.query.await([[SELECT e.id AS enterpriseId, e.name,
            e.owner_member_id AS ownerMemberId, e.retention_status AS retentionStatus,
            DATE_FORMAT(e.retention_warning_cycle, '%Y-%m-%d') AS retentionWarningCycle,
            DATE_FORMAT(e.retention_failure_cycle, '%Y-%m-%d') AS retentionFailureCycle,
            DATE_FORMAT(e.disband_scheduled_at, '%Y-%m-%d %H:%i:%s') AS disbandScheduledAt,
            DATE_FORMAT(e.created_at, '%Y-%m-%d %H:%i:%s') AS createdAt,
            m.player_identifier AS ownerIdentifier
          FROM cen_enterprises e
          LEFT JOIN cen_members m ON m.id = e.owner_member_id AND m.enterprise_id = e.id
          WHERE e.status = 'active' AND e.retention_required = 1]])
    end)
    if not ok or rows == nil then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    return rows
end

function Repository.MarkWarning(enterpriseId, cycleStart)
    local ok, affected = pcall(function()
        return MySQL.update.await([[UPDATE cen_enterprises
          SET retention_status = 'warning', retention_warning_cycle = ?, updated_at = UTC_TIMESTAMP()
          WHERE id = ? AND status = 'active' AND retention_required = 1]], { cycleStart, enterpriseId })
    end)
    return ok and affected == 1
end

function Repository.MarkHealthy(enterpriseId, evaluatedCycle)
    local ok, affected = pcall(function()
        return MySQL.update.await([[UPDATE cen_enterprises
          SET retention_status = 'healthy', retention_failure_cycle = ?,
            disband_scheduled_at = NULL, updated_at = UTC_TIMESTAMP()
          WHERE id = ? AND status = 'active']], { evaluatedCycle, enterpriseId })
    end)
    return ok and affected == 1
end

function Repository.ScheduleDisband(enterpriseId, failedCycle)
    local ok, affected = pcall(function()
        return MySQL.update.await([[UPDATE cen_enterprises
          SET retention_status = 'pending_disband', retention_failure_cycle = ?,
            disband_scheduled_at = DATE_ADD(UTC_TIMESTAMP(), INTERVAL ? DAY),
            updated_at = UTC_TIMESTAMP()
          WHERE id = ? AND status = 'active']], {
            failedCycle, Config.Retention.deletionGraceDays, enterpriseId
        })
    end)
    return ok and affected == 1
end

function Repository.CancelDisband(enterpriseId)
    local ok, affected = pcall(function()
        return MySQL.update.await([[UPDATE cen_enterprises
          SET retention_status = 'healthy', disband_scheduled_at = NULL,
            updated_at = UTC_TIMESTAMP() WHERE id = ? AND status = 'active']], { enterpriseId })
    end)
    return ok and affected == 1
end

function Repository.DisbandDue(enterpriseId)
    -- Retention uses the same atomic soft-disband procedure as owner actions.
    -- Proposed or active wars block disbanding until their escrow is resolved.
    return CENServer.Repository.RetentionDisband(enterpriseId)
end

function Repository.GetRetentionSummary(enterpriseId, currentCycle)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local ok, row = pcall(function()
        return MySQL.single.await([[SELECT retention_required AS retentionRequired,
            retention_status AS retentionStatus, retention_warning_cycle AS warningCycle,
            retention_failure_cycle AS failureCycle, disband_scheduled_at AS disbandScheduledAt,
            creation_plan AS creationPlan
          FROM cen_enterprises WHERE id = ? LIMIT 1]], { enterpriseId })
    end)
    if not ok then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    if not row then return nil, CEN.Errors.INVALID_ENTERPRISE end
    row.retentionRequired = row.retentionRequired == true or row.retentionRequired == 1
    row.minimumActiveMembers = Config.Retention.minimumActiveMembers
    row.minimumMinutesPerMember = Config.Retention.minimumMinutesPerMember
    row.currentCycle = currentCycle
    local qualified, errorCode = Repository.QualifiedCount(enterpriseId, currentCycle)
    if qualified == nil then return nil, errorCode end
    row.qualifiedActiveMembers = qualified
    row.warningDay = Config.Retention.warningDay
    return row
end
