CENServer = CENServer or {}
CENServer.ZoneRepository = CENServer.ZoneRepository or {}
local Repository = CENServer.ZoneRepository

local function decode(value)
    if type(value) == 'table' then return value end
    if type(value) ~= 'string' then return {} end
    local ok, result = pcall(json.decode, value)
    return ok and type(result) == 'table' and result or {}
end

local function normalizeZone(row)
    if not row then return nil end
    row.metadata = decode(row.metadata)
    row.center = { x = tonumber(row.centerX), y = tonumber(row.centerY), z = tonumber(row.centerZ) }
    row.radius = tonumber(row.radius) or 0
    row.requiredLevel = tonumber(row.requiredLevel) or 1
    row.ownerEnterpriseId = tonumber(row.ownerEnterpriseId)
    row.activeContestId = tonumber(row.activeContestId)
    row.attackerEnterpriseId = tonumber(row.attackerEnterpriseId)
    row.defenderEnterpriseId = tonumber(row.defenderEnterpriseId)
    row.attackerScore = tonumber(row.attackerScore) or 0
    row.defenderScore = tonumber(row.defenderScore) or 0
    return row
end

function Repository.List()
    local ok, rows = pcall(function()
        return MySQL.query.await([[SELECT z.id AS zoneId, z.zone_type AS zoneType, z.name,
          z.center_x AS centerX, z.center_y AS centerY, z.center_z AS centerZ, z.radius,
          z.owner_enterprise_id AS ownerEnterpriseId, owner.name AS ownerName,
          z.required_level AS requiredLevel, z.cooldown_until AS cooldownUntil,
          z.metadata, z.status,
          c.id AS activeContestId, c.attacker_enterprise_id AS attackerEnterpriseId,
          c.defender_enterprise_id AS defenderEnterpriseId, c.attacker_score AS attackerScore,
          c.defender_score AS defenderScore, c.ends_at AS contestEndsAt
        FROM cen_zones z
        LEFT JOIN cen_enterprises owner ON owner.id = z.owner_enterprise_id
        LEFT JOIN cen_zone_contests c ON c.zone_id = z.id AND c.status = 'active'
        WHERE z.status = 'active' ORDER BY z.zone_type, z.name]])
    end)
    if not ok or rows == nil then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    for i = 1, #rows do rows[i] = normalizeZone(rows[i]) end
    return rows
end

function Repository.Get(zoneId, lock)
    local suffix = lock and ' FOR UPDATE' or ''
    local ok, row = pcall(function()
        return MySQL.single.await([[SELECT z.id AS zoneId, z.zone_type AS zoneType, z.name,
          z.center_x AS centerX, z.center_y AS centerY, z.center_z AS centerZ, z.radius,
          z.owner_enterprise_id AS ownerEnterpriseId, owner.name AS ownerName,
          z.required_level AS requiredLevel, z.cooldown_until AS cooldownUntil,
          z.capture_duration_seconds AS captureDurationSeconds,
          z.cooldown_seconds AS cooldownSeconds, z.metadata, z.status
        FROM cen_zones z LEFT JOIN cen_enterprises owner ON owner.id = z.owner_enterprise_id
        WHERE z.id = ? LIMIT 1]] .. suffix, { zoneId })
    end)
    if not ok then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    if not row then return nil, CEN.Errors.ZONE_NOT_FOUND end
    return normalizeZone(row)
end

function Repository.Create(zoneType, name, coords, radius, requiredLevel, contestSeconds, cooldownSeconds, metadata)
    local ok, id = pcall(function()
        return MySQL.insert.await([[INSERT INTO cen_zones
          (zone_type, name, center_x, center_y, center_z, radius, required_level,
           capture_duration_seconds, cooldown_seconds, metadata)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)]], {
            zoneType, name, coords.x, coords.y, coords.z, radius, requiredLevel,
            contestSeconds, cooldownSeconds, json.encode(metadata or {})
        })
    end)
    if not ok or not id then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    return id
end

function Repository.Delete(zoneId)
    local ok, affected = pcall(function()
        return MySQL.update.await([[UPDATE cen_zones SET status = 'disabled'
          WHERE id = ? AND NOT EXISTS (SELECT 1 FROM cen_zone_contests WHERE zone_id = ? AND status = 'active')]], { zoneId, zoneId })
    end)
    if not ok then return false, CEN.Errors.DATABASE_UNAVAILABLE end
    return tonumber(affected) == 1, tonumber(affected) == 1 and nil or CEN.Errors.CONTEST_ACTIVE
end

function Repository.SetOwner(zoneId, enterpriseId)
    local ok, result = pcall(function()
        return MySQL.transaction.await({
            { query = [[UPDATE cen_zones SET owner_enterprise_id = ?, cooldown_until = NULL
                WHERE id = ? AND status = 'active']], values = { enterpriseId, zoneId } },
            { query = [[DELETE FROM cen_rackets WHERE zone_id = ?
                AND (? IS NULL OR enterprise_id <> ?)]], values = { zoneId, enterpriseId, enterpriseId } }
        })
    end)
    if not ok or result ~= true then return false, CEN.Errors.DATABASE_UNAVAILABLE end
    local zone = Repository.Get(zoneId)
    if not zone or zone.status ~= 'active' then return false, CEN.Errors.ZONE_NOT_FOUND end
    if tonumber(zone.ownerEnterpriseId) ~= tonumber(enterpriseId) then
        if not (zone.ownerEnterpriseId == nil and enterpriseId == nil) then return false, CEN.Errors.CONFLICT end
    end
    return true
end

function Repository.GetActiveContest(zoneId)
    local ok, row = pcall(function()
        return MySQL.single.await([[SELECT id AS contestId, zone_id AS zoneId,
          attacker_enterprise_id AS attackerEnterpriseId, defender_enterprise_id AS defenderEnterpriseId,
          attacker_score AS attackerScore, defender_score AS defenderScore,
          starts_at AS startsAt, ends_at AS endsAt, status
          FROM cen_zone_contests WHERE zone_id = ? AND status = 'active' LIMIT 1]], { zoneId })
    end)
    if not ok then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    return row
end

function Repository.StartContest(zone, attackerEnterpriseId, memberId)
    local defenderId = zone.ownerEnterpriseId
    local duration = math.max(60, tonumber(zone.captureDurationSeconds) or Config.Zones.defaultContestSeconds)
    local ok, result = pcall(function()
        return MySQL.transaction.await({
            { query = [[INSERT INTO cen_zone_contests
                (zone_id, attacker_enterprise_id, defender_enterprise_id, created_by_member_id,
                 status, starts_at, ends_at)
                SELECT ?, ?, ?, ?, 'active', UTC_TIMESTAMP(), DATE_ADD(UTC_TIMESTAMP(), INTERVAL ? SECOND)
                WHERE NOT EXISTS (SELECT 1 FROM cen_zone_contests WHERE zone_id = ? AND status = 'active')]],
              values = { zone.zoneId, attackerEnterpriseId, defenderId, memberId, duration, zone.zoneId } },
            { query = [[UPDATE cen_zones SET last_contested_at = UTC_TIMESTAMP() WHERE id = ?]], values = { zone.zoneId } }
        })
    end)
    if not ok or result ~= true then return false, CEN.Errors.CONFLICT end
    local contest = Repository.GetActiveContest(zone.zoneId)
    if not contest then return false, CEN.Errors.CONFLICT end
    return contest
end

function Repository.AddScore(contestId, attackerPoints, defenderPoints)
    local ok, affected = pcall(function()
        return MySQL.update.await([[UPDATE cen_zone_contests
          SET attacker_score = attacker_score + ?, defender_score = defender_score + ?
          WHERE id = ? AND status = 'active' AND ends_at > UTC_TIMESTAMP()]], {
            attackerPoints, defenderPoints, contestId
        })
    end)
    return ok and tonumber(affected) == 1
end

function Repository.ListDueContests()
    local ok, rows = pcall(function()
        return MySQL.query.await([[SELECT c.id AS contestId, c.zone_id AS zoneId,
          c.attacker_enterprise_id AS attackerEnterpriseId, c.defender_enterprise_id AS defenderEnterpriseId,
          c.attacker_score AS attackerScore, c.defender_score AS defenderScore,
          z.zone_type AS zoneType, z.cooldown_seconds AS cooldownSeconds
          FROM cen_zone_contests c JOIN cen_zones z ON z.id = c.zone_id
          WHERE c.status = 'active' AND c.ends_at <= UTC_TIMESTAMP()]])
    end)
    if not ok or rows == nil then return nil end
    return rows
end

function Repository.ListActiveContests()
    local ok, rows = pcall(function()
        return MySQL.query.await([[SELECT c.id AS contestId, c.zone_id AS zoneId,
          c.attacker_enterprise_id AS attackerEnterpriseId, c.defender_enterprise_id AS defenderEnterpriseId,
          z.center_x AS centerX, z.center_y AS centerY, z.center_z AS centerZ, z.radius
          FROM cen_zone_contests c JOIN cen_zones z ON z.id = c.zone_id
          WHERE c.status = 'active' AND c.ends_at > UTC_TIMESTAMP()]])
    end)
    return ok and rows or nil
end

function Repository.Resolve(contest, winnerEnterpriseId)
    local cooldown = math.max(0, tonumber(contest.cooldownSeconds) or Config.Zones.defaultCooldownSeconds)
    local ok, result = pcall(function()
        return MySQL.transaction.await({
            { query = [[UPDATE cen_zone_contests SET status = 'completed', winner_enterprise_id = ?,
                completed_at = UTC_TIMESTAMP() WHERE id = ? AND status = 'active']],
              values = { winnerEnterpriseId, contest.contestId } },
            { query = [[UPDATE cen_zones SET owner_enterprise_id = ?,
                cooldown_until = DATE_ADD(UTC_TIMESTAMP(), INTERVAL ? SECOND)
                WHERE id = ?]], values = { winnerEnterpriseId, cooldown, contest.zoneId } },
            { query = [[DELETE FROM cen_rackets WHERE zone_id = ? AND enterprise_id <> ?]],
              values = { contest.zoneId, winnerEnterpriseId } }
        })
    end)
    return ok and result == true
end

function Repository.GetActiveMemberIdentifiers(enterpriseId)
    local ok, rows = pcall(function()
        return MySQL.query.await([[SELECT player_identifier AS identifier FROM cen_members
          WHERE enterprise_id = ? AND status = 'active']], { enterpriseId })
    end)
    if not ok or rows == nil then return nil end
    return rows
end
