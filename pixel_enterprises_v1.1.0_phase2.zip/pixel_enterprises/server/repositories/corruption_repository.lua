CENServer = CENServer or {}
CENServer.CorruptionRepository = CENServer.CorruptionRepository or {}
local Repository = CENServer.CorruptionRepository

local function findResultRow(value)
    if type(value) ~= 'table' then return nil end
    if value.ok ~= nil or value.errorCode ~= nil then return value end
    for i = 1, #value do local found = findResultRow(value[i]); if found then return found end end
end

function Repository.List(enterpriseId)
    local ok, data = pcall(function()
        MySQL.update.await([[UPDATE cen_corruption_offers SET status = 'expired'
          WHERE status = 'pending' AND expires_at <= UTC_TIMESTAMP()]])
        return {
            offers = MySQL.query.await([[SELECT id AS offerId, officer_display_name AS officerDisplayName,
              service_key AS serviceKey, fee, exposure, status,
              DATE_FORMAT(expires_at, '%Y-%m-%d %H:%i:%s') AS expiresAt,
              DATE_FORMAT(completed_at, '%Y-%m-%d %H:%i:%s') AS completedAt
              FROM cen_corruption_offers WHERE enterprise_id = ? ORDER BY id DESC LIMIT 100]], { enterpriseId }) or {},
            contacts = MySQL.query.await([[SELECT officer_display_name AS officerDisplayName, trust,
              exposure, total_paid AS totalPaid, status,
              DATE_FORMAT(last_service_at, '%Y-%m-%d %H:%i:%s') AS lastServiceAt
              FROM cen_corruption_contacts WHERE enterprise_id = ? ORDER BY trust DESC]], { enterpriseId }) or {}
        }
    end)
    if not ok or not data then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    for _, rows in pairs(data) do for i = 1, #rows do
        rows[i].offerId = tonumber(rows[i].offerId); rows[i].fee = tonumber(rows[i].fee)
        rows[i].exposure = tonumber(rows[i].exposure); rows[i].trust = tonumber(rows[i].trust)
        rows[i].totalPaid = tonumber(rows[i].totalPaid)
    end end
    return data
end

function Repository.PendingForOfficer(identifier)
    local ok, rows = pcall(function()
        return MySQL.query.await([[SELECT o.id AS offerId, e.name AS enterpriseName,
          o.service_key AS serviceKey, o.fee, o.exposure,
          DATE_FORMAT(o.expires_at, '%Y-%m-%d %H:%i:%s') AS expiresAt
          FROM cen_corruption_offers o JOIN cen_enterprises e ON e.id = o.enterprise_id
          WHERE o.officer_identifier = ? AND o.status = 'pending' AND o.expires_at > UTC_TIMESTAMP()
          ORDER BY o.id DESC]], { identifier })
    end)
    if not ok or rows == nil then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    for i = 1, #rows do rows[i].offerId = tonumber(rows[i].offerId); rows[i].fee = tonumber(rows[i].fee); rows[i].exposure = tonumber(rows[i].exposure) end
    return rows
end

function Repository.CreateOffer(enterpriseId, memberId, identifier, displayName, serviceKey, fee, exposure)
    local ok, id = pcall(function()
        return MySQL.insert.await([[INSERT INTO cen_corruption_offers
          (enterprise_id, created_by_member_id, officer_identifier, officer_display_name,
           service_key, fee, exposure, expires_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, DATE_ADD(UTC_TIMESTAMP(), INTERVAL ? HOUR))]], {
            enterpriseId, memberId, identifier, displayName, serviceKey, fee, exposure,
            math.max(1, tonumber(Config.Corruption.offerExpiryHours) or 24)
        })
    end)
    if not ok or not id then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    return tonumber(id)
end

function Repository.Accept(offerId, identifier)
    local ok, result = pcall(function()
        return MySQL.query.await('CALL cen_accept_corruption_offer(?,?)', { offerId, identifier })
    end)
    if not ok or not result then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local row = findResultRow(result)
    if not row then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    if tonumber(row.ok) ~= 1 then return nil, row.errorCode or CEN.Errors.CONFLICT end
    row.enterpriseId = tonumber(row.enterpriseId); row.fee = tonumber(row.fee); row.exposure = tonumber(row.exposure)
    return row
end


function Repository.Complete(offerId, enterpriseId)
    local ok, committed = pcall(function()
        return MySQL.transaction.await({
            { query = [[UPDATE cen_corruption_offers SET status = 'completed', completed_at = UTC_TIMESTAMP()
              WHERE id = ? AND enterprise_id = ? AND status = 'accepted']], values = { offerId, enterpriseId } },
            { query = [[INSERT INTO cen_corruption_contacts
              (enterprise_id, officer_identifier, officer_display_name, trust, exposure, total_paid, status, last_service_at)
              SELECT enterprise_id, officer_identifier, officer_display_name, 5, exposure, fee, 'active', UTC_TIMESTAMP()
              FROM cen_corruption_offers WHERE id = ? AND enterprise_id = ? AND status = 'completed'
              ON DUPLICATE KEY UPDATE officer_display_name = VALUES(officer_display_name),
                trust = LEAST(100, trust + 5), exposure = LEAST(1000, exposure + VALUES(exposure)),
                total_paid = total_paid + VALUES(total_paid), last_service_at = UTC_TIMESTAMP()]],
              values = { offerId, enterpriseId } }
        })
    end)
    if not ok or committed ~= true then return false end
    local statusOk, status = pcall(function()
        return MySQL.scalar.await('SELECT status FROM cen_corruption_offers WHERE id = ? AND enterprise_id = ?', { offerId, enterpriseId })
    end)
    return statusOk and status == 'completed'
end

function Repository.GetOffer(offerId)
    local ok, row = pcall(function()
        return MySQL.single.await([[SELECT id AS offerId, enterprise_id AS enterpriseId,
          officer_identifier AS officerIdentifier, service_key AS serviceKey, fee, status
          FROM cen_corruption_offers WHERE id = ?]], { offerId })
    end)
    if not ok then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    if not row then return nil, CEN.Errors.OFFER_NOT_FOUND end
    row.offerId = tonumber(row.offerId); row.enterpriseId = tonumber(row.enterpriseId); row.fee = tonumber(row.fee)
    return row
end

function Repository.Reverse(offerId, enterpriseId, fee)
    local ok, success = pcall(function()
        return MySQL.transaction.await({
            { query = [[UPDATE cen_enterprises SET treasury_balance = treasury_balance + ? WHERE id = ?]], values = { fee, enterpriseId } },
            { query = [[UPDATE cen_corruption_offers SET status = 'failed' WHERE id = ? AND enterprise_id = ?]], values = { offerId, enterpriseId } },
            { query = [[INSERT INTO cen_treasury_transactions
              (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
              SELECT ?, NULL, 'corruption_reversal', ?, treasury_balance, ? FROM cen_enterprises WHERE id = ?]],
              values = { enterpriseId, fee, ('Offer #%s payout reversal'):format(offerId), enterpriseId } }
        })
    end)
    return ok and success == true
end
