CENServer = CENServer or {}
CENServer.FoundingRepository = CENServer.FoundingRepository or {}

local Repository = CENServer.FoundingRepository

local function databaseReady()
    return GetResourceState('oxmysql') == 'started'
end


local function safeSingle(query, values)
    local ok, result = pcall(function() return MySQL.single.await(query, values or {}) end)
    if not ok then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    return result
end

local function safeQuery(query, values)
    local ok, result = pcall(function() return MySQL.query.await(query, values or {}) end)
    if not ok or result == nil then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    return result
end

local function safeScalar(query, values)
    local ok, result = pcall(function() return MySQL.scalar.await(query, values or {}) end)
    if not ok or result == nil then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    return result
end

local function safeUpdate(query, values)
    local ok, result = pcall(function() return MySQL.update.await(query, values or {}) end)
    if not ok or result == nil then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    return result
end

local function findResultRow(value)
    if type(value) ~= 'table' then return nil end
    if value.success ~= nil or value.errorCode ~= nil
        or value.enterpriseId ~= nil or value.proposalId ~= nil then
        return value
    end
    for i = 1, #value do
        local found = findResultRow(value[i])
        if found then return found end
    end
    return nil
end

local function decodeProposal(row)
    if not row then return nil end
    row.requiredAcceptances = tonumber(row.requiredAcceptances) or 0
    row.acceptedCount = tonumber(row.acceptedCount) or 0
    return row
end

function Repository.GetActiveProposalByFounder(identifier)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local row, errorCode = safeSingle([[SELECT
        p.id AS proposalId, p.founder_identifier AS founderIdentifier,
        p.founder_display_name AS founderDisplayName, p.name, p.slug,
        p.enterprise_type AS enterpriseType, p.creation_plan AS creationPlan,
        p.required_acceptances AS requiredAcceptances, p.status,
        p.expires_at AS expiresAt, p.created_at AS createdAt,
        (SELECT COUNT(*) FROM cen_founding_invites i
          WHERE i.proposal_id = p.id AND i.status = 'accepted') AS acceptedCount
      FROM cen_founding_proposals p
      WHERE p.founder_identifier = ?
        AND p.status IN ('pending','ready','awaiting_approval','finalizing')
        AND p.expires_at > UTC_TIMESTAMP()
      ORDER BY p.id DESC LIMIT 1]], { identifier })
    if errorCode then return nil, errorCode end
    return decodeProposal(row)
end

function Repository.GetProposal(proposalId)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local row, errorCode = safeSingle([[SELECT
        p.id AS proposalId, p.founder_identifier AS founderIdentifier,
        p.founder_display_name AS founderDisplayName, p.name, p.slug,
        p.enterprise_type AS enterpriseType, p.creation_plan AS creationPlan,
        p.required_acceptances AS requiredAcceptances, p.status,
        p.expires_at AS expiresAt, p.created_at AS createdAt,
        (SELECT COUNT(*) FROM cen_founding_invites i
          WHERE i.proposal_id = p.id AND i.status = 'accepted') AS acceptedCount
      FROM cen_founding_proposals p WHERE p.id = ? LIMIT 1]], { proposalId })
    if errorCode then return nil, errorCode end
    if not row then return nil, CEN.Errors.PROPOSAL_NOT_FOUND end
    return decodeProposal(row)
end

function Repository.IsNameOrSlugTaken(name, slug)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local count, errorCode = safeScalar([[SELECT (
        (SELECT COUNT(*) FROM cen_enterprises WHERE name = ? OR slug = ?) +
        (SELECT COUNT(*) FROM cen_founding_proposals
          WHERE (name = ? OR slug = ?) AND (
            status = 'finalized'
            OR (status IN ('pending','ready','awaiting_approval','finalizing')
              AND expires_at > UTC_TIMESTAMP())
          ))
      )]], { name, slug, name, slug })
    if count == nil then return nil, errorCode end
    return tonumber(count) > 0
end

function Repository.CreateProposal(founderIdentifier, founderDisplayName, name, slug, enterpriseType, creationPlan)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local hours = math.max(1, tonumber(Config.Creation.founding.proposalExpiryHours) or 168)
    local required = math.max(0, (tonumber(Config.Creation.founding.requiredAcceptances) or 8)
        - (Config.Creation.founding.founderCountsAsAcceptance and 1 or 0))
    local ok, results = pcall(function()
        return MySQL.query.await('CALL cen_create_founding_proposal(?, ?, ?, ?, ?, ?, ?, ?)', {
            founderIdentifier, founderDisplayName, name, slug, enterpriseType,
            creationPlan, required, hours
        })
    end)
    if not ok or results == nil then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local row = findResultRow(results)
    if not row or tonumber(row.success) ~= 1 then
        return nil, (row and row.errorCode) or CEN.Errors.CONFLICT
    end
    return tonumber(row.proposalId)
end

function Repository.CountInvites(proposalId)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local count, errorCode = safeScalar([[SELECT COUNT(*) FROM cen_founding_invites
      WHERE proposal_id = ? AND status IN ('pending','accepted')]], { proposalId })
    if count == nil then return nil, errorCode end
    return tonumber(count)
end

function Repository.ListAcceptedIdentifiers(proposalId)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local ok, rows = pcall(function()
        return MySQL.query.await([[SELECT invited_identifier AS identifier
          FROM cen_founding_invites
          WHERE proposal_id = ? AND status = 'accepted'
          ORDER BY id ASC]], { proposalId })
    end)
    if not ok or rows == nil then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    return rows
end

function Repository.GetActiveSupportByIdentifier(identifier)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local row, errorCode = safeSingle([[SELECT fp.proposal_id AS proposalId
      FROM cen_founding_participants fp
      JOIN cen_founding_proposals p ON p.id = fp.proposal_id
      WHERE fp.identifier = ? AND fp.role = 'supporter'
        AND p.status IN ('pending','ready','awaiting_approval','finalizing')
        AND p.expires_at > UTC_TIMESTAMP()
      LIMIT 1]], { identifier })
    if errorCode then return nil, errorCode end
    return row
end

function Repository.GetActiveParticipationByIdentifier(identifier)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local row, errorCode = safeSingle([[SELECT fp.proposal_id AS proposalId, fp.role
      FROM cen_founding_participants fp
      JOIN cen_founding_proposals p ON p.id = fp.proposal_id
      WHERE fp.identifier = ?
        AND p.status IN ('pending','ready','awaiting_approval','finalizing')
        AND p.expires_at > UTC_TIMESTAMP()
      LIMIT 1]], { identifier })
    if errorCode then return nil, errorCode end
    return row
end

function Repository.CreateInvite(proposalId, invitedIdentifier, invitedDisplayName, invitedByIdentifier)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local hours = math.max(1, tonumber(Config.Creation.founding.inviteExpiryHours) or 72)
    local ok, result = pcall(function()
        local existing = MySQL.single.await([[SELECT id, status FROM cen_founding_invites
          WHERE proposal_id = ? AND invited_identifier = ? LIMIT 1]], { proposalId, invitedIdentifier })
        if existing then
            if existing.status == 'accepted' then return tonumber(existing.id) end
            local affected = MySQL.update.await([[UPDATE cen_founding_invites
              SET invited_display_name = ?, invited_by_identifier = ?, status = 'pending',
                  expires_at = DATE_ADD(UTC_TIMESTAMP(), INTERVAL ? HOUR), responded_at = NULL
              WHERE id = ? AND status IN ('pending','declined','expired')]], {
                invitedDisplayName, invitedByIdentifier, hours, existing.id
            })
            if tonumber(affected) ~= 1 then error('founding_invite_refresh_failed') end
            return tonumber(existing.id)
        end
        return MySQL.insert.await([[INSERT INTO cen_founding_invites
          (proposal_id, invited_identifier, invited_display_name, invited_by_identifier,
           status, expires_at)
          VALUES (?, ?, ?, ?, 'pending', DATE_ADD(UTC_TIMESTAMP(), INTERVAL ? HOUR))]], {
            proposalId, invitedIdentifier, invitedDisplayName, invitedByIdentifier, hours
        })
    end)
    if not ok then return nil, CEN.Errors.CONFLICT end
    return result
end

function Repository.GetPendingInvite(proposalId, identifier)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local row, errorCode = safeSingle([[SELECT i.id AS inviteId, i.proposal_id AS proposalId,
        i.status, i.expires_at AS expiresAt, p.name AS enterpriseName,
        p.founder_display_name AS founderDisplayName
      FROM cen_founding_invites i
      JOIN cen_founding_proposals p ON p.id = i.proposal_id
      WHERE i.proposal_id = ? AND i.invited_identifier = ?
        AND i.status = 'pending' AND i.expires_at > UTC_TIMESTAMP()
        AND p.status IN ('pending','ready') AND p.expires_at > UTC_TIMESTAMP()
      LIMIT 1]], { proposalId, identifier })
    if errorCode then return nil, errorCode end
    if not row then return nil, CEN.Errors.INVITE_NOT_FOUND end
    return row
end

function Repository.ListPendingInvitesForIdentifier(identifier)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    return safeQuery([[SELECT i.proposal_id AS proposalId,
        p.name AS enterpriseName, p.enterprise_type AS enterpriseType,
        p.founder_display_name AS founderDisplayName, i.expires_at AS expiresAt
      FROM cen_founding_invites i
      JOIN cen_founding_proposals p ON p.id = i.proposal_id
      WHERE i.invited_identifier = ? AND i.status = 'pending'
        AND i.expires_at > UTC_TIMESTAMP() AND p.expires_at > UTC_TIMESTAMP()
        AND p.status IN ('pending','ready')
      ORDER BY i.created_at DESC]], { identifier })
end

function Repository.AcceptInvite(inviteId, identifier)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local ok, results = pcall(function()
        return MySQL.query.await('CALL cen_accept_founding_invite(?, ?)', {
            inviteId, identifier
        })
    end)
    if not ok or results == nil then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local row = findResultRow(results)
    if not row or tonumber(row.success) ~= 1 then
        return nil, (row and row.errorCode) or CEN.Errors.CONFLICT
    end
    return true, nil, tonumber(row.proposalId)
end

function Repository.DeclineInvite(inviteId)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local affected, errorCode = safeUpdate([[UPDATE cen_founding_invites
      SET status = 'declined', responded_at = UTC_TIMESTAMP()
      WHERE id = ? AND status = 'pending']], { inviteId })
    if affected == nil then return nil, errorCode end
    if affected ~= 1 then return nil, CEN.Errors.INVITE_ALREADY_RESPONDED end
    return true
end

function Repository.MarkReady(proposalId, awaitingApproval)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local status = awaitingApproval and 'awaiting_approval' or 'ready'
    local affected, errorCode = safeUpdate([[UPDATE cen_founding_proposals SET status = ?, updated_at = UTC_TIMESTAMP()
      WHERE id = ? AND status IN ('pending','ready')]], { status, proposalId })
    if affected == nil then return nil, errorCode end
    if affected == 1 then return true end
    local current, currentError = safeScalar('SELECT status FROM cen_founding_proposals WHERE id = ?', { proposalId })
    if current == nil then return nil, currentError end
    return current == status, current == status and nil or CEN.Errors.PROPOSAL_NOT_READY
end

function Repository.MarkFinalizing(proposalId, expectedStatus)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local affected, errorCode = safeUpdate([[UPDATE cen_founding_proposals
      SET status = 'finalizing', updated_at = UTC_TIMESTAMP()
      WHERE id = ? AND status = ? AND expires_at > UTC_TIMESTAMP()]], { proposalId, expectedStatus })
    if affected == nil then return nil, errorCode end
    return affected == 1, affected == 1 and nil or CEN.Errors.PROPOSAL_NOT_READY
end

function Repository.ResetFinalizing(proposalId, targetStatus)
    if not databaseReady() then return false end
    local affected = safeUpdate([[UPDATE cen_founding_proposals SET status = ?, updated_at = UTC_TIMESTAMP()
      WHERE id = ? AND status = 'finalizing']], { targetStatus or 'ready', proposalId })
    return affected == 1
end

function Repository.CancelProposal(proposalId, founderIdentifier)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local ok, results = pcall(function()
        return MySQL.query.await('CALL cen_cancel_founding_proposal(?, ?)', {
            proposalId, founderIdentifier
        })
    end)
    if not ok or results == nil then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local row = findResultRow(results)
    if not row or tonumber(row.success) ~= 1 then
        return nil, (row and row.errorCode) or CEN.Errors.CONFLICT
    end
    return true
end

local function planSettings(plan)
    local definition = Config.Creation.plans[plan] or Config.Creation.plans.free
    return math.max(1, tonumber(definition.baseMemberLimit) or 12), definition.retentionRequired == true
end

function Repository.CreateEnterpriseDirect(name, slug, enterpriseType, creationPlan, ownerIdentifier, ownerDisplayName)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local baseLimit, retentionRequired = planSettings(creationPlan)
    local ok, results = pcall(function()
        return MySQL.query.await('CALL cen_create_enterprise_direct(?, ?, ?, ?, ?, ?, ?, ?)', {
            name, slug, enterpriseType, creationPlan, baseLimit,
            retentionRequired and 1 or 0, ownerIdentifier, ownerDisplayName
        })
    end)
    if not ok or results == nil then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local row = findResultRow(results)
    if not row or tonumber(row.success) ~= 1 then
        return nil, (row and row.errorCode) or CEN.Errors.CONFLICT
    end
    return tonumber(row.enterpriseId)
end

function Repository.FinalizeProposal(proposalId)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local proposal, proposalError = Repository.GetProposal(proposalId)
    if not proposal then return nil, proposalError end
    local baseLimit, retentionRequired = planSettings(proposal.creationPlan)
    local accepted, acceptedError = safeQuery([[SELECT invited_identifier AS identifier,
        invited_display_name AS displayName
      FROM cen_founding_invites
      WHERE proposal_id = ? AND status = 'accepted'
      ORDER BY responded_at ASC, id ASC]], { proposalId })
    if not accepted then return nil, acceptedError end

    local ok, results = pcall(function()
        return MySQL.query.await('CALL cen_finalize_founding_proposal(?, ?, ?, ?)', {
            proposalId, Config.Membership.absoluteMemberLimit, baseLimit,
            retentionRequired and 1 or 0
        })
    end)
    if not ok or results == nil then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local row = findResultRow(results)
    if not row or tonumber(row.success) ~= 1 then
        return nil, (row and row.errorCode) or CEN.Errors.CONFLICT
    end
    return tonumber(row.enterpriseId), nil, accepted
end

function Repository.ExpireOld()
    if not databaseReady() then return false end
    local ok = pcall(function()
        MySQL.update.await([[UPDATE cen_founding_invites SET status = 'expired'
          WHERE status = 'pending' AND expires_at <= UTC_TIMESTAMP()]])
        MySQL.update.await([[UPDATE cen_founding_proposals SET status = 'expired', updated_at = UTC_TIMESTAMP()
          WHERE status IN ('pending','ready','awaiting_approval','finalizing')
            AND expires_at <= UTC_TIMESTAMP()]])
        MySQL.update.await([[DELETE fp FROM cen_founding_participants fp
          JOIN cen_founding_proposals p ON p.id = fp.proposal_id
          WHERE p.status NOT IN ('pending','ready','awaiting_approval','finalizing')
             OR p.expires_at <= UTC_TIMESTAMP()]])
    end)
    return ok
end
