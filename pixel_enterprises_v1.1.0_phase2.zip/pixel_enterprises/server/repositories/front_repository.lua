CENServer = CENServer or {}
CENServer.FrontRepository = CENServer.FrontRepository or {}
local Repository = CENServer.FrontRepository

local function findResultRow(value)
    if type(value) ~= 'table' then return nil end
    if value.ok ~= nil or value.errorCode ~= nil then return value end
    for i = 1, #value do
        local found = findResultRow(value[i])
        if found then return found end
    end
    return nil
end

local function call(name, values)
    local placeholders = {}
    for i = 1, #values do placeholders[i] = '?' end
    local ok, result = pcall(function()
        return MySQL.query.await(('CALL %s(%s)'):format(name, table.concat(placeholders, ',')), values)
    end)
    if not ok or result == nil then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local row = findResultRow(result)
    if not row or tonumber(row.ok) ~= 1 then
        return nil, row and row.errorCode or CEN.Errors.CONFLICT
    end
    for _, key in ipairs({ 'frontId', 'jobId', 'cleanAmount', 'payoutAmount', 'heat' }) do
        if row[key] ~= nil then row[key] = tonumber(row[key]) end
    end
    return row
end

function Repository.List(enterpriseId)
    local ok, result = pcall(function()
        local fronts = MySQL.query.await([[SELECT id AS frontId, business_type AS businessType, name,
          capacity_per_cycle AS capacityPerCycle, processed_this_cycle AS processedThisCycle,
          DATE_FORMAT(cycle_start, '%Y-%m-%d') AS cycleStart, fee_percent AS feePercent,
          security_level AS securityLevel, status, created_at AS createdAt
        FROM cen_front_businesses WHERE enterprise_id = ? AND status <> 'disabled'
        ORDER BY status, name]], { enterpriseId })
        local jobs = MySQL.query.await([[SELECT j.id AS jobId, j.front_id AS frontId, f.name AS frontName,
          j.dirty_amount AS dirtyAmount, j.clean_amount AS cleanAmount, j.fee_amount AS feeAmount,
          CASE WHEN j.status = 'processing' AND j.ready_at <= UTC_TIMESTAMP() THEN 'ready' ELSE j.status END AS status,
          j.ready_at AS readyAt, j.claimed_at AS claimedAt, j.created_at AS createdAt
        FROM cen_laundering_jobs j JOIN cen_front_businesses f ON f.id = j.front_id
        WHERE j.enterprise_id = ? ORDER BY j.id DESC LIMIT 50]], { enterpriseId })
        return { fronts = fronts or {}, jobs = jobs or {} }
    end)
    if not ok or not result then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    for _, list in pairs(result) do
        for i = 1, #list do
            for _, key in ipairs({ 'frontId', 'capacityPerCycle', 'processedThisCycle', 'feePercent', 'securityLevel', 'jobId', 'dirtyAmount', 'cleanAmount', 'feeAmount' }) do
                if list[i][key] ~= nil then list[i][key] = tonumber(list[i][key]) end
            end
        end
    end
    return result
end

function Repository.Create(enterpriseId, memberId, businessType, name, config, maximumFronts)
    local row, errorCode = call('cen_create_front', {
        enterpriseId, memberId, businessType, name, config.cost, config.capacity,
        config.feePercent, maximumFronts
    })
    return row and row.frontId or nil, errorCode
end

function Repository.Get(frontId, enterpriseId)
    local ok, row = pcall(function()
        return MySQL.single.await([[SELECT id AS frontId, enterprise_id AS enterpriseId,
          business_type AS businessType, name, capacity_per_cycle AS capacityPerCycle,
          processed_this_cycle AS processedThisCycle, DATE_FORMAT(cycle_start, '%Y-%m-%d') AS cycleStart,
          fee_percent AS feePercent, security_level AS securityLevel, status
        FROM cen_front_businesses WHERE id = ? AND enterprise_id = ? LIMIT 1]], { frontId, enterpriseId })
    end)
    if not ok then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    if not row then return nil, CEN.Errors.FRONT_NOT_FOUND end
    for _, key in ipairs({ 'frontId', 'enterpriseId', 'capacityPerCycle', 'processedThisCycle', 'feePercent', 'securityLevel' }) do
        row[key] = tonumber(row[key])
    end
    return row
end

function Repository.StartJob(frontId, enterpriseId, memberId, dirtyAmount, cleanAmount, feeAmount, durationSeconds)
    local row, errorCode = call('cen_start_laundering_job', {
        frontId, enterpriseId, memberId, dirtyAmount, cleanAmount, feeAmount, durationSeconds
    })
    return row and row.jobId or nil, errorCode
end

function Repository.ClaimToTreasury(jobId, enterpriseId, memberId, maximumBalance)
    local row, errorCode = call('cen_claim_laundering_treasury', {
        jobId, enterpriseId, memberId, maximumBalance
    })
    return row, errorCode
end

function Repository.MarkClaiming(jobId, enterpriseId, memberId)
    local ok, affected = pcall(function()
        return MySQL.update.await([[UPDATE cen_laundering_jobs SET status = 'claiming', member_id = ?
          WHERE id = ? AND enterprise_id = ? AND status IN ('processing','ready')
            AND ready_at <= UTC_TIMESTAMP()]], { memberId, jobId, enterpriseId })
    end)
    if not ok then return false, CEN.Errors.DATABASE_UNAVAILABLE end
    return tonumber(affected) == 1, tonumber(affected) == 1 and nil or CEN.Errors.LAUNDERING_NOT_READY
end

function Repository.GetJob(jobId, enterpriseId)
    local ok, row = pcall(function()
        return MySQL.single.await([[SELECT id AS jobId, clean_amount AS cleanAmount, status
          FROM cen_laundering_jobs WHERE id = ? AND enterprise_id = ? LIMIT 1]], { jobId, enterpriseId })
    end)
    if not ok then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    if not row then return nil, CEN.Errors.LAUNDERING_NOT_READY end
    row.jobId = tonumber(row.jobId); row.cleanAmount = tonumber(row.cleanAmount)
    return row
end

function Repository.CompleteJob(jobId, enterpriseId)
    local ok, affected = pcall(function()
        return MySQL.update.await([[UPDATE cen_laundering_jobs SET status = 'claimed', claimed_at = UTC_TIMESTAMP()
          WHERE id = ? AND enterprise_id = ? AND status = 'claiming']], { jobId, enterpriseId })
    end)
    return ok and tonumber(affected) == 1
end

function Repository.ResetJob(jobId, enterpriseId)
    pcall(function()
        MySQL.update.await([[UPDATE cen_laundering_jobs SET status = 'ready'
          WHERE id = ? AND enterprise_id = ? AND status = 'claiming']], { jobId, enterpriseId })
    end)
end

function Repository.ListRackets(enterpriseId)
    local ok, rows = pcall(function()
        return MySQL.query.await([[SELECT r.id AS racketId, r.zone_id AS zoneId, z.name AS zoneName,
          z.zone_type AS zoneType, r.racket_type AS racketType, r.payout_amount AS payoutAmount,
          r.heat, r.last_collected_at AS lastCollectedAt, r.status
        FROM cen_rackets r JOIN cen_zones z ON z.id = r.zone_id
        WHERE r.enterprise_id = ? AND r.status = 'active' ORDER BY z.name]], { enterpriseId })
    end)
    if not ok or rows == nil then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    for i = 1, #rows do
        for _, key in ipairs({ 'racketId', 'zoneId', 'payoutAmount', 'heat' }) do rows[i][key] = tonumber(rows[i][key]) end
    end
    return rows
end

function Repository.CreateRacket(enterpriseId, zoneId, memberId, racketType, payout, heat)
    local ok, id = pcall(function()
        return MySQL.insert.await([[INSERT INTO cen_rackets
          (enterprise_id, zone_id, created_by_member_id, racket_type, payout_amount, heat)
          SELECT ?, z.id, ?, ?, ?, ? FROM cen_zones z
          WHERE z.id = ? AND z.owner_enterprise_id = ? AND z.status = 'active']], {
            enterpriseId, memberId, racketType, payout, heat, zoneId, enterpriseId
        })
    end)
    if not ok or not id then return nil, CEN.Errors.RACKET_EXISTS end
    return id
end

function Repository.CollectRacket(enterpriseId, racketId, intervalSeconds, maxBalance)
    return call('cen_collect_racket', { enterpriseId, racketId, intervalSeconds, maxBalance })
end
