CENServer = CENServer or {}
CENServer.ShipmentRepository = CENServer.ShipmentRepository or {}
local Repository = CENServer.ShipmentRepository

local function findResultRow(value)
    if type(value) ~= 'table' then return nil end
    if value.ok ~= nil or value.errorCode ~= nil then return value end
    for i = 1, #value do local found = findResultRow(value[i]); if found then return found end end
end

function Repository.List(enterpriseId)
    local ok, rows = pcall(function()
        MySQL.update.await([[UPDATE cen_shipments SET status = 'ready'
          WHERE enterprise_id = ? AND status = 'scheduled' AND ready_at <= UTC_TIMESTAMP()]], { enterpriseId })
        MySQL.update.await([[UPDATE cen_shipments SET status = 'expired'
          WHERE enterprise_id = ? AND status IN ('scheduled','ready') AND expires_at <= UTC_TIMESTAMP()]], { enterpriseId })
        return MySQL.query.await([[SELECT id AS shipmentId, catalog_key AS catalogKey,
          delivery_type AS deliveryType, item_name AS itemName, quantity, cost,
          pickup_x AS pickupX, pickup_y AS pickupY, pickup_z AS pickupZ, pickup_label AS pickupLabel,
          status, DATE_FORMAT(ready_at, '%Y-%m-%d %H:%i:%s') AS readyAt,
          DATE_FORMAT(expires_at, '%Y-%m-%d %H:%i:%s') AS expiresAt
          FROM cen_shipments WHERE enterprise_id = ? ORDER BY id DESC LIMIT 100]], { enterpriseId })
    end)
    if not ok or rows == nil then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    for i = 1, #rows do
        local r = rows[i]; r.shipmentId = tonumber(r.shipmentId); r.quantity = tonumber(r.quantity)
        r.cost = tonumber(r.cost); r.pickupX = tonumber(r.pickupX); r.pickupY = tonumber(r.pickupY); r.pickupZ = tonumber(r.pickupZ)
    end
    return rows
end

function Repository.Request(enterpriseId, memberId, catalogKey, entry, location)
    local ok, result = pcall(function()
        return MySQL.query.await('CALL cen_request_shipment(?,?,?,?,?,?,?,?,?,?,?,?,?)', {
            enterpriseId, memberId, catalogKey, entry.delivery, entry.item, entry.quantity, entry.cost,
            location.x, location.y, location.z, location.label,
            math.max(0, tonumber(Config.Shipments.deliveryDelaySeconds) or 900),
            math.max(1, tonumber(Config.Shipments.expiryHours) or 6)
        })
    end)
    if not ok or not result then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local row = findResultRow(result)
    if not row then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    if tonumber(row.ok) ~= 1 then return nil, row.errorCode or CEN.Errors.CONFLICT end
    row.shipmentId = tonumber(row.shipmentId)
    return row
end

function Repository.MarkClaiming(shipmentId, enterpriseId)
    local ok, affected = pcall(function()
        MySQL.update.await([[UPDATE cen_shipments SET status = 'claiming'
          WHERE id = ? AND enterprise_id = ? AND status IN ('ready','scheduled')
            AND ready_at <= UTC_TIMESTAMP() AND expires_at > UTC_TIMESTAMP()]], { shipmentId, enterpriseId })
    end)
    if not ok then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    if tonumber(affected) ~= 1 then return nil, CEN.Errors.SHIPMENT_NOT_READY end
    local row = MySQL.single.await([[SELECT id AS shipmentId, catalog_key AS catalogKey,
      delivery_type AS deliveryType, item_name AS itemName, quantity, pickup_x AS pickupX,
      pickup_y AS pickupY, pickup_z AS pickupZ, pickup_label AS pickupLabel
      FROM cen_shipments WHERE id = ?]], { shipmentId })
    if not row then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    row.shipmentId = tonumber(row.shipmentId); row.quantity = tonumber(row.quantity)
    row.pickupX = tonumber(row.pickupX); row.pickupY = tonumber(row.pickupY); row.pickupZ = tonumber(row.pickupZ)
    return row
end

function Repository.CompleteClaim(shipmentId, enterpriseId, memberId)
    local ok, affected = pcall(function()
        return MySQL.update.await([[UPDATE cen_shipments SET status = 'claimed', claimed_by_member_id = ?,
          claimed_at = UTC_TIMESTAMP() WHERE id = ? AND enterprise_id = ? AND status = 'claiming']],
          { memberId, shipmentId, enterpriseId })
    end)
    return ok and tonumber(affected) == 1
end

function Repository.ResetClaim(shipmentId, enterpriseId)
    pcall(function() MySQL.update.await([[UPDATE cen_shipments SET status = 'ready'
      WHERE id = ? AND enterprise_id = ? AND status = 'claiming']], { shipmentId, enterpriseId }) end)
end
