CENServer = CENServer or {}
CENServer.FacilityRepository = CENServer.FacilityRepository or {}
local Repository = CENServer.FacilityRepository

local function decode(value)
    if type(value) == 'table' then return value end
    if type(value) ~= 'string' or value == '' then return {} end
    local ok, parsed = pcall(json.decode, value)
    return ok and type(parsed) == 'table' and parsed or {}
end

local function normalize(row)
    if not row then return nil end
    row.facilityId = tonumber(row.facilityId or row.id)
    row.enterpriseId = tonumber(row.enterpriseId)
    row.level = tonumber(row.level) or 1
    row.centerX, row.centerY, row.centerZ = tonumber(row.centerX), tonumber(row.centerY), tonumber(row.centerZ)
    row.radius = tonumber(row.radius) or 8
    row.metadata = decode(row.metadata)
    return row
end

function Repository.List(enterpriseId)
    local ok, rows = pcall(function()
        MySQL.update.await([[UPDATE cen_production_jobs SET status = 'ready'
          WHERE enterprise_id = ? AND status = 'processing' AND ends_at <= UTC_TIMESTAMP()]], { enterpriseId })
        return MySQL.query.await([[SELECT id AS facilityId, enterprise_id AS enterpriseId,
          facility_type AS facilityType, subtype, name, center_x AS centerX, center_y AS centerY,
          center_z AS centerZ, radius, level, status, metadata
          FROM cen_facilities WHERE enterprise_id = ? ORDER BY id]], { enterpriseId })
    end)
    if not ok or rows == nil then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    for i = 1, #rows do normalize(rows[i]) end
    return rows
end

function Repository.Get(facilityId)
    local ok, row = pcall(function()
        return MySQL.single.await([[SELECT id AS facilityId, enterprise_id AS enterpriseId,
          facility_type AS facilityType, subtype, name, center_x AS centerX, center_y AS centerY,
          center_z AS centerZ, radius, level, status, metadata
          FROM cen_facilities WHERE id = ?]], { facilityId })
    end)
    if not ok then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    if not row then return nil, CEN.Errors.FACILITY_NOT_FOUND end
    return normalize(row)
end

function Repository.ListJobs(enterpriseId, limit)
    local ok, rows = pcall(function()
        MySQL.update.await([[UPDATE cen_production_jobs SET status = 'ready'
          WHERE enterprise_id = ? AND status = 'processing' AND ends_at <= UTC_TIMESTAMP()]], { enterpriseId })
        return MySQL.query.await([[SELECT j.id AS jobId, j.facility_id AS facilityId, j.recipe_key AS recipeKey,
          j.output_item AS outputItem, j.output_count AS outputCount, j.quality, j.batch_id AS batchId,
          j.status, DATE_FORMAT(j.starts_at, '%Y-%m-%d %H:%i:%s') AS startsAt,
          DATE_FORMAT(j.ends_at, '%Y-%m-%d %H:%i:%s') AS endsAt,
          DATE_FORMAT(j.claimed_at, '%Y-%m-%d %H:%i:%s') AS claimedAt,
          f.name AS facilityName, COALESCE(sm.display_name, 'Unknown') AS startedBy
          FROM cen_production_jobs j JOIN cen_facilities f ON f.id = j.facility_id
          LEFT JOIN cen_members sm ON sm.id = j.started_by_member_id
          WHERE j.enterprise_id = ? ORDER BY j.id DESC LIMIT ?]], {
            enterpriseId, math.max(1, math.min(100, tonumber(limit) or 50))
        })
    end)
    if not ok or rows == nil then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    for i = 1, #rows do
        rows[i].jobId = tonumber(rows[i].jobId); rows[i].facilityId = tonumber(rows[i].facilityId)
        rows[i].outputCount = tonumber(rows[i].outputCount); rows[i].quality = tonumber(rows[i].quality)
    end
    return rows
end

function Repository.StartJob(enterpriseId, facilityId, memberId, recipeKey, recipe, quality, batchId)
    local ok, id = pcall(function()
        return MySQL.insert.await([[INSERT INTO cen_production_jobs
          (facility_id, enterprise_id, started_by_member_id, recipe_key, output_item, output_count,
           quality, batch_id, status, starts_at, ends_at, metadata)
          SELECT ?, ?, ?, ?, ?, ?, ?, ?, 'processing', UTC_TIMESTAMP(),
            DATE_ADD(UTC_TIMESTAMP(), INTERVAL ? SECOND), ?
          FROM cen_facilities WHERE id = ? AND enterprise_id = ? AND status = 'active']], {
            facilityId, enterpriseId, memberId, recipeKey, recipe.outputItem, recipe.outputCount,
            quality, batchId, recipe.durationSeconds, json.encode({ category = recipe.category }),
            facilityId, enterpriseId
        })
    end)
    if not ok then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    if not id then return nil, CEN.Errors.FACILITY_NOT_FOUND end
    return tonumber(id)
end

function Repository.MarkClaiming(jobId, enterpriseId)
    local ok, affected = pcall(function()
        return MySQL.update.await([[UPDATE cen_production_jobs SET status = 'claiming'
          WHERE id = ? AND enterprise_id = ? AND status IN ('ready','processing')
            AND ends_at <= UTC_TIMESTAMP()]], { jobId, enterpriseId })
    end)
    if not ok then return false, CEN.Errors.DATABASE_UNAVAILABLE end
    if tonumber(affected) ~= 1 then return false, CEN.Errors.PRODUCTION_NOT_READY end
    local row = MySQL.single.await([[SELECT j.id AS jobId, j.facility_id AS facilityId,
      j.output_item AS outputItem, j.output_count AS outputCount, j.quality, j.batch_id AS batchId,
      j.recipe_key AS recipeKey, f.name AS facilityName, f.center_x AS centerX,
      f.center_y AS centerY, f.center_z AS centerZ, f.radius
      FROM cen_production_jobs j JOIN cen_facilities f ON f.id = j.facility_id WHERE j.id = ?]], { jobId })
    if not row then return false, CEN.Errors.DATABASE_UNAVAILABLE end
    row.jobId = tonumber(row.jobId); row.facilityId = tonumber(row.facilityId)
    row.outputCount = tonumber(row.outputCount); row.quality = tonumber(row.quality)
    row.centerX, row.centerY, row.centerZ, row.radius = tonumber(row.centerX), tonumber(row.centerY), tonumber(row.centerZ), tonumber(row.radius)
    return row
end

function Repository.CompleteClaim(jobId, enterpriseId, memberId)
    local ok, affected = pcall(function()
        return MySQL.update.await([[UPDATE cen_production_jobs
          SET status = 'claimed', claimed_by_member_id = ?, claimed_at = UTC_TIMESTAMP()
          WHERE id = ? AND enterprise_id = ? AND status = 'claiming']], { memberId, jobId, enterpriseId })
    end)
    return ok and tonumber(affected) == 1
end

function Repository.ResetClaim(jobId, enterpriseId)
    pcall(function()
        MySQL.update.await([[UPDATE cen_production_jobs SET status = 'ready'
          WHERE id = ? AND enterprise_id = ? AND status = 'claiming']], { jobId, enterpriseId })
    end)
end

function Repository.Create(enterpriseId, facilityType, subtype, name, coords, radius)
    local ok, id = pcall(function()
        return MySQL.insert.await([[INSERT INTO cen_facilities
          (enterprise_id, facility_type, subtype, name, center_x, center_y, center_z, radius)
          SELECT ?, ?, ?, ?, ?, ?, ?, ? FROM cen_enterprises WHERE id = ? AND status = 'active']], {
            enterpriseId, facilityType, subtype, name, coords.x, coords.y, coords.z, radius, enterpriseId
        })
    end)
    if not ok or not id then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    return tonumber(id)
end

function Repository.Delete(facilityId)
    local ok, affected = pcall(function()
        return MySQL.update.await([[UPDATE cen_facilities SET status = 'disabled' WHERE id = ?]], { facilityId })
    end)
    return ok and tonumber(affected) == 1
end
