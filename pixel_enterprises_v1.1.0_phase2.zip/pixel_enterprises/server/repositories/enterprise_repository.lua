CENServer = CENServer or {}
CENServer.Repository = CENServer.Repository or {}

local Repository = CENServer.Repository
local schemaVerified = false
local schemaFailure

local function databaseReady()
    return Config.Database.driver == 'oxmysql' and GetResourceState('oxmysql') == 'started'
end

local function decodePermissionList(value)
    if type(value) == 'table' then return value end
    if type(value) ~= 'string' then return {} end
    local ok, decoded = pcall(json.decode, value)
    return ok and type(decoded) == 'table' and decoded or {}
end

local function normalizeMember(row)
    if not row then return nil end
    row.permissions = decodePermissionList(row.permissions)
    row.isOwner = row.isOwner == true or row.isOwner == 1
    if row.retentionRequired ~= nil then
        row.retentionRequired = row.retentionRequired == true or row.retentionRequired == 1
    end
    return row
end

local function safeSingle(query, values)
    local ok, result = pcall(function() return MySQL.single.await(query, values or {}) end)
    if not ok then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    return result
end

local function safeQuery(query, values)
    local ok, result = pcall(function() return MySQL.query.await(query, values or {}) end)
    if not ok or result == nil then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    return result
end

local function safeScalar(query, values)
    local ok, result = pcall(function() return MySQL.scalar.await(query, values or {}) end)
    if not ok or result == nil then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    return result
end

local function findProcedureResult(value)
    if type(value) ~= 'table' then return nil end
    if value.ok ~= nil or value.errorCode ~= nil then return value end
    for i = 1, #value do
        local found = findProcedureResult(value[i])
        if found then return found end
    end
    return nil
end

local function callProcedure(name, values)
    local placeholders = {}
    for i = 1, #values do placeholders[i] = '?' end
    local ok, result = pcall(function()
        return MySQL.query.await(('CALL %s(%s)'):format(name, table.concat(placeholders, ',')), values)
    end)
    if not ok or result == nil then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local row = findProcedureResult(result)
    if not row or tonumber(row.ok) ~= 1 then return nil, row and row.errorCode or CEN.Errors.CONFLICT end
    return row
end

local membershipSelect = [[SELECT
    m.id AS memberId,
    m.enterprise_id AS enterpriseId,
    m.rank_id AS rankId,
    m.player_identifier AS playerIdentifier,
    m.display_name AS displayName,
    m.status,
    m.individual_xp AS individualXp,
    CASE WHEN e.owner_member_id = m.id THEN 1 ELSE 0 END AS isOwner,
    r.name AS rankName,
    r.priority AS rankPriority,
    r.permissions,
    e.enterprise_type AS enterpriseType,
    e.name AS enterpriseName,
    e.level,
    e.xp,
    e.heat,
    e.creation_plan AS creationPlan,
    e.base_member_limit AS baseMemberLimit,
    e.retention_required AS retentionRequired,
    e.retention_status AS retentionStatus,
    e.disband_scheduled_at AS disbandScheduledAt,
    e.status AS enterpriseStatus
FROM cen_members m
JOIN cen_enterprises e ON e.id = m.enterprise_id
JOIN cen_ranks r ON r.id = m.rank_id AND r.enterprise_id = m.enterprise_id]]

function Repository.IsReady()
    return databaseReady() and schemaVerified
end

function Repository.GetSchemaFailure()
    return schemaFailure
end

function Repository.VerifySchema()
    schemaVerified = false
    schemaFailure = nil
    if not databaseReady() then
        schemaFailure = 'oxmysql_not_started'
        return false, schemaFailure
    end

    if Config.Membership.allowMultipleEnterprises then
        schemaFailure = 'allowMultipleEnterprises_is_not_supported_by_the_security_schema'
        return false, schemaFailure
    end

    local checks = {
        {
            name = 'unique_member_index',
            query = [[SELECT COUNT(*) FROM information_schema.STATISTICS
              WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'cen_members'
                AND INDEX_NAME = 'uq_cen_member_player' AND NON_UNIQUE = 0
                AND COLUMN_NAME = 'player_identifier' AND SEQ_IN_INDEX = 1]],
            expected = function(value) return tonumber(value) == 1 end
        },
        {
            name = 'membership_invite_table',
            query = [[SELECT COUNT(*) FROM information_schema.TABLES
              WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'cen_membership_invites']],
            expected = function(value) return tonumber(value) == 1 end
        },
        {
            name = 'v03_required_tables',
            query = [[SELECT COUNT(*) FROM information_schema.TABLES
              WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN (
                'cen_founding_proposals','cen_founding_invites','cen_founding_participants',
                'cen_enterprise_entitlements','cen_member_activity'
              )]],
            expected = function(value) return tonumber(value) == 5 end
        },
        {
            name = 'retention_columns',
            query = [[SELECT COUNT(*) FROM information_schema.COLUMNS
              WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'cen_enterprises'
                AND COLUMN_NAME IN (
                  'creation_plan','base_member_limit','retention_required','retention_status',
                  'retention_warning_cycle','retention_failure_cycle','disband_scheduled_at','disbanded_at'
                )]],
            expected = function(value) return tonumber(value) == 8 end
        },
        {
            name = 'atomic_procedures',
            query = [[SELECT COUNT(*) FROM information_schema.ROUTINES
              WHERE ROUTINE_SCHEMA = DATABASE() AND ROUTINE_TYPE = 'PROCEDURE'
                AND ROUTINE_NAME IN (
                  'cen_accept_membership_invite','cen_create_founding_proposal',
                  'cen_accept_founding_invite','cen_cancel_founding_proposal',
                  'cen_create_enterprise_direct','cen_finalize_founding_proposal'
                )]],
            expected = function(value) return tonumber(value) == 6 end
        },
        {
            name = 'core_mvp_tables',
            query = [[SELECT COUNT(*) FROM information_schema.TABLES
              WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN (
                'cen_treasury_transactions','cen_xp_events','cen_zones','cen_zone_contests'
              )]],
            expected = function(value) return tonumber(value) == 4 end
        },
        {
            name = 'core_mvp_procedures',
            query = [[SELECT COUNT(*) FROM information_schema.ROUTINES
              WHERE ROUTINE_SCHEMA = DATABASE() AND ROUTINE_TYPE = 'PROCEDURE'
                AND ROUTINE_NAME IN ('cen_treasury_deposit','cen_treasury_withdraw')]],
            expected = function(value) return tonumber(value) == 2 end
        },
        {
            name = 'criminal_operations_tables',
            query = [[SELECT COUNT(*) FROM information_schema.TABLES
              WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN (
                'cen_facilities','cen_production_jobs','cen_market_listings','cen_market_sales',
                'cen_market_deliveries','cen_shipments','cen_corruption_offers','cen_corruption_contacts'
              )]],
            expected = function(value) return tonumber(value) == 8 end
        },
        {
            name = 'criminal_operations_procedures',
            query = [[SELECT COUNT(*) FROM information_schema.ROUTINES
              WHERE ROUTINE_SCHEMA = DATABASE() AND ROUTINE_TYPE = 'PROCEDURE'
                AND ROUTINE_NAME IN ('cen_market_purchase','cen_request_shipment','cen_accept_corruption_offer')]],
            expected = function(value) return tonumber(value) == 3 end
        },
        {
            name = 'phase2_tables',
            query = [[SELECT COUNT(*) FROM information_schema.TABLES
              WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN (
                'cen_crews','cen_crew_members','cen_diplomacy_relations','cen_diplomacy_proposals',
                'cen_wars','cen_war_events','cen_front_businesses','cen_laundering_jobs','cen_rackets'
              )]],
            expected = function(value) return tonumber(value) == 9 end
        },
        {
            name = 'phase2_procedures',
            query = [[SELECT COUNT(*) FROM information_schema.ROUTINES
              WHERE ROUTINE_SCHEMA = DATABASE() AND ROUTINE_TYPE = 'PROCEDURE'
                AND ROUTINE_NAME IN (
                  'cen_remove_enterprise_member','cen_soft_disband_enterprise',
                  'cen_create_crew','cen_assign_crew_member','cen_remove_crew_member','cen_set_crew_leader','cen_delete_crew',
                  'cen_propose_diplomacy','cen_respond_diplomacy','cen_cancel_diplomacy','cen_end_diplomacy',
                  'cen_propose_war','cen_respond_war','cen_cancel_war','cen_add_war_score','cen_finalize_war',
                  'cen_create_front','cen_start_laundering_job','cen_claim_laundering_treasury','cen_collect_racket'
                )]],
            expected = function(value) return tonumber(value) == 20 end
        },
        {
            name = 'enterprise_heat_column',
            query = [[SELECT COUNT(*) FROM information_schema.COLUMNS
              WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'cen_enterprises' AND COLUMN_NAME = 'heat']],
            expected = function(value) return tonumber(value) == 1 end
        },
        {
            name = 'founding_participation_invariants',
            query = [[SELECT COUNT(*) FROM (
              SELECT p.founder_identifier AS identifier, p.id AS proposal_id, 'founder' AS role
              FROM cen_founding_proposals p
              WHERE p.status IN ('pending','ready','awaiting_approval','finalizing')
                AND p.expires_at > UTC_TIMESTAMP()
              UNION ALL
              SELECT i.invited_identifier AS identifier, i.proposal_id, 'supporter' AS role
              FROM cen_founding_invites i
              JOIN cen_founding_proposals p ON p.id = i.proposal_id
              WHERE i.status = 'accepted'
                AND p.status IN ('pending','ready','awaiting_approval','finalizing')
                AND p.expires_at > UTC_TIMESTAMP()
            ) expected
            LEFT JOIN cen_founding_participants fp
              ON fp.identifier = expected.identifier
             AND fp.proposal_id = expected.proposal_id
             AND fp.role = expected.role
            WHERE fp.identifier IS NULL]],
            expected = function(value) return tonumber(value) == 0 end
        },
        {
            name = 'duplicate_memberships',
            query = [[SELECT COUNT(*) FROM (
              SELECT player_identifier FROM cen_members
              GROUP BY player_identifier HAVING COUNT(*) > 1
            ) duplicates]],
            expected = function(value) return tonumber(value) == 0 end
        },
        {
            name = 'ownerless_active_enterprises',
            query = [[SELECT COUNT(*) FROM cen_enterprises e
              WHERE e.status = 'active' AND (
                e.owner_member_id IS NULL OR NOT EXISTS (
                  SELECT 1 FROM cen_members m
                  WHERE m.id = e.owner_member_id
                    AND m.enterprise_id = e.id
                    AND m.status = 'active'
                )
              )]],
            expected = function(value) return tonumber(value) == 0 end
        },
        {
            name = 'rank_invariants',
            query = [[SELECT COUNT(*) FROM cen_enterprises e
              WHERE e.status = 'active' AND (
                (SELECT COUNT(*) FROM cen_ranks r
                  WHERE r.enterprise_id = e.id AND r.is_default = 1) <> 1
                OR NOT EXISTS (
                  SELECT 1 FROM cen_ranks r
                  WHERE r.enterprise_id = e.id AND r.is_default = 1 AND r.is_protected = 1
                )
                OR COALESCE((
                  SELECT r.is_protected FROM cen_ranks r
                  WHERE r.enterprise_id = e.id
                  ORDER BY r.priority DESC, r.id ASC
                  LIMIT 1
                ), 0) <> 1
              )]],
            expected = function(value) return tonumber(value) == 0 end
        }
    }

    for i = 1, #checks do
        local value, errorCode = safeScalar(checks[i].query)
        if value == nil then
            schemaFailure = ('%s:%s'):format(checks[i].name, tostring(errorCode))
            return false, schemaFailure
        end
        if not checks[i].expected(value) then
            schemaFailure = checks[i].name
            return false, schemaFailure
        end
    end

    schemaVerified = true
    return true
end

function Repository.GetMembershipByIdentifier(identifier)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    if type(identifier) ~= 'string' then return nil, CEN.Errors.LICENSE_MISSING end

    local row, errorCode = safeSingle(membershipSelect .. [[
        WHERE m.player_identifier = ?
          AND m.status = 'active'
          AND e.status = 'active'
        ORDER BY m.id ASC
        LIMIT 1]], { identifier })
    if errorCode then return nil, errorCode end
    if not row then return nil, CEN.Errors.NOT_MEMBER end
    return normalizeMember(row)
end

function Repository.GetMembershipAnyStatus(identifier)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    if type(identifier) ~= 'string' then return nil, CEN.Errors.LICENSE_MISSING end

    local row, errorCode = safeSingle(membershipSelect .. [[
        WHERE m.player_identifier = ?
        ORDER BY m.id ASC
        LIMIT 1]], { identifier })
    if errorCode then return nil, errorCode end
    if not row then return nil, CEN.Errors.NOT_MEMBER end
    return normalizeMember(row)
end

function Repository.GetMembershipBySource(source)
    local identifier = CENServer.Identity.GetIdentifier(source)
    if not identifier then return nil, CEN.Errors.LICENSE_MISSING end
    return Repository.GetMembershipByIdentifier(identifier)
end

function Repository.GetMemberById(enterpriseId, memberId)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local row, errorCode = safeSingle(membershipSelect .. [[
        WHERE m.enterprise_id = ?
          AND m.id = ?
          AND m.status = 'active'
        LIMIT 1]], { enterpriseId, memberId })
    if errorCode then return nil, errorCode end
    if not row then return nil, CEN.Errors.TARGET_NOT_MEMBER end
    return normalizeMember(row)
end

function Repository.GetEnterprise(enterpriseId)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local row, errorCode = safeSingle([[SELECT
        id, name, slug, enterprise_type AS enterpriseType, level, xp, heat,
        creation_plan AS creationPlan, base_member_limit AS baseMemberLimit,
        retention_required AS retentionRequired, retention_status AS retentionStatus,
        disband_scheduled_at AS disbandScheduledAt,
        treasury_balance AS treasuryBalance, owner_member_id AS ownerMemberId, status
      FROM cen_enterprises WHERE id = ? LIMIT 1]], { enterpriseId })
    if errorCode then return nil, errorCode end
    if not row then return nil, CEN.Errors.INVALID_ENTERPRISE end
    row.retentionRequired = row.retentionRequired == true or row.retentionRequired == 1
    return row
end

function Repository.ListMembers(enterpriseId)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local rows, errorCode = safeQuery([[SELECT
        m.id AS memberId,
        m.player_identifier AS playerIdentifier,
        m.display_name AS displayName,
        m.individual_xp AS individualXp,
        m.joined_at AS joinedAt,
        CASE WHEN e.owner_member_id = m.id THEN 1 ELSE 0 END AS isOwner,
        r.id AS rankId,
        r.name AS rankName,
        r.priority AS rankPriority
      FROM cen_members m
      JOIN cen_enterprises e ON e.id = m.enterprise_id
      JOIN cen_ranks r ON r.id = m.rank_id AND r.enterprise_id = m.enterprise_id
      WHERE m.enterprise_id = ? AND m.status = 'active'
      ORDER BY isOwner DESC, r.priority DESC, m.joined_at ASC]], { enterpriseId })
    if not rows then return nil, errorCode end

    for i = 1, #rows do
        local row = rows[i]
        row.isOwner = row.isOwner == true or row.isOwner == 1
        row.online = CENServer.Identity.GetSourceByIdentifier(row.playerIdentifier) ~= nil
        row.playerIdentifier = nil
    end
    return rows
end

function Repository.ListRanks(enterpriseId)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local rows, errorCode = safeQuery([[SELECT
        r.id AS rankId,
        r.enterprise_id AS enterpriseId,
        r.name,
        r.priority,
        r.permissions,
        r.is_default AS isDefault,
        r.is_protected AS isProtected,
        (SELECT COUNT(*) FROM cen_members m
          WHERE m.rank_id = r.id AND m.enterprise_id = r.enterprise_id
            AND m.status = 'active') AS memberCount
      FROM cen_ranks r
      WHERE r.enterprise_id = ?
      ORDER BY r.priority DESC, r.id ASC]], { enterpriseId })
    if not rows then return nil, errorCode end

    for i = 1, #rows do
        rows[i].permissions = decodePermissionList(rows[i].permissions)
        rows[i].isDefault = rows[i].isDefault == true or rows[i].isDefault == 1
        rows[i].isProtected = rows[i].isProtected == true or rows[i].isProtected == 1
    end
    return rows
end

function Repository.GetRank(enterpriseId, rankId)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local row, errorCode = safeSingle([[SELECT
        id AS rankId, enterprise_id AS enterpriseId, name, priority, permissions,
        is_default AS isDefault, is_protected AS isProtected
      FROM cen_ranks WHERE enterprise_id = ? AND id = ? LIMIT 1]], { enterpriseId, rankId })
    if errorCode then return nil, errorCode end
    if not row then return nil, CEN.Errors.INVALID_RANK end
    row.permissions = decodePermissionList(row.permissions)
    row.isDefault = row.isDefault == true or row.isDefault == 1
    row.isProtected = row.isProtected == true or row.isProtected == 1
    return row
end

function Repository.GetDefaultRank(enterpriseId)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local row, errorCode = safeSingle([[SELECT
        id AS rankId, enterprise_id AS enterpriseId, name, priority, permissions,
        is_default AS isDefault, is_protected AS isProtected
      FROM cen_ranks WHERE enterprise_id = ?
      ORDER BY is_default DESC, priority ASC, id ASC LIMIT 1]], { enterpriseId })
    if errorCode then return nil, errorCode end
    if not row then return nil, CEN.Errors.INVALID_RANK end
    row.permissions = decodePermissionList(row.permissions)
    row.isDefault = row.isDefault == true or row.isDefault == 1
    row.isProtected = row.isProtected == true or row.isProtected == 1
    return row
end

function Repository.CountMembers(enterpriseId)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local value, errorCode = safeScalar([[SELECT COUNT(*) FROM cen_members
      WHERE enterprise_id = ? AND status = 'active']], { enterpriseId })
    if value == nil then return nil, errorCode end
    return tonumber(value)
end

function Repository.CountRanks(enterpriseId)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local value, errorCode = safeScalar('SELECT COUNT(*) FROM cen_ranks WHERE enterprise_id = ?', { enterpriseId })
    if value == nil then return nil, errorCode end
    return tonumber(value)
end

function Repository.RankNameExists(enterpriseId, name, excludeRankId)
    local query = [[SELECT COUNT(*) FROM cen_ranks
      WHERE enterprise_id = ? AND LOWER(name) = LOWER(?)]]
    local values = { enterpriseId, name }
    if excludeRankId then
        query = query .. ' AND id <> ?'
        values[#values + 1] = excludeRankId
    end
    local count, errorCode = safeScalar(query, values)
    if count == nil then return nil, errorCode end
    return tonumber(count) > 0
end

function Repository.CreateRank(enterpriseId, name, priority, permissions)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local exists, errorCode = Repository.RankNameExists(enterpriseId, name)
    if exists == nil then return nil, errorCode end
    if exists then return nil, CEN.Errors.RANK_NAME_EXISTS end

    local ok, result = pcall(function()
        return MySQL.insert.await([[INSERT INTO cen_ranks
          (enterprise_id, name, priority, permissions) VALUES (?, ?, ?, ?)]], {
            enterpriseId, name, priority, json.encode(permissions)
        })
    end)
    if not ok or result == nil then return nil, CEN.Errors.CONFLICT end
    return result
end

function Repository.UpdateRank(enterpriseId, rankId, name, priority, permissions)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local exists, errorCode = Repository.RankNameExists(enterpriseId, name, rankId)
    if exists == nil then return nil, errorCode end
    if exists then return nil, CEN.Errors.RANK_NAME_EXISTS end

    local ok, affected = pcall(function()
        return MySQL.update.await([[UPDATE cen_ranks
          SET name = ?, priority = ?, permissions = ?, updated_at = CURRENT_TIMESTAMP
          WHERE enterprise_id = ? AND id = ? AND is_protected = 0]], {
            name, priority, json.encode(permissions), enterpriseId, rankId
        })
    end)
    if not ok then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    if affected ~= 1 then return nil, CEN.Errors.INVALID_RANK end
    return true
end

function Repository.DeleteRank(enterpriseId, rankId)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local memberCount, countError = safeScalar([[SELECT COUNT(*) FROM cen_members
      WHERE enterprise_id = ? AND rank_id = ?]], { enterpriseId, rankId })
    if memberCount == nil then return nil, countError end
    if tonumber(memberCount) > 0 then return nil, CEN.Errors.RANK_IN_USE end

    local ok, affected = pcall(function()
        return MySQL.update.await([[DELETE FROM cen_ranks
          WHERE enterprise_id = ? AND id = ? AND is_protected = 0]], { enterpriseId, rankId })
    end)
    if not ok then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    if affected ~= 1 then return nil, CEN.Errors.INVALID_RANK end
    return true
end

function Repository.AddMember(enterpriseId, rankId, identifier, displayName)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local ok, result = pcall(function()
        return MySQL.insert.await([[INSERT INTO cen_members
          (enterprise_id, rank_id, player_identifier, display_name, status)
          VALUES (?, ?, ?, ?, 'active')]], {
            enterpriseId, rankId, identifier, displayName
        })
    end)
    if not ok or result == nil then return nil, CEN.Errors.TARGET_ALREADY_MEMBER end
    return result
end

function Repository.SetMemberRank(enterpriseId, memberId, rankId)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local ok, affected = pcall(function()
        return MySQL.update.await([[UPDATE cen_members m
          JOIN cen_ranks r ON r.id = ? AND r.enterprise_id = m.enterprise_id
          SET m.rank_id = ?, m.updated_at = CURRENT_TIMESTAMP
          WHERE m.enterprise_id = ? AND m.id = ? AND m.status = 'active']], {
            rankId, rankId, enterpriseId, memberId
        })
    end)
    if not ok then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    if affected ~= 1 then return nil, CEN.Errors.CONFLICT end
    return true
end

function Repository.RemoveMember(enterpriseId, memberId)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local row, errorCode = callProcedure('cen_remove_enterprise_member', { enterpriseId, memberId })
    return row ~= nil, errorCode
end

function Repository.LeaveEnterprise(enterpriseId, memberId)
    return Repository.RemoveMember(enterpriseId, memberId)
end

function Repository.SoftDisband(enterpriseId, ownerMemberId)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local row, errorCode = callProcedure('cen_soft_disband_enterprise', {
        enterpriseId, ownerMemberId, 0
    })
    return row ~= nil, errorCode
end

function Repository.RetentionDisband(enterpriseId)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local row, errorCode = callProcedure('cen_soft_disband_enterprise', {
        enterpriseId, 0, 1
    })
    return row ~= nil, errorCode
end

function Repository.TransferOwnership(enterpriseId, currentOwnerMemberId, targetMemberId)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local ok, affected = pcall(function()
        return MySQL.update.await([[UPDATE cen_enterprises e
          SET e.owner_member_id = ?, e.updated_at = CURRENT_TIMESTAMP
          WHERE e.id = ? AND e.owner_member_id = ?
            AND EXISTS (
              SELECT 1 FROM cen_members target
              WHERE target.id = ? AND target.enterprise_id = e.id AND target.status = 'active'
            )]], {
            targetMemberId, enterpriseId, currentOwnerMemberId, targetMemberId
        })
    end)
    if not ok then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    if affected ~= 1 then return nil, CEN.Errors.OWNERSHIP_TRANSFER_FAILED end
    return true
end

-- Batch lookup used by retention. Returns only the server-internal identifiers
-- and membership ids; it is never exposed to NUI.
function Repository.GetActiveMembershipsByIdentifiers(identifiers)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    if type(identifiers) ~= 'table' or #identifiers == 0 then return {} end
    local placeholders, values = {}, {}
    for i = 1, #identifiers do
        placeholders[i] = '?'
        values[i] = identifiers[i]
    end
    local query = ([[SELECT m.id AS memberId, m.enterprise_id AS enterpriseId,
        m.player_identifier AS playerIdentifier
      FROM cen_members m JOIN cen_enterprises e ON e.id = m.enterprise_id
      WHERE m.status = 'active' AND e.status = 'active'
        AND m.player_identifier IN (%s)]]):format(table.concat(placeholders, ','))
    return safeQuery(query, values)
end

function Repository.RestoreEnterprise(enterpriseId)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local ok, committed = pcall(function()
        return MySQL.transaction.await({
            { query = [[UPDATE cen_enterprises e
                JOIN cen_members owner_member ON owner_member.id = e.owner_member_id
                  AND owner_member.enterprise_id = e.id
                SET e.status = 'active', e.retention_status = IF(e.retention_required = 1, 'healthy', 'exempt'),
                    e.disband_scheduled_at = NULL, e.disbanded_at = NULL, e.updated_at = UTC_TIMESTAMP()
                WHERE e.id = ? AND e.status = 'disbanded' AND owner_member.status = 'removed']], values = { enterpriseId } },
            { query = [[UPDATE cen_members m
                JOIN cen_enterprises e ON e.id = m.enterprise_id
                JOIN cen_ranks r ON r.enterprise_id = e.id AND r.is_default = 1
                SET m.status = 'active', m.rank_id = IF(m.id = e.owner_member_id,
                    (SELECT owner_rank.id FROM cen_ranks owner_rank WHERE owner_rank.enterprise_id = e.id
                     ORDER BY owner_rank.priority DESC, owner_rank.id ASC LIMIT 1), r.id),
                    m.updated_at = UTC_TIMESTAMP()
                WHERE m.enterprise_id = ? AND m.status = 'removed' AND e.status = 'active']], values = { enterpriseId } }
        })
    end)
    if not ok or committed ~= true then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local status = safeScalar('SELECT status FROM cen_enterprises WHERE id = ?', { enterpriseId })
    if status ~= 'active' then return nil, CEN.Errors.CONFLICT end
    return true
end
