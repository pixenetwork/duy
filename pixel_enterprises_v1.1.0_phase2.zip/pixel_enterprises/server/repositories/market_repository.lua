CENServer = CENServer or {}
CENServer.MarketRepository = CENServer.MarketRepository or {}
local Repository = CENServer.MarketRepository

local function findResultRow(value)
    if type(value) ~= 'table' then return nil end
    if value.ok ~= nil or value.errorCode ~= nil then return value end
    for i = 1, #value do local found = findResultRow(value[i]); if found then return found end end
end

local function decode(value)
    if type(value) == 'table' then return value end
    if type(value) ~= 'string' or value == '' then return {} end
    local ok, parsed = pcall(json.decode, value); return ok and type(parsed) == 'table' and parsed or {}
end

function Repository.List(enterpriseId, limit)
    local ok, data = pcall(function()
        MySQL.update.await([[UPDATE cen_market_listings SET status = 'expired'
          WHERE status = 'active' AND expires_at <= UTC_TIMESTAMP()]])
        local listings = MySQL.query.await([[SELECT l.id AS listingId, l.seller_enterprise_id AS sellerEnterpriseId,
          e.name AS sellerName, e.enterprise_type AS sellerType, l.category, l.item_name AS itemName,
          l.quantity_remaining AS quantityRemaining, l.unit_price AS unitPrice, l.quality, l.batch_id AS batchId,
          l.status, l.metadata, DATE_FORMAT(l.expires_at, '%Y-%m-%d %H:%i:%s') AS expiresAt
          FROM cen_market_listings l JOIN cen_enterprises e ON e.id = l.seller_enterprise_id
          WHERE l.status = 'active' AND l.expires_at > UTC_TIMESTAMP()
          ORDER BY l.id DESC LIMIT ?]], { math.max(1, math.min(200, tonumber(limit) or 100)) })
        local deliveries = MySQL.query.await([[SELECT id AS deliveryId, source_type AS sourceType,
          item_name AS itemName, quantity, quality, batch_id AS batchId, status, metadata,
          DATE_FORMAT(created_at, '%Y-%m-%d %H:%i:%s') AS createdAt
          FROM cen_market_deliveries WHERE enterprise_id = ? AND status IN ('pending','claiming')
          ORDER BY id DESC LIMIT 100]], { enterpriseId })
        local own = MySQL.query.await([[SELECT id AS listingId, category, item_name AS itemName,
          quantity_remaining AS quantityRemaining, unit_price AS unitPrice, quality, status,
          DATE_FORMAT(expires_at, '%Y-%m-%d %H:%i:%s') AS expiresAt
          FROM cen_market_listings WHERE seller_enterprise_id = ? ORDER BY id DESC LIMIT 50]], { enterpriseId })
        return { listings = listings or {}, deliveries = deliveries or {}, ownListings = own or {} }
    end)
    if not ok or not data then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    for _, collection in pairs({ data.listings, data.deliveries, data.ownListings }) do
        for i = 1, #collection do
            local r = collection[i]
            r.listingId = tonumber(r.listingId); r.deliveryId = tonumber(r.deliveryId)
            r.sellerEnterpriseId = tonumber(r.sellerEnterpriseId)
            r.quantityRemaining = tonumber(r.quantityRemaining); r.quantity = tonumber(r.quantity)
            r.unitPrice = tonumber(r.unitPrice); r.quality = tonumber(r.quality)
            r.metadata = decode(r.metadata)
        end
    end
    return data
end

function Repository.CreateListing(enterpriseId, memberId, category, itemName, quantity, unitPrice, quality, batchId, metadata)
    local ok, id = pcall(function()
        return MySQL.insert.await([[INSERT INTO cen_market_listings
          (seller_enterprise_id, created_by_member_id, category, item_name, quantity_initial,
           quantity_remaining, unit_price, quality, batch_id, metadata, expires_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, DATE_ADD(UTC_TIMESTAMP(), INTERVAL ? HOUR))]], {
            enterpriseId, memberId, category, itemName, quantity, quantity, unitPrice, quality,
            batchId, json.encode(metadata or {}), math.max(1, tonumber(Config.Operations.listingExpiryHours) or 72)
        })
    end)
    if not ok or not id then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    return tonumber(id)
end

function Repository.GetListing(listingId)
    local ok, row = pcall(function()
        return MySQL.single.await([[SELECT l.id AS listingId, l.seller_enterprise_id AS sellerEnterpriseId,
          e.enterprise_type AS sellerType, l.category, l.item_name AS itemName,
          l.quantity_remaining AS quantityRemaining, l.unit_price AS unitPrice, l.quality,
          l.batch_id AS batchId, l.status, DATE_FORMAT(l.expires_at, '%Y-%m-%d %H:%i:%s') AS expiresAt,
          CASE WHEN l.expires_at > UTC_TIMESTAMP() THEN 1 ELSE 0 END AS unexpired
          FROM cen_market_listings l JOIN cen_enterprises e ON e.id = l.seller_enterprise_id WHERE l.id = ?]], { listingId })
    end)
    if not ok then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    if not row then return nil, CEN.Errors.LISTING_NOT_FOUND end
    row.listingId = tonumber(row.listingId); row.sellerEnterpriseId = tonumber(row.sellerEnterpriseId)
    row.quantityRemaining = tonumber(row.quantityRemaining); row.unitPrice = tonumber(row.unitPrice)
    row.quality = tonumber(row.quality); row.unexpired = tonumber(row.unexpired) == 1
    return row
end

function Repository.Purchase(listingId, enterpriseId, memberId, quantity)
    local ok, result = pcall(function()
        return MySQL.query.await('CALL cen_market_purchase(?,?,?,?)', { listingId, enterpriseId, memberId, quantity })
    end)
    if not ok or not result then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local row = findResultRow(result)
    if not row then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    if tonumber(row.ok) ~= 1 then return nil, row.errorCode or CEN.Errors.CONFLICT end
    row.deliveryId = tonumber(row.deliveryId); row.totalPrice = tonumber(row.totalPrice)
    return row
end

function Repository.CancelListing(listingId, enterpriseId)
    local ok, success = pcall(function()
        return MySQL.transaction.await({
            { query = [[INSERT INTO cen_market_deliveries
                (enterprise_id, source_type, source_id, item_name, quantity, quality, batch_id, metadata)
              SELECT seller_enterprise_id, 'listing_return', id, item_name, quantity_remaining, quality, batch_id,
                JSON_OBJECT('listingId', id)
              FROM cen_market_listings WHERE id = ? AND seller_enterprise_id = ?
                AND status = 'active' AND quantity_remaining > 0]], values = { listingId, enterpriseId } },
            { query = [[UPDATE cen_market_listings SET status = 'cancelled'
              WHERE id = ? AND seller_enterprise_id = ? AND status = 'active']], values = { listingId, enterpriseId } }
        })
    end)
    if not ok or success ~= true then return false, CEN.Errors.CONFLICT end
    return true
end

function Repository.MarkDeliveryClaiming(deliveryId, enterpriseId)
    local ok, affected = pcall(function()
        return MySQL.update.await([[UPDATE cen_market_deliveries SET status = 'claiming'
          WHERE id = ? AND enterprise_id = ? AND status = 'pending']], { deliveryId, enterpriseId })
    end)
    if not ok then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    if tonumber(affected) ~= 1 then return nil, CEN.Errors.CONFLICT end
    local row = MySQL.single.await([[SELECT id AS deliveryId, item_name AS itemName, quantity,
      quality, batch_id AS batchId, metadata FROM cen_market_deliveries WHERE id = ?]], { deliveryId })
    if not row then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    row.deliveryId = tonumber(row.deliveryId); row.quantity = tonumber(row.quantity); row.quality = tonumber(row.quality)
    row.metadata = decode(row.metadata)
    return row
end

function Repository.CompleteDelivery(deliveryId, enterpriseId, memberId)
    local ok, affected = pcall(function()
        return MySQL.update.await([[UPDATE cen_market_deliveries SET status = 'claimed',
          claimed_by_member_id = ?, claimed_at = UTC_TIMESTAMP()
          WHERE id = ? AND enterprise_id = ? AND status = 'claiming']], { memberId, deliveryId, enterpriseId })
    end)
    return ok and tonumber(affected) == 1
end

function Repository.ResetDelivery(deliveryId, enterpriseId)
    pcall(function() MySQL.update.await([[UPDATE cen_market_deliveries SET status = 'pending'
      WHERE id = ? AND enterprise_id = ? AND status = 'claiming']], { deliveryId, enterpriseId }) end)
end

function Repository.FindTurfAt(coords)
    local ok, row = pcall(function()
        return MySQL.single.await([[SELECT id AS zoneId, owner_enterprise_id AS ownerEnterpriseId,
          name, radius, center_x AS centerX, center_y AS centerY
          FROM cen_zones WHERE zone_type = 'turf' AND status = 'active'
            AND POW(center_x - ?, 2) + POW(center_y - ?, 2) <= POW(radius, 2)
          ORDER BY owner_enterprise_id IS NOT NULL DESC, radius ASC LIMIT 1]], { coords.x, coords.y })
    end)
    if not ok then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    if row then row.zoneId = tonumber(row.zoneId); row.ownerEnterpriseId = tonumber(row.ownerEnterpriseId) end
    return row
end
