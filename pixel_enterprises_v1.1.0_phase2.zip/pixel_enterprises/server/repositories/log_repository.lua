CENServer = CENServer or {}
CENServer.LogRepository = CENServer.LogRepository or {}
local Repository = CENServer.LogRepository

function Repository.List(enterpriseId, beforeId, limit)
    limit = math.max(1, math.min(Config.Logs.maximumPageSize, tonumber(limit) or Config.Logs.pageSize))
    local query = [[SELECT a.id, a.event_name AS eventName, a.payload, a.created_at AS createdAt,
        COALESCE(m.display_name, CASE WHEN a.actor_identifier = 'system' THEN 'System' ELSE 'Former member' END) AS actorDisplayName
      FROM cen_audit_logs a
      LEFT JOIN cen_members m ON m.player_identifier = a.actor_identifier
      WHERE a.enterprise_id = ?]]
    local values = { enterpriseId }
    if tonumber(beforeId) then
        query = query .. ' AND a.id < ?'
        values[#values + 1] = tonumber(beforeId)
    end
    query = query .. ' ORDER BY a.id DESC LIMIT ?'
    values[#values + 1] = limit
    local ok, rows = pcall(function() return MySQL.query.await(query, values) end)
    if not ok or rows == nil then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    for i = 1, #rows do
        if type(rows[i].payload) == 'string' then
            local decodedOk, decoded = pcall(json.decode, rows[i].payload)
            rows[i].payload = decodedOk and type(decoded) == 'table' and decoded or {}
        elseif type(rows[i].payload) ~= 'table' then
            rows[i].payload = {}
        end
        rows[i].payload.actorIdentifier = nil
        rows[i].payload.playerIdentifier = nil
        rows[i].payload.targetIdentifier = nil
    end
    return rows
end
