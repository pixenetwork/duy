CENServer = CENServer or {}
CENServer.MembershipInviteRepository = CENServer.MembershipInviteRepository or {}

local Repository = CENServer.MembershipInviteRepository

local function databaseReady()
    return GetResourceState('oxmysql') == 'started'
end

local function findResultRow(value)
    if type(value) ~= 'table' then return nil end
    if value.success ~= nil or value.errorCode ~= nil or value.enterpriseId ~= nil then
        return value
    end
    for i = 1, #value do
        local found = findResultRow(value[i])
        if found then return found end
    end
    return nil
end

function Repository.ExpireOld()
    if not databaseReady() then return false end
    local ok = pcall(function()
        MySQL.update.await([[UPDATE cen_membership_invites
          SET status = 'expired', responded_at = UTC_TIMESTAMP()
          WHERE status = 'pending' AND expires_at <= UTC_TIMESTAMP()]])
    end)
    return ok
end

function Repository.ListPendingForIdentifier(identifier)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local ok, rows = pcall(function()
        return MySQL.query.await([[SELECT
            i.id AS inviteId,
            i.enterprise_id AS enterpriseId,
            e.name AS enterpriseName,
            e.enterprise_type AS enterpriseType,
            r.id AS rankId,
            r.name AS rankName,
            i.expires_at AS expiresAt,
            i.created_at AS createdAt
          FROM cen_membership_invites i
          JOIN cen_enterprises e ON e.id = i.enterprise_id AND e.status = 'active'
          JOIN cen_ranks r ON r.id = i.rank_id AND r.enterprise_id = i.enterprise_id
          WHERE i.invited_identifier = ?
            AND i.status = 'pending'
            AND i.expires_at > UTC_TIMESTAMP()
          ORDER BY i.created_at DESC]], { identifier })
    end)
    if not ok or rows == nil then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    return rows
end

function Repository.GetPendingById(inviteId, identifier)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local ok, row = pcall(function()
        return MySQL.single.await([[SELECT
            i.id AS inviteId,
            i.enterprise_id AS enterpriseId,
            i.rank_id AS rankId,
            i.invited_identifier AS invitedIdentifier,
            i.invited_display_name AS invitedDisplayName,
            i.invited_by_member_id AS invitedByMemberId,
            i.expires_at AS expiresAt,
            e.name AS enterpriseName,
            e.enterprise_type AS enterpriseType,
            e.base_member_limit AS baseMemberLimit,
            e.status AS enterpriseStatus,
            r.name AS rankName
          FROM cen_membership_invites i
          JOIN cen_enterprises e ON e.id = i.enterprise_id
          JOIN cen_ranks r ON r.id = i.rank_id AND r.enterprise_id = i.enterprise_id
          WHERE i.id = ?
            AND i.invited_identifier = ?
            AND i.status = 'pending'
            AND i.expires_at > UTC_TIMESTAMP()
            AND e.status = 'active'
          LIMIT 1]], { inviteId, identifier })
    end)
    if not ok then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    if not row then return nil, CEN.Errors.MEMBERSHIP_INVITE_NOT_FOUND end
    return row
end

function Repository.Create(enterpriseId, invitedIdentifier, invitedDisplayName, invitedByMemberId, rankId)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local hours = math.max(1, tonumber(Config.Membership.inviteExpiryHours) or 72)

    local ok, inviteId = pcall(function()
        MySQL.update.await([[UPDATE cen_membership_invites
          SET status = 'expired', responded_at = UTC_TIMESTAMP()
          WHERE enterprise_id = ? AND invited_identifier = ?
            AND status = 'pending' AND expires_at <= UTC_TIMESTAMP()]], {
            enterpriseId, invitedIdentifier
        })

        local existing = MySQL.single.await([[SELECT id FROM cen_membership_invites
          WHERE enterprise_id = ? AND invited_identifier = ?
            AND status = 'pending' AND expires_at > UTC_TIMESTAMP()
          ORDER BY id ASC LIMIT 1]], { enterpriseId, invitedIdentifier })

        if existing then
            local affected = MySQL.update.await([[UPDATE cen_membership_invites
              SET rank_id = ?, invited_display_name = ?, invited_by_member_id = ?,
                  expires_at = DATE_ADD(UTC_TIMESTAMP(), INTERVAL ? HOUR), responded_at = NULL
              WHERE id = ? AND status = 'pending']], {
                rankId, invitedDisplayName, invitedByMemberId, hours, existing.id
            })
            if affected ~= 1 then error('invite_refresh_failed') end
            return tonumber(existing.id)
        end

        return MySQL.insert.await([[INSERT INTO cen_membership_invites
          (enterprise_id, rank_id, invited_identifier, invited_display_name,
           invited_by_member_id, status, expires_at)
          VALUES (?, ?, ?, ?, ?, 'pending', DATE_ADD(UTC_TIMESTAMP(), INTERVAL ? HOUR))]], {
            enterpriseId, rankId, invitedIdentifier, invitedDisplayName,
            invitedByMemberId, hours
        })
    end)

    if not ok or inviteId == nil then return nil, CEN.Errors.CONFLICT end
    return tonumber(inviteId)
end

function Repository.Accept(invite, displayName)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end

    local ok, results = pcall(function()
        return MySQL.query.await('CALL cen_accept_membership_invite(?, ?, ?, ?)', {
            invite.inviteId,
            invite.invitedIdentifier,
            displayName or invite.invitedDisplayName or 'Unknown',
            Config.Membership.absoluteMemberLimit
        })
    end)
    if not ok or results == nil then return nil, CEN.Errors.DATABASE_UNAVAILABLE end

    local row = findResultRow(results)
    if not row then return nil, CEN.Errors.CONFLICT end
    if tonumber(row.success) ~= 1 then
        return nil, row.errorCode or CEN.Errors.CONFLICT
    end
    return true, nil, tonumber(row.enterpriseId)
end

function Repository.Decline(inviteId, identifier)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local ok, affected = pcall(function()
        return MySQL.update.await([[UPDATE cen_membership_invites
          SET status = 'declined', responded_at = UTC_TIMESTAMP()
          WHERE id = ? AND invited_identifier = ? AND status = 'pending']], {
            inviteId, identifier
        })
    end)
    if not ok then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    if affected ~= 1 then return nil, CEN.Errors.MEMBERSHIP_INVITE_NOT_FOUND end
    return true
end

function Repository.CancelPendingForEnterprise(enterpriseId)
    if not databaseReady() then return false end
    local ok = pcall(function()
        MySQL.update.await([[UPDATE cen_membership_invites
          SET status = 'cancelled', responded_at = UTC_TIMESTAMP()
          WHERE enterprise_id = ? AND status = 'pending']], { enterpriseId })
    end)
    return ok
end
