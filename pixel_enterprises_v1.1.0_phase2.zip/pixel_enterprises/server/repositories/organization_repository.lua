CENServer = CENServer or {}
CENServer.OrganizationRepository = CENServer.OrganizationRepository or {}
local Repository = CENServer.OrganizationRepository


local function findResultRow(value)
    if type(value) ~= 'table' then return nil end
    if value.ok ~= nil or value.errorCode ~= nil then return value end
    for i = 1, #value do
        local found = findResultRow(value[i])
        if found then return found end
    end
    return nil
end

local function call(name, values)
    local placeholders = {}
    for i = 1, #values do placeholders[i] = '?' end
    local ok, result = pcall(function()
        return MySQL.query.await(('CALL %s(%s)'):format(name, table.concat(placeholders, ',')), values)
    end)
    if not ok or result == nil then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local row = findResultRow(result)
    if not row or tonumber(row.ok) ~= 1 then
        return nil, row and row.errorCode or CEN.Errors.CONFLICT
    end
    if row.crewId then row.crewId = tonumber(row.crewId) end
    if row.proposalId then row.proposalId = tonumber(row.proposalId) end
    return row
end

function Repository.ListCrews(enterpriseId)
    local ok, rows = pcall(function()
        return MySQL.query.await([[SELECT c.id AS crewId, c.name, c.leader_member_id AS leaderMemberId,
          COALESCE(leader.display_name, 'Unassigned') AS leaderDisplayName, c.max_members AS maxMembers,
          COUNT(cm.member_id) AS memberCount, c.created_at AS createdAt
        FROM cen_crews c
        LEFT JOIN cen_members leader ON leader.id = c.leader_member_id
        LEFT JOIN cen_crew_members cm ON cm.crew_id = c.id
        WHERE c.enterprise_id = ? AND c.status = 'active'
        GROUP BY c.id, c.name, c.leader_member_id, leader.display_name, c.max_members, c.created_at
        ORDER BY c.name]], { enterpriseId })
    end)
    if not ok or rows == nil then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local membersOk, members = pcall(function()
        return MySQL.query.await([[SELECT cm.crew_id AS crewId, m.id AS memberId, m.display_name AS displayName,
          cm.role, r.name AS rankName
        FROM cen_crew_members cm
        JOIN cen_members m ON m.id = cm.member_id AND m.status = 'active'
        JOIN cen_ranks r ON r.id = m.rank_id
        JOIN cen_crews c ON c.id = cm.crew_id
        WHERE c.enterprise_id = ? AND c.status = 'active'
        ORDER BY cm.role = 'leader' DESC, m.display_name]], { enterpriseId })
    end)
    if not membersOk or members == nil then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local byCrew = {}
    for i = 1, #rows do
        rows[i].crewId = tonumber(rows[i].crewId)
        rows[i].leaderMemberId = tonumber(rows[i].leaderMemberId)
        rows[i].maxMembers = tonumber(rows[i].maxMembers) or 0
        rows[i].memberCount = tonumber(rows[i].memberCount) or 0
        rows[i].members = {}
        byCrew[rows[i].crewId] = rows[i]
    end
    for i = 1, #members do
        local crew = byCrew[tonumber(members[i].crewId)]
        if crew then
            members[i].crewId = tonumber(members[i].crewId)
            members[i].memberId = tonumber(members[i].memberId)
            crew.members[#crew.members + 1] = members[i]
        end
    end
    return rows
end

function Repository.CreateCrew(enterpriseId, name, leaderMemberId, maxMembers, maximumCrews)
    local row, errorCode = call('cen_create_crew', {
        enterpriseId, name, leaderMemberId, maxMembers, maximumCrews
    })
    return row and row.crewId or nil, errorCode
end

function Repository.AssignCrewMember(enterpriseId, crewId, memberId)
    local row, errorCode = call('cen_assign_crew_member', { enterpriseId, crewId, memberId })
    return row ~= nil, errorCode
end

function Repository.RemoveCrewMember(enterpriseId, crewId, memberId)
    local row, errorCode = call('cen_remove_crew_member', { enterpriseId, crewId, memberId })
    return row ~= nil, errorCode
end

function Repository.DeleteCrew(enterpriseId, crewId)
    local row, errorCode = call('cen_delete_crew', { enterpriseId, crewId })
    return row ~= nil, errorCode
end

function Repository.SetCrewLeader(enterpriseId, crewId, memberId)
    local row, errorCode = call('cen_set_crew_leader', { enterpriseId, crewId, memberId })
    return row ~= nil, errorCode
end

local function pair(a, b)
    a, b = tonumber(a), tonumber(b)
    return math.min(a, b), math.max(a, b)
end

function Repository.ListDiplomacy(enterpriseId, directoryLimit)
    local ok, result = pcall(function()
        local relations = MySQL.query.await([[SELECT r.id AS relationId, r.relation_type AS relationType,
          r.established_by AS establishedBy, r.expires_at AS expiresAt,
          CASE WHEN r.enterprise_low_id = ? THEN r.enterprise_high_id ELSE r.enterprise_low_id END AS otherEnterpriseId,
          CASE WHEN r.enterprise_low_id = ? THEN high.name ELSE low.name END AS otherEnterpriseName
        FROM cen_diplomacy_relations r
        JOIN cen_enterprises low ON low.id = r.enterprise_low_id
        JOIN cen_enterprises high ON high.id = r.enterprise_high_id
        WHERE (r.enterprise_low_id = ? OR r.enterprise_high_id = ?)
          AND (r.expires_at IS NULL OR r.expires_at > UTC_TIMESTAMP())
        ORDER BY r.relation_type, otherEnterpriseName]], { enterpriseId, enterpriseId, enterpriseId, enterpriseId })
        local proposals = MySQL.query.await([[SELECT p.id AS proposalId, p.proposer_enterprise_id AS proposerEnterpriseId,
          proposer.name AS proposerName, p.target_enterprise_id AS targetEnterpriseId,
          target.name AS targetName, p.relation_type AS relationType, p.message, p.status,
          p.expires_at AS expiresAt, p.created_at AS createdAt
        FROM cen_diplomacy_proposals p
        JOIN cen_enterprises proposer ON proposer.id = p.proposer_enterprise_id
        JOIN cen_enterprises target ON target.id = p.target_enterprise_id
        WHERE (p.proposer_enterprise_id = ? OR p.target_enterprise_id = ?)
          AND p.status = 'pending' AND p.expires_at > UTC_TIMESTAMP()
        ORDER BY p.created_at DESC]], { enterpriseId, enterpriseId })
        local directory = MySQL.query.await([[SELECT id AS enterpriseId, name, enterprise_type AS enterpriseType,
          level FROM cen_enterprises WHERE status = 'active' AND id <> ?
          ORDER BY level DESC, name LIMIT ?]], { enterpriseId, math.max(1, math.min(250, tonumber(directoryLimit) or 100)) })
        return { relations = relations or {}, proposals = proposals or {}, directory = directory or {} }
    end)
    if not ok or not result then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    for _, list in pairs(result) do
        for i = 1, #list do
            for _, key in ipairs({ 'relationId', 'otherEnterpriseId', 'proposalId', 'proposerEnterpriseId', 'targetEnterpriseId', 'enterpriseId', 'level' }) do
                if list[i][key] ~= nil then list[i][key] = tonumber(list[i][key]) end
            end
            if list[i].enterpriseType then
                local definition = CEN.EnterpriseTypes[list[i].enterpriseType]
                list[i].tier = definition and tonumber(definition.tier) or 0
            end
        end
    end
    return result
end

function Repository.CreateDiplomacyProposal(proposerId, targetId, memberId, relationType, message, expiryHours, cooldownSeconds)
    local row, errorCode = call('cen_propose_diplomacy', {
        proposerId, targetId, memberId, relationType, message, expiryHours, cooldownSeconds
    })
    return row and row.proposalId or nil, errorCode
end

function Repository.RespondDiplomacy(proposalId, targetEnterpriseId, accepted, ceasefireHours)
    local row, errorCode = call('cen_respond_diplomacy', {
        proposalId, targetEnterpriseId, accepted and 1 or 0, ceasefireHours
    })
    return row ~= nil, errorCode
end

function Repository.EndRelation(enterpriseId, relationId)
    local row, errorCode = call('cen_end_diplomacy', { enterpriseId, relationId })
    return row ~= nil, errorCode
end

function Repository.CancelDiplomacy(proposalId, proposerEnterpriseId)
    local row, errorCode = call('cen_cancel_diplomacy', { proposalId, proposerEnterpriseId })
    return row ~= nil, errorCode
end

function Repository.AreEnemies(a, b)
    local low, high = pair(a, b)
    local ok, count = pcall(function()
        return MySQL.scalar.await([[SELECT COUNT(*) FROM cen_diplomacy_relations
          WHERE enterprise_low_id = ? AND enterprise_high_id = ? AND relation_type = 'enemy'
            AND (expires_at IS NULL OR expires_at > UTC_TIMESTAMP())]], { low, high })
    end)
    return ok and tonumber(count) and tonumber(count) > 0
end
