CENServer = CENServer or {}
CENServer.EntitlementRepository = CENServer.EntitlementRepository or {}

local Repository = CENServer.EntitlementRepository

local function databaseReady()
    return GetResourceState('oxmysql') == 'started'
end

function Repository.ResolveEnterprise(reference)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local numeric = tonumber(reference)
    local ok, row = pcall(function()
        if numeric and numeric > 0 then
            return MySQL.single.await([[SELECT id, name, slug FROM cen_enterprises
              WHERE id = ? AND status = 'active' LIMIT 1]], { numeric })
        end
        return MySQL.single.await([[SELECT id, name, slug FROM cen_enterprises
          WHERE slug = ? AND status = 'active' LIMIT 1]], { tostring(reference) })
    end)
    if not ok then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    if not row then return nil, CEN.Errors.INVALID_ENTERPRISE end
    return row
end


function Repository.GetGrant(grantKey)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    if not CEN.Validation.ValidGrantKey(grantKey) then return nil, CEN.Errors.INVALID_GRANT_KEY end
    local ok, row = pcall(function()
        return MySQL.single.await([[SELECT id, enterprise_id AS enterpriseId,
            package_key AS packageKey, quantity, status
          FROM cen_enterprise_entitlements
          WHERE grant_key = ? AND provider = 'tebex' LIMIT 1]], { grantKey })
    end)
    if not ok then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    if not row then return nil, CEN.Errors.ENTITLEMENT_NOT_FOUND end
    return row
end

function Repository.GetActiveExtraMemberSlots(enterpriseId)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local ok, total = pcall(function()
        return MySQL.scalar.await([[SELECT COALESCE(SUM(quantity), 0)
          FROM cen_enterprise_entitlements
          WHERE enterprise_id = ? AND entitlement_type = 'member_slots'
            AND status = 'active' AND (expires_at IS NULL OR expires_at > UTC_TIMESTAMP())]], { enterpriseId })
    end)
    if not ok or total == nil then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    return math.min(tonumber(total) or 0, Config.Tebex.maxPaidExtraSlots)
end

function Repository.GrantSlots(enterpriseId, packageKey, grantKey, purchaserIdentifier, metadata)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    local package = Config.Tebex.slotPackages[packageKey]
    if not package then return nil, CEN.Errors.INVALID_TEBEX_PACKAGE end
    if not CEN.Validation.ValidGrantKey(grantKey) then return nil, CEN.Errors.INVALID_GRANT_KEY end

    local existing = MySQL.single.await([[SELECT enterprise_id AS enterpriseId,
        package_key AS packageKey, quantity, status
        FROM cen_enterprise_entitlements WHERE grant_key = ? LIMIT 1]], { grantKey })
    if existing then
        if tonumber(existing.enterpriseId) ~= tonumber(enterpriseId)
            or existing.packageKey ~= packageKey
            or tonumber(existing.quantity) ~= tonumber(package.slots) then
            return nil, CEN.Errors.CONFLICT
        end
        if existing.status == 'active' then
            return true, nil, package.slots
        end
        -- A refunded/revoked purchase must never be revived by duplicate delivery.
        return nil, CEN.Errors.CONFLICT
    end

    local ok, result = pcall(function()
        return MySQL.insert.await([[INSERT INTO cen_enterprise_entitlements
          (enterprise_id, entitlement_type, provider, package_key, grant_key,
           purchaser_identifier, quantity, status, metadata)
          VALUES (?, 'member_slots', 'tebex', ?, ?, ?, ?, 'active', ?)]], {
                enterpriseId, packageKey, grantKey, purchaserIdentifier,
                package.slots, json.encode(metadata or {})
            })
    end)
    if not ok or not result then return nil, CEN.Errors.CONFLICT end
    return true, nil, package.slots
end

function Repository.RevokeGrant(grantKey)
    if not databaseReady() then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    if not CEN.Validation.ValidGrantKey(grantKey) then return nil, CEN.Errors.INVALID_GRANT_KEY end

    local existing, existingError = Repository.GetGrant(grantKey)
    if not existing then return nil, existingError end
    if existing.status == 'revoked' then
        return true, nil, tonumber(existing.enterpriseId), true
    end

    local ok, affected = pcall(function()
        return MySQL.update.await([[UPDATE cen_enterprise_entitlements
          SET status = 'revoked', revoked_at = UTC_TIMESTAMP()
          WHERE grant_key = ? AND provider = 'tebex' AND status = 'active']], { grantKey })
    end)
    if not ok then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    if affected ~= 1 then return nil, CEN.Errors.CONFLICT end
    return true, nil, tonumber(existing.enterpriseId), false
end
