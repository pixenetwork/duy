CENServer = CENServer or {}
CENServer.Identity = CENServer.Identity or {}

function CENServer.Identity.GetIdentifier(source)
    if type(source) ~= 'number' or source <= 0 then return nil end
    return GetPlayerIdentifierByType(source, 'license')
end

function CENServer.Identity.GetDisplayName(source)
    if type(source) ~= 'number' or source <= 0 then return 'Unknown' end
    local name = GetPlayerName(source)
    if type(name) ~= 'string' or name == '' then return ('Player %s'):format(source) end
    return name:sub(1, 80)
end

function CENServer.Identity.GetSourceByIdentifier(identifier)
    if type(identifier) ~= 'string' then return nil end

    for _, playerId in ipairs(GetPlayers()) do
        local source = tonumber(playerId)
        if source and CENServer.Identity.GetIdentifier(source) == identifier then
            return source
        end
    end

    return nil
end

function CENServer.Identity.AreNearby(sourceA, sourceB, maxDistance)
    local pedA = GetPlayerPed(sourceA)
    local pedB = GetPlayerPed(sourceB)
    if pedA <= 0 or pedB <= 0 then return false end

    local coordsA = GetEntityCoords(pedA)
    local coordsB = GetEntityCoords(pedB)
    return #(coordsA - coordsB) <= maxDistance
end


-- Override this function in the bridge for ESX/QB/Qbox if creation mode uses
-- framework_group. Returning nil keeps framework-group creation denied.
function CENServer.Identity.GetFrameworkGroup(source)
    return nil
end

function CENServer.Identity.GetJob(source)
    if GetResourceState('es_extended') ~= 'started' then return nil end
    local ok, result = pcall(function()
        local ESX = exports.es_extended:getSharedObject()
        local player = ESX.GetPlayerFromId(source)
        if not player then return nil end
        local job = type(player.getJob) == 'function' and player.getJob() or player.job
        if not job then return nil end
        return { name = job.name, grade = tonumber(job.grade) or 0, label = job.label }
    end)
    return ok and result or nil
end
