CENServer = CENServer or {}
CENServer.Inventory = CENServer.Inventory or {}
local Inventory = CENServer.Inventory

function Inventory.IsAvailable()
    return GetResourceState('ox_inventory') == 'started'
end

function Inventory.Count(source, item, metadata)
    if not Inventory.IsAvailable() then return nil, CEN.Errors.INVENTORY_UNAVAILABLE end
    local ok, count = pcall(function()
        return exports.ox_inventory:Search(source, 'count', item, metadata)
    end)
    if not ok then return nil, CEN.Errors.INVENTORY_UNAVAILABLE end
    return tonumber(count) or 0
end

function Inventory.CanCarry(source, item, count, metadata)
    if not Inventory.IsAvailable() then return false, CEN.Errors.INVENTORY_UNAVAILABLE end
    local ok, allowed = pcall(function()
        return exports.ox_inventory:CanCarryItem(source, item, count, metadata)
    end)
    if not ok then return false, CEN.Errors.INVENTORY_UNAVAILABLE end
    return allowed == true, allowed == true and nil or CEN.Errors.CANNOT_CARRY
end

function Inventory.Remove(source, item, count, metadata)
    if not Inventory.IsAvailable() then return false, CEN.Errors.INVENTORY_UNAVAILABLE end
    local available, countError = Inventory.Count(source, item, metadata)
    if available == nil then return false, countError end
    if available < count then return false, CEN.Errors.ITEM_REQUIRED end
    local ok, success = pcall(function()
        return exports.ox_inventory:RemoveItem(source, item, count, metadata)
    end)
    if not ok or success ~= true then return false, CEN.Errors.ITEM_REQUIRED end
    return true
end

function Inventory.Add(source, item, count, metadata)
    local canCarry, carryError = Inventory.CanCarry(source, item, count, metadata)
    if not canCarry then return false, carryError end
    local ok, success = pcall(function()
        return exports.ox_inventory:AddItem(source, item, count, metadata)
    end)
    if not ok or success ~= true then return false, CEN.Errors.INVENTORY_UNAVAILABLE end
    return true
end
