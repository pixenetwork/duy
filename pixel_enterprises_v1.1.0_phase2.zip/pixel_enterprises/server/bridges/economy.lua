CENServer = CENServer or {}
CENServer.Economy = CENServer.Economy or {}

local Economy = CENServer.Economy
local cachedESX

local function getESX()
    if cachedESX then return cachedESX end
    if GetResourceState('es_extended') ~= 'started' then return nil end
    local ok, object = pcall(function()
        return exports.es_extended:getSharedObject()
    end)
    if ok then cachedESX = object end
    return cachedESX
end

local function getPlayer(source)
    if Config.Economy.provider ~= 'esx' then return nil end
    local esx = getESX()
    return esx and esx.GetPlayerFromId(source) or nil
end

function Economy.IsAvailable()
    if Config.Economy.provider == 'custom' then
        return type(Economy.CustomGetBalance) == 'function'
            and type(Economy.CustomRemoveMoney) == 'function'
            and type(Economy.CustomAddMoney) == 'function'
    end
    return getESX() ~= nil
end

function Economy.GetBalance(source)
    if Config.Economy.provider == 'custom' then
        return Economy.CustomGetBalance(source, Config.Economy.account)
    end
    local player = getPlayer(source)
    if not player then return nil, CEN.Errors.ECONOMY_UNAVAILABLE end
    local account = player.getAccount(Config.Economy.account)
    if not account then return nil, CEN.Errors.ECONOMY_UNAVAILABLE end
    return tonumber(account.money) or 0
end

function Economy.RemoveMoney(source, amount, reason)
    amount = math.floor(tonumber(amount) or 0)
    if amount <= 0 then return false, CEN.Errors.INVALID_AMOUNT end
    if Config.Economy.provider == 'custom' then
        return Economy.CustomRemoveMoney(source, Config.Economy.account, amount, reason)
    end
    local player = getPlayer(source)
    if not player then return false, CEN.Errors.ECONOMY_UNAVAILABLE end
    local balance = Economy.GetBalance(source)
    if not balance then return false, CEN.Errors.ECONOMY_UNAVAILABLE end
    if balance < amount then return false, CEN.Errors.INSUFFICIENT_FUNDS end
    player.removeAccountMoney(Config.Economy.account, amount, reason or 'CEN treasury deposit')
    return true
end

function Economy.AddMoney(source, amount, reason)
    amount = math.floor(tonumber(amount) or 0)
    if amount <= 0 then return false, CEN.Errors.INVALID_AMOUNT end
    if Config.Economy.provider == 'custom' then
        return Economy.CustomAddMoney(source, Config.Economy.account, amount, reason)
    end
    local player = getPlayer(source)
    if not player then return false, CEN.Errors.ECONOMY_UNAVAILABLE end
    player.addAccountMoney(Config.Economy.account, amount, reason or 'CEN treasury withdrawal')
    return true
end



function Economy.GetAccountBalance(source, accountName)
    if Config.Economy.provider == 'custom' then
        if type(Economy.CustomGetBalance) ~= 'function' then return nil, CEN.Errors.ECONOMY_UNAVAILABLE end
        return Economy.CustomGetBalance(source, accountName)
    end
    local player = getPlayer(source)
    if not player then return nil, CEN.Errors.ECONOMY_UNAVAILABLE end
    local account = player.getAccount(accountName)
    if not account then return nil, CEN.Errors.ECONOMY_UNAVAILABLE end
    return tonumber(account.money) or 0
end

function Economy.RemoveAccountMoney(source, accountName, amount, reason)
    amount = math.floor(tonumber(amount) or 0)
    if amount <= 0 then return false, CEN.Errors.INVALID_AMOUNT end
    if Config.Economy.provider == 'custom' then
        if type(Economy.CustomRemoveMoney) ~= 'function' then return false, CEN.Errors.ECONOMY_UNAVAILABLE end
        return Economy.CustomRemoveMoney(source, accountName, amount, reason)
    end
    local player = getPlayer(source)
    if not player then return false, CEN.Errors.ECONOMY_UNAVAILABLE end
    local balance, balanceError = Economy.GetAccountBalance(source, accountName)
    if balance == nil then return false, balanceError end
    if balance < amount then return false, CEN.Errors.INSUFFICIENT_FUNDS end
    player.removeAccountMoney(accountName, amount, reason or 'CEN account withdrawal')
    return true
end

function Economy.AddAccountMoney(source, accountName, amount, reason)
    amount = math.floor(tonumber(amount) or 0)
    if amount <= 0 then return false, CEN.Errors.INVALID_AMOUNT end
    if Config.Economy.provider == 'custom' then
        if type(Economy.CustomAddMoney) ~= 'function' then return false, CEN.Errors.ECONOMY_UNAVAILABLE end
        return Economy.CustomAddMoney(source, accountName, amount, reason)
    end
    local player = getPlayer(source)
    if not player then return false, CEN.Errors.ECONOMY_UNAVAILABLE end
    local account = player.getAccount(accountName)
    if not account then return false, CEN.Errors.ECONOMY_UNAVAILABLE end
    player.addAccountMoney(accountName, amount, reason or 'CEN operation payout')
    return true
end
