CENServer = CENServer or {}
CENServer.MarketController = CENServer.MarketController or {}
local Controller = CENServer.MarketController
local EnterpriseRepository = CENServer.Repository
local Market = CENServer.MarketRepository
local streetCooldowns = {}

local function resolve(source, identifier, permission, moduleName)
    local live = CENServer.Identity.GetIdentifier(source)
    if not live or live ~= identifier then return nil, CEN.Errors.CONFLICT end
    local actor, errorCode = EnterpriseRepository.GetMembershipByIdentifier(identifier)
    if not actor then return nil, errorCode end
    local allowed, authorizationError = CENServer.Authorize(actor, permission, moduleName)
    if not allowed then return nil, authorizationError end
    return actor
end

local function positive(value, maximum)
    value = tonumber(value); if not CEN.Validation.IsPositiveInteger(value) then return nil end
    value = math.floor(value); if maximum and value > maximum then return nil end
    return value
end

local function inferredCategory(itemName)
    for _, recipe in pairs(Config.Recipes or {}) do
        if recipe.outputItem == itemName then return recipe.category end
        for ingredient in pairs(recipe.ingredients or {}) do if ingredient == itemName then return 'raw_material' end end
    end
    for _, shipment in pairs((Config.Shipments or {}).catalog or {}) do
        if shipment.item == itemName then
            if tostring(itemName):find('component', 1, true) then return 'arms' end
            return 'contraband'
        end
    end
    return nil
end

local function canSupply(actor, category)
    if category == 'finished_drug' then return Config.Market.finishedDrugSuppliers[actor.enterpriseType] == true end
    if category == 'arms' then return Config.Market.armsSuppliers[actor.enterpriseType] == true end
    return true
end

local function canBuy(actor, listing)
    if listing.sellerEnterpriseId == actor.enterpriseId then return false end
    if actor.enterpriseType == 'street_gang' then
        if not Config.Market.streetGangAllowedCategories[listing.category] then return false end
        if listing.category == 'finished_drug' and not Config.Market.finishedDrugSuppliers[listing.sellerType] then return false end
    end
    return true
end

function Controller.List(source, payload, identifier)
    local actor, errorCode = resolve(source, identifier, CEN.Permissions.VIEW, CEN.Modules.WHOLESALE)
    if not actor then return nil, errorCode end
    local data, listError = Market.List(actor.enterpriseId, payload.limit)
    if not data then return nil, listError end
    data.canPost = CENServer.HasPermission(actor, CEN.Permissions.POST_WHOLESALE)
    data.canBuy = CENServer.HasPermission(actor, CEN.Permissions.BUY_WHOLESALE)
    data.categories = Config.Market.categories
    data.enterpriseType = actor.enterpriseType
    return data
end

function Controller.Create(source, payload, identifier)
    local actor, errorCode = resolve(source, identifier, CEN.Permissions.POST_WHOLESALE, CEN.Modules.WHOLESALE)
    if not actor then return nil, errorCode end
    local itemName = tostring(payload.itemName or ''):lower():match('^[%w_%-]+$')
    if not itemName or #itemName > 80 then return nil, CEN.Errors.LISTING_NOT_ALLOWED end
    local category = inferredCategory(itemName)
    if not category or category ~= tostring(payload.category or '') or not canSupply(actor, category) then
        return nil, CEN.Errors.LISTING_NOT_ALLOWED
    end
    local quantity = positive(payload.quantity, Config.Operations.maximumListingQuantity)
    local unitPrice = positive(payload.unitPrice, Config.Operations.maximumUnitPrice)
    if not quantity or not unitPrice then return nil, CEN.Errors.INVALID_AMOUNT end
    local available, countError = CENServer.Inventory.Count(source, itemName)
    if available == nil then return nil, countError end
    if available < quantity then return nil, CEN.Errors.ITEM_REQUIRED end
    local removed, removeError = CENServer.Inventory.Remove(source, itemName, quantity)
    if not removed then return nil, removeError end
    local quality = math.max(1, math.min(100, math.floor(tonumber(payload.quality) or 50)))
    local batchId = CEN.Validation.Trim(payload.batchId or '')
    if batchId == '' then batchId = nil elseif #batchId > 40 then batchId = batchId:sub(1, 40) end
    local listingId, createError = Market.CreateListing(actor.enterpriseId, actor.memberId, category,
        itemName, quantity, unitPrice, quality, batchId, { postedBy = actor.displayName })
    if not listingId then
        CENServer.Inventory.Add(source, itemName, quantity)
        return nil, createError
    end
    CENServer.Audit('market_listing_created', source, {
        enterpriseId = actor.enterpriseId, listingId = listingId, itemName = itemName,
        quantity = quantity, unitPrice = unitPrice, category = category
    }, identifier)
    return Controller.List(source, {}, identifier)
end

function Controller.Buy(source, payload, identifier)
    local actor, errorCode = resolve(source, identifier, CEN.Permissions.BUY_WHOLESALE, CEN.Modules.WHOLESALE)
    if not actor then return nil, errorCode end
    local listingId = positive(payload.listingId); local quantity = positive(payload.quantity, Config.Operations.maximumListingQuantity)
    if not listingId or not quantity then return nil, CEN.Errors.BAD_REQUEST end
    local listing, listingError = Market.GetListing(listingId)
    if not listing then return nil, listingError end
    if listing.status ~= 'active' or not listing.unexpired or listing.quantityRemaining < quantity or not canBuy(actor, listing) then
        return nil, CEN.Errors.LISTING_NOT_ALLOWED
    end
    local result, purchaseError = Market.Purchase(listingId, actor.enterpriseId, actor.memberId, quantity)
    if not result then return nil, purchaseError end
    CENServer.Audit('market_listing_purchased', source, {
        enterpriseId = actor.enterpriseId, sellerEnterpriseId = listing.sellerEnterpriseId,
        listingId = listingId, quantity = quantity, totalPrice = result.totalPrice,
        deliveryId = result.deliveryId
    }, identifier)
    CENServer.Progression.AddXp(actor.enterpriseId, actor.memberId, math.max(20, quantity * 2), 'wholesale_purchase', { listingId = listingId })
    return Controller.List(source, {}, identifier)
end

function Controller.Cancel(source, payload, identifier)
    local actor, errorCode = resolve(source, identifier, CEN.Permissions.MANAGE_MARKET, CEN.Modules.WHOLESALE)
    if not actor then
        actor, errorCode = resolve(source, identifier, CEN.Permissions.POST_WHOLESALE, CEN.Modules.WHOLESALE)
        if not actor then return nil, errorCode end
    end
    local listingId = positive(payload.listingId); if not listingId then return nil, CEN.Errors.LISTING_NOT_FOUND end
    local listing, listingError = Market.GetListing(listingId)
    if not listing then return nil, listingError end
    if listing.sellerEnterpriseId ~= actor.enterpriseId then return nil, CEN.Errors.FORBIDDEN end
    local ok, cancelError = Market.CancelListing(listingId, actor.enterpriseId)
    if not ok then return nil, cancelError end
    CENServer.Audit('market_listing_cancelled', source, { enterpriseId = actor.enterpriseId, listingId = listingId }, identifier)
    return Controller.List(source, {}, identifier)
end

function Controller.ClaimDelivery(source, payload, identifier)
    local actor, errorCode = resolve(source, identifier, CEN.Permissions.VIEW, CEN.Modules.WHOLESALE)
    if not actor then return nil, errorCode end
    if not actor.isOwner and not CENServer.HasPermission(actor, CEN.Permissions.BUY_WHOLESALE)
        and not CENServer.HasPermission(actor, CEN.Permissions.POST_WHOLESALE) then
        return nil, CEN.Errors.FORBIDDEN
    end
    local deliveryId = positive(payload.deliveryId); if not deliveryId then return nil, CEN.Errors.BAD_REQUEST end
    local delivery, deliveryError = Market.MarkDeliveryClaiming(deliveryId, actor.enterpriseId)
    if not delivery then return nil, deliveryError end
    local metadata = delivery.metadata or {}
    metadata.quality = delivery.quality; metadata.batchId = delivery.batchId
    metadata.recipientEnterpriseId = actor.enterpriseId; metadata.recipientEnterprise = actor.enterpriseName
    local added, addError = CENServer.Inventory.Add(source, delivery.itemName, delivery.quantity, metadata)
    if not added then Market.ResetDelivery(deliveryId, actor.enterpriseId); return nil, addError end
    if not Market.CompleteDelivery(deliveryId, actor.enterpriseId, actor.memberId) then
        CENServer.Inventory.Remove(source, delivery.itemName, delivery.quantity, metadata)
        Market.ResetDelivery(deliveryId, actor.enterpriseId)
        return nil, CEN.Errors.DATABASE_UNAVAILABLE
    end
    CENServer.Audit('market_delivery_claimed', source, {
        enterpriseId = actor.enterpriseId, deliveryId = deliveryId,
        itemName = delivery.itemName, quantity = delivery.quantity
    }, identifier)
    return Controller.List(source, {}, identifier)
end

local function payStreet(source, amount)
    if Config.Operations.dirtyMoneyMode == 'item' then
        return CENServer.Inventory.Add(source, Config.Operations.dirtyMoneyItem, amount)
    end
    local ok, errorCode = CENServer.Economy.AddAccountMoney(source,
        Config.Operations.dirtyMoneyAccount or 'black_money', amount, 'Street distribution')
    if ok then return true end
    if Config.Operations.fallbackStreetPayoutToBank then return CENServer.Economy.AddMoney(source, amount, 'Street distribution fallback') end
    return false, errorCode
end

function Controller.StreetSell(source, payload, identifier)
    local actor, errorCode = resolve(source, identifier, CEN.Permissions.STREET_SELL, CEN.Modules.STREET_DISTRIBUTION)
    if not actor then return nil, errorCode end
    if actor.enterpriseType ~= 'street_gang' then return nil, CEN.Errors.FORBIDDEN end
    local itemName = tostring(payload.itemName or '')
    local product = Config.StreetSales.products[itemName]
    if not product then return nil, CEN.Errors.LISTING_NOT_ALLOWED end
    local now = os.time(); local previous = streetCooldowns[identifier] or 0
    if now - previous < math.max(1, tonumber(Config.Operations.streetSaleCooldownSeconds) or 20) then return nil, CEN.Errors.RATE_LIMITED end
    local ped = GetPlayerPed(source); if ped <= 0 then return nil, CEN.Errors.TARGET_UNAVAILABLE end
    local coords = GetEntityCoords(ped)
    local turf, turfError = Market.FindTurfAt(coords)
    if turfError then return nil, turfError end
    local multiplier = turf and turf.ownerEnterpriseId == actor.enterpriseId
        and Config.StreetSales.ownedTurfMultiplier or Config.StreetSales.unownedTurfMultiplier
    local payout = math.floor(math.random(product.minimum, product.maximum) * multiplier)
    local removed, removeError = CENServer.Inventory.Remove(source, itemName, 1)
    if not removed then return nil, removeError end
    local paid, payError = payStreet(source, payout)
    if not paid then CENServer.Inventory.Add(source, itemName, 1); return nil, payError end
    streetCooldowns[identifier] = now
    CENServer.Heat.Add(actor.enterpriseId, product.heat or 0, 'street_sale')
    CENServer.Progression.AddXp(actor.enterpriseId, actor.memberId, product.xp or 0, 'street_sale', {
        itemName = itemName, payout = payout, turfId = turf and turf.zoneId or nil
    })
    CENServer.Audit('street_product_sold', source, {
        enterpriseId = actor.enterpriseId, itemName = itemName, payout = payout,
        turfId = turf and turf.zoneId or nil, controlled = turf and turf.ownerEnterpriseId == actor.enterpriseId or false
    }, identifier)
    if turf and turf.ownerEnterpriseId and turf.ownerEnterpriseId ~= actor.enterpriseId then
        CENServer.Wars.RecordEvent(actor.enterpriseId, turf.ownerEnterpriseId, 'enemy_turf_sale',
            Config.Wars.points.enemyTurfSale, { turfId = turf.zoneId, itemName = itemName })
    end
    return { sold = true, payout = payout, turf = turf and turf.name or 'uncontrolled', heat = product.heat or 0 }
end

local actions = {
    listMarket = Controller.List, createMarketListing = Controller.Create, buyMarketListing = Controller.Buy,
    cancelMarketListing = Controller.Cancel, claimMarketDelivery = Controller.ClaimDelivery,
    sellStreetProduct = Controller.StreetSell
}
Controller.Mutations = {
    createMarketListing = true, buyMarketListing = true, cancelMarketListing = true,
    claimMarketDelivery = true, sellStreetProduct = true
}
function Controller.IsKnownAction(action) return actions[action] ~= nil end
function Controller.GetMutationKeys(source, action, payload, identifier)
    local actor, errorCode = EnterpriseRepository.GetMembershipByIdentifier(identifier)
    if not actor then return nil, errorCode end
    local keys = { ('enterprise:%s'):format(actor.enterpriseId), ('identity:%s'):format(identifier) }
    if payload.listingId then
        keys[#keys + 1] = ('market-listing:%s'):format(tostring(payload.listingId))
        local listing = Market.GetListing(tonumber(payload.listingId))
        if listing and listing.sellerEnterpriseId then
            keys[#keys + 1] = ('enterprise:%s'):format(listing.sellerEnterpriseId)
        end
    end
    if payload.deliveryId then keys[#keys + 1] = ('market-delivery:%s'):format(tostring(payload.deliveryId)) end
    return keys
end
function Controller.Handle(source, action, payload, identifier)
    local handler = actions[action]; if not handler then return nil, CEN.Errors.BAD_REQUEST end
    return handler(source, payload or {}, identifier)
end

AddEventHandler('playerDropped', function() streetCooldowns[CENServer.Identity.GetIdentifier(source) or ''] = nil end)
