CENServer = CENServer or {}
CENServer.ShipmentController = CENServer.ShipmentController or {}
local Controller = CENServer.ShipmentController
local EnterpriseRepository = CENServer.Repository
local Shipments = CENServer.ShipmentRepository

local function resolve(source, identifier, permission, moduleName)
    local live = CENServer.Identity.GetIdentifier(source)
    if not live or live ~= identifier then return nil, CEN.Errors.CONFLICT end
    local actor, errorCode = EnterpriseRepository.GetMembershipByIdentifier(identifier)
    if not actor then return nil, errorCode end
    local allowed, authorizationError = CENServer.Authorize(actor, permission, moduleName)
    if not allowed then return nil, authorizationError end
    return actor
end

local function positive(value)
    value = tonumber(value); if not CEN.Validation.IsPositiveInteger(value) then return nil end
    return math.floor(value)
end

local function allowed(entry, enterpriseType)
    for i = 1, #(entry.allowedEnterpriseTypes or {}) do if entry.allowedEnterpriseTypes[i] == enterpriseType then return true end end
    return false
end

local function catalogDto(actor)
    local list = {}
    for key, entry in pairs(Config.Shipments.catalog or {}) do
        if allowed(entry, actor.enterpriseType) then
            list[#list + 1] = { key = key, label = entry.label, item = entry.item, quantity = entry.quantity,
                cost = entry.cost, minimumLevel = entry.minimumLevel, delivery = entry.delivery,
                unlocked = tonumber(actor.level) >= tonumber(entry.minimumLevel or 1) }
        end
    end
    table.sort(list, function(a, b) return a.cost < b.cost end)
    return list
end

function Controller.List(source, payload, identifier)
    local actor, errorCode = resolve(source, identifier, CEN.Permissions.VIEW, CEN.Modules.SMUGGLING)
    if not actor then
        actor, errorCode = resolve(source, identifier, CEN.Permissions.VIEW, CEN.Modules.AIRDROPS)
        if not actor then return nil, errorCode end
    end
    local rows, listError = Shipments.List(actor.enterpriseId)
    if not rows then return nil, listError end
    return { shipments = rows, catalog = catalogDto(actor), enterpriseLevel = actor.level,
        canStart = CENServer.HasPermission(actor, CEN.Permissions.START_SHIPMENT),
        canAirdrop = CENServer.HasPermission(actor, CEN.Permissions.REQUEST_AIRDROP) }
end

function Controller.Request(source, payload, identifier)
    local key = tostring(payload.catalogKey or '')
    local entry = Config.Shipments.catalog[key]
    if not entry then return nil, CEN.Errors.SHIPMENT_NOT_FOUND end
    local permission = entry.delivery == 'airdrop' and CEN.Permissions.REQUEST_AIRDROP or CEN.Permissions.START_SHIPMENT
    local moduleName = entry.delivery == 'airdrop' and CEN.Modules.AIRDROPS or CEN.Modules.SMUGGLING
    local actor, errorCode = resolve(source, identifier, permission, moduleName)
    if not actor then return nil, errorCode end
    if not allowed(entry, actor.enterpriseType) or tonumber(actor.level) < tonumber(entry.minimumLevel or 1) then
        return nil, CEN.Errors.FORBIDDEN
    end
    if entry.delivery == 'airdrop' then
        local active = MySQL.scalar.await([[SELECT COUNT(*) FROM cen_shipments
          WHERE enterprise_id = ? AND delivery_type = 'airdrop' AND status IN ('scheduled','ready')
            AND created_at >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL ? SECOND)]], {
            actor.enterpriseId, math.max(1, tonumber(Config.Operations.airdropCooldownSeconds) or 7200)
        })
        if tonumber(active) > 0 then return nil, CEN.Errors.SHIPMENT_COOLDOWN end
    end
    local locations = Config.Shipments.locations or {}; if #locations == 0 then return nil, CEN.Errors.INTERNAL_ERROR end
    local location = locations[math.random(1, #locations)]
    local result, requestError = Shipments.Request(actor.enterpriseId, actor.memberId, key, entry, location)
    if not result then return nil, requestError end
    CENServer.Heat.Add(actor.enterpriseId, entry.heat or 0, 'shipment_requested')
    CENServer.Audit('shipment_requested', source, {
        enterpriseId = actor.enterpriseId, shipmentId = result.shipmentId,
        catalogKey = key, delivery = entry.delivery, cost = entry.cost
    }, identifier)
    return Controller.List(source, {}, identifier)
end

function Controller.Claim(source, payload, identifier)
    local actor, errorCode = resolve(source, identifier, CEN.Permissions.VIEW_SHIPMENTS, CEN.Modules.SMUGGLING)
    if not actor then
        actor, errorCode = resolve(source, identifier, CEN.Permissions.REQUEST_AIRDROP, CEN.Modules.AIRDROPS)
        if not actor then return nil, errorCode end
    end
    local shipmentId = positive(payload.shipmentId); if not shipmentId then return nil, CEN.Errors.SHIPMENT_NOT_FOUND end
    local shipment, claimError = Shipments.MarkClaiming(shipmentId, actor.enterpriseId)
    if not shipment then return nil, claimError end
    local ped = GetPlayerPed(source); if ped <= 0 then Shipments.ResetClaim(shipmentId, actor.enterpriseId); return nil, CEN.Errors.TARGET_UNAVAILABLE end
    local c = GetEntityCoords(ped)
    local dx, dy, dz = c.x - shipment.pickupX, c.y - shipment.pickupY, c.z - shipment.pickupZ
    if math.sqrt(dx * dx + dy * dy + dz * dz) > math.max(2, tonumber(Config.Operations.shipmentClaimDistance) or 12) then
        Shipments.ResetClaim(shipmentId, actor.enterpriseId); return nil, CEN.Errors.TOO_FAR_FROM_ZONE
    end
    local metadata = { shipmentId = shipmentId, catalogKey = shipment.catalogKey,
        importedBy = actor.enterpriseName, importedByEnterpriseId = actor.enterpriseId,
        deliveryType = shipment.deliveryType }
    local added, addError = CENServer.Inventory.Add(source, shipment.itemName, shipment.quantity, metadata)
    if not added then Shipments.ResetClaim(shipmentId, actor.enterpriseId); return nil, addError end
    if not Shipments.CompleteClaim(shipmentId, actor.enterpriseId, actor.memberId) then
        CENServer.Inventory.Remove(source, shipment.itemName, shipment.quantity, metadata)
        Shipments.ResetClaim(shipmentId, actor.enterpriseId); return nil, CEN.Errors.DATABASE_UNAVAILABLE
    end
    CENServer.Progression.AddXp(actor.enterpriseId, actor.memberId, shipment.deliveryType == 'airdrop' and 500 or 200,
        'shipment_claimed', { shipmentId = shipmentId })
    CENServer.Audit('shipment_claimed', source, { enterpriseId = actor.enterpriseId, shipmentId = shipmentId }, identifier)
    return Controller.List(source, {}, identifier)
end

local actions = { listShipments = Controller.List, requestShipment = Controller.Request, claimShipment = Controller.Claim }
Controller.Mutations = { requestShipment = true, claimShipment = true }
function Controller.IsKnownAction(action) return actions[action] ~= nil end
function Controller.GetMutationKeys(source, action, payload, identifier)
    local actor, errorCode = EnterpriseRepository.GetMembershipByIdentifier(identifier)
    if not actor then return nil, errorCode end
    local keys = { ('enterprise:%s'):format(actor.enterpriseId), ('identity:%s'):format(identifier) }
    if payload.shipmentId then keys[#keys + 1] = ('shipment:%s'):format(tostring(payload.shipmentId)) end
    return keys
end
function Controller.Handle(source, action, payload, identifier)
    local handler = actions[action]; if not handler then return nil, CEN.Errors.BAD_REQUEST end
    return handler(source, payload or {}, identifier)
end
