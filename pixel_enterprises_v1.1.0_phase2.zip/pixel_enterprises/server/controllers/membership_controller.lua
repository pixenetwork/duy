CENServer = CENServer or {}
CENServer.MembershipController = CENServer.MembershipController or {}

local Controller = CENServer.MembershipController
local Repository = CENServer.Repository
local Invites = CENServer.MembershipInviteRepository

local function integer(value)
    local converted = tonumber(value)
    if not CEN.Validation.IsPositiveInteger(converted) then return nil end
    return converted
end

local function resolveRequester(source, expectedIdentifier)
    local liveIdentifier = CENServer.Identity.GetIdentifier(source)
    if not liveIdentifier then return nil end
    if expectedIdentifier and liveIdentifier ~= expectedIdentifier then return nil end
    return expectedIdentifier or liveIdentifier
end

local function sameRequester(source, expectedIdentifier)
    return resolveRequester(source, expectedIdentifier) ~= nil
end

local function audit(eventName, source, actorIdentifier, payload)
    return CENServer.Audit(eventName, source, payload, actorIdentifier)
end

local function sameStringArray(a, b)
    if type(a) ~= 'table' or type(b) ~= 'table' or #a ~= #b then return false end
    local left, right = {}, {}
    for i = 1, #a do left[i] = a[i] end
    for i = 1, #b do right[i] = b[i] end
    table.sort(left)
    table.sort(right)
    for i = 1, #left do
        if left[i] ~= right[i] then return false end
    end
    return true
end

local function memberLimit(actorOrEnterprise)
    local enterpriseId = tonumber(actorOrEnterprise.enterpriseId or actorOrEnterprise.id)
    local base = tonumber(actorOrEnterprise.baseMemberLimit) or Config.Membership.defaultMemberLimit
    local extra, errorCode = CENServer.EntitlementRepository.GetActiveExtraMemberSlots(enterpriseId)
    if extra == nil then return nil, errorCode end
    return math.min(base + extra, Config.Membership.absoluteMemberLimit), extra
end

local function getActor(source, expectedIdentifier, permission, moduleName)
    expectedIdentifier = resolveRequester(source, expectedIdentifier)
    if not expectedIdentifier then return nil, CEN.Errors.CONFLICT end
    local actor, errorCode = Repository.GetMembershipByIdentifier(expectedIdentifier)
    if not actor then return nil, errorCode end

    local allowed, authorizationError = CENServer.Authorize(actor, permission, moduleName)
    if not allowed then return nil, authorizationError end
    return actor
end

local function actorDto(actor)
    return {
        memberId = actor.memberId,
        enterpriseId = actor.enterpriseId,
        rankId = actor.rankId,
        displayName = actor.displayName,
        isOwner = actor.isOwner,
        rankName = actor.rankName,
        rankPriority = actor.rankPriority,
        permissions = actor.permissions,
        enterpriseType = actor.enterpriseType,
        enterpriseName = actor.enterpriseName,
        level = actor.level,
        xp = actor.xp,
        heat = actor.heat,
        creationPlan = actor.creationPlan,
        baseMemberLimit = actor.baseMemberLimit,
        retentionRequired = actor.retentionRequired,
        retentionStatus = actor.retentionStatus,
        disbandScheduledAt = actor.disbandScheduledAt,
        enterpriseStatus = actor.enterpriseStatus
    }
end

local function permissionCatalogFor(actor)
    local catalog = {}
    for permission, definition in pairs(CEN.PermissionDefinitions) do
        if not definition.ownerOnly
            and (not definition.module or CENServer.CanAccessModule(actor.enterpriseType, definition.module)) then
            catalog[#catalog + 1] = {
                permission = permission,
                label = definition.label,
                module = definition.module,
                canGrant = actor.isOwner == true or CENServer.HasPermission(actor, permission)
            }
        end
    end
    table.sort(catalog, function(a, b) return a.permission < b.permission end)
    return catalog
end

local function listRoster(actor)
    local members, memberError = Repository.ListMembers(actor.enterpriseId)
    if not members then return nil, memberError end
    local ranks, rankError = Repository.ListRanks(actor.enterpriseId)
    if not ranks then return nil, rankError end
    local limit, extraSlotsOrError = memberLimit(actor)
    if not limit then return nil, extraSlotsOrError end

    return {
        members = members,
        ranks = ranks,
        memberLimit = limit,
        paidExtraMemberSlots = extraSlotsOrError,
        permissionCatalog = permissionCatalogFor(actor)
    }
end

function Controller.Bootstrap(source, payload, expectedIdentifier)
    local actor, errorCode = getActor(source, expectedIdentifier, CEN.Permissions.VIEW, CEN.Modules.DASHBOARD)
    if not actor then return nil, errorCode end
    local enterpriseDefinition = CEN.EnterpriseTypes[actor.enterpriseType]
    if not enterpriseDefinition then return nil, CEN.Errors.INVALID_ENTERPRISE_TYPE end

    local roster
    if CENServer.CanAccessModule(actor.enterpriseType, CEN.Modules.MEMBERS) then
        roster, errorCode = listRoster(actor)
        if not roster then return nil, errorCode end
    end

    local retention, retentionError = CENServer.ActivityRepository.GetRetentionSummary(
        actor.enterpriseId, CENServer.Retention.CycleStart())
    if not retention and retentionError then return nil, retentionError end

    audit('tablet_opened', source, expectedIdentifier, {
        enterpriseId = actor.enterpriseId,
        enterpriseType = actor.enterpriseType
    })

    return {
        member = actorDto(actor),
        modules = CENServer.EnabledModulesForEnterprise(actor.enterpriseType),
        enterpriseType = {
            key = actor.enterpriseType,
            label = enterpriseDefinition.label,
            tier = enterpriseDefinition.tier
        },
        roster = roster,
        retention = retention,
        version = CEN.Version
    }
end

function Controller.GetRoster(source, payload, expectedIdentifier)
    local actor, errorCode = getActor(source, expectedIdentifier, CEN.Permissions.VIEW, CEN.Modules.MEMBERS)
    if not actor then return nil, errorCode end
    return listRoster(actor)
end

function Controller.CreateRank(source, payload, expectedIdentifier)
    local actor, errorCode = getActor(source, expectedIdentifier, CEN.Permissions.MANAGE_RANKS, CEN.Modules.RANKS)
    if not actor then return nil, errorCode end

    local name = CEN.Validation.Trim(payload.name)
    local priority = tonumber(payload.priority)
    if not CEN.Validation.ValidRankName(name) then return nil, CEN.Errors.INVALID_RANK_NAME end
    if not CEN.Validation.IsInteger(priority)
        or priority < Config.Ranks.minPriority or priority > Config.Ranks.maxPriority then
        return nil, CEN.Errors.INVALID_PRIORITY
    end
    if not actor.isOwner and priority >= tonumber(actor.rankPriority) then
        return nil, CEN.Errors.CANNOT_ASSIGN_EQUAL_OR_HIGHER
    end

    local permissions, validationError = CEN.Validation.NormalizePermissions(payload.permissions or {})
    if not permissions then return nil, validationError end
    permissions = CENServer.FilterPermissionsForEnterprise(actor.enterpriseType, permissions)
    local canGrant, grantError = CENServer.CanGrantPermissions(actor, permissions)
    if not canGrant then return nil, grantError end

    local rankCount, countError = Repository.CountRanks(actor.enterpriseId)
    if rankCount == nil then return nil, countError end
    if rankCount >= Config.Ranks.maxRanks then return nil, CEN.Errors.RANK_LIMIT_REACHED end

    local rankId, createError = Repository.CreateRank(actor.enterpriseId, name, priority, permissions)
    if not rankId then return nil, createError end
    audit('rank_created', source, expectedIdentifier, {
        enterpriseId = actor.enterpriseId, rankId = rankId, name = name,
        priority = priority, permissions = permissions
    })
    return listRoster(actor)
end

function Controller.UpdateRank(source, payload, expectedIdentifier)
    local actor, errorCode = getActor(source, expectedIdentifier, CEN.Permissions.MANAGE_RANKS, CEN.Modules.RANKS)
    if not actor then return nil, errorCode end

    local rankId = integer(payload.rankId)
    local name = CEN.Validation.Trim(payload.name)
    local priority = tonumber(payload.priority)
    if not rankId then return nil, CEN.Errors.INVALID_RANK end
    if not CEN.Validation.ValidRankName(name) then return nil, CEN.Errors.INVALID_RANK_NAME end
    if not CEN.Validation.IsInteger(priority)
        or priority < Config.Ranks.minPriority or priority > Config.Ranks.maxPriority then
        return nil, CEN.Errors.INVALID_PRIORITY
    end

    local rank, rankError = Repository.GetRank(actor.enterpriseId, rankId)
    if not rank then return nil, rankError end
    if rank.isProtected then return nil, CEN.Errors.PROTECTED_RANK end
    if not actor.isOwner and (tonumber(rank.priority) >= tonumber(actor.rankPriority)
        or priority >= tonumber(actor.rankPriority)) then
        return nil, CEN.Errors.CANNOT_ASSIGN_EQUAL_OR_HIGHER
    end

    local permissions, validationError = CEN.Validation.NormalizePermissions(payload.permissions or {})
    if not permissions then return nil, validationError end
    permissions = CENServer.FilterPermissionsForEnterprise(actor.enterpriseType, permissions)
    local canGrant, grantError = CENServer.CanGrantPermissions(actor, permissions)
    if not canGrant then return nil, grantError end

    if rank.name == name and tonumber(rank.priority) == priority and sameStringArray(rank.permissions, permissions) then
        return listRoster(actor)
    end

    local updated, updateError = Repository.UpdateRank(actor.enterpriseId, rankId, name, priority, permissions)
    if not updated then return nil, updateError end
    audit('rank_updated', source, expectedIdentifier, {
        enterpriseId = actor.enterpriseId, rankId = rankId, before = rank,
        after = { name = name, priority = priority, permissions = permissions }
    })
    return listRoster(actor)
end

function Controller.DeleteRank(source, payload, expectedIdentifier)
    local actor, errorCode = getActor(source, expectedIdentifier, CEN.Permissions.MANAGE_RANKS, CEN.Modules.RANKS)
    if not actor then return nil, errorCode end
    local rankId = integer(payload.rankId)
    if not rankId then return nil, CEN.Errors.INVALID_RANK end

    local rank, rankError = Repository.GetRank(actor.enterpriseId, rankId)
    if not rank then return nil, rankError end
    if rank.isProtected then return nil, CEN.Errors.PROTECTED_RANK end
    if not actor.isOwner and tonumber(rank.priority) >= tonumber(actor.rankPriority) then
        return nil, CEN.Errors.CANNOT_MANAGE_EQUAL_OR_HIGHER
    end

    local deleted, deleteError = Repository.DeleteRank(actor.enterpriseId, rankId)
    if not deleted then return nil, deleteError end
    audit('rank_deleted', source, expectedIdentifier, { enterpriseId = actor.enterpriseId, rank = rank })
    return listRoster(actor)
end

local function unavailableTarget(source, actor, reason)
    audit('member_invite_target_unavailable', source, actor.playerIdentifier, {
        enterpriseId = actor.enterpriseId,
        reason = reason
    })
    return nil, CEN.Errors.TARGET_UNAVAILABLE
end

function Controller.InviteMember(source, payload, expectedIdentifier)
    local actor, errorCode = getActor(source, expectedIdentifier, CEN.Permissions.INVITE_MEMBERS, CEN.Modules.MEMBERS)
    if not actor then return nil, errorCode end

    local targetSource = integer(payload.targetServerId)
    if not targetSource or not GetPlayerName(targetSource) then
        return unavailableTarget(source, actor, 'not_found')
    end
    if targetSource == source then return nil, CEN.Errors.CANNOT_TARGET_SELF end

    local targetIdentifier = CENServer.Identity.GetIdentifier(targetSource)
    if not targetIdentifier then return unavailableTarget(source, actor, 'identifier_missing') end

    local existing, membershipError = Repository.GetMembershipAnyStatus(targetIdentifier)
    if existing and existing.status ~= 'removed' then
        return unavailableTarget(source, actor, 'already_member')
    end
    if not existing and membershipError ~= CEN.Errors.NOT_MEMBER then
        return nil, membershipError
    end

    local foundingProposal, proposalError = CENServer.FoundingRepository.GetActiveProposalByFounder(targetIdentifier)
    if foundingProposal then return unavailableTarget(source, actor, 'active_founding_proposal') end
    if proposalError then return nil, proposalError end
    local foundingSupport, supportError = CENServer.FoundingRepository.GetActiveSupportByIdentifier(targetIdentifier)
    if foundingSupport then return unavailableTarget(source, actor, 'active_founding_support') end
    if supportError then return nil, supportError end

    if Config.Membership.requireNearbyInvite
        and not CENServer.Identity.AreNearby(source, targetSource, Config.Membership.inviteMaxDistance) then
        return unavailableTarget(source, actor, 'too_far')
    end

    local currentCount, countError = Repository.CountMembers(actor.enterpriseId)
    if currentCount == nil then return nil, countError end
    local limit, limitError = memberLimit(actor)
    if not limit then return nil, limitError end
    if currentCount >= limit then return nil, CEN.Errors.MEMBER_LIMIT_REACHED end

    local rank
    if payload.rankId ~= nil then
        if not CENServer.HasPermission(actor, CEN.Permissions.ASSIGN_RANKS) then
            return nil, CEN.Errors.FORBIDDEN
        end
        local rankId = integer(payload.rankId)
        if not rankId then return nil, CEN.Errors.INVALID_RANK end
        rank, errorCode = Repository.GetRank(actor.enterpriseId, rankId)
    else
        rank, errorCode = Repository.GetDefaultRank(actor.enterpriseId)
    end
    if not rank then return nil, errorCode end
    local canAssign, assignError = CENServer.CanAssignRank(actor, rank)
    if not canAssign then return nil, assignError end
    local canGrant, grantError = CENServer.CanGrantPermissions(actor, rank.permissions or {})
    if not canGrant then return nil, grantError end

    local inviteId, inviteError = Invites.Create(
        actor.enterpriseId, targetIdentifier, CENServer.Identity.GetDisplayName(targetSource),
        actor.memberId, rank.rankId)
    if not inviteId then return nil, inviteError end

    if CENServer.Identity.GetIdentifier(targetSource) == targetIdentifier then
        CENServer.NotifySource(targetSource, ('%s invited you to join %s as %s. Use /cenjoinaccept %d or /cenjoindecline %d.'):format(
            actor.displayName, actor.enterpriseName, rank.name, inviteId, inviteId), 'info')
    end
    audit('membership_invite_sent', source, expectedIdentifier, {
        enterpriseId = actor.enterpriseId,
        inviteId = inviteId,
        rankId = rank.rankId
    })

    local roster, rosterError = listRoster(actor)
    if not roster then return nil, rosterError end
    roster.inviteSent = { inviteId = inviteId, targetDisplayName = CENServer.Identity.GetDisplayName(targetSource) }
    return roster
end

local function validatePendingInviteAuthority(invite)
    local inviter, inviterError = Repository.GetMemberById(invite.enterpriseId, invite.invitedByMemberId)
    if not inviter then return nil, inviterError or CEN.Errors.FORBIDDEN end
    if not CENServer.HasPermission(inviter, CEN.Permissions.INVITE_MEMBERS) then
        return nil, CEN.Errors.FORBIDDEN
    end

    local rank, rankError = Repository.GetRank(invite.enterpriseId, invite.rankId)
    if not rank then return nil, rankError end
    local defaultRank, defaultError = Repository.GetDefaultRank(invite.enterpriseId)
    if not defaultRank then return nil, defaultError end

    if tonumber(rank.rankId) ~= tonumber(defaultRank.rankId)
        and not CENServer.HasPermission(inviter, CEN.Permissions.ASSIGN_RANKS) then
        return nil, CEN.Errors.FORBIDDEN
    end

    local canAssign, assignError = CENServer.CanAssignRank(inviter, rank)
    if not canAssign then return nil, assignError end
    local canGrant, grantError = CENServer.CanGrantPermissions(inviter, rank.permissions or {})
    if not canGrant then return nil, grantError end
    return true
end

function Controller.AcceptMembershipInvite(source, payload, expectedIdentifier)
    expectedIdentifier = resolveRequester(source, expectedIdentifier)
    if not expectedIdentifier then return nil, CEN.Errors.CONFLICT end
    local inviteId = integer(payload.inviteId)
    if not inviteId then return nil, CEN.Errors.MEMBERSHIP_INVITE_NOT_FOUND end

    local existing, membershipError = Repository.GetMembershipAnyStatus(expectedIdentifier)
    if existing and existing.status ~= 'removed' then return nil, CEN.Errors.TARGET_ALREADY_MEMBER end
    if not existing and membershipError ~= CEN.Errors.NOT_MEMBER then return nil, membershipError end

    local foundingProposal, proposalError = CENServer.FoundingRepository.GetActiveProposalByFounder(expectedIdentifier)
    if foundingProposal then return nil, CEN.Errors.ALREADY_HAS_PROPOSAL end
    if proposalError then return nil, proposalError end
    local foundingSupport, supportError = CENServer.FoundingRepository.GetActiveSupportByIdentifier(expectedIdentifier)
    if foundingSupport then return nil, CEN.Errors.ALREADY_SUPPORTING_PROPOSAL end
    if supportError then return nil, supportError end

    local invite, inviteError = Invites.GetPendingById(inviteId, expectedIdentifier)
    if not invite then return nil, inviteError end
    local authorityOk, authorityError = validatePendingInviteAuthority(invite)
    if not authorityOk then return nil, authorityError end
    local enterprise, enterpriseError = Repository.GetEnterprise(invite.enterpriseId)
    if not enterprise then return nil, enterpriseError end

    local count, countError = Repository.CountMembers(invite.enterpriseId)
    if count == nil then return nil, countError end
    local limit, limitError = memberLimit(enterprise)
    if not limit then return nil, limitError end
    if count >= limit then return nil, CEN.Errors.MEMBER_LIMIT_REACHED end

    local accepted, acceptError = Invites.Accept(invite, CENServer.Identity.GetDisplayName(source))
    if not accepted then return nil, acceptError end
    audit('membership_invite_accepted', source, expectedIdentifier, {
        enterpriseId = invite.enterpriseId,
        inviteId = inviteId
    })
    CENServer.Progression.AddXp(invite.enterpriseId, nil,
        Config.Progression.awards.memberJoined or 0, 'member_joined', { inviteId = inviteId })
    if CENServer.Identity.GetIdentifier(source) == expectedIdentifier then
        TriggerClientEvent('pixel_enterprises:client:membershipChanged', source, {
            enterpriseId = invite.enterpriseId,
            enterpriseName = invite.enterpriseName,
            joined = true
        })
    end
    return { joined = true, enterpriseId = invite.enterpriseId, enterpriseName = invite.enterpriseName }
end

function Controller.DeclineMembershipInvite(source, payload, expectedIdentifier)
    expectedIdentifier = resolveRequester(source, expectedIdentifier)
    if not expectedIdentifier then return nil, CEN.Errors.CONFLICT end
    local inviteId = integer(payload.inviteId)
    if not inviteId then return nil, CEN.Errors.MEMBERSHIP_INVITE_NOT_FOUND end
    local declined, errorCode = Invites.Decline(inviteId, expectedIdentifier)
    if not declined then return nil, errorCode end
    audit('membership_invite_declined', source, expectedIdentifier, { inviteId = inviteId })
    return { declined = true, inviteId = inviteId }
end

function Controller.SetMemberRank(source, payload, expectedIdentifier)
    local actor, errorCode = getActor(source, expectedIdentifier, CEN.Permissions.ASSIGN_RANKS, CEN.Modules.MEMBERS)
    if not actor then return nil, errorCode end
    local memberId = integer(payload.memberId)
    local rankId = integer(payload.rankId)
    if not memberId then return nil, CEN.Errors.TARGET_NOT_MEMBER end
    if not rankId then return nil, CEN.Errors.INVALID_RANK end
    if memberId == actor.memberId then return nil, CEN.Errors.CANNOT_TARGET_SELF end

    local target, targetError = Repository.GetMemberById(actor.enterpriseId, memberId)
    if not target then return nil, targetError end
    local rank, rankError = Repository.GetRank(actor.enterpriseId, rankId)
    if not rank then return nil, rankError end
    local canManage, manageError = CENServer.CanManageMember(actor, target)
    if not canManage then return nil, manageError end
    local canAssign, assignError = CENServer.CanAssignRank(actor, rank)
    if not canAssign then return nil, assignError end
    local canGrant, grantError = CENServer.CanGrantPermissions(actor, rank.permissions or {})
    if not canGrant then return nil, grantError end
    if tonumber(target.rankId) == rankId then return listRoster(actor) end

    local updated, updateError = Repository.SetMemberRank(actor.enterpriseId, memberId, rankId)
    if not updated then return nil, updateError end
    audit('member_rank_changed', source, expectedIdentifier, {
        enterpriseId = actor.enterpriseId, memberId = memberId,
        previousRankId = target.rankId, newRankId = rankId
    })
    return listRoster(actor)
end

function Controller.RemoveMember(source, payload, expectedIdentifier)
    local actor, errorCode = getActor(source, expectedIdentifier, CEN.Permissions.REMOVE_MEMBERS, CEN.Modules.MEMBERS)
    if not actor then return nil, errorCode end
    local memberId = integer(payload.memberId)
    if not memberId then return nil, CEN.Errors.TARGET_NOT_MEMBER end
    if memberId == actor.memberId then return nil, CEN.Errors.CANNOT_TARGET_SELF end

    local target, targetError = Repository.GetMemberById(actor.enterpriseId, memberId)
    if not target then return nil, targetError end
    local canManage, manageError = CENServer.CanManageMember(actor, target)
    if not canManage then return nil, manageError end

    local targetIdentifier = target.playerIdentifier
    local targetSource = CENServer.Identity.GetSourceByIdentifier(targetIdentifier)
    local removed, removeError = Repository.RemoveMember(actor.enterpriseId, memberId)
    if not removed then return nil, removeError end
    audit('member_removed', source, expectedIdentifier, {
        enterpriseId = actor.enterpriseId,
        memberId = memberId
    })

    if targetSource and CENServer.Identity.GetIdentifier(targetSource) == targetIdentifier then
        TriggerClientEvent('pixel_enterprises:client:membershipChanged', targetSource, {
            enterpriseId = actor.enterpriseId,
            enterpriseName = actor.enterpriseName,
            joined = false
        })
    end
    return listRoster(actor)
end

function Controller.LeaveEnterprise(source, payload, expectedIdentifier)
    local actor, errorCode = getActor(source, expectedIdentifier, CEN.Permissions.VIEW, CEN.Modules.DASHBOARD)
    if not actor then return nil, errorCode end
    if actor.isOwner then return nil, CEN.Errors.CANNOT_LEAVE_AS_OWNER end

    local left, leaveError = Repository.LeaveEnterprise(actor.enterpriseId, actor.memberId)
    if not left then return nil, leaveError end
    audit('member_left', source, expectedIdentifier, {
        enterpriseId = actor.enterpriseId,
        memberId = actor.memberId
    })
    if CENServer.Identity.GetIdentifier(source) == expectedIdentifier then
        TriggerClientEvent('pixel_enterprises:client:membershipChanged', source, {
            enterpriseId = actor.enterpriseId,
            enterpriseName = actor.enterpriseName,
            joined = false
        })
    end
    return { left = true, enterpriseId = actor.enterpriseId }
end

function Controller.DisbandEnterprise(source, payload, expectedIdentifier)
    local actor, errorCode = getActor(source, expectedIdentifier, CEN.Permissions.TRANSFER_OWNERSHIP, CEN.Modules.MEMBERS)
    if not actor then return nil, errorCode end
    if not actor.isOwner then return nil, CEN.Errors.OWNER_ONLY end
    if CEN.Validation.Trim(payload.confirm) ~= actor.enterpriseName then return nil, CEN.Errors.BAD_REQUEST end

    local disbanded, disbandError = Repository.SoftDisband(actor.enterpriseId, actor.memberId)
    if not disbanded then return nil, disbandError end
    audit('enterprise_owner_disbanded', source, expectedIdentifier, {
        enterpriseId = actor.enterpriseId,
        enterpriseName = actor.enterpriseName
    })
    return { disbanded = true, enterpriseId = actor.enterpriseId }
end

function Controller.TransferOwnership(source, payload, expectedIdentifier)
    local actor, errorCode = getActor(source, expectedIdentifier, CEN.Permissions.TRANSFER_OWNERSHIP, CEN.Modules.MEMBERS)
    if not actor then return nil, errorCode end
    if not actor.isOwner then return nil, CEN.Errors.OWNER_ONLY end

    local targetMemberId = integer(payload.memberId)
    if not targetMemberId then return nil, CEN.Errors.TARGET_NOT_MEMBER end
    if targetMemberId == actor.memberId then return nil, CEN.Errors.CANNOT_TARGET_SELF end
    local target, targetError = Repository.GetMemberById(actor.enterpriseId, targetMemberId)
    if not target then return nil, targetError end
    if target.isOwner then return nil, CEN.Errors.CONFLICT end

    local transferred, transferError = Repository.TransferOwnership(
        actor.enterpriseId, actor.memberId, targetMemberId)
    if not transferred then return nil, transferError end
    audit('ownership_transferred', source, expectedIdentifier, {
        enterpriseId = actor.enterpriseId,
        previousOwnerMemberId = actor.memberId,
        newOwnerMemberId = targetMemberId
    })

    local refreshedActor = Repository.GetMembershipByIdentifier(expectedIdentifier)
    return listRoster(refreshedActor or actor)
end

local actions = {
    bootstrap = Controller.Bootstrap,
    getRoster = Controller.GetRoster,
    createRank = Controller.CreateRank,
    updateRank = Controller.UpdateRank,
    deleteRank = Controller.DeleteRank,
    inviteMember = Controller.InviteMember,
    acceptMembershipInvite = Controller.AcceptMembershipInvite,
    declineMembershipInvite = Controller.DeclineMembershipInvite,
    setMemberRank = Controller.SetMemberRank,
    removeMember = Controller.RemoveMember,
    leaveEnterprise = Controller.LeaveEnterprise,
    disbandEnterprise = Controller.DisbandEnterprise,
    transferOwnership = Controller.TransferOwnership
}

Controller.Mutations = {
    createRank = true,
    updateRank = true,
    deleteRank = true,
    inviteMember = true,
    acceptMembershipInvite = true,
    declineMembershipInvite = true,
    setMemberRank = true,
    removeMember = true,
    leaveEnterprise = true,
    disbandEnterprise = true,
    transferOwnership = true
}

function Controller.IsKnownAction(action)
    return actions[action] ~= nil
end

function Controller.GetMutationKeys(source, action, payload, requesterIdentifier)
    if action == 'acceptMembershipInvite' or action == 'declineMembershipInvite' then
        local inviteId = integer(payload.inviteId)
        if not inviteId then return nil, CEN.Errors.MEMBERSHIP_INVITE_NOT_FOUND end
        local invite, errorCode = Invites.GetPendingById(inviteId, requesterIdentifier)
        if not invite then return nil, errorCode end
        return {
            ('enterprise:%s'):format(invite.enterpriseId),
            ('identity:%s'):format(requesterIdentifier),
            ('membership-invite:%s'):format(inviteId)
        }
    end

    local actor, errorCode = Repository.GetMembershipByIdentifier(requesterIdentifier)
    if not actor then return nil, errorCode end
    return { ('enterprise:%s'):format(actor.enterpriseId) }
end

function Controller.Handle(source, action, payload, requesterIdentifier)
    local handler = actions[action]
    if not handler then return nil, CEN.Errors.BAD_REQUEST end
    return handler(source, payload or {}, requesterIdentifier)
end
