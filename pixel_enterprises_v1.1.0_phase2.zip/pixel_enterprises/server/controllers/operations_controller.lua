CENServer = CENServer or {}
CENServer.OperationsController = CENServer.OperationsController or {}
local Controller = CENServer.OperationsController
local EnterpriseRepository = CENServer.Repository
local Treasury = CENServer.TreasuryRepository

local function resolve(source, expectedIdentifier, permission, moduleName)
    local live = CENServer.Identity.GetIdentifier(source)
    if not live or (expectedIdentifier and live ~= expectedIdentifier) then return nil, CEN.Errors.CONFLICT end
    local actor, errorCode = EnterpriseRepository.GetMembershipByIdentifier(expectedIdentifier or live)
    if not actor then return nil, errorCode end
    local allowed, authorizationError = CENServer.Authorize(actor, permission, moduleName)
    if not allowed then return nil, authorizationError end
    return actor
end

local function amount(value)
    value = tonumber(value)
    if not CEN.Validation.IsPositiveInteger(value) then return nil end
    value = math.floor(value)
    if value < Config.Economy.minimumTransaction or value > Config.Economy.maximumTransaction then return nil end
    return value
end

local function note(value)
    value = CEN.Validation.Trim(value or '')
    if #value > 120 then value = value:sub(1, 120) end
    return value
end

function Controller.GetTreasury(source, payload, expectedIdentifier)
    local actor, errorCode = resolve(source, expectedIdentifier, CEN.Permissions.VIEW, CEN.Modules.TREASURY)
    if not actor then return nil, errorCode end
    local summary, summaryError = Treasury.GetSummary(actor.enterpriseId, payload.limit)
    if not summary then return nil, summaryError end
    summary.canDeposit = CENServer.HasPermission(actor, CEN.Permissions.TREASURY_DEPOSIT)
    summary.canWithdraw = CENServer.HasPermission(actor, CEN.Permissions.TREASURY_WITHDRAW)
    summary.dailyWithdrawalLimit = Config.Economy.withdrawalDailyLimit
    return summary
end

function Controller.DepositTreasury(source, payload, expectedIdentifier)
    local actor, errorCode = resolve(source, expectedIdentifier, CEN.Permissions.TREASURY_DEPOSIT, CEN.Modules.TREASURY)
    if not actor then return nil, errorCode end
    local value = amount(payload.amount)
    if not value then return nil, CEN.Errors.INVALID_AMOUNT end
    local removed, removeError = CENServer.Economy.RemoveMoney(source, value, 'Enterprise treasury deposit')
    if not removed then return nil, removeError end
    local result, depositError = Treasury.Deposit(actor.enterpriseId, actor.memberId, value, note(payload.note), Config.Economy.maximumTreasuryBalance)
    if not result then
        CENServer.Economy.AddMoney(source, value, 'Treasury deposit refund')
        return nil, depositError
    end
    CENServer.Audit('treasury_deposit', source, { enterpriseId = actor.enterpriseId, amount = value }, expectedIdentifier)
    local award = math.floor((value / 1000) * (Config.Progression.awards.treasuryDepositPerThousand or 0))
    if award > 0 then CENServer.Progression.AddXp(actor.enterpriseId, actor.memberId, award, 'treasury_deposit', { amount = value }) end
    return Controller.GetTreasury(source, {}, expectedIdentifier)
end

function Controller.WithdrawTreasury(source, payload, expectedIdentifier)
    local actor, errorCode = resolve(source, expectedIdentifier, CEN.Permissions.TREASURY_WITHDRAW, CEN.Modules.TREASURY)
    if not actor then return nil, errorCode end
    local value = amount(payload.amount)
    if not value then return nil, CEN.Errors.INVALID_AMOUNT end
    local result, withdrawError = Treasury.Withdraw(actor.enterpriseId, actor.memberId, value, note(payload.note), Config.Economy.withdrawalDailyLimit)
    if not result then return nil, withdrawError end
    local paid, payError = CENServer.Economy.AddMoney(source, value, 'Enterprise treasury withdrawal')
    if not paid then
        Treasury.Reverse(actor.enterpriseId, actor.memberId, value, 'withdrawal_reversal', 'Automatic reversal: player payout failed')
        return nil, payError
    end
    CENServer.Audit('treasury_withdrawal', source, { enterpriseId = actor.enterpriseId, amount = value }, expectedIdentifier)
    return Controller.GetTreasury(source, {}, expectedIdentifier)
end

function Controller.GetProgression(source, payload, expectedIdentifier)
    local actor, errorCode = resolve(source, expectedIdentifier, CEN.Permissions.VIEW, CEN.Modules.PROGRESSION)
    if not actor then return nil, errorCode end
    return CENServer.Progression.Summary(actor.enterpriseId)
end

function Controller.GetLogs(source, payload, expectedIdentifier)
    local actor, errorCode = resolve(source, expectedIdentifier, CEN.Permissions.VIEW_LOGS, CEN.Modules.LOGS)
    if not actor then return nil, errorCode end
    local rows, listError = CENServer.LogRepository.List(actor.enterpriseId, payload.beforeId, payload.limit)
    if not rows then return nil, listError end
    return { logs = rows, hasMore = #rows >= math.min(Config.Logs.maximumPageSize, tonumber(payload.limit) or Config.Logs.pageSize) }
end

function Controller.OpenStorage(source, payload, expectedIdentifier)
    local actor, errorCode = resolve(source, expectedIdentifier, CEN.Permissions.STORAGE_ACCESS, CEN.Modules.STORAGE)
    if not actor then return nil, errorCode end
    if not CENServer.Storage.Open(source, actor.enterpriseId, actor.enterpriseName) then
        return nil, CEN.Errors.INTERNAL_ERROR
    end
    CENServer.Audit('storage_opened', source, { enterpriseId = actor.enterpriseId }, expectedIdentifier)
    return { opened = true }
end

local actions = {
    getTreasury = Controller.GetTreasury,
    depositTreasury = Controller.DepositTreasury,
    withdrawTreasury = Controller.WithdrawTreasury,
    getProgression = Controller.GetProgression,
    getLogs = Controller.GetLogs,
    openStorage = Controller.OpenStorage
}

Controller.Mutations = { depositTreasury = true, withdrawTreasury = true, openStorage = true }
function Controller.IsKnownAction(action) return actions[action] ~= nil end
function Controller.GetMutationKeys(source, action, payload, requesterIdentifier)
    local actor, errorCode = EnterpriseRepository.GetMembershipByIdentifier(requesterIdentifier)
    if not actor then return nil, errorCode end
    return { ('enterprise:%s'):format(actor.enterpriseId), ('identity:%s'):format(requesterIdentifier) }
end
function Controller.Handle(source, action, payload, requesterIdentifier)
    local handler = actions[action]
    if not handler then return nil, CEN.Errors.BAD_REQUEST end
    return handler(source, payload or {}, requesterIdentifier)
end
