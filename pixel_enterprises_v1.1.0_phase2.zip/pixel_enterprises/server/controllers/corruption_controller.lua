CENServer = CENServer or {}
CENServer.CorruptionController = CENServer.CorruptionController or {}
local Controller = CENServer.CorruptionController
local EnterpriseRepository = CENServer.Repository
local Corruption = CENServer.CorruptionRepository

local function resolve(source, identifier, permission)
    local live = CENServer.Identity.GetIdentifier(source)
    if not live or live ~= identifier then return nil, CEN.Errors.CONFLICT end
    local actor, errorCode = EnterpriseRepository.GetMembershipByIdentifier(identifier)
    if not actor then return nil, errorCode end
    local allowed, authorizationError = CENServer.Authorize(actor, permission, CEN.Modules.CORRUPTION)
    if not allowed then return nil, authorizationError end
    if tonumber(actor.level) < tonumber(Config.Corruption.minimumEnterpriseLevel or 6) then
        return nil, CEN.Errors.CORRUPTION_NOT_ALLOWED
    end
    return actor
end

local function positive(value)
    value = tonumber(value); if not CEN.Validation.IsPositiveInteger(value) then return nil end
    return math.floor(value)
end

function Controller.List(source, payload, identifier)
    local actor, errorCode = resolve(source, identifier, CEN.Permissions.VIEW)
    if not actor then return nil, errorCode end
    local data, listError = Corruption.List(actor.enterpriseId)
    if not data then return nil, listError end
    data.services = {}
    for key, service in pairs(Config.Corruption.services or {}) do
        data.services[#data.services + 1] = {
            key = key, label = service.label, minimumFee = service.minimumFee,
            exposure = service.exposure, heatReduction = service.heatReduction
        }
    end
    table.sort(data.services, function(a, b) return a.minimumFee < b.minimumFee end)
    data.canManage = CENServer.HasPermission(actor, CEN.Permissions.MANAGE_CORRUPTION)
    return data
end

function Controller.OfficerOffers(source, payload, identifier)
    local live = CENServer.Identity.GetIdentifier(source)
    if not live or live ~= identifier then return nil, CEN.Errors.CONFLICT end
    if not Config.Corruption.enabled then return { offers = {} } end
    local job = CENServer.Identity.GetJob(source)
    if not job or not Config.Corruption.policeJobs[job.name] then return { offers = {} } end
    local rows, errorCode = Corruption.PendingForOfficer(identifier)
    if not rows then return nil, errorCode end
    return { offers = rows, job = job.name }
end

function Controller.Create(source, payload, identifier)
    local actor, errorCode = resolve(source, identifier, CEN.Permissions.MANAGE_CORRUPTION)
    if not actor then return nil, errorCode end
    local target = positive(payload.targetServerId); if not target or GetPlayerName(target) == nil then return nil, CEN.Errors.TARGET_UNAVAILABLE end
    if target == source then return nil, CEN.Errors.CANNOT_TARGET_SELF end
    if not CENServer.Identity.AreNearby(source, target, Config.Membership.inviteMaxDistance) then return nil, CEN.Errors.TARGET_TOO_FAR end
    local job = CENServer.Identity.GetJob(target)
    if not job or not Config.Corruption.policeJobs[job.name] then return nil, CEN.Errors.CORRUPTION_NOT_ALLOWED end
    local serviceKey = tostring(payload.serviceKey or '')
    local service = Config.Corruption.services[serviceKey]
    if not service then return nil, CEN.Errors.CORRUPTION_NOT_ALLOWED end
    local fee = positive(payload.fee)
    if not fee or fee < tonumber(service.minimumFee or 0) or fee > Config.Economy.maximumTransaction then return nil, CEN.Errors.INVALID_AMOUNT end
    local targetIdentifier = CENServer.Identity.GetIdentifier(target)
    if not targetIdentifier then return nil, CEN.Errors.TARGET_UNAVAILABLE end
    local offerId, createError = Corruption.CreateOffer(actor.enterpriseId, actor.memberId,
        targetIdentifier, CENServer.Identity.GetDisplayName(target), serviceKey, fee, service.exposure or 0)
    if not offerId then return nil, createError end
    CENServer.NotifySource(target, ('You received a discreet enterprise offer. Open CEN to review offer #%s.'):format(offerId))
    CENServer.Audit('corruption_offer_created', source, {
        enterpriseId = actor.enterpriseId, offerId = offerId, serviceKey = serviceKey,
        fee = fee, officerJob = job.name
    }, identifier)
    return Controller.List(source, {}, identifier)
end

function Controller.Accept(source, payload, identifier)
    local live = CENServer.Identity.GetIdentifier(source)
    if not live or live ~= identifier then return nil, CEN.Errors.CONFLICT end
    local job = CENServer.Identity.GetJob(source)
    if not job or not Config.Corruption.policeJobs[job.name] then return nil, CEN.Errors.CORRUPTION_NOT_ALLOWED end
    local offerId = positive(payload.offerId); if not offerId then return nil, CEN.Errors.OFFER_NOT_FOUND end
    local before, beforeError = Corruption.GetOffer(offerId)
    if not before then return nil, beforeError end
    if before.officerIdentifier ~= identifier or before.status ~= 'pending' then return nil, CEN.Errors.OFFER_NOT_FOUND end
    local service = Config.Corruption.services[before.serviceKey]
    if not service then return nil, CEN.Errors.CORRUPTION_NOT_ALLOWED end
    local result, acceptError = Corruption.Accept(offerId, identifier)
    if not result then return nil, acceptError end
    local paid, payError = CENServer.Economy.AddMoney(source, result.fee, 'CEN corruption service payment')
    if not paid then
        Corruption.Reverse(offerId, result.enterpriseId, result.fee)
        return nil, payError
    end
    local completed = Corruption.Complete(offerId, result.enterpriseId)
    if completed and tonumber(service.heatReduction or 0) > 0 then
        CENServer.Heat.Reduce(result.enterpriseId, service.heatReduction, 'corruption_service')
    end
    if not completed then
        CENServer.Audit('corruption_completion_pending', source, {
            enterpriseId = result.enterpriseId, offerId = offerId
        }, identifier)
    end
    CENServer.Audit('corruption_offer_completed', source, {
        enterpriseId = result.enterpriseId, offerId = offerId,
        serviceKey = before.serviceKey, fee = result.fee, officerJob = job.name
    }, identifier)
    return Controller.OfficerOffers(source, {}, identifier)
end

function Controller.Decline(source, payload, identifier)
    local live = CENServer.Identity.GetIdentifier(source)
    if not live or live ~= identifier then return nil, CEN.Errors.CONFLICT end
    local offerId = positive(payload.offerId); if not offerId then return nil, CEN.Errors.OFFER_NOT_FOUND end
    local ok, affected = pcall(function()
        return MySQL.update.await([[UPDATE cen_corruption_offers SET status = 'declined'
          WHERE id = ? AND officer_identifier = ? AND status = 'pending']], { offerId, identifier })
    end)
    if not ok then return nil, CEN.Errors.DATABASE_UNAVAILABLE end
    if tonumber(affected) ~= 1 then return nil, CEN.Errors.OFFER_NOT_FOUND end
    return Controller.OfficerOffers(source, {}, identifier)
end

local actions = {
    listCorruption = Controller.List, getOfficerOffers = Controller.OfficerOffers,
    createCorruptionOffer = Controller.Create, acceptCorruptionOffer = Controller.Accept,
    declineCorruptionOffer = Controller.Decline
}
Controller.Mutations = { createCorruptionOffer = true, acceptCorruptionOffer = true, declineCorruptionOffer = true }
function Controller.IsKnownAction(action) return actions[action] ~= nil end
function Controller.GetMutationKeys(source, action, payload, identifier)
    if action == 'createCorruptionOffer' then
        local actor, errorCode = EnterpriseRepository.GetMembershipByIdentifier(identifier)
        if not actor then return nil, errorCode end
        return { ('enterprise:%s'):format(actor.enterpriseId), ('identity:%s'):format(identifier),
            ('identity-target:%s'):format(tostring(payload.targetServerId or 'unknown')) }
    end
    if action == 'acceptCorruptionOffer' or action == 'declineCorruptionOffer' then
        local offerId = positive(payload.offerId); if not offerId then return nil, CEN.Errors.OFFER_NOT_FOUND end
        local offer, errorCode = Corruption.GetOffer(offerId)
        if not offer then return nil, errorCode end
        return { ('corruption-offer:%s'):format(offerId), ('enterprise:%s'):format(offer.enterpriseId),
            ('identity:%s'):format(identifier) }
    end
    return { ('identity:%s'):format(identifier) }
end
function Controller.Handle(source, action, payload, identifier)
    local handler = actions[action]; if not handler then return nil, CEN.Errors.BAD_REQUEST end
    return handler(source, payload or {}, identifier)
end
