CENServer = CENServer or {}
CENServer.WarController = CENServer.WarController or {}
local Controller = CENServer.WarController
local Enterprises = CENServer.Repository
local Wars = CENServer.WarRepository

local function resolve(source, identifier, permission)
    local live = CENServer.Identity.GetIdentifier(source)
    if not live or live ~= identifier then return nil, CEN.Errors.CONFLICT end
    local actor, errorCode = Enterprises.GetMembershipByIdentifier(identifier)
    if not actor then return nil, errorCode end
    local allowed, authorizationError = CENServer.Authorize(actor, permission, CEN.Modules.WARS)
    if not allowed then return nil, authorizationError end
    return actor
end

local function integer(value, allowZero)
    value = tonumber(value)
    if allowZero and value == 0 then return 0 end
    if not CEN.Validation.IsPositiveInteger(value) then return nil end
    return math.floor(value)
end

function Controller.List(source, payload, identifier)
    local actor, errorCode = resolve(source, identifier, CEN.Permissions.VIEW)
    if not actor then return nil, errorCode end
    local wars, listError = Wars.List(actor.enterpriseId)
    if not wars then return nil, listError end
    local diplomacy, diplomacyError = CENServer.OrganizationRepository.ListDiplomacy(actor.enterpriseId, Config.Diplomacy.directoryLimit)
    if not diplomacy then return nil, diplomacyError end
    return {
        wars = wars,
        directory = diplomacy.directory,
        enterpriseId = actor.enterpriseId,
        enterpriseLevel = actor.level,
        canDeclare = CENServer.HasPermission(actor, CEN.Permissions.DECLARE_WAR),
        canRespond = CENServer.HasPermission(actor, CEN.Permissions.RESPOND_WAR),
        config = {
            minimumLevel = Config.Wars.minimumEnterpriseLevel,
            minimumStake = Config.Wars.minimumStake,
            maximumStake = Config.Wars.maximumStake,
            defaultTargetScore = Config.Wars.defaultTargetScore,
            minimumTargetScore = Config.Wars.minimumTargetScore,
            maximumTargetScore = Config.Wars.maximumTargetScore,
            durationSeconds = Config.Wars.durationSeconds,
            postWarCeasefireHours = Config.Wars.postWarCeasefireHours or 0
        }
    }
end

function Controller.Propose(source, payload, identifier)
    local actor, errorCode = resolve(source, identifier, CEN.Permissions.DECLARE_WAR)
    if not actor then return nil, errorCode end
    if tonumber(actor.level) < tonumber(Config.Wars.minimumEnterpriseLevel) then return nil, CEN.Errors.FORBIDDEN end
    local targetId = integer(payload.targetEnterpriseId)
    local stake = integer(payload.stake, true)
    local targetScore = integer(payload.targetScore)
    if not targetId or targetId == actor.enterpriseId or stake == nil or not targetScore then return nil, CEN.Errors.INVALID_WAR end
    if stake < Config.Wars.minimumStake or stake > Config.Wars.maximumStake
        or targetScore < Config.Wars.minimumTargetScore or targetScore > Config.Wars.maximumTargetScore then
        return nil, CEN.Errors.INVALID_WAR
    end
    local target, targetError = Enterprises.GetEnterprise(targetId)
    if not target or target.status ~= 'active' or tonumber(target.level) < tonumber(Config.Wars.minimumEnterpriseLevel) then
        return nil, targetError or CEN.Errors.INVALID_ENTERPRISE
    end
    local reason = CEN.Validation.Trim(payload.reason or '')
    if #reason > 180 then reason = reason:sub(1, 180) end
    local result, proposeError = Wars.Propose(actor.enterpriseId, targetId, actor.memberId, reason,
        targetScore, stake, Config.Wars.durationSeconds, Config.Wars.proposalExpiryHours)
    if not result then return nil, proposeError end
    CENServer.Audit('war_proposed', source, {
        enterpriseId = actor.enterpriseId, defenderEnterpriseId = targetId,
        warId = result.warId, stake = stake, targetScore = targetScore
    }, identifier)
    return Controller.List(source, {}, identifier)
end

function Controller.Respond(source, payload, identifier)
    local actor, errorCode = resolve(source, identifier, CEN.Permissions.RESPOND_WAR)
    if not actor then return nil, errorCode end
    local warId = integer(payload.warId)
    if not warId then return nil, CEN.Errors.WAR_NOT_FOUND end
    local war, warError = Wars.Get(warId)
    if not war then return nil, warError end
    if war.defenderEnterpriseId ~= actor.enterpriseId or war.status ~= 'proposed' then return nil, CEN.Errors.FORBIDDEN end
    local accepted = payload.accepted == true
    local result, respondError = Wars.Respond(warId, actor.enterpriseId, actor.memberId, accepted, Config.Wars.durationSeconds)
    if not result then return nil, respondError end
    CENServer.Audit('war_responded', source, {
        enterpriseId = actor.enterpriseId, warId = warId, accepted = accepted,
        attackerEnterpriseId = war.attackerEnterpriseId
    }, identifier)
    return Controller.List(source, {}, identifier)
end

function Controller.Cancel(source, payload, identifier)
    local actor, errorCode = resolve(source, identifier, CEN.Permissions.DECLARE_WAR)
    if not actor then return nil, errorCode end
    local warId = integer(payload.warId)
    if not warId then return nil, CEN.Errors.WAR_NOT_FOUND end
    local war, warError = Wars.Get(warId)
    if not war then return nil, warError end
    if war.attackerEnterpriseId ~= actor.enterpriseId or war.status ~= 'proposed' then return nil, CEN.Errors.FORBIDDEN end
    local result, cancelError = Wars.Cancel(warId, actor.enterpriseId)
    if not result then return nil, cancelError end
    CENServer.Audit('war_cancelled', source, { enterpriseId = actor.enterpriseId, warId = warId }, identifier)
    return Controller.List(source, {}, identifier)
end

local actions = { listWars = Controller.List, proposeWar = Controller.Propose, respondWar = Controller.Respond, cancelWar = Controller.Cancel }
Controller.Mutations = { proposeWar = true, respondWar = true, cancelWar = true }
function Controller.IsKnownAction(action) return actions[action] ~= nil end
function Controller.GetMutationKeys(source, action, payload, identifier)
    local actor, errorCode = Enterprises.GetMembershipByIdentifier(identifier)
    if not actor then return nil, errorCode end
    local keys = { ('enterprise:%s'):format(actor.enterpriseId), ('identity:%s'):format(identifier) }
    if payload.targetEnterpriseId then keys[#keys + 1] = ('enterprise:%s'):format(tostring(payload.targetEnterpriseId)) end
    if payload.warId then
        keys[#keys + 1] = ('war:%s'):format(tostring(payload.warId))
        local war = Wars.Get(tonumber(payload.warId))
        if war then
            keys[#keys + 1] = ('enterprise:%s'):format(war.attackerEnterpriseId)
            keys[#keys + 1] = ('enterprise:%s'):format(war.defenderEnterpriseId)
        end
    end
    return keys
end
function Controller.Handle(source, action, payload, identifier)
    local handler = actions[action]
    if not handler then return nil, CEN.Errors.BAD_REQUEST end
    return handler(source, payload or {}, identifier)
end
