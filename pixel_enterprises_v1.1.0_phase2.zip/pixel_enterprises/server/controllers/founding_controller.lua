CENServer = CENServer or {}
CENServer.FoundingController = CENServer.FoundingController or {}

local Controller = CENServer.FoundingController
local Founding = CENServer.FoundingRepository
local Members = CENServer.Repository

local function positiveInteger(value)
    local number = tonumber(value)
    if not CEN.Validation.IsPositiveInteger(number) then return nil end
    return number
end

local function identifier(source, expectedIdentifier)
    local value = CENServer.Identity.GetIdentifier(source)
    if not value then return nil, CEN.Errors.LICENSE_MISSING end
    if expectedIdentifier and value ~= expectedIdentifier then return nil, CEN.Errors.CONFLICT end
    return expectedIdentifier or value
end

local function ensureNotMember(playerIdentifier)
    local existing, errorCode = Members.GetMembershipAnyStatus(playerIdentifier)
    if existing and existing.status ~= 'removed' then return false, CEN.Errors.TARGET_ALREADY_MEMBER end
    if not existing and errorCode ~= CEN.Errors.NOT_MEMBER then return false, errorCode end
    return true
end

local function audit(eventName, source, actorIdentifier, payload)
    return CENServer.Audit(eventName, source, payload, actorIdentifier)
end

local function proposalDto(proposal)
    if not proposal then return nil end
    return {
        proposalId = proposal.proposalId,
        founderDisplayName = proposal.founderDisplayName,
        name = proposal.name,
        slug = proposal.slug,
        enterpriseType = proposal.enterpriseType,
        creationPlan = proposal.creationPlan,
        requiredAcceptances = proposal.requiredAcceptances,
        acceptedCount = proposal.acceptedCount,
        status = proposal.status,
        expiresAt = proposal.expiresAt,
        createdAt = proposal.createdAt
    }
end

local function finalizeWithParticipantLocks(source, proposal, requesterIdentifier)
    -- Database procedures enforce participant exclusivity and lock the proposal.
    -- Keeping this flat avoids lock-order inversion between proposal/name/identity keys.
    return Founding.FinalizeProposal(proposal.proposalId)
end

local function proposalForFounder(source, expectedIdentifier)
    local founderIdentifier, idError = identifier(source, expectedIdentifier)
    if not founderIdentifier then return nil, idError end
    local proposal, errorCode = Founding.GetActiveProposalByFounder(founderIdentifier)
    if not proposal then return nil, errorCode or CEN.Errors.PROPOSAL_NOT_FOUND end
    return proposal, nil, founderIdentifier
end

function Controller.GetCreationContext(source, payload, expectedIdentifier)
    local playerIdentifier, idError = identifier(source, expectedIdentifier)
    if not playerIdentifier then return nil, idError end
    local membership = Members.GetMembershipByIdentifier(playerIdentifier)
    local proposal = Founding.GetActiveProposalByFounder(playerIdentifier)
    local invites, inviteError = Founding.ListPendingInvitesForIdentifier(playerIdentifier)
    if not invites and inviteError then return nil, inviteError end
    local membershipInvites, membershipInviteError = CENServer.MembershipInviteRepository.ListPendingForIdentifier(playerIdentifier)
    if not membershipInvites and membershipInviteError then return nil, membershipInviteError end

    local policies = {}
    for key in pairs(CEN.EnterpriseTypes) do policies[key] = CENServer.CreationPolicy.Resolve(key) end

    return {
        isMember = membership ~= nil,
        proposal = proposalDto(proposal),
        pendingInvites = invites or {},
        pendingMembershipInvites = membershipInvites or {},
        typePolicies = policies,
        requiredAcceptances = Config.Creation.founding.requiredAcceptances,
        founderCountsAsAcceptance = Config.Creation.founding.founderCountsAsAcceptance,
        baseMemberLimit = Config.Creation.plans.free.baseMemberLimit
    }
end

function Controller.StartFounding(source, payload, expectedIdentifier)
    local playerIdentifier, idError = identifier(source, expectedIdentifier)
    if not playerIdentifier then return nil, idError end
    local notMember, membershipError = ensureNotMember(playerIdentifier)
    if not notMember then return nil, membershipError end
    local participation, participationError = Founding.GetActiveParticipationByIdentifier(playerIdentifier)
    if participation then
        return nil, participation.role == 'founder'
            and CEN.Errors.ALREADY_HAS_PROPOSAL or CEN.Errors.ALREADY_SUPPORTING_PROPOSAL
    end
    if participationError then return nil, participationError end

    local enterpriseType = CEN.Validation.Trim(payload.enterpriseType)
    local allowed, policyError, creationPlan = CENServer.CreationPolicy.CanStart(source, enterpriseType)
    if not allowed then return nil, policyError end

    local existing, existingError = Founding.GetActiveProposalByFounder(playerIdentifier)
    if existing then return nil, CEN.Errors.ALREADY_HAS_PROPOSAL end
    if existingError then return nil, existingError end

    local name = CEN.Validation.Trim(payload.name)
    if not CEN.Validation.ValidEnterpriseName(name) then return nil, CEN.Errors.INVALID_ENTERPRISE_NAME end
    local slug = CEN.Validation.Slugify(name)
    if not slug then return nil, CEN.Errors.INVALID_ENTERPRISE_NAME end
    local taken, takenError = Founding.IsNameOrSlugTaken(name, slug)
    if taken == nil then return nil, takenError end
    if taken then return nil, CEN.Errors.ENTERPRISE_NAME_EXISTS end

    local proposalId, createError = Founding.CreateProposal(
        playerIdentifier,
        CENServer.Identity.GetDisplayName(source),
        name,
        slug,
        enterpriseType,
        creationPlan or 'free'
    )
    if not proposalId then return nil, createError end

    audit('founding_proposal_created', source, playerIdentifier, {
        proposalId = proposalId,
        name = name,
        slug = slug,
        enterpriseType = enterpriseType,
        requiredAcceptances = Config.Creation.founding.requiredAcceptances
    })
    local proposal, proposalError = Founding.GetProposal(proposalId)
    if not proposal then return nil, proposalError end
    return proposalDto(proposal)
end

function Controller.InviteFounder(source, payload, expectedIdentifier)
    local proposal, proposalError, founderIdentifier = proposalForFounder(source, expectedIdentifier)
    if not proposal then return nil, proposalError end
    if proposal.status ~= 'pending' and proposal.status ~= 'ready' then return nil, CEN.Errors.PROPOSAL_NOT_READY end

    local targetSource = positiveInteger(payload.targetServerId)
    if not targetSource or not GetPlayerName(targetSource) then return nil, CEN.Errors.TARGET_UNAVAILABLE end
    if targetSource == source then return nil, CEN.Errors.CANNOT_TARGET_SELF end
    if Config.Creation.founding.requireNearbyInvite
        and not CENServer.Identity.AreNearby(source, targetSource, Config.Creation.founding.inviteMaxDistance) then
        return nil, CEN.Errors.TARGET_UNAVAILABLE
    end

    local targetIdentifier = CENServer.Identity.GetIdentifier(targetSource)
    if not targetIdentifier then return nil, CEN.Errors.LICENSE_MISSING end
    local notMember, membershipError = ensureNotMember(targetIdentifier)
    if not notMember then return nil, membershipError end
    local participation, participationError = Founding.GetActiveParticipationByIdentifier(targetIdentifier)
    if participation then
        return nil, participation.role == 'founder'
            and CEN.Errors.ALREADY_HAS_PROPOSAL or CEN.Errors.ALREADY_SUPPORTING_PROPOSAL
    end
    if participationError then return nil, participationError end

    local inviteCount, countError = Founding.CountInvites(proposal.proposalId)
    if inviteCount == nil then return nil, countError end
    if inviteCount >= Config.Creation.founding.maxPendingInvites then
        return nil, CEN.Errors.INVITE_LIMIT_REACHED
    end

    local inviteId, inviteError = Founding.CreateInvite(
        proposal.proposalId,
        targetIdentifier,
        CENServer.Identity.GetDisplayName(targetSource),
        founderIdentifier
    )
    if not inviteId then return nil, inviteError end

    if CENServer.Identity.GetIdentifier(targetSource) == targetIdentifier then
        CENServer.NotifySource(targetSource, ('You were invited to help found %s. Accept proposal #%d.'):format(
            proposal.name, proposal.proposalId), 'info')
    end
    audit('founding_invite_sent', source, founderIdentifier, {
        proposalId = proposal.proposalId,
        inviteId = inviteId,
        targetSource = targetSource
    })
    local refreshed, refreshError = Founding.GetProposal(proposal.proposalId)
    if not refreshed then return nil, refreshError end
    return proposalDto(refreshed)
end

local function notifyFoundingMembers(proposal, accepted)
    local founderSource = CENServer.Identity.GetSourceByIdentifier(proposal.founderIdentifier)
    if founderSource then
        TriggerClientEvent('pixel_enterprises:client:membershipChanged', founderSource, {
            enterpriseName = proposal.name, joined = true
        })
    end
    for i = 1, #(accepted or {}) do
        local source = CENServer.Identity.GetSourceByIdentifier(accepted[i].identifier)
        if source then
            TriggerClientEvent('pixel_enterprises:client:membershipChanged', source, {
                enterpriseName = proposal.name, joined = true
            })
        end
    end
end

function Controller.AcceptFounding(source, payload, expectedIdentifier)
    local playerIdentifier, idError = identifier(source, expectedIdentifier)
    if not playerIdentifier then return nil, idError end
    local notMember, membershipError = ensureNotMember(playerIdentifier)
    if not notMember then return nil, membershipError end

    local proposalId = positiveInteger(payload.proposalId)
    if not proposalId then return nil, CEN.Errors.PROPOSAL_NOT_FOUND end
    local participation, participationError = Founding.GetActiveParticipationByIdentifier(playerIdentifier)
    if participation then
        return nil, participation.role == 'founder'
            and CEN.Errors.ALREADY_HAS_PROPOSAL or CEN.Errors.ALREADY_SUPPORTING_PROPOSAL
    end
    if participationError then return nil, participationError end

    local invite, inviteError = Founding.GetPendingInvite(proposalId, playerIdentifier)
    if not invite then return nil, inviteError end
    local accepted, acceptError = Founding.AcceptInvite(invite.inviteId, playerIdentifier)
    if not accepted then return nil, acceptError end

    local proposal, proposalError = Founding.GetProposal(proposalId)
    if not proposal then return nil, proposalError end
    audit('founding_invite_accepted', source, playerIdentifier, {
        proposalId = proposalId,
        acceptedCount = proposal.acceptedCount,
        requiredAcceptances = proposal.requiredAcceptances
    })

    if proposal.acceptedCount >= proposal.requiredAcceptances then
        if Config.Creation.founding.requireAdminApprovalAfterThreshold then
            local marked, markError = Founding.MarkReady(proposalId, true)
            if not marked then return nil, markError or CEN.Errors.CONFLICT end
            CENServer.NotifyIdentifier(proposal.founderIdentifier,
                ('%s reached the founding requirement and is awaiting administrator approval.'):format(proposal.name), 'success')
        elseif Config.Creation.founding.autoFinalizeAtThreshold then
            local marked, markError = Founding.MarkReady(proposalId, false)
            if not marked then return nil, markError or CEN.Errors.CONFLICT end
            local finalizing, finalizingError = Founding.MarkFinalizing(proposalId, 'ready')
            if not finalizing then return nil, finalizingError end
            local enterpriseId, finalizeError, acceptedMembers = finalizeWithParticipantLocks(source, proposal, playerIdentifier)
            if not enterpriseId then
                Founding.ResetFinalizing(proposalId, 'ready')
                return nil, finalizeError
            end
            notifyFoundingMembers(proposal, acceptedMembers)
            audit('enterprise_founded', source, playerIdentifier, {
                enterpriseId = enterpriseId,
                proposalId = proposalId,
                enterpriseType = proposal.enterpriseType,
                foundingAcceptances = proposal.acceptedCount
            })
            CENServer.Progression.AddXp(enterpriseId, nil,
                Config.Progression.awards.foundingCompleted or 0,
                'enterprise_founded', { proposalId = proposalId })
            return {
                finalized = true,
                enterpriseId = enterpriseId,
                enterpriseName = proposal.name
            }
        end
    end

    local refreshed, refreshError = Founding.GetProposal(proposalId)
    if not refreshed then return nil, refreshError end
    return proposalDto(refreshed)
end

function Controller.DeclineFounding(source, payload, expectedIdentifier)
    local playerIdentifier, idError = identifier(source, expectedIdentifier)
    if not playerIdentifier then return nil, idError end
    local proposalId = positiveInteger(payload.proposalId)
    if not proposalId then return nil, CEN.Errors.PROPOSAL_NOT_FOUND end
    local invite, inviteError = Founding.GetPendingInvite(proposalId, playerIdentifier)
    if not invite then return nil, inviteError end
    local declined, declineError = Founding.DeclineInvite(invite.inviteId)
    if not declined then return nil, declineError end
    audit('founding_invite_declined', source, playerIdentifier, { proposalId = proposalId })
    return { declined = true, proposalId = proposalId }
end

function Controller.CancelFounding(source, payload, expectedIdentifier)
    local proposal, proposalError, founderIdentifier = proposalForFounder(source, expectedIdentifier)
    if not proposal then return nil, proposalError end
    if payload.proposalId and tonumber(payload.proposalId) ~= tonumber(proposal.proposalId) then
        return nil, CEN.Errors.PROPOSAL_NOT_FOUND
    end
    local cancelled, cancelError = Founding.CancelProposal(proposal.proposalId, founderIdentifier)
    if not cancelled then return nil, cancelError end
    audit('founding_proposal_cancelled', source, founderIdentifier, { proposalId = proposal.proposalId })
    return { cancelled = true, proposalId = proposal.proposalId }
end

local actions = {
    getCreationContext = Controller.GetCreationContext,
    startFounding = Controller.StartFounding,
    inviteFoundingMember = Controller.InviteFounder,
    acceptFoundingInvite = Controller.AcceptFounding,
    declineFoundingInvite = Controller.DeclineFounding,
    cancelFounding = Controller.CancelFounding
}

Controller.Mutations = {
    startFounding = true,
    inviteFoundingMember = true,
    acceptFoundingInvite = true,
    declineFoundingInvite = true,
    cancelFounding = true
}

function Controller.IsKnownAction(action) return actions[action] ~= nil end
function Controller.GetMutationKeys(source, action, payload, requesterIdentifier)
    if action == 'acceptFoundingInvite' or action == 'declineFoundingInvite' then
        local proposalId = positiveInteger(payload.proposalId)
        if not proposalId then return nil, CEN.Errors.PROPOSAL_NOT_FOUND end
        return {
            ('founding-proposal:%s'):format(proposalId),
            ('identity:%s'):format(requesterIdentifier)
        }
    end
    if action == 'startFounding' then
        local name = CEN.Validation.Trim(payload.name)
        local slug = CEN.Validation.Slugify(name)
        if not slug then return nil, CEN.Errors.INVALID_ENTERPRISE_NAME end
        return {
            ('identity:%s'):format(requesterIdentifier),
            ('founding-name:%s'):format(slug)
        }
    end
    return { ('identity:%s'):format(requesterIdentifier) }
end

function Controller.Handle(source, action, payload, requesterIdentifier)
    local handler = actions[action]
    if not handler then return nil, CEN.Errors.BAD_REQUEST end
    return handler(source, payload or {}, requesterIdentifier)
end
