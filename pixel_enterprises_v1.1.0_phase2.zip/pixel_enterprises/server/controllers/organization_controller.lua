CENServer = CENServer or {}
CENServer.OrganizationController = CENServer.OrganizationController or {}
local Controller = CENServer.OrganizationController
local Enterprises = CENServer.Repository
local Organizations = CENServer.OrganizationRepository

local function resolve(source, identifier, permission, moduleName)
    local live = CENServer.Identity.GetIdentifier(source)
    if not live or live ~= identifier then return nil, CEN.Errors.CONFLICT end
    local actor, errorCode = Enterprises.GetMembershipByIdentifier(identifier)
    if not actor then return nil, errorCode end
    local allowed, authorizationError = CENServer.Authorize(actor, permission, moduleName)
    if not allowed then return nil, authorizationError end
    return actor
end

local function integer(value)
    value = tonumber(value)
    if not CEN.Validation.IsPositiveInteger(value) then return nil end
    return math.floor(value)
end

local function cleanText(value, maximum)
    value = CEN.Validation.Trim(value or '')
    if value == '' then return nil end
    if #value > maximum then value = value:sub(1, maximum) end
    return value
end

local function crewLimit(level)
    local every = math.max(1, tonumber(Config.Crews.extraCrewEveryLevels) or 5)
    local value = (tonumber(Config.Crews.baseMaximumCrews) or 2) + math.floor((tonumber(level) or 1) / every)
    return math.min(tonumber(Config.Crews.maximumCrews) or 8, value)
end

function Controller.ListCrews(source, payload, identifier)
    local actor, errorCode = resolve(source, identifier, CEN.Permissions.VIEW, CEN.Modules.CREWS)
    if not actor then return nil, errorCode end
    local crews, listError = Organizations.ListCrews(actor.enterpriseId)
    if not crews then return nil, listError end
    return {
        crews = crews,
        canManage = CENServer.HasPermission(actor, CEN.Permissions.MANAGE_CREWS),
        maximumCrews = crewLimit(actor.level),
        defaultMaximumMembers = Config.Crews.defaultMaximumMembers
    }
end

function Controller.CreateCrew(source, payload, identifier)
    local actor, errorCode = resolve(source, identifier, CEN.Permissions.MANAGE_CREWS, CEN.Modules.CREWS)
    if not actor then return nil, errorCode end
    if tonumber(actor.level) < tonumber(Config.Crews.minimumEnterpriseLevel) then return nil, CEN.Errors.FORBIDDEN end
    local crews, listError = Organizations.ListCrews(actor.enterpriseId)
    if not crews then return nil, listError end
    if #crews >= crewLimit(actor.level) then return nil, CEN.Errors.CREW_LIMIT_REACHED end
    local name = cleanText(payload.name, Config.Crews.maximumNameLength)
    if not name or #name < Config.Crews.minimumNameLength then return nil, CEN.Errors.BAD_REQUEST end
    local leaderMemberId = integer(payload.leaderMemberId)
    if not leaderMemberId then return nil, CEN.Errors.TARGET_NOT_MEMBER end
    local leader, leaderError = Enterprises.GetMemberById(actor.enterpriseId, leaderMemberId)
    if not leader then return nil, leaderError end
    local maxMembers = math.max(2, math.min(Config.Crews.absoluteMaximumMembers,
        integer(payload.maxMembers) or Config.Crews.defaultMaximumMembers))
    local crewId, createError = Organizations.CreateCrew(actor.enterpriseId, name, leaderMemberId, maxMembers, crewLimit(actor.level))
    if not crewId then return nil, createError end
    CENServer.Audit('crew_created', source, {
        enterpriseId = actor.enterpriseId, crewId = crewId, name = name,
        leaderMemberId = leaderMemberId, maxMembers = maxMembers
    }, identifier)
    return Controller.ListCrews(source, {}, identifier)
end

function Controller.AssignCrewMember(source, payload, identifier)
    local actor, errorCode = resolve(source, identifier, CEN.Permissions.MANAGE_CREWS, CEN.Modules.CREWS)
    if not actor then return nil, errorCode end
    local crewId, memberId = integer(payload.crewId), integer(payload.memberId)
    if not crewId or not memberId then return nil, CEN.Errors.BAD_REQUEST end
    local target, targetError = Enterprises.GetMemberById(actor.enterpriseId, memberId)
    if not target then return nil, targetError end
    local ok, assignError = Organizations.AssignCrewMember(actor.enterpriseId, crewId, memberId)
    if not ok then return nil, assignError end
    CENServer.Audit('crew_member_assigned', source, {
        enterpriseId = actor.enterpriseId, crewId = crewId, targetMemberId = memberId
    }, identifier)
    return Controller.ListCrews(source, {}, identifier)
end

function Controller.RemoveCrewMember(source, payload, identifier)
    local actor, errorCode = resolve(source, identifier, CEN.Permissions.MANAGE_CREWS, CEN.Modules.CREWS)
    if not actor then return nil, errorCode end
    local crewId, memberId = integer(payload.crewId), integer(payload.memberId)
    if not crewId or not memberId then return nil, CEN.Errors.BAD_REQUEST end
    local ok, removeError = Organizations.RemoveCrewMember(actor.enterpriseId, crewId, memberId)
    if not ok then return nil, removeError end
    CENServer.Audit('crew_member_removed', source, {
        enterpriseId = actor.enterpriseId, crewId = crewId, targetMemberId = memberId
    }, identifier)
    return Controller.ListCrews(source, {}, identifier)
end


function Controller.SetCrewLeader(source, payload, identifier)
    local actor, errorCode = resolve(source, identifier, CEN.Permissions.MANAGE_CREWS, CEN.Modules.CREWS)
    if not actor then return nil, errorCode end
    local crewId, memberId = integer(payload.crewId), integer(payload.memberId)
    if not crewId or not memberId then return nil, CEN.Errors.BAD_REQUEST end
    local target, targetError = Enterprises.GetMemberById(actor.enterpriseId, memberId)
    if not target then return nil, targetError end
    local ok, setError = Organizations.SetCrewLeader(actor.enterpriseId, crewId, memberId)
    if not ok then return nil, setError end
    CENServer.Audit('crew_leader_changed', source, {
        enterpriseId = actor.enterpriseId, crewId = crewId, targetMemberId = memberId
    }, identifier)
    return Controller.ListCrews(source, {}, identifier)
end

function Controller.DeleteCrew(source, payload, identifier)
    local actor, errorCode = resolve(source, identifier, CEN.Permissions.MANAGE_CREWS, CEN.Modules.CREWS)
    if not actor then return nil, errorCode end
    local crewId = integer(payload.crewId)
    if not crewId then return nil, CEN.Errors.CREW_NOT_FOUND end
    local ok, deleteError = Organizations.DeleteCrew(actor.enterpriseId, crewId)
    if not ok then return nil, deleteError end
    CENServer.Audit('crew_deleted', source, { enterpriseId = actor.enterpriseId, crewId = crewId }, identifier)
    return Controller.ListCrews(source, {}, identifier)
end

function Controller.ListDiplomacy(source, payload, identifier)
    local actor, errorCode = resolve(source, identifier, CEN.Permissions.VIEW, CEN.Modules.DIPLOMACY)
    if not actor then return nil, errorCode end
    local data, listError = Organizations.ListDiplomacy(actor.enterpriseId, Config.Diplomacy.directoryLimit)
    if not data then return nil, listError end
    data.enterpriseId = actor.enterpriseId
    data.canManage = CENServer.HasPermission(actor, CEN.Permissions.MANAGE_DIPLOMACY)
    return data
end

function Controller.ProposeDiplomacy(source, payload, identifier)
    local actor, errorCode = resolve(source, identifier, CEN.Permissions.MANAGE_DIPLOMACY, CEN.Modules.DIPLOMACY)
    if not actor then return nil, errorCode end
    local targetId = integer(payload.targetEnterpriseId)
    local relationType = tostring(payload.relationType or '')
    if not targetId or targetId == actor.enterpriseId or (relationType ~= 'allied' and relationType ~= 'ceasefire') then
        return nil, CEN.Errors.BAD_REQUEST
    end
    local target, targetError = Enterprises.GetEnterprise(targetId)
    if not target or target.status ~= 'active' then return nil, targetError or CEN.Errors.INVALID_ENTERPRISE end
    local message = cleanText(payload.message, 180) or ''
    local proposalId, createError = Organizations.CreateDiplomacyProposal(actor.enterpriseId, targetId,
        actor.memberId, relationType, message, Config.Diplomacy.proposalExpiryHours,
        Config.Diplomacy.relationshipCooldownSeconds)
    if not proposalId then return nil, createError end
    CENServer.Audit('diplomacy_proposed', source, {
        enterpriseId = actor.enterpriseId, targetEnterpriseId = targetId,
        relationType = relationType, proposalId = proposalId
    }, identifier)
    return Controller.ListDiplomacy(source, {}, identifier)
end

function Controller.RespondDiplomacy(source, payload, identifier)
    local actor, errorCode = resolve(source, identifier, CEN.Permissions.MANAGE_DIPLOMACY, CEN.Modules.DIPLOMACY)
    if not actor then return nil, errorCode end
    local proposalId = integer(payload.proposalId)
    if not proposalId then return nil, CEN.Errors.DIPLOMACY_NOT_FOUND end
    local accepted = payload.accepted == true
    local ok, respondError = Organizations.RespondDiplomacy(proposalId, actor.enterpriseId, accepted,
        Config.Diplomacy.ceasefireHours)
    if not ok then return nil, respondError end
    CENServer.Audit('diplomacy_responded', source, {
        enterpriseId = actor.enterpriseId, proposalId = proposalId, accepted = accepted
    }, identifier)
    return Controller.ListDiplomacy(source, {}, identifier)
end


function Controller.CancelDiplomacy(source, payload, identifier)
    local actor, errorCode = resolve(source, identifier, CEN.Permissions.MANAGE_DIPLOMACY, CEN.Modules.DIPLOMACY)
    if not actor then return nil, errorCode end
    local proposalId = integer(payload.proposalId)
    if not proposalId then return nil, CEN.Errors.DIPLOMACY_NOT_FOUND end
    local ok, cancelError = Organizations.CancelDiplomacy(proposalId, actor.enterpriseId)
    if not ok then return nil, cancelError end
    CENServer.Audit('diplomacy_cancelled', source, {
        enterpriseId = actor.enterpriseId, proposalId = proposalId
    }, identifier)
    return Controller.ListDiplomacy(source, {}, identifier)
end

function Controller.EndDiplomacy(source, payload, identifier)
    local actor, errorCode = resolve(source, identifier, CEN.Permissions.MANAGE_DIPLOMACY, CEN.Modules.DIPLOMACY)
    if not actor then return nil, errorCode end
    local relationId = integer(payload.relationId)
    if not relationId then return nil, CEN.Errors.DIPLOMACY_NOT_FOUND end
    local ok, endError = Organizations.EndRelation(actor.enterpriseId, relationId)
    if not ok then return nil, endError end
    CENServer.Audit('diplomacy_ended', source, {
        enterpriseId = actor.enterpriseId, relationId = relationId
    }, identifier)
    return Controller.ListDiplomacy(source, {}, identifier)
end

local actions = {
    listCrews = Controller.ListCrews,
    createCrew = Controller.CreateCrew,
    assignCrewMember = Controller.AssignCrewMember,
    removeCrewMember = Controller.RemoveCrewMember,
    setCrewLeader = Controller.SetCrewLeader,
    deleteCrew = Controller.DeleteCrew,
    listDiplomacy = Controller.ListDiplomacy,
    proposeDiplomacy = Controller.ProposeDiplomacy,
    respondDiplomacy = Controller.RespondDiplomacy,
    cancelDiplomacy = Controller.CancelDiplomacy,
    endDiplomacy = Controller.EndDiplomacy
}

Controller.Mutations = {
    createCrew = true, assignCrewMember = true, removeCrewMember = true, setCrewLeader = true, deleteCrew = true,
    proposeDiplomacy = true, respondDiplomacy = true, cancelDiplomacy = true, endDiplomacy = true
}
function Controller.IsKnownAction(action) return actions[action] ~= nil end
function Controller.GetMutationKeys(source, action, payload, identifier)
    local actor, errorCode = Enterprises.GetMembershipByIdentifier(identifier)
    if not actor then return nil, errorCode end
    local keys = { ('enterprise:%s'):format(actor.enterpriseId), ('identity:%s'):format(identifier) }
    if payload.crewId then keys[#keys + 1] = ('crew:%s'):format(tostring(payload.crewId)) end
    if payload.memberId then keys[#keys + 1] = ('member:%s'):format(tostring(payload.memberId)) end
    if payload.targetEnterpriseId then keys[#keys + 1] = ('enterprise:%s'):format(tostring(payload.targetEnterpriseId)) end
    if payload.proposalId then keys[#keys + 1] = ('diplomacy-proposal:%s'):format(tostring(payload.proposalId)) end
    if payload.relationId then keys[#keys + 1] = ('diplomacy-relation:%s'):format(tostring(payload.relationId)) end
    return keys
end
function Controller.Handle(source, action, payload, identifier)
    local handler = actions[action]
    if not handler then return nil, CEN.Errors.BAD_REQUEST end
    return handler(source, payload or {}, identifier)
end
