CENServer = CENServer or {}
CENServer.TerritoryController = CENServer.TerritoryController or {}
local Controller = CENServer.TerritoryController
local EnterpriseRepository = CENServer.Repository
local Zones = CENServer.ZoneRepository

local function resolve(source, expectedIdentifier, permission, moduleName)
    local live = CENServer.Identity.GetIdentifier(source)
    if not live or (expectedIdentifier and live ~= expectedIdentifier) then return nil, CEN.Errors.CONFLICT end
    local actor, errorCode = EnterpriseRepository.GetMembershipByIdentifier(expectedIdentifier or live)
    if not actor then return nil, errorCode end
    local allowed, authorizationError = CENServer.Authorize(actor, permission, moduleName)
    if not allowed then return nil, authorizationError end
    return actor
end

local function positiveInteger(value)
    value = tonumber(value)
    if not CEN.Validation.IsPositiveInteger(value) then return nil end
    return math.floor(value)
end

local function moduleForZone(zoneType)
    return zoneType == 'turf' and CEN.Modules.TURFS or CEN.Modules.TERRITORIES
end

local function permissionForZone(zoneType)
    return zoneType == 'turf' and CEN.Permissions.START_TURF_CONTEST
        or CEN.Permissions.START_TERRITORY_CONTEST
end

function Controller.ListZones(source, payload, expectedIdentifier)
    local actor, errorCode = resolve(source, expectedIdentifier, CEN.Permissions.VIEW, CEN.Modules.DASHBOARD)
    if not actor then return nil, errorCode end
    local zones, listError = Zones.List()
    if not zones then return nil, listError end
    local filtered = {}
    for i = 1, #zones do
        if CENServer.CanAccessModule(actor.enterpriseType, moduleForZone(zones[i].zoneType)) then
            filtered[#filtered + 1] = zones[i]
        end
    end
    return { zones = filtered, enterpriseId = actor.enterpriseId, enterpriseLevel = actor.level }
end

function Controller.StartContest(source, payload, expectedIdentifier)
    local zoneId = positiveInteger(payload.zoneId)
    if not zoneId then return nil, CEN.Errors.ZONE_NOT_FOUND end
    local zone, zoneError = Zones.Get(zoneId)
    if not zone then return nil, zoneError end
    local actor, errorCode = resolve(source, expectedIdentifier,
        permissionForZone(zone.zoneType), moduleForZone(zone.zoneType))
    if not actor then return nil, errorCode end
    if zone.ownerEnterpriseId == actor.enterpriseId then return nil, CEN.Errors.ZONE_NOT_CONTESTABLE end
    if tonumber(actor.level) < tonumber(zone.requiredLevel) then return nil, CEN.Errors.CONTEST_REQUIREMENTS end
    if zone.cooldownUntil then
        local active = MySQL.scalar.await('SELECT CASE WHEN cooldown_until > UTC_TIMESTAMP() THEN 1 ELSE 0 END FROM cen_zones WHERE id = ?', { zoneId })
        if tonumber(active) == 1 then return nil, CEN.Errors.ZONE_COOLDOWN end
    end
    if Config.Zones.requireAttackerInsideZone and not CENServer.Territory.IsPlayerInside(source, zone) then
        return nil, CEN.Errors.TOO_FAR_FROM_ZONE
    end
    if CENServer.Territory.OnlineMembers(actor.enterpriseId) < Config.Zones.minimumOnlineAttackers then
        return nil, CEN.Errors.CONTEST_REQUIREMENTS
    end
    if zone.ownerEnterpriseId and Config.Zones.minimumOnlineDefenders > 0
        and CENServer.Territory.OnlineMembers(zone.ownerEnterpriseId) < Config.Zones.minimumOnlineDefenders then
        return nil, CEN.Errors.CONTEST_REQUIREMENTS
    end
    local active = Zones.GetActiveContest(zoneId)
    if active then return nil, CEN.Errors.CONTEST_ACTIVE end
    local contest, startError = Zones.StartContest(zone, actor.enterpriseId, actor.memberId)
    if not contest then return nil, startError end
    CENServer.Audit('zone_contest_started', source, {
        enterpriseId = actor.enterpriseId,
        zoneId = zoneId,
        contestId = contest.contestId,
        defenderEnterpriseId = zone.ownerEnterpriseId,
        zoneType = zone.zoneType
    }, expectedIdentifier)
    return Controller.ListZones(source, {}, expectedIdentifier)
end

local actions = { listZones = Controller.ListZones, startZoneContest = Controller.StartContest }
Controller.Mutations = { startZoneContest = true }
function Controller.IsKnownAction(action) return actions[action] ~= nil end
function Controller.GetMutationKeys(source, action, payload, requesterIdentifier)
    if action == 'startZoneContest' then
        local zoneId = positiveInteger(payload.zoneId)
        if not zoneId then return nil, CEN.Errors.ZONE_NOT_FOUND end
        local actor, errorCode = EnterpriseRepository.GetMembershipByIdentifier(requesterIdentifier)
        if not actor then return nil, errorCode end
        return { ('enterprise:%s'):format(actor.enterpriseId), ('zone:%s'):format(zoneId) }
    end
    return { ('identity:%s'):format(requesterIdentifier) }
end
function Controller.Handle(source, action, payload, requesterIdentifier)
    local handler = actions[action]
    if not handler then return nil, CEN.Errors.BAD_REQUEST end
    return handler(source, payload or {}, requesterIdentifier)
end
