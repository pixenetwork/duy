CENServer = CENServer or {}
CENServer.FrontController = CENServer.FrontController or {}
local Controller = CENServer.FrontController
local Enterprises = CENServer.Repository
local Fronts = CENServer.FrontRepository

local function resolve(source, identifier, permission, moduleName)
    local live = CENServer.Identity.GetIdentifier(source)
    if not live or live ~= identifier then return nil, CEN.Errors.CONFLICT end
    local actor, errorCode = Enterprises.GetMembershipByIdentifier(identifier)
    if not actor then return nil, errorCode end
    local allowed, authorizationError = CENServer.Authorize(actor, permission, moduleName)
    if not allowed then return nil, authorizationError end
    return actor
end

local function integer(value)
    value = tonumber(value)
    if not CEN.Validation.IsPositiveInteger(value) then return nil end
    return math.floor(value)
end

local function typeAllowed(actorType, allowed)
    for i = 1, #(allowed or {}) do if allowed[i] == actorType then return true end end
    return false
end

function Controller.ListFronts(source, payload, identifier)
    local actor, errorCode = resolve(source, identifier, CEN.Permissions.VIEW, CEN.Modules.FRONTS)
    if not actor then return nil, errorCode end
    local data, listError = Fronts.List(actor.enterpriseId)
    if not data then return nil, listError end
    data.canManage = CENServer.HasPermission(actor, CEN.Permissions.MANAGE_FRONTS)
    data.canLaunder = CENServer.HasPermission(actor, CEN.Permissions.LAUNDER_MONEY)
    data.enterpriseLevel = actor.level
    data.maximumPerEnterprise = Config.Fronts.maximumPerEnterprise
    data.payoutDestination = Config.Fronts.payoutDestination or 'enterprise_treasury'
    data.businessTypes = {}
    for key, config in pairs(Config.Fronts.businessTypes or {}) do
        data.businessTypes[#data.businessTypes + 1] = {
            key = key, label = config.label, cost = config.cost, capacity = config.capacity,
            feePercent = config.feePercent, durationSeconds = config.durationSeconds,
            minimumLevel = config.minimumLevel, allowed = typeAllowed(actor.enterpriseType, config.allowedEnterpriseTypes)
                and tonumber(actor.level) >= tonumber(config.minimumLevel)
        }
    end
    table.sort(data.businessTypes, function(a, b) return a.cost < b.cost end)
    return data
end

function Controller.CreateFront(source, payload, identifier)
    local actor, errorCode = resolve(source, identifier, CEN.Permissions.MANAGE_FRONTS, CEN.Modules.FRONTS)
    if not actor then return nil, errorCode end
    local businessType = tostring(payload.businessType or '')
    local config = Config.Fronts.businessTypes[businessType]
    if not config or not typeAllowed(actor.enterpriseType, config.allowedEnterpriseTypes)
        or tonumber(actor.level) < tonumber(config.minimumLevel) then return nil, CEN.Errors.FORBIDDEN end
    local current, listError = Fronts.List(actor.enterpriseId)
    if not current then return nil, listError end
    if #current.fronts >= Config.Fronts.maximumPerEnterprise then return nil, CEN.Errors.FRONT_LIMIT_REACHED end
    local name = CEN.Validation.Trim(payload.name or '')
    if #name < 3 or #name > 80 then return nil, CEN.Errors.BAD_REQUEST end
    local frontId, createError = Fronts.Create(actor.enterpriseId, actor.memberId, businessType, name,
        config, Config.Fronts.maximumPerEnterprise)
    if not frontId then return nil, createError end
    CENServer.Audit('front_created', source, {
        enterpriseId = actor.enterpriseId, frontId = frontId,
        businessType = businessType, cost = config.cost
    }, identifier)
    return Controller.ListFronts(source, {}, identifier)
end

function Controller.StartLaundering(source, payload, identifier)
    local actor, errorCode = resolve(source, identifier, CEN.Permissions.LAUNDER_MONEY, CEN.Modules.FRONTS)
    if not actor then return nil, errorCode end
    local frontId, dirtyAmount = integer(payload.frontId), integer(payload.amount)
    if not frontId or not dirtyAmount or dirtyAmount < Config.Fronts.minimumLaunderAmount
        or dirtyAmount > Config.Fronts.maximumLaunderAmount then return nil, CEN.Errors.INVALID_AMOUNT end
    local front, frontError = Fronts.Get(frontId, actor.enterpriseId)
    if not front then return nil, frontError end
    local config = Config.Fronts.businessTypes[front.businessType]
    if not config or front.status ~= 'active' then return nil, CEN.Errors.FRONT_NOT_FOUND end
    local feeAmount = math.floor(dirtyAmount * (tonumber(front.feePercent) or config.feePercent) / 100)
    local cleanAmount = dirtyAmount - feeAmount
    if cleanAmount <= 0 then return nil, CEN.Errors.INVALID_AMOUNT end
    local removed, removeError = CENServer.Economy.RemoveAccountMoney(source,
        Config.Fronts.dirtyAccount, dirtyAmount, 'Enterprise laundering intake')
    if not removed then return nil, removeError end
    local jobId, jobError = Fronts.StartJob(frontId, actor.enterpriseId, actor.memberId,
        dirtyAmount, cleanAmount, feeAmount, config.durationSeconds)
    if not jobId then
        local refunded, refundError = CENServer.Economy.AddAccountMoney(source, Config.Fronts.dirtyAccount,
            dirtyAmount, 'Laundering refund')
        if not refunded then
            CENServer.Audit('laundering_refund_failed', source, {
                enterpriseId = actor.enterpriseId, frontId = frontId, dirtyAmount = dirtyAmount,
                originalError = jobError, refundError = refundError
            }, identifier)
            return nil, CEN.Errors.ECONOMY_UNAVAILABLE
        end
        return nil, jobError
    end
    CENServer.Heat.Add(actor.enterpriseId, math.max(1, math.floor(dirtyAmount / 100000)), 'laundering')
    CENServer.Audit('laundering_started', source, {
        enterpriseId = actor.enterpriseId, frontId = frontId, jobId = jobId,
        dirtyAmount = dirtyAmount, cleanAmount = cleanAmount, feeAmount = feeAmount
    }, identifier)
    return Controller.ListFronts(source, {}, identifier)
end

function Controller.ClaimLaundering(source, payload, identifier)
    local actor, errorCode = resolve(source, identifier, CEN.Permissions.LAUNDER_MONEY, CEN.Modules.FRONTS)
    if not actor then return nil, errorCode end
    local jobId = integer(payload.jobId)
    if not jobId then return nil, CEN.Errors.LAUNDERING_NOT_READY end

    local destination = Config.Fronts.payoutDestination or 'enterprise_treasury'
    local cleanAmount
    if destination == 'enterprise_treasury' then
        local result, claimError = Fronts.ClaimToTreasury(jobId, actor.enterpriseId, actor.memberId,
            Config.Economy.maximumTreasuryBalance)
        if not result then return nil, claimError end
        cleanAmount = result.cleanAmount
    else
        local marked, markError = Fronts.MarkClaiming(jobId, actor.enterpriseId, actor.memberId)
        if not marked then return nil, markError end
        local job, jobError = Fronts.GetJob(jobId, actor.enterpriseId)
        if not job then Fronts.ResetJob(jobId, actor.enterpriseId); return nil, jobError end
        local paid, payError = CENServer.Economy.AddAccountMoney(source,
            Config.Fronts.cleanAccount, job.cleanAmount, 'Laundered funds')
        if not paid then Fronts.ResetJob(jobId, actor.enterpriseId); return nil, payError end
        if not Fronts.CompleteJob(jobId, actor.enterpriseId) then
            local reversed = CENServer.Economy.RemoveAccountMoney(source, Config.Fronts.cleanAccount,
                job.cleanAmount, 'Laundering claim rollback')
            if reversed then Fronts.ResetJob(jobId, actor.enterpriseId) end
            CENServer.Audit('laundering_claim_finalize_failed', source, {
                enterpriseId = actor.enterpriseId, jobId = jobId, cleanAmount = job.cleanAmount,
                payoutRollbackSucceeded = reversed == true
            }, identifier)
            return nil, CEN.Errors.DATABASE_UNAVAILABLE
        end
        cleanAmount = job.cleanAmount
    end

    CENServer.Audit('laundering_claimed', source, {
        enterpriseId = actor.enterpriseId, jobId = jobId, cleanAmount = cleanAmount,
        destination = destination
    }, identifier)
    return Controller.ListFronts(source, {}, identifier)
end

function Controller.ListRackets(source, payload, identifier)
    local actor, errorCode = resolve(source, identifier, CEN.Permissions.VIEW, CEN.Modules.RACKETS)
    if not actor then return nil, errorCode end
    local rackets, listError = Fronts.ListRackets(actor.enterpriseId)
    if not rackets then return nil, listError end
    local zones, zoneError = CENServer.ZoneRepository.List()
    if not zones then return nil, zoneError end
    local owned = {}
    for i = 1, #zones do if zones[i].ownerEnterpriseId == actor.enterpriseId then owned[#owned + 1] = zones[i] end end
    local types = {}
    for key, config in pairs(Config.Rackets.types or {}) do
        types[#types + 1] = { key = key, label = config.label, payout = config.payout, heat = config.heat,
            allowed = typeAllowed(actor.enterpriseType, config.allowedEnterpriseTypes) }
    end
    return {
        rackets = rackets, ownedZones = owned, types = types,
        canManage = CENServer.HasPermission(actor, CEN.Permissions.MANAGE_RACKETS),
        canCollect = CENServer.HasPermission(actor, CEN.Permissions.COLLECT_RACKETS),
        intervalSeconds = Config.Rackets.collectionIntervalSeconds
    }
end

function Controller.CreateRacket(source, payload, identifier)
    local actor, errorCode = resolve(source, identifier, CEN.Permissions.MANAGE_RACKETS, CEN.Modules.RACKETS)
    if not actor then return nil, errorCode end
    if tonumber(actor.level) < tonumber(Config.Rackets.minimumEnterpriseLevel) then return nil, CEN.Errors.FORBIDDEN end
    local zoneId = integer(payload.zoneId)
    local racketType = tostring(payload.racketType or '')
    local config = Config.Rackets.types[racketType]
    if not zoneId or not config or not typeAllowed(actor.enterpriseType, config.allowedEnterpriseTypes) then
        return nil, CEN.Errors.FORBIDDEN
    end
    local id, createError = Fronts.CreateRacket(actor.enterpriseId, zoneId, actor.memberId,
        racketType, config.payout, config.heat)
    if not id then return nil, createError end
    CENServer.Audit('racket_established', source, {
        enterpriseId = actor.enterpriseId, racketId = id, zoneId = zoneId, racketType = racketType
    }, identifier)
    return Controller.ListRackets(source, {}, identifier)
end

function Controller.CollectRacket(source, payload, identifier)
    local actor, errorCode = resolve(source, identifier, CEN.Permissions.COLLECT_RACKETS, CEN.Modules.RACKETS)
    if not actor then return nil, errorCode end
    local racketId = integer(payload.racketId)
    if not racketId then return nil, CEN.Errors.RACKET_NOT_FOUND end
    local result, collectError = Fronts.CollectRacket(actor.enterpriseId, racketId,
        Config.Rackets.collectionIntervalSeconds, Config.Economy.maximumTreasuryBalance)
    if not result then return nil, collectError end
    CENServer.Heat.Add(actor.enterpriseId, result.heat, 'racket_collection')
    CENServer.Progression.AddXp(actor.enterpriseId, actor.memberId, 100, 'racket_collection', { racketId = racketId })
    CENServer.Audit('racket_collected', source, {
        enterpriseId = actor.enterpriseId, racketId = racketId,
        payout = result.payoutAmount, heat = result.heat
    }, identifier)
    return Controller.ListRackets(source, {}, identifier)
end

local actions = {
    listFronts = Controller.ListFronts, createFront = Controller.CreateFront,
    startLaundering = Controller.StartLaundering, claimLaundering = Controller.ClaimLaundering,
    listRackets = Controller.ListRackets, createRacket = Controller.CreateRacket,
    collectRacket = Controller.CollectRacket
}
Controller.Mutations = {
    createFront = true, startLaundering = true, claimLaundering = true,
    createRacket = true, collectRacket = true
}
function Controller.IsKnownAction(action) return actions[action] ~= nil end
function Controller.GetMutationKeys(source, action, payload, identifier)
    local actor, errorCode = Enterprises.GetMembershipByIdentifier(identifier)
    if not actor then return nil, errorCode end
    local keys = { ('enterprise:%s'):format(actor.enterpriseId), ('identity:%s'):format(identifier) }
    if payload.frontId then keys[#keys + 1] = ('front:%s'):format(tostring(payload.frontId)) end
    if payload.jobId then keys[#keys + 1] = ('laundering-job:%s'):format(tostring(payload.jobId)) end
    if payload.zoneId then keys[#keys + 1] = ('zone:%s'):format(tostring(payload.zoneId)) end
    if payload.racketId then keys[#keys + 1] = ('racket:%s'):format(tostring(payload.racketId)) end
    return keys
end
function Controller.Handle(source, action, payload, identifier)
    local handler = actions[action]
    if not handler then return nil, CEN.Errors.BAD_REQUEST end
    return handler(source, payload or {}, identifier)
end
