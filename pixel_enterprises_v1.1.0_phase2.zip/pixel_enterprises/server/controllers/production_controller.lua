CENServer = CENServer or {}
CENServer.ProductionController = CENServer.ProductionController or {}
local Controller = CENServer.ProductionController
local EnterpriseRepository = CENServer.Repository
local Facilities = CENServer.FacilityRepository

local function resolve(source, identifier, permission, moduleName)
    local live = CENServer.Identity.GetIdentifier(source)
    if not live or live ~= identifier then return nil, CEN.Errors.CONFLICT end
    local actor, errorCode = EnterpriseRepository.GetMembershipByIdentifier(identifier)
    if not actor then return nil, errorCode end
    local allowed, authorizationError = CENServer.Authorize(actor, permission, moduleName)
    if not allowed then return nil, authorizationError end
    return actor
end

local function positive(value)
    value = tonumber(value); if not CEN.Validation.IsPositiveInteger(value) then return nil end
    return math.floor(value)
end

local function typeAllowed(recipe, enterpriseType)
    for i = 1, #(recipe.allowedEnterpriseTypes or {}) do
        if recipe.allowedEnterpriseTypes[i] == enterpriseType then return true end
    end
    return false
end

local function moduleForRecipe(recipe)
    return recipe.category == 'arms' and CEN.Modules.ARMS or CEN.Modules.LABS
end

local function permissionForRecipe(recipe, claim)
    if recipe.category == 'arms' then return CEN.Permissions.MANAGE_ARMS end
    return claim and CEN.Permissions.CLAIM_PRODUCTION or CEN.Permissions.MANAGE_LABS
end

local function near(source, row, fallback)
    local ped = GetPlayerPed(source); if ped <= 0 then return false end
    local c = GetEntityCoords(ped)
    local dx, dy, dz = c.x - row.centerX, c.y - row.centerY, c.z - row.centerZ
    return math.sqrt(dx * dx + dy * dy + dz * dz) <= math.max(1.0, tonumber(row.radius) or fallback or 8.0)
end

local function recipeDto(actor)
    local list = {}
    for key, recipe in pairs(Config.Recipes or {}) do
        if typeAllowed(recipe, actor.enterpriseType) and tonumber(actor.level) >= tonumber(recipe.minimumLevel or 1) then
            list[#list + 1] = {
                key = key, label = recipe.label, category = recipe.category,
                outputItem = recipe.outputItem, outputCount = recipe.outputCount,
                durationSeconds = recipe.durationSeconds, minimumLevel = recipe.minimumLevel,
                ingredients = recipe.ingredients
            }
        end
    end
    table.sort(list, function(a, b) return a.label < b.label end)
    return list
end

function Controller.List(source, payload, identifier)
    local live = CENServer.Identity.GetIdentifier(source)
    if not live or live ~= identifier then return nil, CEN.Errors.CONFLICT end
    local actor, errorCode = EnterpriseRepository.GetMembershipByIdentifier(identifier)
    if not actor then return nil, errorCode end
    if not CENServer.HasPermission(actor, CEN.Permissions.VIEW)
        or (not CENServer.CanAccessModule(actor.enterpriseType, CEN.Modules.LABS)
            and not CENServer.CanAccessModule(actor.enterpriseType, CEN.Modules.ARMS)) then
        return nil, CEN.Errors.FORBIDDEN
    end
    local facilities, facilityError = Facilities.List(actor.enterpriseId)
    if not facilities then return nil, facilityError end
    local jobs, jobError = Facilities.ListJobs(actor.enterpriseId, payload.limit)
    if not jobs then return nil, jobError end
    return { facilities = facilities, jobs = jobs, recipes = recipeDto(actor), enterpriseLevel = actor.level }
end

function Controller.Start(source, payload, identifier)
    local recipe = Config.Recipes[tostring(payload.recipeKey or '')]
    if not recipe then return nil, CEN.Errors.RECIPE_NOT_ALLOWED end
    local actor, errorCode = resolve(source, identifier, permissionForRecipe(recipe, false), moduleForRecipe(recipe))
    if not actor then return nil, errorCode end
    if not typeAllowed(recipe, actor.enterpriseType) or tonumber(actor.level) < tonumber(recipe.minimumLevel or 1) then
        return nil, CEN.Errors.RECIPE_NOT_ALLOWED
    end
    local facilityId = positive(payload.facilityId); if not facilityId then return nil, CEN.Errors.FACILITY_NOT_FOUND end
    local facility, facilityError = Facilities.Get(facilityId)
    if not facility then return nil, facilityError end
    if facility.enterpriseId ~= actor.enterpriseId or facility.status ~= 'active' then return nil, CEN.Errors.FACILITY_NOT_FOUND end
    if facility.facilityType ~= 'lab' then return nil, CEN.Errors.FACILITY_REQUIRED end
    if not near(source, facility, Config.Operations.facilityUseDistance) then return nil, CEN.Errors.TOO_FAR_FROM_ZONE end

    local removed = {}
    for item, count in pairs(recipe.ingredients or {}) do
        local ok, removeError = CENServer.Inventory.Remove(source, item, count)
        if not ok then
            for i = 1, #removed do CENServer.Inventory.Add(source, removed[i].item, removed[i].count) end
            return nil, removeError
        end
        removed[#removed + 1] = { item = item, count = count }
    end
    local quality = math.max(40, math.min(100, 55 + tonumber(facility.level or 1) * 4 + math.random(-5, 10)))
    local batchId = ('CEN-%s-%06d-%04d'):format(tostring(recipe.category):upper():sub(1, 4), os.time() % 1000000, math.random(1000, 9999))
    local jobId, startError = Facilities.StartJob(actor.enterpriseId, facilityId, actor.memberId,
        tostring(payload.recipeKey), recipe, quality, batchId)
    if not jobId then
        for i = 1, #removed do CENServer.Inventory.Add(source, removed[i].item, removed[i].count) end
        return nil, startError
    end
    CENServer.Heat.Add(actor.enterpriseId, recipe.heat or 0, 'production_started')
    CENServer.Audit('production_started', source, {
        enterpriseId = actor.enterpriseId, facilityId = facilityId, jobId = jobId,
        recipeKey = payload.recipeKey, batchId = batchId, quality = quality
    }, identifier)
    return Controller.List(source, {}, identifier)
end

function Controller.Claim(source, payload, identifier)
    local jobId = positive(payload.jobId); if not jobId then return nil, CEN.Errors.PRODUCTION_NOT_READY end
    local actor, errorCode = resolve(source, identifier, CEN.Permissions.CLAIM_PRODUCTION, CEN.Modules.LABS)
    if not actor then
        actor, errorCode = resolve(source, identifier, CEN.Permissions.MANAGE_ARMS, CEN.Modules.ARMS)
        if not actor then return nil, errorCode end
    end
    local job, claimError = Facilities.MarkClaiming(jobId, actor.enterpriseId)
    if not job then return nil, claimError end
    if not near(source, job, Config.Operations.facilityUseDistance) then
        Facilities.ResetClaim(jobId, actor.enterpriseId); return nil, CEN.Errors.TOO_FAR_FROM_ZONE
    end
    local metadata = {
        batchId = job.batchId, quality = job.quality, producerEnterprise = actor.enterpriseName,
        producerEnterpriseId = actor.enterpriseId, recipe = job.recipeKey
    }
    local added, addError = CENServer.Inventory.Add(source, job.outputItem, job.outputCount, metadata)
    if not added then Facilities.ResetClaim(jobId, actor.enterpriseId); return nil, addError end
    if not Facilities.CompleteClaim(jobId, actor.enterpriseId, actor.memberId) then
        CENServer.Inventory.Remove(source, job.outputItem, job.outputCount, metadata)
        Facilities.ResetClaim(jobId, actor.enterpriseId)
        return nil, CEN.Errors.DATABASE_UNAVAILABLE
    end
    CENServer.Progression.AddXp(actor.enterpriseId, actor.memberId, math.max(25, job.outputCount * 5), 'production_claimed', { jobId = jobId })
    CENServer.Audit('production_claimed', source, { enterpriseId = actor.enterpriseId, jobId = jobId, batchId = job.batchId }, identifier)
    return Controller.List(source, {}, identifier)
end

local actions = { listProduction = Controller.List, startProduction = Controller.Start, claimProduction = Controller.Claim }
Controller.Mutations = { startProduction = true, claimProduction = true }
function Controller.IsKnownAction(action) return actions[action] ~= nil end
function Controller.GetMutationKeys(source, action, payload, identifier)
    local actor, errorCode = EnterpriseRepository.GetMembershipByIdentifier(identifier)
    if not actor then return nil, errorCode end
    local keys = { ('enterprise:%s'):format(actor.enterpriseId), ('identity:%s'):format(identifier) }
    if payload.facilityId then keys[#keys + 1] = ('facility:%s'):format(tostring(payload.facilityId)) end
    if payload.jobId then keys[#keys + 1] = ('production:%s'):format(tostring(payload.jobId)) end
    return keys
end
function Controller.Handle(source, action, payload, identifier)
    local handler = actions[action]; if not handler then return nil, CEN.Errors.BAD_REQUEST end
    return handler(source, payload or {}, identifier)
end
