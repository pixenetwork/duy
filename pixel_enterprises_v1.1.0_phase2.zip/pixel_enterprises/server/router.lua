CENServer = CENServer or {}
CENServer.Router = CENServer.Router or {}

local controllers = {
    CENServer.MembershipController,
    CENServer.FoundingController,
    CENServer.OperationsController,
    CENServer.TerritoryController,
    CENServer.ProductionController,
    CENServer.MarketController,
    CENServer.ShipmentController,
    CENServer.CorruptionController,
    CENServer.OrganizationController,
    CENServer.WarController,
    CENServer.FrontController
}

function CENServer.Router.IsKnownAction(action)
    for i = 1, #controllers do
        if controllers[i].IsKnownAction(action) then return true end
    end
    return false
end

function CENServer.Router.IsMutation(action)
    for i = 1, #controllers do
        if controllers[i].Mutations and controllers[i].Mutations[action] then return true end
    end
    return false
end

function CENServer.Router.GetMutationKeys(source, action, payload, requesterIdentifier)
    for i = 1, #controllers do
        local controller = controllers[i]
        if controller.IsKnownAction(action) then
            if type(controller.GetMutationKeys) == 'function' then
                return controller.GetMutationKeys(source, action, payload or {}, requesterIdentifier)
            end
            return { ('requester:%s'):format(requesterIdentifier) }
        end
    end
    return nil, CEN.Errors.BAD_REQUEST
end

function CENServer.Router.Handle(source, action, payload, requesterIdentifier)
    for i = 1, #controllers do
        if controllers[i].IsKnownAction(action) then
            return controllers[i].Handle(source, action, payload, requesterIdentifier)
        end
    end
    return nil, CEN.Errors.BAD_REQUEST
end
