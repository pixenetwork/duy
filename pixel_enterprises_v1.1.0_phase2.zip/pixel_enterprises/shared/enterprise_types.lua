CEN = CEN or {}

CEN.EnterpriseTypes = {
    street_gang = {
        label = 'Street Gang',
        tier = 1,
        modules = {
            'dashboard', 'members', 'ranks', 'treasury', 'storage', 'logs', 'progression',
            'crews', 'diplomacy', 'wars',
            'wholesale', 'street_distribution', 'turfs', 'territories', 'rackets'
        },
        restrictions = {
            canManufactureFinishedDrugs = false,
            canPurchasePublicDrugSupply = false,
            finishedDrugSources = { 'processor', 'cartel', 'syndicate', 'wholesaler' }
        }
    },

    processor = {
        label = 'Processing Enterprise',
        tier = 2,
        modules = {
            'dashboard', 'members', 'ranks', 'treasury', 'storage', 'logs', 'progression',
            'crews', 'diplomacy', 'wars',
            'labs', 'wholesale', 'smuggling', 'territories', 'fronts'
        }
    },

    wholesaler = {
        label = 'Wholesale Distributor',
        tier = 2,
        modules = {
            'dashboard', 'members', 'ranks', 'treasury', 'storage', 'logs', 'progression',
            'crews', 'diplomacy', 'wars',
            'wholesale', 'smuggling', 'territories', 'fronts'
        }
    },

    cartel = {
        label = 'Cartel',
        tier = 3,
        modules = {
            'dashboard', 'members', 'ranks', 'treasury', 'storage', 'logs', 'progression',
            'crews', 'diplomacy', 'wars',
            'labs', 'wholesale', 'smuggling', 'airdrops', 'territories', 'corruption', 'fronts', 'rackets'
        }
    },

    arms_enterprise = {
        label = 'Arms Enterprise',
        tier = 3,
        modules = {
            'dashboard', 'members', 'ranks', 'treasury', 'storage', 'logs', 'progression',
            'crews', 'diplomacy', 'wars',
            'arms', 'smuggling', 'airdrops', 'territories', 'corruption', 'fronts'
        }
    },

    smuggling_crew = {
        label = 'Smuggling Crew',
        tier = 2,
        modules = {
            'dashboard', 'members', 'ranks', 'treasury', 'storage', 'logs', 'progression',
            'crews', 'diplomacy', 'wars',
            'smuggling', 'airdrops', 'territories', 'fronts'
        }
    },

    mafia = {
        label = 'Crime Family',
        tier = 3,
        modules = {
            'dashboard', 'members', 'ranks', 'treasury', 'storage', 'logs', 'progression',
            'crews', 'diplomacy', 'wars',
            'wholesale', 'territories', 'corruption', 'fronts', 'rackets'
        }
    },

    syndicate = {
        label = 'Criminal Syndicate',
        tier = 3,
        modules = {
            'dashboard', 'members', 'ranks', 'treasury', 'storage', 'logs', 'progression',
            'crews', 'diplomacy', 'wars',
            'wholesale', 'smuggling', 'arms', 'territories', 'corruption', 'fronts', 'rackets'
        }
    }
}
