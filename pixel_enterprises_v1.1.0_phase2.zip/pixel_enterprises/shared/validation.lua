CEN = CEN or {}
CEN.Validation = CEN.Validation or {}

local function trim(value)
    return value:match('^%s*(.-)%s*$')
end

function CEN.Validation.Trim(value)
    if type(value) ~= 'string' then return nil end
    return trim(value)
end

function CEN.Validation.IsInteger(value)
    return type(value) == 'number'
        and value == value
        and value ~= math.huge
        and value ~= -math.huge
        and value == math.floor(value)
        and math.abs(value) <= 9007199254740991
end

function CEN.Validation.IsPositiveInteger(value)
    return CEN.Validation.IsInteger(value) and value > 0
end

function CEN.Validation.ValidRankName(value)
    local name = CEN.Validation.Trim(value)
    if not name then return false end
    if #name < Config.Ranks.minNameLength or #name > Config.Ranks.maxNameLength then
        return false
    end

    return name:match('^[%w%s%-%_]+$') ~= nil
end

function CEN.Validation.NormalizePermissions(values)
    if type(values) ~= 'table' then return nil, CEN.Errors.INVALID_PERMISSION end

    local normalized = {}
    local seen = {}
    for i = 1, #values do
        local permission = values[i]
        if type(permission) ~= 'string' or not CEN.PermissionDefinitions[permission] then
            return nil, CEN.Errors.INVALID_PERMISSION
        end

        if not seen[permission] then
            seen[permission] = true
            normalized[#normalized + 1] = permission
        end
    end

    table.sort(normalized)
    return normalized
end

function CEN.Validation.PayloadWithinLimit(payload)
    local ok, encoded = pcall(json.encode, payload or {})
    return ok and #encoded <= Config.Security.maxPayloadBytes
end


function CEN.Validation.ValidEnterpriseName(value)
    local name = CEN.Validation.Trim(value)
    if not name then return false end
    local rules = Config.Creation and Config.Creation.founding or {}
    local minLength = tonumber(rules.minNameLength) or 3
    local maxLength = tonumber(rules.maxNameLength) or 80
    if #name < minLength or #name > maxLength then return false end
    return name:match('^[%w%s%-%_%.&]+$') ~= nil
end

function CEN.Validation.Slugify(value)
    local name = CEN.Validation.Trim(value)
    if not name then return nil end
    local slug = name:lower():gsub('[^%w]+', '-'):gsub('^%-+', ''):gsub('%-+$', '')
    if slug == '' or #slug > 80 then return nil end
    return slug
end

function CEN.Validation.ValidGrantKey(value)
    return type(value) == 'string'
        and #value >= 6
        and #value <= 128
        and value:match('^[%w%-%_%.:]+$') ~= nil
end
