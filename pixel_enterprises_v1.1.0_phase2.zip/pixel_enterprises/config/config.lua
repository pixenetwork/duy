Config = Config or {}

Config.Debug = false

Config.Tablet = {
    mode = 'both', -- lb-tablet | standalone | both | auto
    appIdentifier = 'criminal_enterprise_network',
    appName = 'Criminal Enterprise Network',

    lbTablet = {
        resource = 'lb-tablet',
        defaultApp = false,
        requireItem = true,
        itemNames = { 'tablet' }
    },

    standalone = {
        enabled = true,
        requireItem = true,
        itemName = 'criminal_tablet',
        command = 'enterprise',
        keybind = 'F6'
    }
}

Config.Database = {
    driver = 'oxmysql'
}

Config.Security = {
    requestCooldownMs = 250,
    mutationCooldownMs = 750,
    requestWindowMs = 2000,
    maxRequestsPerWindow = 12,
    mutationLockTimeoutMs = 5000,
    maxMutationQueuePerSource = 4,
    maxPayloadBytes = 32768,
    maxRequestIdLength = 96,
    auditDenials = true,
    standaloneSessionSeconds = 120,
    tabletSessionAbsoluteSeconds = 900,
    recheckTabletItemEverySeconds = 20
}

-- Controls who may START a new enterprise. Public/ACE creation still uses the
-- founding acceptance process unless explicitly bypassed by an administrator.
Config.Creation = {
    enabled = true,
    mode = 'per_type', -- admin_only | ace | public | framework_group | per_type
    adminAce = 'pixel_enterprises.admin.create',
    creatorAce = 'pixel_enterprises.create',
    allowedFrameworkGroups = { 'admin', 'superadmin' },
    adminBypassFoundingRequirements = true,

    -- Higher-tier organizations are admin-controlled by default. Servers can
    -- change any entry to public_founding, ace_founding, framework_founding,
    -- or disabled without editing server code.
    typePolicies = {
        street_gang = 'public_founding',
        processor = 'admin_only',
        wholesaler = 'admin_only',
        cartel = 'admin_only',
        arms_enterprise = 'admin_only',
        smuggling_crew = 'admin_only',
        mafia = 'admin_only',
        syndicate = 'admin_only'
    },

    founding = {
        requiredAcceptances = 8, -- eight OTHER players by default
        founderCountsAsAcceptance = false,
        proposalExpiryHours = 168,
        inviteExpiryHours = 72,
        maxPendingInvites = 11,
        requireNearbyInvite = true,
        inviteMaxDistance = 5.0,
        autoFinalizeAtThreshold = true,
        requireAdminApprovalAfterThreshold = false,
        minNameLength = 3,
        maxNameLength = 80
    },

    plans = {
        free = {
            baseMemberLimit = 12,
            retentionRequired = true
        },
        admin = {
            baseMemberLimit = 12,
            retentionRequired = false
        },
        premium = {
            baseMemberLimit = 12,
            retentionRequired = false
        }
    }
}

Config.Membership = {
    allowMultipleEnterprises = false, -- hard-enforced by the database and startup health checks
    defaultMemberLimit = 12,
    memberLimitPerLevel = 0, -- paid entitlements, not leveling, add member slots
    absoluteMemberLimit = 80,
    inviteMaxDistance = 5.0,
    requireNearbyInvite = true,
    inviteExpiryHours = 72
}

-- Tebex should execute these commands from the server console. Each grant key
-- must be unique (normally a Tebex transaction/payment identifier), making
-- duplicate delivery idempotent and allowing refunds to revoke the same grant.
Config.Tebex = {
    enabled = true,
    consoleOnly = true,
    adminAce = 'pixel_enterprises.tebex.manage',
    maxPaidExtraSlots = 68,
    slotPackages = {
        gang_slots_2 = { slots = 2 },
        gang_slots_4 = { slots = 4 },
        gang_slots_8 = { slots = 8 }
    }
}

-- Applies only to enterprises whose creation plan has retentionRequired=true.
-- An active member is a distinct roster member with the configured amount of
-- tracked online time during the monthly cycle. The owner counts if qualified.
Config.Retention = {
    enabled = true,
    useUtc = true,
    minimumActiveMembers = 5,
    minimumMinutesPerMember = 60,
    warningDay = 21,
    activityHeartbeatMinutes = 5,
    evaluationIntervalMinutes = 60,
    deletionGraceDays = 7,
    allowRecoveryDuringGrace = true,
    hardDelete = false, -- false = soft disband so admins can restore it
    exemptPlans = { admin = true, premium = true }
}

Config.Ranks = {
    maxRanks = 12,
    minNameLength = 2,
    maxNameLength = 32,
    minPriority = 0,
    maxPriority = 1000
}

Config.Progression = {
    maxLevel = 50,
    baseXp = 1000,
    growth = 1.35,
    allowLevelLoss = false,
    awards = {
        memberJoined = 100,
        foundingCompleted = 1500,
        treasuryDepositPerThousand = 2,
        turfWin = 500,
        territoryWin = 1500
    }
}

Config.Economy = {
    provider = 'esx', -- esx | custom
    account = 'bank',
    minimumTransaction = 1,
    maximumTransaction = 10000000,
    maximumTreasuryBalance = 2000000000,
    withdrawalDailyLimit = 1000000
}

Config.Storage = {
    enabled = true,
    slots = 100,
    maxWeight = 500000,
    owner = false
}

Config.Zones = {
    enabled = true,
    adminAce = 'pixel_enterprises.admin.zones',
    scoreIntervalSeconds = 10,
    evaluationIntervalSeconds = 5,
    defaultContestSeconds = 900,
    defaultCooldownSeconds = 3600,
    defaultRadius = 65.0,
    minimumOnlineAttackers = 2,
    minimumOnlineDefenders = 0,
    requireAttackerInsideZone = true,
    turfMinimumLevel = 2,
    territoryMinimumLevel = 5,
    attackerPresencePoints = 2,
    defenderPresencePoints = 2,
    uncontestedPresenceBonus = 1
}

Config.Logs = {
    pageSize = 50,
    maximumPageSize = 100
}

Config.Admin = {
    ace = 'pixel_enterprises.admin'
}


Config.Operations = {
    enabled = true,
    heatMaximum = 1000,
    heatDecayPerHour = 5,
    dirtyMoneyMode = 'account', -- account | item
    dirtyMoneyAccount = 'black_money',
    dirtyMoneyItem = 'black_money',
    fallbackStreetPayoutToBank = false,
    facilityUseDistance = 8.0,
    shipmentClaimDistance = 12.0,
    listingExpiryHours = 72,
    maximumListingQuantity = 1000,
    maximumUnitPrice = 100000,
    streetSaleCooldownSeconds = 20,
    airdropCooldownSeconds = 7200
}

Config.Recipes = {
    cocaine_package = {
        label = 'Cocaine Package', category = 'finished_drug', outputItem = 'cocaine_baggy', outputCount = 10,
        durationSeconds = 900, minimumLevel = 3, heat = 12,
        allowedEnterpriseTypes = { 'processor', 'cartel', 'syndicate' },
        ingredients = { coca_paste = 5, chemicals = 2 }
    },
    meth_package = {
        label = 'Meth Package', category = 'finished_drug', outputItem = 'meth_baggy', outputCount = 10,
        durationSeconds = 1200, minimumLevel = 4, heat = 16,
        allowedEnterpriseTypes = { 'processor', 'cartel', 'syndicate' },
        ingredients = { pseudoephedrine = 5, chemicals = 3 }
    },
    weed_bricks = {
        label = 'Packaged Cannabis', category = 'finished_drug', outputItem = 'weed_brick', outputCount = 5,
        durationSeconds = 600, minimumLevel = 2, heat = 6,
        allowedEnterpriseTypes = { 'processor', 'cartel', 'syndicate' },
        ingredients = { cannabis = 20, packaging = 5 }
    },
    pistol_components = {
        label = 'Pistol Component Set', category = 'arms', outputItem = 'pistol_components', outputCount = 2,
        durationSeconds = 1500, minimumLevel = 5, heat = 18,
        allowedEnterpriseTypes = { 'arms_enterprise', 'syndicate' },
        ingredients = { steel = 10, weapon_parts = 4 }
    }
}

Config.Market = {
    enabled = true,
    categories = { 'raw_material', 'finished_drug', 'arms', 'contraband' },
    finishedDrugSuppliers = { processor = true, cartel = true, syndicate = true, wholesaler = true },
    armsSuppliers = { arms_enterprise = true, syndicate = true },
    streetGangAllowedCategories = { finished_drug = true, contraband = true }
}

Config.StreetSales = {
    enabled = true,
    products = {
        cocaine_baggy = { minimum = 350, maximum = 500, heat = 3, xp = 8 },
        meth_baggy = { minimum = 300, maximum = 450, heat = 4, xp = 9 },
        weed_brick = { minimum = 600, maximum = 850, heat = 2, xp = 6 }
    },
    ownedTurfMultiplier = 1.20,
    unownedTurfMultiplier = 0.85
}

Config.Shipments = {
    enabled = true,
    catalog = {
        pistol_components = { label = 'Pistol Component Shipment', item = 'pistol_components', quantity = 5, cost = 75000, minimumLevel = 5, delivery = 'dead_drop', heat = 20, allowedEnterpriseTypes = { 'arms_enterprise', 'syndicate' } },
        rifle_components = { label = 'Rifle Component Shipment', item = 'rifle_components', quantity = 3, cost = 150000, minimumLevel = 8, delivery = 'airdrop', heat = 35, allowedEnterpriseTypes = { 'arms_enterprise', 'syndicate' } },
        chemical_crate = { label = 'Chemical Precursor Crate', item = 'chemicals', quantity = 20, cost = 50000, minimumLevel = 3, delivery = 'dead_drop', heat = 12, allowedEnterpriseTypes = { 'processor', 'cartel', 'smuggling_crew', 'syndicate' } }
    },
    deliveryDelaySeconds = 900,
    expiryHours = 6,
    locations = {
        { x = 1734.2, y = 3310.6, z = 41.2, label = 'Sandy Airfield' },
        { x = 1204.7, y = -3117.8, z = 5.5, label = 'Port Container Yard' },
        { x = -429.3, y = 6148.8, z = 31.5, label = 'Paleto Industrial' },
        { x = 2673.8, y = 3511.1, z = 52.7, label = 'Grand Senora Depot' }
    }
}

Config.Corruption = {
    enabled = true,
    policeJobs = { police = true, sheriff = true, state = true },
    minimumEnterpriseLevel = 6,
    offerExpiryHours = 24,
    services = {
        shipment_warning = { label = 'Shipment Warning', minimumFee = 25000, exposure = 8, heatReduction = 0 },
        reduce_heat = { label = 'Reduce Police Pressure', minimumFee = 50000, exposure = 15, heatReduction = 25 },
        evidence_tip = { label = 'Evidence Tip', minimumFee = 40000, exposure = 12, heatReduction = 5 }
    }
}


-- Phase 2: internal crews/chapters.
Config.Crews = {
    enabled = true,
    minimumEnterpriseLevel = 2,
    baseMaximumCrews = 2,
    extraCrewEveryLevels = 5,
    maximumCrews = 8,
    defaultMaximumMembers = 8,
    absoluteMaximumMembers = 20,
    minimumNameLength = 2,
    maximumNameLength = 60
}

Config.Diplomacy = {
    enabled = true,
    proposalExpiryHours = 24,
    ceasefireHours = 24,
    relationshipCooldownSeconds = 3600,
    directoryLimit = 100
}

Config.Wars = {
    enabled = true,
    minimumEnterpriseLevel = 3,
    proposalExpiryHours = 24,
    durationSeconds = 7200,
    postWarCeasefireHours = 12,
    minimumStake = 0,
    maximumStake = 5000000,
    defaultTargetScore = 100,
    minimumTargetScore = 25,
    maximumTargetScore = 1000,
    points = {
        turfWin = 20,
        territoryWin = 50,
        enemyTurfSale = 2
    },
    winnerXp = 2500,
    loserXp = 500
}

Config.Fronts = {
    enabled = true,
    maximumPerEnterprise = 3,
    dirtyAccount = 'black_money',
    cleanAccount = 'bank',
    payoutDestination = 'enterprise_treasury', -- enterprise_treasury | player_account
    minimumLaunderAmount = 1000,
    maximumLaunderAmount = 1000000,
    businessTypes = {
        restaurant = { label = 'Restaurant', cost = 250000, capacity = 250000, feePercent = 18, durationSeconds = 1800, minimumLevel = 3,
            allowedEnterpriseTypes = { 'mafia', 'cartel', 'syndicate', 'wholesaler', 'street_gang' } },
        nightclub = { label = 'Nightclub', cost = 500000, capacity = 500000, feePercent = 14, durationSeconds = 2700, minimumLevel = 5,
            allowedEnterpriseTypes = { 'mafia', 'cartel', 'syndicate' } },
        construction = { label = 'Construction Company', cost = 750000, capacity = 1000000, feePercent = 11, durationSeconds = 3600, minimumLevel = 8,
            allowedEnterpriseTypes = { 'mafia', 'cartel', 'syndicate', 'wholesaler' } }
    }
}

Config.Rackets = {
    enabled = true,
    collectionIntervalSeconds = 86400,
    minimumEnterpriseLevel = 3,
    types = {
        protection = { label = 'Protection Collection', payout = 25000, heat = 4,
            allowedEnterpriseTypes = { 'street_gang', 'mafia', 'cartel', 'syndicate' } },
        contraband_tax = { label = 'Contraband Tax', payout = 40000, heat = 6,
            allowedEnterpriseTypes = { 'mafia', 'cartel', 'syndicate', 'wholesaler' } },
        port_fee = { label = 'Smuggling Route Fee', payout = 50000, heat = 8,
            allowedEnterpriseTypes = { 'smuggling_crew', 'cartel', 'syndicate' } }
    }
}
