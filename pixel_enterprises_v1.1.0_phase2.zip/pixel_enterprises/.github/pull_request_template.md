## Scope

## Acceptance criteria
- [ ] Scoped issue requirements are complete
- [ ] Server-authoritative validation is preserved
- [ ] LB Tablet and standalone compatibility considered
- [ ] SQL migration included when required
- [ ] CHANGELOG.md updated

## Test evidence
- [ ] Static/lint checks
- [ ] FiveM development server test steps included
- [ ] Permission-denial cases tested
- [ ] Duplicate/replay requests tested

## Review
- Writer AI:
- CodeRabbit review:
- Claude audit required: Yes / No
- Human test approval:
