# Runtime test plan

Use a disposable database and development server.

## Startup and schema

1. Import the clean SQL on the exact production MariaDB version.
2. Start oxmysql, ox_inventory, ESX, optional LB Tablet, then `pixel_enterprises`.
3. Confirm no `SECURITY STOP` message appears.
4. Confirm all stored procedures exist.

## Tablet access

1. Open standalone with and without `criminal_tablet`.
2. Open LB Tablet with and without the configured LB tablet item.
3. Trigger a raw request without a valid server-issued token and verify rejection.
4. Drop the item during a session and confirm access expires after the configured recheck.

## Founding and membership

1. Start a free street-gang proposal.
2. Attempt duplicate founder/supporter participation.
3. Accept simultaneously with the seventh/eighth supporters.
4. Confirm the founder plus eight supporters become members exactly once.
5. Test normal consent invites, expiration, cancellation, rank authority changes, leave, ownership transfer, and soft disband.

## Tebex and retention

1. Deliver the same grant twice and confirm no duplicated slots.
2. Refund twice and confirm idempotent revocation.
3. Race an invite acceptance with a slot refund at the member cap.
4. Simulate day 21, month end, grace recovery, and soft disband.

## Treasury and progression

1. Deposit and withdraw funds.
2. Force payout failure and confirm treasury reversal.
3. Confirm daily withdrawal and maximum-balance limits.
4. Award XP through founding, production, street sales, shipments, and zones.

## Production and market

1. Place a lab and test ingredient removal and failure refunds.
2. Start and claim a batch from two clients simultaneously.
3. Post, cancel, buy, and claim listings.
4. Verify street gangs cannot buy a finished-drug listing from an unapproved seller type.
5. Verify item metadata contains batch/producer/recipient information.

## Shipments and airdrops

1. Request a dead drop and an airdrop.
2. Confirm treasury deduction, level/type requirements, cooldown, ready/expiry times, proximity, inventory capacity, and double-claim protection.

## Turfs and territories

1. Contest with insufficient level or online members.
2. Score attacker/defender presence.
3. Confirm winner, owner change, cooldown, XP, and audit records.

## Corruption

1. Target a configured police job and a non-police job.
2. Accept and decline voluntarily from the officer account.
3. Confirm treasury fee, officer payout, heat reduction, trust, exposure, and audit records.
4. Force player payout failure and confirm treasury reversal and failed-offer state.

## Load and abuse

1. Spam each NUI action and malformed payloads.
2. Disconnect/reconnect during queued mutations.
3. Restart oxmysql during a request.
4. Test 64-128 connected clients for retention heartbeat and zone scoring load.

## Phase 2 crews and diplomacy

1. Create crews at, below, and above the level-based crew limit.
2. Move one member between crews and confirm one-crew-only membership.
3. Replace a crew leader and verify the previous leader becomes a normal member.
4. Remove or disconnect a leader and verify the crew remains recoverable.
5. Propose, accept, decline, cancel, expire, and end alliances/ceasefires.
6. Race two diplomacy responses and confirm exactly one result commits.

## Phase 2 wars

1. Propose a war with insufficient and sufficient treasury funds.
2. Accept from two clients simultaneously and verify one matched defender stake.
3. Decline/cancel/expire proposals and verify exact escrow refunds.
4. Score through turf victory, territory victory, and enemy-turf street sales.
5. Attempt duplicate score events and resolution races.
6. Confirm winner payout, draw refunds, XP, completed status, and post-war ceasefire.

## Phase 2 fronts, laundering, and rackets

1. Purchase fronts at the enterprise level/type/front-count boundaries.
2. Start simultaneous laundering jobs at the processing-capacity limit.
3. Force a database reservation failure and confirm dirty-money refund.
4. Claim the same job concurrently and confirm one treasury payout.
5. Establish a racket only on an owned eligible zone.
6. Collect concurrently and confirm one payout per cooldown.
7. Transfer the zone and confirm the previous owner's racket is removed.
8. Test treasury maximums, heat, XP, and audit records for every financial path.
