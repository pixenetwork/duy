# Administrator and server commands

## Enterprises

```text
cenenterprisecreate <type> <owner-server-id> <name>
cenfoundapprove <proposal-id>
cenrestore <enterprise-id>
cenxp <enterprise-id> <amount> [reason]
centreasury <enterprise-id> <signed-amount>
cenheat <enterprise-id> <signed-amount>
```

Enterprise types:

```text
street_gang
processor
wholesaler
cartel
arms_enterprise
smuggling_crew
mafia
syndicate
```

## Zones

Run zone creation while standing at the zone center:

```text
cenzonecreate <turf|territory> <radius> <required-level> <name>
cenzonedelete <zone-id>
cenzoneowner <zone-id> <enterprise-id-or-0>
```

## Facilities

Run facility creation while standing at the interaction center:

```text
cenfacilitycreate <enterprise-id> <lab|warehouse|front> <subtype> <radius> <name>
cenfacilitydelete <facility-id>
```

Examples:

```text
cenfacilitycreate 4 lab drug_lab 8 Cypress Processing Lab
cenfacilitycreate 7 lab arms_workshop 8 Port Machine Shop
cenfacilitycreate 3 warehouse distribution 12 Eastside Warehouse
```

## Tebex

```text
cen_tebex_slots_grant <package-key> <enterprise-id-or-slug> <unique-grant-key> [purchaser-identifier]
cen_tebex_slots_revoke <unique-grant-key>
```

Default packages:

```text
gang_slots_2
gang_slots_4
gang_slots_8
```

## Player founding commands

The tablet provides these flows, but chat commands remain available:

```text
/cenfound <enterprise-type> <name>
/cenfoundinvite <server-id>
/cenfoundaccept <proposal-id>
/cenfounddecline <proposal-id>
```


## Crooked-officer responses

```text
/cencorruptaccept <offer-id>
/cencorruptdecline <offer-id>
```
