# AI Development Team

## Duy Tran — Product Owner and Final Approver
Defines gameplay direction, approves UX and economy decisions, tests on the FiveM development server, and authorizes merges.

## ChatGPT / GPT-5.6 Thinking — Lead Architect and Technical Product Manager
Owns requirements, system architecture, acceptance criteria, implementation prompts, review reconciliation, release notes and task sequencing.

## OpenAI Codex — Primary Implementation Engineer
Writes one scoped branch/PR at a time, runs local checks, updates tests and CHANGELOG, and responds to review findings.

## Claude Code — Independent Architecture and Security Auditor
Reviews high-risk changes, permission boundaries, SQL/data integrity, race conditions, exploit paths and cross-module design. It does not rewrite the same PR unless explicitly assigned the writer role.

## Cursor — Local Integration Engineer
Used for focused repo navigation, small edits, conflict resolution, manual integration and developer-controlled fixes. Cursor is not a second autonomous writer on a Codex-owned PR.

## CodeRabbit — Automated Pull Request Reviewer
Reviews each pull request, summarizes changes, flags defects and re-reviews new commits. It never replaces FiveM server testing or human approval.

## Perplexity Research — External Documentation Scout
Used only for targeted current documentation, dependency compatibility and market/script research. It does not make repository changes.

## Gemini / Antigravity — Optional Architecture Bench
Used only when Codex and Claude disagree materially or a second independent design opinion is needed.

## Workflow
1. ChatGPT writes the issue specification and acceptance tests.
2. One writer is assigned—normally Codex.
3. The writer creates a feature branch and draft pull request.
4. CodeRabbit performs the first automatic review.
5. Claude Code audits security-sensitive or architecture-heavy changes.
6. The original writer fixes accepted findings.
7. CodeRabbit re-reviews the new commits.
8. Duy tests on the FiveM development server.
9. Human approval is required before merge to main.
