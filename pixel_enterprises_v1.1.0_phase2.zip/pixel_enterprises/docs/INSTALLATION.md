# Installation

## 1. Copy the resource

Place the folder in your resources directory as:

```text
resources/[pixel]/pixel_enterprises
```

## 2. Database

For a new installation, import:

```text
sql/pixel_enterprises.sql
```

For an existing installation, back up the database and apply these in order:

```text
002_membership_ranks.sql
003_creation_retention_tebex.sql
004_security_hardening.sql
005_atomicity_and_review_fixes.sql
006_core_mvp.sql
007_criminal_operations.sql
008_phase2_organizations_conflict.sql
009_phase2_hardening.sql
```

The SQL files contain MariaDB stored procedures and `DELIMITER` directives. Import them with a database client that supports procedure delimiters, such as the MariaDB/MySQL CLI, HeidiSQL, or phpMyAdmin. Do not paste the procedure scripts into an oxmysql query call.

On startup, the resource checks required tables, columns, indexes, all Phase 1/2 procedures, owner records, default ranks, and founding-participation invariants. It refuses to serve requests when the schema is incomplete.

## 3. Inventory items

Merge the definitions in:

```text
docs/OX_INVENTORY_ITEMS.lua
```

into the server's ox_inventory item configuration. Rename the example items in `config/config.lua` when the server already uses different drug, precursor, weapons-component, packaging, or tablet names.

## 4. server.cfg

```cfg
ensure oxmysql
ensure ox_inventory
ensure es_extended
ensure lb-tablet          # optional
ensure pixel_enterprises

add_ace group.admin pixel_enterprises.admin allow
add_ace group.admin pixel_enterprises.admin.create allow
add_ace group.admin pixel_enterprises.admin.zones allow
add_ace group.admin pixel_enterprises.tebex.manage allow
```

## 5. Tablet mode

```lua
Config.Tablet.mode = 'both'
```

Supported values:

- `standalone`
- `lb-tablet`
- `both`
- `auto`

Both hosts require a server-issued session. Item possession is checked server-side and periodically rechecked while the session remains active.

## 6. Economy

The default provider is ESX:

```lua
Config.Economy.provider = 'esx'
Config.Economy.account = 'bank'
Config.Operations.dirtyMoneyMode = 'account'
Config.Operations.dirtyMoneyAccount = 'black_money'
```

For another economy, set `provider = 'custom'` and implement the custom functions documented in `server/bridges/economy.lua`.

## 7. Create initial content

Create an enterprise, zones, and facilities using the commands in `docs/ADMIN_COMMANDS.md`.

Example:

```text
cenenterprisecreate processor 12 Northside Processing
cenzonecreate turf 65 2 Forum Drive
cenfacilitycreate 1 lab drug_lab 8 Strawberry Processing Lab
centreasury 1 250000
```

## 8. Tebex slots

Configure package commands using a unique transaction/payment key:

```text
cen_tebex_slots_grant gang_slots_4 <enterprise-id-or-slug> {transaction} {identifier}
```

Refund/revoke command:

```text
cen_tebex_slots_revoke {transaction}
```

Use the exact Tebex placeholder names supported by your store package setup. Duplicate delivery is safe when the same unique grant key is reused.


## 9. Phase 2 configuration

The new modules can be disabled independently:

```lua
Config.Crews.enabled = true
Config.Diplomacy.enabled = true
Config.Wars.enabled = true
Config.Fronts.enabled = true
Config.Rackets.enabled = true
```

Disabled modules are removed from the tablet and rejected by server authorization. Configure war stakes and scoring, front-business capacity/fees, laundering payout destination, and racket intervals in `config/config.lua`.
