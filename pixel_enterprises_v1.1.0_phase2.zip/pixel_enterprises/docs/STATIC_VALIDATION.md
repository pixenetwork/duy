# Static validation — v1.1.0 Phase 2

Completed on 2026-08-04.

## Passed

- 52 Lua files parsed successfully against Lua 5.4.
- `ui/app.js` passed Node.js syntax validation.
- All 53 local files referenced by `fxmanifest.lua` exist.
- The external `@oxmysql/lib/MySQL.lua` manifest import is declared separately and is expected to be supplied by oxmysql.
- All 66 server controller actions have a matching client NUI action mapping.
- All referenced `CEN.Errors` constants are defined.
- `git diff --check` reports no whitespace errors.
- Clean-install SQL contains 31 tables and 31 unique stored-procedure names.
- Migration 009 contains 20 matching `DROP PROCEDURE` / `CREATE PROCEDURE` definitions and 20 procedure terminators.
- The migration 009 procedure block embedded in `sql/pixel_enterprises.sql` exactly matches the standalone migration.
- Phase 2 schema verification covers crews, diplomacy, wars, front businesses, laundering, rackets, score events, and required procedures.
- The manifest and shared constant version are both 1.1.0.
- Tablet notification text strips GTA formatting control characters before rendering.
- Client-facing roster and founding DTOs do not expose stable player identifiers or live server IDs.

## Phase 2 coverage checked

- Crew and chapter creation, assignment, leader replacement, removal, and deletion.
- Alliance and ceasefire proposal, response, cancellation, expiry, and termination.
- War proposal, matched escrow, acceptance, cancellation, scoring, automatic finalization, payout, and post-war ceasefire.
- Front-business purchase, laundering capacity reservation, timed jobs, and treasury payout.
- Protection-racket creation, ownership validation, cooldown, heat, treasury payout, and stale-racket cleanup after zone transfer.
- Member removal, voluntary leave, owner disband, and retention disband interactions with crews and active wars.
- Configuration-aware module filtering for both tablet visibility and server authorization.

## Not validated in this environment

- Importing migrations 008 and 009 on the exact production MariaDB version.
- Runtime execution and result shapes of all stored procedures through the installed oxmysql build.
- ESX bank, cash, and dirty-money account behavior.
- Real ox_inventory item definitions, weights, capacity, metadata, and stash hooks.
- LB Tablet custom-app registration on the installed LB version.
- OneSync proximity and server-side player coordinates.
- Real multi-client races involving founding, invitations, crew assignment, diplomacy, war escrow, war scoring, laundering, rackets, territory resolution, Tebex refunds, or retention enforcement.
- Performance with the production player count and database latency.

Run `docs/RUNTIME_TEST_PLAN.md` on a disposable development server before external audit or production deployment.
