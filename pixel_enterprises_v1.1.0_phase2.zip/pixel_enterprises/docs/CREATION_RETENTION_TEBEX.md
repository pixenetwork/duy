# Creation, Founding, Retention and Tebex Slots

## Creation policy

`Config.Creation.mode` supports `admin_only`, `ace`, `public`, `framework_group`, or `per_type`.
The default is `per_type`: street gangs use public founding, while higher-tier enterprises are admin-only.

Server owners may change `Config.Creation.typePolicies` without editing the backend.

## Free gang founding

Default flow:

1. Founder starts a street-gang proposal with `/cenfound street_gang <name>`.
2. Founder invites nearby players with `/cenfoundinvite <serverId>`.
3. Eight other players must individually accept using `/cenfoundaccept <proposalId>`.
4. At the eighth acceptance, the free gang is created automatically with the founder plus the eight supporters.

The founder does not count toward the eight by default. When `founderCountsAsAcceptance = true`, the backend subtracts the founder from the configured required total.

## Admin creation

Console or ACE-authorized admin:

`cenenterprisecreate <enterpriseType> <ownerServerId> <enterprise name>`

Example:

`cenenterprisecreate cartel 24 Los Santos Cartel`

ACE example:

`add_ace group.admin pixel_enterprises.admin.create allow`

When `requireAdminApprovalAfterThreshold = true`, the eight accepted supporters move the proposal to `awaiting_approval`. An authorized administrator completes it with:

`cenfoundapprove <proposalId>`

## Member slots

Free gangs have 12 total slots. Levels do not add member capacity. Active Tebex entitlements are added to the base limit and capped by `Config.Membership.absoluteMemberLimit`.

Tebex purchase command pattern:

`cen_tebex_slots_grant <packageKey> <enterpriseId-or-slug> <uniqueGrantKey> [purchaserIdentifier]`

Refund/removal command:

`cen_tebex_slots_revoke <uniqueGrantKey>`

The grant key must be the same unique Tebex payment/transaction reference on purchase and refund. Duplicate active delivery is idempotent. A revoked/refunded grant key cannot be reactivated; a new purchase must use a new unique grant key.

## Monthly retention

Only plans with `retentionRequired = true` are evaluated. Defaults:

- Five distinct members must each accumulate 60 tracked online minutes during the month.
- On day 21, an under-minimum gang receives a warning and tablet banner.
- After a failed full month, deletion is scheduled with a seven-day grace period.
- Reaching the current-month minimum during grace cancels deletion.
- `hardDelete = false` soft-disbands the gang so administrators can restore it.

New gangs are not judged until they have existed for a complete calendar cycle.


## Normal membership invitations

Enterprise recruiters create an expiring invitation rather than immediately adding the target. The target must accept with `/cenjoinaccept <inviteId>` or decline with `/cenjoindecline <inviteId>`. The member limit is checked again at acceptance time, and accepting one invitation cancels the target's other pending membership invitations.

Removed members are retained as soft history rows but may join another enterprise later. Suspended or active memberships remain exclusive and cannot be moved by invitations.
