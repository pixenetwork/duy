# Codex Re-audit Brief — v0.3.2

Review `pixel_enterprises` v0.3.2 as an independent security and correctness reviewer. Do not modify files yet.

First compare the implementation against:

- `docs/CODEX_V031_SECURITY_REVIEW_RESULTS.md`
- `docs/CODEX_V031_REVIEW_RESPONSE.md`
- `docs/PR_002_TEST_PLAN.md`

Re-test every v0.3.1 finding, with special attention to:

1. Existing-rank permission ceilings in `inviteMember`, invitation acceptance and `setMemberRank`.
2. Stale/expired/cancelled membership invitation acceptance and zero-row transaction behavior.
3. Atomic rollback of direct enterprise creation and founding finalization through migration 005 procedures.
4. One-identity founding participation across founder/supporter roles and concurrent eighth acceptances.
5. Client-facing proposal DTO privacy.
6. Retention disband locking against membership/rank/invite operations.
7. Source-ID reuse in rate-limit, queue, lock-wait and audit attribution state.
8. Tebex grant/revoke serialization with member-limit checks and idempotent refund retries.
9. Re-sent invitation rank/expiry consistency.
10. Server-side standalone tablet possession/session enforcement.
11. Startup schema verification coverage and exact first-day retention boundaries.

Also inspect migration `005_atomicity_and_review_fixes.sql` for MariaDB syntax, transaction semantics, handler behavior, affected-row assertions, deadlocks and compatibility with oxmysql `CALL` result shapes.

Return:

- Critical, High, Medium and Low findings
- Exact file/function/procedure references
- Reproducible exploit or failure paths
- Smallest safe fixes
- A pass/fail result for each prior finding
- A final production merge recommendation
