# Codex v0.3.1 Review Response — v0.3.2

The v0.3.1 independent review reported 3 High, 7 Medium and 4 Low findings. v0.3.2 addresses all reported items as follows.

## High findings

- **H-1 permission ceiling bypass:** fixed in both explicit-rank invitations and existing-rank assignment. Acceptance revalidates the inviter and current rank permissions under the enterprise lock.
- **H-2 stale invitation acceptance:** replaced the multi-query zero-row transaction with `cen_accept_membership_invite`, which locks and asserts the invite, active enterprise, rank, membership state and capacity before committing.
- **H-3 non-atomic creation/finalization:** direct creation and founding finalization now use transaction-backed MariaDB procedures. Partial write cleanup is no longer the rollback mechanism.

## Medium findings

- **M-1 founding identity exclusivity:** `cen_founding_participants.identifier` is unique and represents both founders and accepted supporters. Controllers and finalization recheck participation under stable proposal/identity locks.
- **M-2 founder identifier privacy:** all client-facing founding responses use an explicit proposal DTO without `founderIdentifier`.
- **M-3 retention lock bypass:** each retention mutation executes inside `enterprise:<id>` and re-reads state after acquiring the lock.
- **M-4 source reuse queue accounting:** state is keyed by a captured connection-generation token, and lock waiting aborts immediately when identity/generation changes.
- **M-5 audit attribution:** audit calls accept and store the captured actor identifier instead of resolving a potentially reused source after awaits.
- **M-6 Tebex concurrency:** grants/revokes acquire both enterprise and grant-key locks and re-read state after lock acquisition.
- **M-7 stale rank messaging:** repeat invitations refresh the stored rank, inviter, display name and expiry; notification/audit values match the stored invitation.

## Low findings

- **L-1 revoke idempotency:** repeated revocation returns success with `alreadyRevoked = true`.
- **L-2 standalone item gate:** standalone requests require a short-lived server-issued session created only after a server-side ox_inventory check.
- **L-3 incomplete schema readiness:** startup verifies all v0.3 tables, retention columns and required stored procedures.
- **L-4 first-day retention boundary:** full timestamps are compared against the exact cycle-start midnight, not date strings alone.

## Remaining release gate

Static parsing is complete, but migration 005 and the concurrency flows must be executed on a disposable copy of the server's actual MariaDB/oxmysql/FiveM stack before production promotion.
