# Independent Security and Correctness Review — v0.3.1

Reviewed archive: `pixel_enterprises_phase1_v0.3.1-security-hardened.zip`  
SHA-256: `130C56EAFF2EB60A0452AF0BE3F3A0F8B19654BDFB43255F07152E11994B79D2`  
Review date: 2026-08-03

## Executive summary

The candidate should not be promoted to production in its current form. I found no Critical issue, but I verified three High findings, seven Medium findings, and four Low findings. The principal merge blockers are:

1. Managers can grant permissions they do not possess by assigning an existing rank, and `inviteMember` can use an explicit rank without the assign-rank permission.
2. Membership invitation acceptance treats a zero-row guarded update as a successful transaction step; an expired or concurrently cancelled invitation can still create/reactivate a member.
3. Founding and direct enterprise creation are a sequence of autocommitted writes with best-effort cleanup, so the failure mode most in need of rollback—a database interruption—can leave partial enterprises or moved historical members.

The review also found regressions or incomplete fixes in NUI identifier privacy, founding-identity exclusivity, source-ID reuse, scoped locking, consent messaging, and Tebex concurrency.

## Findings

### Critical

No Critical finding was verified.

### High

#### H-1 — Existing-rank assignment bypasses the permission grant ceiling

**References**

- `server/controllers/membership_controller.lua::InviteMember`, lines 257–311, especially 296–306
- `server/controllers/membership_controller.lua::SetMemberRank`, lines 384–409, especially 393–400
- `server/services/permissions.lua::CanAssignRank`, lines 68–81
- `server/services/permissions.lua::CanGrantPermissions`, lines 98–112

**Failure/exploit path**

1. An owner creates a rank at priority 50 containing `treasury.withdraw`.
2. A manager at priority 100 has `members.assign_rank` and/or `members.invite`, but does not have `treasury.withdraw`.
3. The manager assigns an accomplice to that rank with `setMemberRank`, or invites the accomplice with that rank ID.
4. `CanAssignRank` checks only enterprise equality and priority. It never calls `CanGrantPermissions`, so the accomplice receives a permission the manager cannot grant.
5. `InviteMember` is even broader: it authorizes only `members.invite`; supplying an explicit non-default rank does not require `members.assign_rank`.

This contradicts the documented security rule that non-owners cannot grant permissions they do not possess.

**Smallest safe fix**

- Before either assignment, run `CanGrantPermissions(actor, rank.permissions)`.
- When `inviteMember` supplies an explicit rank other than the default rank, also require `members.assign_rank`.
- Revalidate the inviter's current authority and the rank's current permissions at invitation acceptance, because both can change while an invitation is pending.

#### H-2 — A stale, expired, or cancelled membership invite can still create a member

**References**

- `server/controllers/membership_controller.lua::AcceptMembershipInvite`, lines 329–370
- `server/repositories/membership_invite_repository.lua::Accept`, lines 106–157

**Failure/exploit path**

1. Acceptance reads an invite while it is pending and unexpired.
2. Before the transaction executes, the invite expires or another path cancels it—for example, retention disbands the enterprise.
3. Transaction query 1 updates zero rows because its `status = 'pending'` / expiry predicate no longer matches.
4. Oxmysql continues with queries 2 and 3 because a zero-row update is not a query failure. The unconditional `INSERT ... ON DUPLICATE KEY UPDATE` can create or reactivate the member and other invitations are cancelled.
5. The post-commit verification detects the inconsistency and returns `conflict`, but the committed membership and cancellations are not rolled back.

A boundary test is reproducible by pausing acceptance after `GetPendingById`, advancing the invite past `expires_at`, then allowing `Repository.Accept` to run. The caller receives failure while the target can become an active member without a valid invitation. The retention interleaving can additionally create an active member attached to a disbanded enterprise.

Oxmysql documents that its transaction returns success when all statements execute successfully; the documented specific query-array format does not make zero affected rows a rollback condition: <https://overextended.dev/docs/oxmysql/Functions/transaction>.

**Smallest safe fix**

Make every later statement conditional on the invite still being accepted and the enterprise still being active. In particular:

- Insert/reactivate with `INSERT ... SELECT` joined to the still-pending, unexpired invite, active enterprise, and matching rank.
- Update the invite to `accepted` only when an active membership for the same identifier and enterprise exists.
- Cancel other invites only by joining to the now-accepted invite.
- Prefer a stored procedure with `START TRANSACTION`, affected-row assertions, `SIGNAL`, and rollback so a failed predicate aborts the transaction rather than merely producing zero affected rows.

#### H-3 — Founding and admin creation rollback is not atomic and fails during database outages

**References**

- `server/repositories/founding_repository.lua::cleanupPartialEnterprise`, lines 256–278
- `server/repositories/founding_repository.lua::CreateEnterpriseDirect`, lines 319–337
- `server/repositories/founding_repository.lua::FinalizeProposal`, lines 340–410

**Failure/exploit path**

1. Finalization inserts the enterprise, owner/member ranks, and one or more members as independent autocommitted queries.
2. Inject a database failure after a historical `removed` member is reactivated into the new enterprise but before the owner/proposal updates complete.
3. The `pcall` catches the failure and calls `cleanupPartialEnterprise`.
4. Cleanup uses the same unavailable database and ignores every cleanup error with `pcall`; restoration, deletes, and proposal-state restoration can all fail.
5. The database can retain an active ownerless enterprise, partial ranks/members, or a historical member moved away from its original enterprise. Startup verification may then security-stop the whole resource.

The same defect exists in direct admin creation. This fails the promised rollback-restoration behavior and the PR-002 runtime test that a failed finalization leaves no partial enterprise.

**Smallest safe fix**

Move enterprise insertion, rank creation, member activation/insertion, owner assignment, and proposal finalization into one server-side database transaction that can use generated IDs on a single connection. A MariaDB stored procedure is the smallest reliable option with the current oxmysql API. Retain a startup reconciler for proposals stuck in `finalizing` as defense in depth.

### Medium

#### M-1 — A player can simultaneously found one proposal and support another

**References**

- `server/controllers/founding_controller.lua::StartFounding`, lines 61–101
- `server/controllers/founding_controller.lua::InviteFounder`, lines 103–148
- `server/controllers/founding_controller.lua::AcceptFounding`, lines 167–221
- `server/controllers/founding_controller.lua::GetMutationKeys`, lines 266–295
- `server/repositories/founding_repository.lua::FinalizeProposal`, lines 340–410

**Failure/exploit path**

1. Player A starts proposal A.
2. Founder B invites A to proposal B. `InviteFounder` checks A's membership and accepted support, but not whether A is already an active founder.
3. A accepts B's invitation. `AcceptFounding` also omits the active-founder check.
4. Proposal B finalizes and makes A an active member while proposal A remains active and keeps its name/slug reserved.
5. Proposal A can no longer finalize because its founder is already a member. The inverse is also allowed: `StartFounding` does not reject a player who is already an accepted supporter.

For simultaneous seventh/eighth acceptances, `GetMutationKeys` also snapshots accepted identities before acquiring the proposal lock, so the finalizer's identity-lock set can be stale.

**Smallest safe fix**

- Add symmetrical checks: a founder cannot be active support, and an invitee/supporter cannot be an active founder.
- Repeat those checks inside finalization while holding a stable set of identity locks.
- Acquire the proposal lock first, then read and lock the current founder/supporter identity set before finalization, or enforce one active founding-participation row per identifier in the database.

#### M-2 — Founder's Rockstar license is returned to NUI/LB Tablet

**References**

- `server/repositories/founding_repository.lua::GetActiveProposalByFounder`, lines 42–59
- `server/repositories/founding_repository.lua::GetProposal`, lines 61–75
- `server/controllers/founding_controller.lua::GetCreationContext`, lines 36–58
- `server/controllers/founding_controller.lua::StartFounding`, line 100
- `server/controllers/founding_controller.lua::InviteFounder`, line 147
- `server/controllers/founding_controller.lua::AcceptFounding`, line 220

**Failure/exploit path**

`GetProposal` and `GetActiveProposalByFounder` select `founder_identifier AS founderIdentifier`. Controller methods return these repository rows directly. Before the threshold is reached, an invited supporter who accepts receives another player's stable Rockstar license in the server response, which is delivered to the NUI/LB Tablet callback.

The static string scan passes only because `playerIdentifier`/`onlineSource` do not occur literally in client code; it does not inspect runtime DTOs. This is a regression from PR-002 M-1/M-4 and contradicts README line 62.

**Smallest safe fix**

Add an explicit `proposalDto` that contains only the proposal ID, display fields, counts, status, and timestamps. Never return repository rows containing `founderIdentifier` to a client-facing controller.

#### M-3 — Retention disband bypasses enterprise mutation locks

**References**

- `server/services/retention.lua::Evaluate`, lines 66–157
- `server/repositories/activity_repository.lua::DisbandDue`, lines 100–147
- `server/controllers/membership_controller.lua::GetMutationKeys`, lines 538–554
- `server/main.lua::WithMutationLocks`, lines 111–125

**Failure/exploit path**

1. Invitation acceptance holds `enterprise:<id>`, reads member count/limit, and yields on database work.
2. Retention concurrently calls `DisbandDue` without acquiring that enterprise lock; it disbands the enterprise, removes members, and cancels pending invites.
3. Acceptance resumes. With H-2 present, it can reactivate the target into the disbanded enterprise. Other member/rank/ownership mutations can also race the lifecycle change and return misleading partial outcomes.

**Smallest safe fix**

Run each retention state mutation inside `WithMutationLocks(0, { 'enterprise:<id>' }, 'console', ...)`, then re-read due/recovery conditions inside the lock. Keep the SQL predicates as a second line of defense.

#### M-4 — Source reuse corrupts mutation queue accounting and delays stale requests

**References**

- `server/main.lua::acquireLocks`, lines 86–109
- network mutation thread and `finishQueue`, lines 176–224
- `playerDropped` cleanup, lines 300–310

**Failure/exploit path**

1. Source 12 has one or more mutation threads running or waiting.
2. That player disconnects; `playerDropped` sets `queuedMutations[12] = nil` even though the old threads still exist.
3. A new player receives source 12 and queues mutations.
4. An old thread finishes and decrements the new player's counter at line 190, allowing the new generation to exceed `maxMutationQueuePerSource`.
5. While waiting, `acquireLocks` tests only `GetPlayerName(12)`, so the presence of the new player prevents early cancellation of the stale request. The identity mismatch is detected only after lock acquisition.

This is an incomplete fix for the scoped queue/source-reuse hardening in C-1/M-8.

**Smallest safe fix**

Key request-window, cooldown, and queue state by a connection-generation token such as `source + captured identifier`, and have each thread decrement only its own generation. Pass the captured identifier into `acquireLocks` and abort as soon as it no longer matches.

#### M-5 — Audit records can attribute a completed mutation to a reused source ID

**References**

- `server/services/audit.lua::CENServer.Audit`, lines 18–51, especially line 35
- mutation handler, `server/main.lua`, lines 212–243
- mutation call sites throughout `membership_controller.lua` and `founding_controller.lua`

**Failure/exploit path**

1. Player A is authorized and a handler resolves A's captured identifier.
2. A disconnects while a database await is in progress; source ID is reused by player B.
3. The already-authorized mutation completes.
4. The handler calls `Audit(..., source, ...)`; `Audit` resolves the actor from the live source at that moment and stores B's identifier.

Replies and several notifications use the captured identifier, but audit attribution does not. This creates false evidence and weakens incident response.

**Smallest safe fix**

Allow `Audit` to receive an explicit captured actor identifier and pass `requesterIdentifier` from the router/controllers. Use source resolution only as a fallback for non-request events.

#### M-6 — Tebex revoke is not serialized with member-limit acceptance

**References**

- `server/commands.lua::cen_tebex_slots_grant`, lines 217–247
- `server/commands.lua::cen_tebex_slots_revoke`, lines 249–268
- `server/controllers/membership_controller.lua::AcceptMembershipInvite`, lines 346–358
- `server/repositories/entitlement_repository.lua::RevokeGrant`, lines 73–83

**Failure/exploit path**

1. An enterprise has 13 active members and a +2 entitlement, for a limit of 14.
2. Acceptance holds the enterprise lock and verifies `13 < 14`.
3. A concurrent refund locks only `tebex-grant:<key>`, revokes the entitlement, and reduces the current limit to 12.
4. Acceptance continues and adds member 14 after revocation. This contradicts the documented behavior that revocation blocks new joins while an enterprise is over its reduced limit.

**Smallest safe fix**

Resolve the entitlement's enterprise before mutation, then acquire both `tebex-grant:<key>` and `enterprise:<id>` for revoke. Grant should also take the enterprise lock. Re-read the grant/enterprise after both locks are held.

#### M-7 — Re-sending a pending invite can misrepresent the rank being accepted

**References**

- `server/repositories/membership_invite_repository.lua::Create`, lines 74–104
- `server/controllers/membership_controller.lua::InviteMember`, lines 296–326

**Failure/exploit path**

1. An inviter creates a pending invite to a privileged Rank A.
2. The inviter repeats the invitation for the same enterprise/identifier, now selecting ordinary Rank B.
3. `Repository.Create` returns the existing invite ID without updating its rank or expiry.
4. The controller ignores the second return value and notifies the target that the invitation is for Rank B; the audit also records Rank B.
5. On acceptance, the stored invite still assigns Rank A.

The same behavior can tell the target a fresh invite exists even when the retained invite is about to expire.

**Smallest safe fix**

Either atomically refresh the pending row's rank, inviter, display name, and expiry and return that row, or return the existing stored invite and notify/audit its actual rank and expiry. Revalidate rank-grant authority at acceptance as required by H-1.

### Low

#### L-1 — Tebex revoke is not API-idempotent

**References**

- `server/repositories/entitlement_repository.lua::RevokeGrant`, lines 73–83
- `server/commands.lua::cen_tebex_slots_revoke`, lines 249–268

**Failure path**

The first refund delivery changes `active` to `revoked`; a retry updates zero rows and returns `entitlement_not_found`. State remains safe, but a retrying provider sees a permanent failure instead of successful idempotent completion.

**Smallest safe fix**

Return success when the key exists for Tebex and is already `revoked`; reserve `entitlement_not_found` for a key that does not exist.

#### L-2 — The configured standalone tablet-item requirement is client-only

**References**

- `client/adapters/standalone.lua::hasRequiredTabletItem`, lines 18–25
- `server/main.lua` network request handler, lines 140–245

**Failure path**

A modified client can call `pixel_enterprises:server:request` directly without opening the standalone UI or possessing `criminal_tablet`. Membership and permission checks still prevent privilege escalation, but the configured possession gate is bypassed.

**Smallest safe fix**

Enforce a server-issued, short-lived tablet session/access proof before post-bootstrap actions, using an adapter-owned server check rather than trusting the client-side inventory lookup.

#### L-3 — Startup verification can report ready with an incomplete v0.3 schema

**References**

- `server/repositories/enterprise_repository.lua::VerifySchema`, lines 81–164

**Failure path**

The verifier checks the membership-invite table but not the founding, entitlement, or activity tables and not the v0.3 retention columns. A database with migration 002 plus a manually/piecemeal-created membership-invite table can pass startup, after which founding and retention queries fail at runtime.

**Smallest safe fix**

Verify every table and column required by enabled modules, plus the exact columns/order of the unique membership index. Return a named schema failure before setting `schemaVerified = true`.

#### L-4 — An enterprise created during the first day is treated as having a complete calendar cycle

**References**

- `server/services/retention.lua::createdBeforeOrOnCycle`, lines 25–28
- `server/services/retention.lua::Evaluate`, lines 88–133

**Failure path**

An enterprise created at 23:59 on the first day has `createdAt:sub(1, 10) == cycleStart`, so it is evaluated next month as though it existed for the complete previous calendar cycle.

**Smallest safe fix**

Compare full UTC timestamps and require `created_at <=` the exact cycle-start instant (normally midnight), not merely the same date string.

## Static validation results

Independently reproduced:

- `ui/app.js` passes the bundled Node.js syntax checker.
- The archive contains 24 Lua files.
- All 26 local paths referenced by `fxmanifest.lua` exist.
- 19 NUI callback/action mappings are present.
- Literal scans of client/NUI source contain neither `playerIdentifier` nor `onlineSource`.
- Migrations 002–004, changelog, test plan, and security-fix record are present.
- Migration text contains duplicate-membership preflight, deterministic rank repair, the named global unique-membership index, and the membership-invite table.

Not independently rerun:

- Lua parsing and Lua logic smoke tests, because this environment does not include Lua/LuaTeX. The relevant Lua was manually inspected.
- FiveM/OneSync, LB Tablet, ESX identifier, Tebex delivery, and real multi-client tests.
- Execution against the production MariaDB version and installed oxmysql build.

Static compatibility notes:

- The oxmysql `{ query, values }` transaction-array shape used by the package is documented and valid: <https://overextended.dev/docs/oxmysql/Functions/transaction>.
- MariaDB documents the `ALTER TABLE ... ADD COLUMN IF NOT EXISTS` and `ADD INDEX IF NOT EXISTS` forms used by migration 002: <https://mariadb.com/docs/server/reference/sql-statements/data-definition/alter/alter-table>.
- No static MariaDB syntax blocker was verified. Exact-version execution remains required.

## Review-area checklist

| Review area | Result | Notes |
|---|---|---|
| Scoped locks, timeouts, queues, source reuse | **Fail** | Scoped/sorted locks and timeouts exist, but M-3/M-4/M-6 leave lifecycle, source-generation, and entitlement gaps. |
| Consent invitations, leave/disband, member-limit recheck | **Fail** | Leave/disband and a count recheck exist; H-1/H-2/M-6/M-7 break authority, consent, and concurrency guarantees. |
| Founding locks, eighth acceptance, rollback | **Fail** | Proposal CAS exists; M-1 and H-3 break identity exclusivity and reliable rollback. |
| Admin creation/approval ACE and console restrictions | **Pass (static)** | Both commands check console/ACE authorization and recheck source identity after lock waits. H-3 still affects creation atomicity. |
| Unique membership, owner/default/protected startup invariants | **Pass/partial** | Explicit invariants are checked; L-3 shows the overall schema readiness check is incomplete. |
| Tebex idempotency/concurrency | **Fail** | Grant replay/revoked-key protection passes; M-6 and L-1 remain. |
| Monthly activity/warning/outage/grace/disband | **Fail/partial** | Query failures skip evaluation and soft disband reassigns ranks; M-3 and L-4 remain. |
| NUI/LB privacy and spoofing resistance | **Fail** | Server-side membership/permission checks are present, but M-2 leaks a stable identifier and L-2 bypasses the configured device gate. |
| MariaDB/oxmysql migrations and transactions | **Partial** | Documented syntax/array shape is valid statically; H-2/H-3 are transaction-semantic defects and production runtime testing remains required. |

## Regression comparison with `PR_002_SECURITY_FIXES.md`

- **Regressed/incomplete:** M-1/M-4 NUI privacy — proposal repository rows bypass the new DTO boundary (M-2).
- **Regressed/incomplete:** C-1/M-8 scoped queue/source reuse — queue state is still keyed only by recyclable source ID and audit attribution re-resolves the live source (M-4/M-5).
- **Regressed/incomplete:** H-1 consent flow — stale invite reuse can describe a different rank, and a stale guarded acceptance can still add a member (H-2/M-7).
- **Regressed/incomplete:** founding identity locks and rollback restoration — participation is not mutually exclusive and cleanup is best effort rather than atomic (M-1/H-3).
- **Regressed/incomplete:** Tebex concurrent command handling — grant-key locking does not serialize capacity changes with enterprise membership (M-6).
- **Still effective in inspected paths:** global lock was replaced by sorted scoped locks with a timeout; normal roster DTOs remove member identifiers; member/rank list/count database failures generally fail closed; revoked grant keys cannot be reactivated; retention qualified-count outages skip evaluation; removed/disbanded members are reassigned to the default rank.

## Recommended fix order

1. H-1 permission ceiling and explicit-rank invitation authorization.
2. H-2 conditional/atomic invitation acceptance.
3. H-3 atomic founding/admin creation.
4. M-1 founding participation invariants and stable identity-lock acquisition.
5. M-2 identifier DTO regression.
6. M-3/M-4/M-5/M-6 concurrency and source-generation fixes.
7. M-7 and Low findings, followed by the full runtime test plan on disposable MariaDB data.
