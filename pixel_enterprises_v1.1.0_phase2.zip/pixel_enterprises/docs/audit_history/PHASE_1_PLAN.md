# Phase 1 — Enterprise Core

## Goal
Build the shared, server-authoritative foundation used by both the LB Tablet app and standalone tablet.

## Deliverables
1. Enterprise types and module allowlists.
2. Enterprise membership, ranks, permissions and ownership.
3. Organization level and XP foundation.
4. Treasury transaction foundation.
5. Audit logging foundation.
6. LB Tablet adapter.
7. Standalone NUI adapter.
8. Admin bootstrap tools and seed workflow.
9. Test harness for permission and request validation.
10. Migration-safe SQL schema and CHANGELOG.

## First implementation PRs
- PR-001: bootstrap resource and database schema.
- PR-002: membership, ranks and permission service.
- PR-003: shared tablet session/bootstrap API.
- PR-004: standalone tablet adapter and access item.
- PR-005: LB Tablet custom-app adapter.
- PR-006: dashboard, members and audit-log read models.

## Non-negotiable security rules
- The UI never grants access.
- Every mutation resolves the player's server identity again.
- Every enterprise action checks enterprise, rank, permission and module eligibility.
- Rewards, inventory, money, XP and territory state are server-authoritative.
- No direct pushes to main.
- One writer AI per PR; independent reviewers may review the same PR.
