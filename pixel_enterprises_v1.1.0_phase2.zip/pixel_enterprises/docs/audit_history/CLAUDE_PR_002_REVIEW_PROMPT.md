# Claude Code Review Prompt — PR-002

Review this `pixel_enterprises` v0.3.1 security-hardened creation/retention candidate as a security reviewer only. Do not rewrite files yet.

Focus on:

1. FiveM event spoofing and whether every mutation re-resolves server identity.
2. Cross-enterprise member/rank access.
3. Rank priority bypasses and permission-escalation paths.
4. Ownership transfer correctness under concurrent requests.
5. Duplicate membership races.
6. SQL/MariaDB compatibility with oxmysql.
7. Source reuse, disconnect and stale-player edge cases.
8. Information leakage to NUI or LB Tablet.
9. Rate-limit bypasses and oversized payload handling.
10. Any way a non-owner can acquire owner-only authority.

Return findings grouped as Critical, High, Medium and Low. For every finding include the exact file/function, an exploit scenario, and the smallest safe remediation. Also provide a pass/fail checklist against `docs/PR_002_TEST_PLAN.md`.


## v0.3 extension review
Also audit founding proposal races, duplicate supporter acceptance, auto-finalization cleanup,
Tebex grant/revoke idempotency, member-limit calculation, retention cycle boundaries,
warning/deletion recovery, and any way a client can create a higher-tier enterprise.


## Regression checks from the prior audit

Confirm that the global lock, rate limiter, migration invariants, consent flow, NUI privacy,
source reuse, database fail-closed behavior, leave/disband lifecycle, founding identity locks,
Tebex replay handling and retention outage safety remain fixed. Treat any regression in those
areas as a merge blocker.
