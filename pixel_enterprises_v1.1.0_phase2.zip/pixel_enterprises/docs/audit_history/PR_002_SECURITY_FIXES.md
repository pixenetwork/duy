# PR-002 / v0.3.1 Security Hardening Record

This build addresses the blocking and high-value findings from the independent v0.2 audit.

## Fixed

- **C-1:** Replaced the global unbounded mutation lock with sorted scoped locks, a timeout, per-source queue ceilings and resource-stop cleanup.
- **H-1:** Replaced instant membership enrollment with expiring consent-based invites; added leave and soft-disband actions.
- **H-2:** Added deterministic membership ordering, startup unique-index verification and duplicate-membership refusal.
- **H-3:** Added an early per-source request window before payload encoding plus shared read/mutation cooldown buckets.
- **H-4:** Rebuilt migration 002 with preflight duplicate checks, owner recovery, protected/default rank backfill and post-migration owner assertions.
- **M-1/M-4:** Added an explicit NUI actor DTO and removed identifiers and live server IDs from browser payloads.
- **M-2:** Bootstrap only attaches roster data when the enterprise type has the members module.
- **M-3:** Membership target failures return a generic `target_unavailable` error while the precise reason remains in audit storage.
- **M-5/M-6:** Denials are audited; console audit output is debug-only and excludes identifiers.
- **M-7:** Member/rank list and count queries fail closed instead of coercing database failures into empty/zero results.
- **M-8:** The original license identifier is carried through lock waits, actor resolution and target notifications.
- **M-9:** Multi-enterprise mode is explicitly refused by startup verification; removed members can be reactivated while suspended members remain protected.

## Additional hardening

- Founding finalization and membership acceptance share identity locks.
- Founding proposals use a `finalizing` compare-and-set state before enterprise creation.
- Tebex refund revocations cannot be undone by replaying an old grant command.
- Retention heartbeat credit uses elapsed time and does not grant minutes on resource restart.
- Soft retention disband removes active memberships and cancels pending invites only after the enterprise reaches the disbanded state.
- Retention evaluation treats database failures as an evaluation skip, never as zero qualified members.
- Removed/disbanded members are moved to the protected default rank so historical rows do not pin deletable custom ranks.
- Denial auditing is sampled per source/action/error to prevent the audit path becoming a new write-amplification vector.

## Still requires runtime validation

- oxmysql transaction behavior on the server's installed build.
- MariaDB compatibility for the exact production version.
- ESX character identifier bridge if the server does not use Rockstar license identifiers.
- Multi-client concurrency testing for eighth founding acceptance, invitation acceptance, ownership transfer and retention disband.
