# Codex Brief — PR-003 Tablet Session API

Do not start until PR-002 review findings are resolved.

Goal: add short-lived server-issued tablet sessions shared by LB Tablet and standalone mode.

Requirements:

- Issue a random session token only after membership/access validation.
- Bind session to source, player identifier, enterprise ID and resource generation.
- Expire on timeout, disconnect, membership removal, enterprise suspension or resource restart.
- Require the token for all post-bootstrap requests.
- Rotate or revoke after ownership/membership changes.
- Never store authoritative permissions in the client session.
- Add tests for token replay, source reuse, expired tokens and cross-enterprise token use.
- Preserve current NUI callback names and both tablet adapters.
- Update SQL only if persistence is truly necessary; prefer in-memory sessions.
