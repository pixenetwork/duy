# Codex Review Brief — v0.3.1

Review this package as an independent security and correctness reviewer. Do not add new gameplay modules and do not rewrite the architecture unless a verified defect requires it.

First run the checks described in `docs/STATIC_VALIDATION.md`, then inspect:

1. Scoped mutation locks, timeouts, queue bounds and source/license reuse.
2. Consent-based membership invitations, leave/disband behavior and member-limit rechecks.
3. Founding proposal identity/name locks, eighth-acceptance finalization and rollback restoration.
4. Admin creation and approval commands, including ACE and console restrictions.
5. Unique-membership, owner, default-rank and protected-rank startup invariants.
6. Tebex grant/revoke idempotency and concurrent command handling.
7. Monthly activity calculations, day-21 warning, outage fail-closed behavior, grace recovery and soft disband.
8. NUI/LB Tablet payload privacy and client-event spoofing resistance.
9. MariaDB/oxmysql compatibility of migrations 002–004 and transaction query arrays.

Return Critical, High, Medium and Low findings with exact file/function references, a reproducible failure or exploit path, and the smallest safe fix. Compare against `docs/PR_002_SECURITY_FIXES.md` and call out any regression from the earlier audit.
