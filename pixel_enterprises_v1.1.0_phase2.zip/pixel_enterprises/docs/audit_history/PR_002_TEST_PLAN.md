# PR-002 Runtime Test Plan

Use a development server and disposable database backup.

## Setup

1. Import the v0.3.2 schema, or run migrations 002, 003, 004 and 005 in order.
2. Seed one owner, one manager rank and one recruit rank.
3. Connect three test characters: owner, manager and recruit.
4. Ensure OneSync is enabled when nearby invitation validation is enabled.

## Access

- Owner can bootstrap through standalone mode.
- Owner can bootstrap through LB Tablet mode.
- A non-member receives `not_member`.
- A suspended membership receives `not_member` or `forbidden` and no roster data.

## Invitations

- Owner can send an expiring invitation to a nearby online non-member.
- Distant, nonexistent, already-member and otherwise unavailable targets all receive the generic `target_unavailable` response.
- The target is not added until explicitly accepting the invitation.
- Concurrent invitations/acceptances for the same player produce only one active membership row.
- Pause acceptance after its initial read, expire/cancel the invite, then resume: no membership is created and no other invitations are cancelled.
- Member limit is checked both when sending and when accepting.
- Accepting one invitation cancels the target's other pending membership invitations.
- Non-owner members can leave; owners must transfer ownership or confirm a soft disband.

## Rank security

- Owner can create and edit normal ranks.
- Manager cannot create a rank at or above the manager's own priority.
- Manager cannot grant a permission the manager does not possess through rank creation, rank assignment or explicit-rank invitation.
- Pending invitation acceptance revalidates the inviter’s current invite/assign-rank authority and the rank’s current permission set.
- Manager cannot edit/delete a protected rank.
- A rank assigned to a member cannot be deleted.
- Duplicate rank names are rejected.

## Member security

- Manager can manage lower-ranked members only.
- Manager cannot remove or change an equal/higher-ranked member.
- No member can remove or re-rank themselves.
- Owner cannot be removed through the remove-member action.
- Rank assignment only accepts ranks belonging to the same enterprise.

## Ownership

- Only the current owner can transfer ownership.
- Transfer changes `cen_enterprises.owner_member_id` exactly once.
- Previous owner immediately loses owner bypass.
- New owner immediately receives owner bypass.
- Failed transfer leaves the original owner unchanged.

## Audit and privacy

- Every successful mutation writes a `cen_audit_logs` row; denied attempts are sampled/rate-limited into audit rows.
- The NUI roster never receives `player_identifier`.
- Malformed and oversized payloads do not execute an action.
- Repeated mutation spam is rate-limited.


## Creation policy and founding

- With `street_gang = public_founding`, a non-member can create one pending proposal.
- The same founder cannot create a second active proposal.
- Cartel/processor/arms creation is denied to normal players under default config.
- ACE/admin creation succeeds only for an authorized source or server console.
- Founder cannot invite themselves, existing members, distant players, or nonexistent IDs.
- A supporter must explicitly accept; an invitation alone does not count.
- One identity cannot simultaneously found one proposal and support another, or support two active proposals.
- Seven acceptances do not create the gang; the eighth acceptance does.
- Final gang contains the founder plus eight accepted supporters by default.
- Inject a database error during direct creation/finalization: the MariaDB transaction rolls back the enterprise, ranks, memberships and proposal state with no cleanup dependency.
- A reused historical `removed` member row remains unchanged when the creation/finalization transaction rolls back.
- When approval-gated founding is enabled, only console/ACE administrators can run `cenfoundapprove`.
- Two simultaneous proposals/admin creations using the same slug cannot both succeed.

## Tebex slots

- Base free-gang limit is 12 and enterprise levels do not increase it.
- `gang_slots_2` changes the limit to 14 after a console grant.
- Re-delivering the same grant key does not add slots twice.
- Reusing a grant key for another enterprise is rejected.
- Refund/revoke returns the limit to the remaining active entitlement total.
- Race a refund against invitation acceptance at the capacity boundary; enterprise locking prevents a post-refund join.
- Re-delivering the same revoke command succeeds idempotently without changing state twice.
- Revoking slots never removes existing members; it only blocks new invitations while over limit.
- Player-issued fulfillment commands are denied while `consoleOnly = true`.

## Retention

- Activity heartbeat counts distinct active roster members, not sessions.
- A member qualifies only after the configured monthly minutes threshold.
- New gangs are not evaluated before a complete calendar cycle.
- Day 21 produces one warning per cycle when fewer than five members qualify.
- Month-end failure schedules disbanding with the configured grace period.
- Reaching five qualified members during grace cancels pending disbanding when recovery is enabled.
- Default enforcement soft-disbands and keeps rows available for administrator restoration.


## Retention outage safety

- Stop or interrupt database access during evaluation; no warning, schedule or disband is created from a failed qualified-member query.
- Restart database access and verify evaluation resumes without duplicating the cycle warning.
- Soft-disbanded members are reassigned to the protected default rank so old custom ranks can be deleted later without FK conflicts.


## Source reuse and tablet access

- Disconnect a player with queued mutations, reuse the same server ID, and verify old threads cannot decrement or bypass the new connection's queue limit.
- Verify completed audits retain the captured original actor identifier even if the source ID is reused before the database await returns.
- With standalone `requireItem = true`, direct server requests without a valid server-issued session are rejected.
- Removing the tablet prevents a new session; an existing session expires after `standaloneSessionSeconds`.
- LB Tablet requests remain independent of standalone access tokens and are accepted only while the configured LB Tablet resource is started.
