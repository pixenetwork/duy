-- Merge these examples into ox_inventory/data/items.lua and adapt names/weights.
return {
    ['criminal_tablet'] = {
        label = 'Encrypted Enterprise Tablet',
        weight = 850,
        stack = false,
        close = true,
        description = 'An encrypted device connected to the Criminal Enterprise Network.',
        client = { export = 'pixel_enterprises.openTablet' }
    },
    ['coca_paste'] = { label = 'Coca Paste', weight = 150 },
    ['pseudoephedrine'] = { label = 'Pseudoephedrine', weight = 100 },
    ['chemicals'] = { label = 'Chemical Precursors', weight = 250 },
    ['cannabis'] = { label = 'Cannabis', weight = 50 },
    ['packaging'] = { label = 'Packaging Materials', weight = 25 },
    ['steel'] = { label = 'Machined Steel', weight = 300 },
    ['weapon_parts'] = { label = 'Weapon Parts', weight = 250 },
    ['cocaine_baggy'] = { label = 'Cocaine Package', weight = 50 },
    ['meth_baggy'] = { label = 'Meth Package', weight = 50 },
    ['weed_brick'] = { label = 'Cannabis Brick', weight = 500 },
    ['pistol_components'] = { label = 'Pistol Components', weight = 750 },
    ['rifle_components'] = { label = 'Rifle Components', weight = 1100 },
    ['black_money'] = { label = 'Dirty Money', weight = 0 }
}
