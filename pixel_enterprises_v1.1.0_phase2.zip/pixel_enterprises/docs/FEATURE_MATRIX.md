# Enterprise feature matrix

| Type | Tier | Primary role | Specialist modules |
|---|---:|---|---|
| Street Gang | 1 | Local retail and turf influence | Wholesale buying, street sales, turfs, crews, wars, rackets |
| Processor | 2 | Finished-product production | Labs, wholesale, smuggling, fronts, crews, wars |
| Wholesaler | 2 | Bulk distribution | Wholesale market, smuggling, fronts, crews, wars |
| Smuggling Crew | 2 | Logistics and contraband | Dead drops, airdrops, territories, fronts, crews, wars |
| Cartel | 3 | Production and regional supply | Labs, wholesale, shipments, airdrops, corruption, fronts, rackets, wars |
| Arms Enterprise | 3 | Weapon components and gunrunning | Workshops, arms shipments, airdrops, corruption, fronts, wars |
| Crime Family | 3 | Influence and financial control | Wholesale, territories, corruption, fronts, rackets, wars |
| Syndicate | 3 | Multi-role high-trust operation | Configured labs/arms, wholesale, smuggling, corruption, fronts, rackets, wars |

All enterprise types receive dashboard, members, ranks, treasury, storage, logs, progression, crews, and diplomacy unless a module is disabled in configuration.

Enterprise type controls which specialist modules exist. Enterprise level controls scale, crew count, front availability, war access, and activity requirements inside those modules.

Street gangs cannot start configured production recipes. In the CEN market, their finished-drug purchases are accepted only when the listing seller is an approved higher-tier supplier type.
