# Agent Rules for pixel_enterprises

- Never push directly to `main`.
- One implementation writer owns each PR.
- Update `CHANGELOG.md` for every user-visible or behavioral change.
- Do not add ReaperV4 imports, manifest dependencies or protection hooks.
- Keep enterprise rules server-authoritative.
- Treat NUI and client events as untrusted input.
- Preserve LB Tablet and standalone compatibility through adapters.
- Do not hardcode one framework into core domain services.
- Add migrations rather than destructive schema edits.
- Include reproducible FiveM test steps in each PR.
