# Pixel Enterprises — Criminal Enterprise Network

`pixel_enterprises` is a server-authoritative FiveM criminal-organization system for ESX Legacy, oxmysql, ox_inventory, and LB Tablet or a standalone encrypted tablet.

Version: **1.1.0 Phase 2**

## Enterprise foundation

- LB Tablet app, standalone tablet, or both from one shared backend
- Street gangs, processors, wholesalers, cartels, arms enterprises, smuggling crews, crime families, and syndicates
- Public street-gang founding with **one founder plus eight accepted supporters**
- Admin/ACE/framework-controlled higher-tier enterprise creation
- Consent-based membership invitations, custom ranks, permission ceilings, ownership transfer, leaving, soft disbanding, and restoration
- **12 free member slots**, expanded only through idempotent Tebex slot entitlements
- Monthly free-gang retention: five qualified active members, day-21 warning, grace period, and reversible soft disband
- Treasury, progression, privacy-filtered logs, secure ox_inventory storage, turfs, territories, and contests

## Criminal economy

- Labs and workshops with production queues, quality, recipes, and traceable batch metadata
- Higher-tier wholesale market with atomic treasury settlement and claimable deliveries
- Street gangs restricted to configured higher-tier finished-drug suppliers
- Turf-aware street distribution with dirty-money payout, XP, heat, and cooldowns
- Treasury-funded dead drops and airdrops for components, chemicals, and contraband
- Opt-in crooked-officer offers with job validation, fees, trust, exposure, and audit records

## Phase 2 systems

- Internal crews/chapters with assignable members and replaceable leaders
- Alliances and ceasefires with bilateral consent and outgoing cancellation
- Formal wars with matched stakes, target scores, timed resolution, automatic payouts, and post-war ceasefires
- War scoring from zone victories and configured enemy-turf activity
- Front businesses with level/type restrictions and cycle-based laundering capacity
- Treasury or optional player-account laundering payouts
- Zone-linked protection rackets with recurring income, heat, XP, cooldowns, and ownership cleanup

## Required resources

- `oxmysql`
- `ox_inventory`
- ESX Legacy when `Config.Economy.provider = 'esx'`
- LB Tablet only when using the LB integration mode

## Installation

Read [`docs/INSTALLATION.md`](docs/INSTALLATION.md). For upgrades, apply migrations through `009_phase2_hardening.sql` in order.

## Runtime status

The Lua and JavaScript sources pass static parsing and manifest checks. Stored procedures, real multi-client races, ESX accounts, LB Tablet registration, inventory items, front payouts, war escrow, and racket collection must still be tested on a disposable copy of the server database before production use. The external audit is intentionally deferred until this complete Phase 2 package passes development-server testing.
