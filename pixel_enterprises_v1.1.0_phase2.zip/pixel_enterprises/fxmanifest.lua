fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Pixel Network'
description 'Criminal Enterprise Network - shared backend with LB Tablet and standalone tablet adapters'
version '1.1.0'

ui_page 'ui/index.html'

dependencies { 'oxmysql', 'ox_inventory' }

files {
    'ui/index.html',
    'ui/styles.css',
    'ui/app.js'
}

shared_scripts {
    'config/config.lua',
    'shared/constants.lua',
    'shared/enterprise_types.lua',
    'shared/validation.lua'
}

client_scripts {
    'client/adapters/lb_tablet.lua',
    'client/adapters/standalone.lua',
    'client/main.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/bridges/identity.lua',
    'server/bridges/economy.lua',
    'server/bridges/inventory.lua',
    'server/services/audit.lua',
    'server/services/notifications.lua',
    'server/services/permissions.lua',
    'server/services/creation_policy.lua',
    'server/repositories/enterprise_repository.lua',
    'server/repositories/membership_invite_repository.lua',
    'server/repositories/founding_repository.lua',
    'server/repositories/entitlement_repository.lua',
    'server/repositories/activity_repository.lua',
    'server/repositories/treasury_repository.lua',
    'server/repositories/progression_repository.lua',
    'server/repositories/log_repository.lua',
    'server/repositories/zone_repository.lua',
    'server/repositories/facility_repository.lua',
    'server/repositories/market_repository.lua',
    'server/repositories/shipment_repository.lua',
    'server/repositories/corruption_repository.lua',
    'server/repositories/organization_repository.lua',
    'server/repositories/war_repository.lua',
    'server/repositories/front_repository.lua',
    'server/services/retention.lua',
    'server/services/progression.lua',
    'server/services/heat.lua',
    'server/services/storage.lua',
    'server/controllers/membership_controller.lua',
    'server/controllers/founding_controller.lua',
    'server/controllers/operations_controller.lua',
    'server/controllers/territory_controller.lua',
    'server/controllers/production_controller.lua',
    'server/controllers/market_controller.lua',
    'server/controllers/shipment_controller.lua',
    'server/controllers/corruption_controller.lua',
    'server/controllers/organization_controller.lua',
    'server/controllers/war_controller.lua',
    'server/controllers/front_controller.lua',
    'server/router.lua',
    'server/services/wars.lua',
    'server/services/territory.lua',
    'server/commands.lua',
    'server/main.lua'
}
