# Changelog

## 1.1.0 — Organizations, Diplomacy and Criminal Influence

### Internal organization
- Added configurable crews and chapters with member assignments, capacity limits, replaceable leaders, and enterprise-level crew limits.
- Added server-authoritative crew permissions, audit records, scoped locks, and atomic crew mutations.

### Diplomacy and wars
- Added bilateral alliances and ceasefires with proposals, acceptance, decline, cancellation, expiry, and relationship cooldowns.
- Added formal war contracts with matched treasury escrow, target scores, timed duration, cancellation/refunds, automatic resolution, winner payouts, and post-war ceasefires.
- Added automatic war scoring from turf/territory victories and configured enemy-turf street sales.
- Added atomic score events so a war event can never be logged without its score being applied.

### Front businesses and laundering
- Added purchasable front businesses with enterprise-type and level restrictions.
- Added cycle-based processing capacity, laundering fees, timed jobs, and atomic treasury payouts.
- Added optional player-account payout mode with compensating rollback and audit alerts.

### Protection rackets
- Added zone-linked protection, contraband-tax, and smuggling-route rackets.
- Added recurring treasury collection, cooldowns, heat, XP, ownership validation, and atomic double-collection protection.
- Rackets are automatically removed when a zone changes to a different owner.

### Security and integration
- Added migration 009 with affected-row-verified MariaDB procedures for all Phase 2 financial and lifecycle mutations.
- Added Phase 2 schema/procedure startup verification.
- Added configuration-aware module filtering so disabled systems disappear from the tablet and authorization layer.
- Corrected diplomacy directory tier derivation and front-business UI limits.
- Closed the earlier tablet-host spoof, retention date serialization, and global creation-mode policy gaps in the consolidated Phase 2 build.
- Member removal now cleans crew leadership atomically; enterprise disband is blocked while proposed or active war escrow remains unresolved.

## 1.0.0 — Complete Core MVP

### Enterprise core
- Added dual LB Tablet and standalone access with server-issued sessions and server-side item checks.
- Added configurable enterprise types, module restrictions, ranks, granular permissions, ownership transfer, leave/disband, and admin restoration.
- Added consent-based invitations and database-enforced one-enterprise/founding participation.
- Added public street-gang founding requiring eight accepted supporters.
- Added 12-slot free plans and idempotent Tebex slot grants/refunds.
- Added five-member monthly retention, day-21 warning, grace recovery, and soft disband.

### Management and conflict
- Added treasury, transactions, XP/levels, audit log read model, enterprise storage, turfs, strategic territories, contests, cooldowns, and admin builders.

### Criminal operations
- Added configurable labs/workshops, production queues, ingredients, output quality, and traceable batch metadata.
- Added higher-tier wholesale listings, atomic treasury settlement, buyer deliveries, seller returns, and delivery claims.
- Enforced street-gang finished-drug purchases from approved higher-tier suppliers in the CEN marketplace.
- Added turf-aware street distribution, dirty-money payout, XP, heat, and cooldowns.
- Added treasury-funded dead-drop and airdrop shipments with timed pickup locations.
- Added opt-in crooked-officer offers, police-job validation, fees, trust, exposure, heat reduction, and audit logging.
- Added enterprise heat and hourly decay.

### Security
- Added scoped sorted locks, queue limits, lock timeouts, source-generation tokens, request windows, cooldowns, payload limits, schema security stops, and server-authoritative authorization.
- Added atomic MariaDB procedures for invitations, creation, treasury, market purchases, shipments, and corruption payments.
- Removed stable player identifiers and server IDs from NUI/LB Tablet read models.

### Database
- Added migrations 006 and 007.
- Added facilities, production, market, delivery, shipment, corruption, treasury, XP, zones, contests, and heat schema.
