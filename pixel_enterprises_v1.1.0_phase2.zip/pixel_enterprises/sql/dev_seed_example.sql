-- DEVELOPMENT ONLY. Replace the sample license before running.
START TRANSACTION;

INSERT INTO cen_enterprises (name, slug, enterprise_type)
VALUES ('Southside Test Crew', 'southside-test-crew', 'street_gang');
SET @enterprise_id = LAST_INSERT_ID();

INSERT INTO cen_ranks (enterprise_id, name, priority, permissions, is_default, is_protected)
VALUES
(@enterprise_id, 'Recruit', 10, JSON_ARRAY('enterprise.view'), 1, 1),
(@enterprise_id, 'Shot Caller', 800, JSON_ARRAY(
  'enterprise.view',
  'members.invite',
  'members.remove',
  'members.assign_rank',
  'ranks.manage',
  'treasury.deposit',
  'logs.view',
  'wholesale.buy',
  'turfs.contest'
), 0, 1);
SELECT id INTO @leader_rank_id FROM cen_ranks WHERE enterprise_id = @enterprise_id AND name = 'Shot Caller' LIMIT 1;

INSERT INTO cen_members (enterprise_id, rank_id, player_identifier, display_name)
VALUES (@enterprise_id, @leader_rank_id, 'license:REPLACE_ME', 'Development Owner');
SET @owner_member_id = LAST_INSERT_ID();

UPDATE cen_enterprises SET owner_member_id = @owner_member_id WHERE id = @enterprise_id;
COMMIT;
