CREATE TABLE IF NOT EXISTS `cen_enterprises` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(80) NOT NULL,
  `slug` VARCHAR(80) NOT NULL,
  `enterprise_type` VARCHAR(40) NOT NULL,
  `level` INT UNSIGNED NOT NULL DEFAULT 1,
  `xp` BIGINT UNSIGNED NOT NULL DEFAULT 0,
  `treasury_balance` BIGINT NOT NULL DEFAULT 0,
  `creation_plan` VARCHAR(20) NOT NULL DEFAULT 'admin',
  `base_member_limit` SMALLINT UNSIGNED NOT NULL DEFAULT 12,
  `retention_required` TINYINT(1) NOT NULL DEFAULT 0,
  `retention_status` VARCHAR(24) NOT NULL DEFAULT 'exempt',
  `retention_warning_cycle` DATE NULL,
  `retention_failure_cycle` DATE NULL,
  `disband_scheduled_at` DATETIME NULL,
  `disbanded_at` DATETIME NULL,
  `owner_member_id` BIGINT UNSIGNED NULL,
  `status` ENUM('active','suspended','disbanded') NOT NULL DEFAULT 'active',
  `metadata` JSON NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cen_enterprise_slug` (`slug`),
  KEY `idx_cen_enterprise_type_status` (`enterprise_type`, `status`),
  KEY `idx_cen_enterprise_owner` (`owner_member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_ranks` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `enterprise_id` BIGINT UNSIGNED NOT NULL,
  `name` VARCHAR(60) NOT NULL,
  `priority` INT NOT NULL DEFAULT 0,
  `permissions` JSON NOT NULL,
  `is_default` TINYINT(1) NOT NULL DEFAULT 0,
  `is_protected` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cen_rank_name` (`enterprise_id`, `name`),
  KEY `idx_cen_rank_enterprise_priority` (`enterprise_id`, `priority`),
  CONSTRAINT `fk_cen_rank_enterprise` FOREIGN KEY (`enterprise_id`) REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_members` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `enterprise_id` BIGINT UNSIGNED NOT NULL,
  `rank_id` BIGINT UNSIGNED NOT NULL,
  `player_identifier` VARCHAR(80) NOT NULL,
  `display_name` VARCHAR(80) NOT NULL DEFAULT 'Unknown',
  `status` ENUM('active','suspended','removed') NOT NULL DEFAULT 'active',
  `individual_xp` BIGINT UNSIGNED NOT NULL DEFAULT 0,
  `joined_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cen_member_player` (`player_identifier`),
  KEY `idx_cen_member_enterprise_status` (`enterprise_id`, `status`),
  KEY `idx_cen_member_rank` (`rank_id`),
  CONSTRAINT `fk_cen_member_enterprise` FOREIGN KEY (`enterprise_id`) REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_member_rank` FOREIGN KEY (`rank_id`) REFERENCES `cen_ranks` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_membership_invites` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `enterprise_id` BIGINT UNSIGNED NOT NULL,
  `rank_id` BIGINT UNSIGNED NOT NULL,
  `invited_identifier` VARCHAR(80) NOT NULL,
  `invited_display_name` VARCHAR(80) NOT NULL DEFAULT 'Unknown',
  `invited_by_member_id` BIGINT UNSIGNED NULL,
  `status` ENUM('pending','accepted','declined','expired','cancelled') NOT NULL DEFAULT 'pending',
  `expires_at` DATETIME NOT NULL,
  `responded_at` DATETIME NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cen_membership_invitee_status` (`invited_identifier`, `status`, `expires_at`),
  KEY `idx_cen_membership_enterprise_status` (`enterprise_id`, `status`, `expires_at`),
  CONSTRAINT `fk_cen_membership_invite_enterprise` FOREIGN KEY (`enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_membership_invite_rank` FOREIGN KEY (`rank_id`)
    REFERENCES `cen_ranks` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_membership_invite_inviter` FOREIGN KEY (`invited_by_member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_audit_logs` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `enterprise_id` BIGINT UNSIGNED NULL,
  `actor_identifier` VARCHAR(80) NULL,
  `event_name` VARCHAR(80) NOT NULL,
  `payload` JSON NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cen_audit_enterprise_time` (`enterprise_id`, `created_at`),
  KEY `idx_cen_audit_event_time` (`event_name`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `cen_founding_proposals` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `founder_identifier` VARCHAR(80) NOT NULL,
  `founder_display_name` VARCHAR(80) NOT NULL,
  `name` VARCHAR(80) NOT NULL,
  `slug` VARCHAR(80) NOT NULL,
  `enterprise_type` VARCHAR(40) NOT NULL,
  `creation_plan` VARCHAR(20) NOT NULL DEFAULT 'free',
  `required_acceptances` SMALLINT UNSIGNED NOT NULL DEFAULT 8,
  `status` VARCHAR(24) NOT NULL DEFAULT 'pending',
  `finalized_enterprise_id` BIGINT UNSIGNED NULL,
  `expires_at` DATETIME NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cen_founding_slug` (`slug`),
  KEY `idx_cen_founding_founder_status` (`founder_identifier`, `status`),
  KEY `idx_cen_founding_expiry` (`status`, `expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_founding_invites` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `proposal_id` BIGINT UNSIGNED NOT NULL,
  `invited_identifier` VARCHAR(80) NOT NULL,
  `invited_display_name` VARCHAR(80) NOT NULL,
  `invited_by_identifier` VARCHAR(80) NOT NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'pending',
  `expires_at` DATETIME NOT NULL,
  `responded_at` DATETIME NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cen_founding_invite` (`proposal_id`, `invited_identifier`),
  KEY `idx_cen_founding_invitee_status` (`invited_identifier`, `status`),
  CONSTRAINT `fk_cen_founding_invite_proposal` FOREIGN KEY (`proposal_id`)
    REFERENCES `cen_founding_proposals` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_enterprise_entitlements` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `enterprise_id` BIGINT UNSIGNED NOT NULL,
  `entitlement_type` VARCHAR(40) NOT NULL,
  `provider` VARCHAR(30) NOT NULL,
  `package_key` VARCHAR(80) NOT NULL,
  `grant_key` VARCHAR(128) NOT NULL,
  `purchaser_identifier` VARCHAR(100) NULL,
  `quantity` INT NOT NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'active',
  `metadata` JSON NULL,
  `expires_at` DATETIME NULL,
  `revoked_at` DATETIME NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cen_entitlement_grant` (`grant_key`),
  KEY `idx_cen_entitlement_enterprise` (`enterprise_id`, `entitlement_type`, `status`),
  CONSTRAINT `fk_cen_entitlement_enterprise` FOREIGN KEY (`enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_member_activity` (
  `enterprise_id` BIGINT UNSIGNED NOT NULL,
  `member_id` BIGINT UNSIGNED NOT NULL,
  `activity_cycle` DATE NOT NULL,
  `active_minutes` INT UNSIGNED NOT NULL DEFAULT 0,
  `actions_count` INT UNSIGNED NOT NULL DEFAULT 0,
  `last_seen_at` DATETIME NULL,
  PRIMARY KEY (`enterprise_id`, `member_id`, `activity_cycle`),
  KEY `idx_cen_activity_cycle_minutes` (`enterprise_id`, `activity_cycle`, `active_minutes`),
  CONSTRAINT `fk_cen_activity_enterprise` FOREIGN KEY (`enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_activity_member` FOREIGN KEY (`member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Upgrade v0.3.1 to v0.3.2.
-- Adds database-enforced founding participation and atomic procedures for
-- membership acceptance and enterprise creation/finalization.
-- Back up the database before running this migration.

CREATE TABLE IF NOT EXISTS `cen_founding_participants` (
  `identifier` VARCHAR(80) NOT NULL,
  `proposal_id` BIGINT UNSIGNED NOT NULL,
  `role` ENUM('founder','supporter') NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`identifier`),
  KEY `idx_cen_founding_participant_proposal` (`proposal_id`, `role`),
  CONSTRAINT `fk_cen_founding_participant_proposal` FOREIGN KEY (`proposal_id`)
    REFERENCES `cen_founding_proposals` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Rebuild participation rows for non-finalized, non-expired proposals. A server
-- startup check will refuse to run if pre-existing data contains conflicting
-- participation that cannot be represented by the unique identifier key.
DELETE fp FROM `cen_founding_participants` fp
LEFT JOIN `cen_founding_proposals` p ON p.id = fp.proposal_id
WHERE p.id IS NULL OR p.status NOT IN ('pending','ready','awaiting_approval','finalizing')
   OR p.expires_at <= UTC_TIMESTAMP();

INSERT IGNORE INTO `cen_founding_participants` (`identifier`, `proposal_id`, `role`)
SELECT p.founder_identifier, p.id, 'founder'
FROM `cen_founding_proposals` p
WHERE p.status IN ('pending','ready','awaiting_approval','finalizing')
  AND p.expires_at > UTC_TIMESTAMP();

INSERT IGNORE INTO `cen_founding_participants` (`identifier`, `proposal_id`, `role`)
SELECT i.invited_identifier, i.proposal_id, 'supporter'
FROM `cen_founding_invites` i
JOIN `cen_founding_proposals` p ON p.id = i.proposal_id
WHERE i.status = 'accepted'
  AND p.status IN ('pending','ready','awaiting_approval','finalizing')
  AND p.expires_at > UTC_TIMESTAMP();

DROP PROCEDURE IF EXISTS `cen_accept_membership_invite`;
DROP PROCEDURE IF EXISTS `cen_create_founding_proposal`;
DROP PROCEDURE IF EXISTS `cen_accept_founding_invite`;
DROP PROCEDURE IF EXISTS `cen_cancel_founding_proposal`;
DROP PROCEDURE IF EXISTS `cen_create_enterprise_direct`;
DROP PROCEDURE IF EXISTS `cen_finalize_founding_proposal`;

DELIMITER //

CREATE PROCEDURE `cen_accept_membership_invite`(
  IN p_invite_id BIGINT UNSIGNED,
  IN p_identifier VARCHAR(80),
  IN p_display_name VARCHAR(80),
  IN p_absolute_limit INT
)
proc: BEGIN
  DECLARE v_enterprise_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_rank_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_invite_status VARCHAR(20) DEFAULT NULL;
  DECLARE v_expires_at DATETIME DEFAULT NULL;
  DECLARE v_enterprise_status VARCHAR(20) DEFAULT NULL;
  DECLARE v_base_limit INT DEFAULT 0;
  DECLARE v_extra_slots INT DEFAULT 0;
  DECLARE v_current_count INT DEFAULT 0;
  DECLARE v_member_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_member_status VARCHAR(20) DEFAULT NULL;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE v_affected INT DEFAULT 0;

  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS success, 'database_unavailable' AS errorCode, NULL AS enterpriseId;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;

  SET v_not_found = 0;
  SELECT enterprise_id, rank_id, status, expires_at
    INTO v_enterprise_id, v_rank_id, v_invite_status, v_expires_at
  FROM cen_membership_invites
  WHERE id = p_invite_id AND invited_identifier = p_identifier
  FOR UPDATE;

  IF v_not_found = 1 OR v_enterprise_id IS NULL THEN
    ROLLBACK;
    SELECT 0 AS success, 'membership_invite_not_found' AS errorCode, NULL AS enterpriseId;
    LEAVE proc;
  END IF;

  IF v_invite_status <> 'pending' OR v_expires_at <= UTC_TIMESTAMP() THEN
    ROLLBACK;
    SELECT 0 AS success, 'membership_invite_expired' AS errorCode, NULL AS enterpriseId;
    LEAVE proc;
  END IF;

  SET v_not_found = 0;
  SELECT status, base_member_limit
    INTO v_enterprise_status, v_base_limit
  FROM cen_enterprises
  WHERE id = v_enterprise_id
  FOR UPDATE;

  IF v_not_found = 1 OR v_enterprise_status <> 'active' THEN
    ROLLBACK;
    SELECT 0 AS success, 'invalid_enterprise' AS errorCode, NULL AS enterpriseId;
    LEAVE proc;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM cen_ranks
    WHERE id = v_rank_id AND enterprise_id = v_enterprise_id
  ) THEN
    ROLLBACK;
    SELECT 0 AS success, 'invalid_rank' AS errorCode, NULL AS enterpriseId;
    LEAVE proc;
  END IF;

  IF EXISTS (
    SELECT 1 FROM cen_founding_participants fp
    JOIN cen_founding_proposals p ON p.id = fp.proposal_id
    WHERE fp.identifier = p_identifier
      AND p.status IN ('pending','ready','awaiting_approval','finalizing')
      AND p.expires_at > UTC_TIMESTAMP()
  ) THEN
    ROLLBACK;
    SELECT 0 AS success, 'already_supporting_proposal' AS errorCode, NULL AS enterpriseId;
    LEAVE proc;
  END IF;

  SET v_not_found = 0;
  SET v_member_id = NULL;
  SET v_member_status = NULL;
  SELECT id, status INTO v_member_id, v_member_status
  FROM cen_members
  WHERE player_identifier = p_identifier
  LIMIT 1
  FOR UPDATE;
  SET v_not_found = 0;

  IF v_member_id IS NOT NULL AND v_member_status <> 'removed' THEN
    ROLLBACK;
    SELECT 0 AS success, 'target_already_member' AS errorCode, NULL AS enterpriseId;
    LEAVE proc;
  END IF;

  SELECT COUNT(*) INTO v_current_count
  FROM cen_members
  WHERE enterprise_id = v_enterprise_id AND status = 'active';

  SELECT COALESCE(SUM(quantity), 0) INTO v_extra_slots
  FROM cen_enterprise_entitlements
  WHERE enterprise_id = v_enterprise_id
    AND entitlement_type = 'member_slots'
    AND status = 'active'
    AND (expires_at IS NULL OR expires_at > UTC_TIMESTAMP());

  IF v_current_count >= LEAST(v_base_limit + v_extra_slots, p_absolute_limit) THEN
    ROLLBACK;
    SELECT 0 AS success, 'member_limit_reached' AS errorCode, v_enterprise_id AS enterpriseId;
    LEAVE proc;
  END IF;

  IF v_member_id IS NULL THEN
    INSERT INTO cen_members
      (enterprise_id, rank_id, player_identifier, display_name, status, individual_xp, joined_at, updated_at)
    VALUES
      (v_enterprise_id, v_rank_id, p_identifier, p_display_name, 'active', 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);
  ELSE
    UPDATE cen_members
    SET enterprise_id = v_enterprise_id,
        rank_id = v_rank_id,
        display_name = p_display_name,
        status = 'active',
        individual_xp = 0,
        joined_at = CURRENT_TIMESTAMP,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = v_member_id AND status = 'removed';
    SET v_affected = ROW_COUNT();
    IF v_affected <> 1 THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'member_reactivation_failed';
    END IF;
  END IF;

  UPDATE cen_membership_invites
  SET status = 'accepted', responded_at = UTC_TIMESTAMP()
  WHERE id = p_invite_id
    AND invited_identifier = p_identifier
    AND status = 'pending'
    AND expires_at > UTC_TIMESTAMP();
  SET v_affected = ROW_COUNT();
  IF v_affected <> 1 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'invite_accept_guard_failed';
  END IF;

  UPDATE cen_membership_invites
  SET status = 'cancelled', responded_at = UTC_TIMESTAMP()
  WHERE invited_identifier = p_identifier
    AND id <> p_invite_id
    AND status = 'pending';

  COMMIT;
  SELECT 1 AS success, NULL AS errorCode, v_enterprise_id AS enterpriseId;
END//

CREATE PROCEDURE `cen_create_founding_proposal`(
  IN p_founder_identifier VARCHAR(80),
  IN p_founder_display_name VARCHAR(80),
  IN p_name VARCHAR(80),
  IN p_slug VARCHAR(80),
  IN p_enterprise_type VARCHAR(40),
  IN p_creation_plan VARCHAR(20),
  IN p_required_acceptances INT,
  IN p_expiry_hours INT
)
proc: BEGIN
  DECLARE v_proposal_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS success, 'conflict' AS errorCode, NULL AS proposalId;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;

  IF EXISTS (
    SELECT 1 FROM cen_members
    WHERE player_identifier = p_founder_identifier AND status IN ('active','suspended')
  ) OR EXISTS (
    SELECT 1 FROM cen_founding_participants fp
      JOIN cen_founding_proposals active_p ON active_p.id = fp.proposal_id
      WHERE fp.identifier = p_founder_identifier
        AND active_p.status IN ('pending','ready','awaiting_approval','finalizing')
        AND active_p.expires_at > UTC_TIMESTAMP()
  ) THEN
    ROLLBACK;
    SELECT 0 AS success, 'already_has_proposal' AS errorCode, NULL AS proposalId;
    LEAVE proc;
  END IF;

  INSERT INTO cen_founding_proposals
    (founder_identifier, founder_display_name, name, slug, enterprise_type,
     creation_plan, required_acceptances, status, expires_at)
  VALUES
    (p_founder_identifier, p_founder_display_name, p_name, p_slug, p_enterprise_type,
     p_creation_plan, p_required_acceptances, 'pending',
     DATE_ADD(UTC_TIMESTAMP(), INTERVAL p_expiry_hours HOUR));
  SET v_proposal_id = LAST_INSERT_ID();

  INSERT INTO cen_founding_participants (identifier, proposal_id, role)
  VALUES (p_founder_identifier, v_proposal_id, 'founder');

  COMMIT;
  SELECT 1 AS success, NULL AS errorCode, v_proposal_id AS proposalId;
END//

CREATE PROCEDURE `cen_accept_founding_invite`(
  IN p_invite_id BIGINT UNSIGNED,
  IN p_identifier VARCHAR(80)
)
proc: BEGIN
  DECLARE v_proposal_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_invite_status VARCHAR(20) DEFAULT NULL;
  DECLARE v_invite_expiry DATETIME DEFAULT NULL;
  DECLARE v_proposal_status VARCHAR(24) DEFAULT NULL;
  DECLARE v_proposal_expiry DATETIME DEFAULT NULL;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE v_affected INT DEFAULT 0;

  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS success, 'conflict' AS errorCode, NULL AS proposalId;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;

  SET v_not_found = 0;
  SELECT proposal_id, status, expires_at
    INTO v_proposal_id, v_invite_status, v_invite_expiry
  FROM cen_founding_invites
  WHERE id = p_invite_id AND invited_identifier = p_identifier
  FOR UPDATE;

  IF v_not_found = 1 OR v_proposal_id IS NULL THEN
    ROLLBACK;
    SELECT 0 AS success, 'invite_not_found' AS errorCode, NULL AS proposalId;
    LEAVE proc;
  END IF;

  SET v_not_found = 0;
  SELECT status, expires_at INTO v_proposal_status, v_proposal_expiry
  FROM cen_founding_proposals
  WHERE id = v_proposal_id
  FOR UPDATE;

  IF v_not_found = 1
     OR v_invite_status <> 'pending'
     OR v_invite_expiry <= UTC_TIMESTAMP()
     OR v_proposal_status NOT IN ('pending','ready')
     OR v_proposal_expiry <= UTC_TIMESTAMP() THEN
    ROLLBACK;
    SELECT 0 AS success, 'invite_already_responded' AS errorCode, v_proposal_id AS proposalId;
    LEAVE proc;
  END IF;

  IF EXISTS (
    SELECT 1 FROM cen_members
    WHERE player_identifier = p_identifier AND status IN ('active','suspended')
  ) THEN
    ROLLBACK;
    SELECT 0 AS success, 'target_already_member' AS errorCode, v_proposal_id AS proposalId;
    LEAVE proc;
  END IF;

  IF EXISTS (SELECT 1 FROM cen_founding_participants WHERE identifier = p_identifier) THEN
    ROLLBACK;
    SELECT 0 AS success, 'already_supporting_proposal' AS errorCode, v_proposal_id AS proposalId;
    LEAVE proc;
  END IF;

  INSERT INTO cen_founding_participants (identifier, proposal_id, role)
  VALUES (p_identifier, v_proposal_id, 'supporter');

  UPDATE cen_founding_invites
  SET status = 'accepted', responded_at = UTC_TIMESTAMP()
  WHERE id = p_invite_id AND invited_identifier = p_identifier
    AND status = 'pending' AND expires_at > UTC_TIMESTAMP();
  SET v_affected = ROW_COUNT();
  IF v_affected <> 1 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'founding_invite_accept_guard_failed';
  END IF;

  COMMIT;
  SELECT 1 AS success, NULL AS errorCode, v_proposal_id AS proposalId;
END//

CREATE PROCEDURE `cen_cancel_founding_proposal`(
  IN p_proposal_id BIGINT UNSIGNED,
  IN p_founder_identifier VARCHAR(80)
)
proc: BEGIN
  DECLARE v_affected INT DEFAULT 0;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS success, 'database_unavailable' AS errorCode;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;
  UPDATE cen_founding_proposals
  SET status = 'cancelled', updated_at = UTC_TIMESTAMP()
  WHERE id = p_proposal_id AND founder_identifier = p_founder_identifier
    AND status IN ('pending','ready','awaiting_approval');
  SET v_affected = ROW_COUNT();
  IF v_affected <> 1 THEN
    ROLLBACK;
    SELECT 0 AS success, 'proposal_not_found' AS errorCode;
    LEAVE proc;
  END IF;

  DELETE FROM cen_founding_participants WHERE proposal_id = p_proposal_id;
  COMMIT;
  SELECT 1 AS success, NULL AS errorCode;
END//

CREATE PROCEDURE `cen_create_enterprise_direct`(
  IN p_name VARCHAR(80),
  IN p_slug VARCHAR(80),
  IN p_enterprise_type VARCHAR(40),
  IN p_creation_plan VARCHAR(20),
  IN p_base_member_limit INT,
  IN p_retention_required TINYINT,
  IN p_owner_identifier VARCHAR(80),
  IN p_owner_display_name VARCHAR(80)
)
proc: BEGIN
  DECLARE v_enterprise_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_owner_rank_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_owner_member_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_existing_member_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_existing_status VARCHAR(20) DEFAULT NULL;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE v_affected INT DEFAULT 0;

  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS success, 'conflict' AS errorCode, NULL AS enterpriseId;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;

  SET v_not_found = 0;
  SELECT id, status INTO v_existing_member_id, v_existing_status
  FROM cen_members WHERE player_identifier = p_owner_identifier
  LIMIT 1 FOR UPDATE;
  SET v_not_found = 0;

  IF v_existing_member_id IS NOT NULL AND v_existing_status <> 'removed' THEN
    ROLLBACK;
    SELECT 0 AS success, 'target_already_member' AS errorCode, NULL AS enterpriseId;
    LEAVE proc;
  END IF;

  IF EXISTS (SELECT 1 FROM cen_founding_participants fp
      JOIN cen_founding_proposals active_p ON active_p.id = fp.proposal_id
      WHERE fp.identifier = p_owner_identifier
        AND active_p.status IN ('pending','ready','awaiting_approval','finalizing')
        AND active_p.expires_at > UTC_TIMESTAMP()) THEN
    ROLLBACK;
    SELECT 0 AS success, 'already_has_proposal' AS errorCode, NULL AS enterpriseId;
    LEAVE proc;
  END IF;

  INSERT INTO cen_enterprises
    (name, slug, enterprise_type, creation_plan, base_member_limit,
     retention_required, retention_status, status)
  VALUES
    (p_name, p_slug, p_enterprise_type, p_creation_plan, p_base_member_limit,
     p_retention_required, IF(p_retention_required = 1, 'healthy', 'exempt'), 'active');
  SET v_enterprise_id = LAST_INSERT_ID();

  INSERT INTO cen_ranks
    (enterprise_id, name, priority, permissions, is_default, is_protected)
  VALUES (v_enterprise_id, 'Owner', 1000, '[]', 0, 1);
  SET v_owner_rank_id = LAST_INSERT_ID();

  INSERT INTO cen_ranks
    (enterprise_id, name, priority, permissions, is_default, is_protected)
  VALUES (v_enterprise_id, 'Member', 10, '["enterprise.view","storage.access","progression.view"]', 1, 1);

  IF v_existing_member_id IS NULL THEN
    INSERT INTO cen_members
      (enterprise_id, rank_id, player_identifier, display_name, status, individual_xp, joined_at, updated_at)
    VALUES
      (v_enterprise_id, v_owner_rank_id, p_owner_identifier, p_owner_display_name,
       'active', 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);
    SET v_owner_member_id = LAST_INSERT_ID();
  ELSE
    UPDATE cen_members
    SET enterprise_id = v_enterprise_id,
        rank_id = v_owner_rank_id,
        display_name = p_owner_display_name,
        status = 'active',
        individual_xp = 0,
        joined_at = CURRENT_TIMESTAMP,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = v_existing_member_id AND status = 'removed';
    SET v_affected = ROW_COUNT();
    IF v_affected <> 1 THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'owner_reactivation_failed';
    END IF;
    SET v_owner_member_id = v_existing_member_id;
  END IF;

  UPDATE cen_enterprises SET owner_member_id = v_owner_member_id
  WHERE id = v_enterprise_id;
  IF ROW_COUNT() <> 1 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'owner_assignment_failed';
  END IF;

  COMMIT;
  SELECT 1 AS success, NULL AS errorCode, v_enterprise_id AS enterpriseId;
END//

CREATE PROCEDURE `cen_finalize_founding_proposal`(
  IN p_proposal_id BIGINT UNSIGNED,
  IN p_absolute_member_limit INT,
  IN p_base_member_limit INT,
  IN p_retention_required TINYINT
)
proc: BEGIN
  DECLARE v_founder_identifier VARCHAR(80) DEFAULT NULL;
  DECLARE v_founder_display_name VARCHAR(80) DEFAULT NULL;
  DECLARE v_name VARCHAR(80) DEFAULT NULL;
  DECLARE v_slug VARCHAR(80) DEFAULT NULL;
  DECLARE v_enterprise_type VARCHAR(40) DEFAULT NULL;
  DECLARE v_creation_plan VARCHAR(20) DEFAULT NULL;
  DECLARE v_required INT DEFAULT 0;
  DECLARE v_status VARCHAR(24) DEFAULT NULL;
  DECLARE v_expires_at DATETIME DEFAULT NULL;
  DECLARE v_accepted_count INT DEFAULT 0;
  DECLARE v_participant_count INT DEFAULT 0;
  DECLARE v_enterprise_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_owner_rank_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_member_rank_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_owner_member_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_existing_owner_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_existing_owner_status VARCHAR(20) DEFAULT NULL;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE v_affected INT DEFAULT 0;

  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS success, 'conflict' AS errorCode, NULL AS enterpriseId;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;

  SET v_not_found = 0;
  SELECT founder_identifier, founder_display_name, name, slug, enterprise_type,
         creation_plan, required_acceptances, status, expires_at
    INTO v_founder_identifier, v_founder_display_name, v_name, v_slug, v_enterprise_type,
         v_creation_plan, v_required, v_status, v_expires_at
  FROM cen_founding_proposals
  WHERE id = p_proposal_id
  FOR UPDATE;

  IF v_not_found = 1 OR v_founder_identifier IS NULL THEN
    ROLLBACK;
    SELECT 0 AS success, 'proposal_not_found' AS errorCode, NULL AS enterpriseId;
    LEAVE proc;
  END IF;

  IF v_status NOT IN ('pending','ready','awaiting_approval','finalizing')
     OR v_expires_at <= UTC_TIMESTAMP() THEN
    ROLLBACK;
    SELECT 0 AS success, 'proposal_not_ready' AS errorCode, NULL AS enterpriseId;
    LEAVE proc;
  END IF;

  SELECT COUNT(*) INTO v_accepted_count
  FROM cen_founding_invites
  WHERE proposal_id = p_proposal_id AND status = 'accepted';

  SELECT COUNT(*) INTO v_participant_count
  FROM cen_founding_participants
  WHERE proposal_id = p_proposal_id;

  IF v_accepted_count < v_required OR v_participant_count <> v_accepted_count + 1 THEN
    ROLLBACK;
    SELECT 0 AS success, 'founding_acceptances_required' AS errorCode, NULL AS enterpriseId;
    LEAVE proc;
  END IF;

  IF v_participant_count > LEAST(p_base_member_limit, p_absolute_member_limit) THEN
    ROLLBACK;
    SELECT 0 AS success, 'member_limit_reached' AS errorCode, NULL AS enterpriseId;
    LEAVE proc;
  END IF;

  IF EXISTS (
    SELECT 1
    FROM cen_founding_participants fp
    JOIN cen_members m ON m.player_identifier = fp.identifier
    WHERE fp.proposal_id = p_proposal_id AND m.status IN ('active','suspended')
  ) THEN
    ROLLBACK;
    SELECT 0 AS success, 'target_already_member' AS errorCode, NULL AS enterpriseId;
    LEAVE proc;
  END IF;

  INSERT INTO cen_enterprises
    (name, slug, enterprise_type, creation_plan, base_member_limit,
     retention_required, retention_status, status)
  VALUES
    (v_name, v_slug, v_enterprise_type, v_creation_plan, p_base_member_limit,
     p_retention_required, IF(p_retention_required = 1, 'healthy', 'exempt'), 'active');
  SET v_enterprise_id = LAST_INSERT_ID();

  INSERT INTO cen_ranks
    (enterprise_id, name, priority, permissions, is_default, is_protected)
  VALUES (v_enterprise_id, 'Owner', 1000, '[]', 0, 1);
  SET v_owner_rank_id = LAST_INSERT_ID();

  INSERT INTO cen_ranks
    (enterprise_id, name, priority, permissions, is_default, is_protected)
  VALUES (v_enterprise_id, 'Member', 10, '["enterprise.view","storage.access","progression.view"]', 1, 1);
  SET v_member_rank_id = LAST_INSERT_ID();

  SET v_not_found = 0;
  SELECT id, status INTO v_existing_owner_id, v_existing_owner_status
  FROM cen_members WHERE player_identifier = v_founder_identifier
  LIMIT 1 FOR UPDATE;
  SET v_not_found = 0;

  IF v_existing_owner_id IS NULL THEN
    INSERT INTO cen_members
      (enterprise_id, rank_id, player_identifier, display_name, status, individual_xp, joined_at, updated_at)
    VALUES
      (v_enterprise_id, v_owner_rank_id, v_founder_identifier, v_founder_display_name,
       'active', 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);
    SET v_owner_member_id = LAST_INSERT_ID();
  ELSE
    UPDATE cen_members
    SET enterprise_id = v_enterprise_id,
        rank_id = v_owner_rank_id,
        display_name = v_founder_display_name,
        status = 'active',
        individual_xp = 0,
        joined_at = CURRENT_TIMESTAMP,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = v_existing_owner_id AND status = 'removed';
    SET v_affected = ROW_COUNT();
    IF v_affected <> 1 THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'founder_reactivation_failed';
    END IF;
    SET v_owner_member_id = v_existing_owner_id;
  END IF;

  UPDATE cen_members m
  JOIN cen_founding_participants fp
    ON fp.identifier = m.player_identifier
   AND fp.proposal_id = p_proposal_id
   AND fp.role = 'supporter'
  JOIN cen_founding_invites fi
    ON fi.proposal_id = p_proposal_id
   AND fi.invited_identifier = fp.identifier
   AND fi.status = 'accepted'
  SET m.enterprise_id = v_enterprise_id,
      m.rank_id = v_member_rank_id,
      m.display_name = fi.invited_display_name,
      m.status = 'active',
      m.individual_xp = 0,
      m.joined_at = CURRENT_TIMESTAMP,
      m.updated_at = CURRENT_TIMESTAMP
  WHERE m.status = 'removed';

  INSERT INTO cen_members
    (enterprise_id, rank_id, player_identifier, display_name, status, individual_xp, joined_at, updated_at)
  SELECT v_enterprise_id, v_member_rank_id, fp.identifier, fi.invited_display_name,
         'active', 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
  FROM cen_founding_participants fp
  JOIN cen_founding_invites fi
    ON fi.proposal_id = fp.proposal_id
   AND fi.invited_identifier = fp.identifier
   AND fi.status = 'accepted'
  LEFT JOIN cen_members m ON m.player_identifier = fp.identifier
  WHERE fp.proposal_id = p_proposal_id
    AND fp.role = 'supporter'
    AND m.id IS NULL;

  UPDATE cen_enterprises SET owner_member_id = v_owner_member_id
  WHERE id = v_enterprise_id;
  IF ROW_COUNT() <> 1 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'owner_assignment_failed';
  END IF;

  UPDATE cen_founding_proposals
  SET status = 'finalized', finalized_enterprise_id = v_enterprise_id, updated_at = UTC_TIMESTAMP()
  WHERE id = p_proposal_id
    AND status IN ('pending','ready','awaiting_approval','finalizing');
  IF ROW_COUNT() <> 1 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'proposal_finalize_failed';
  END IF;

  DELETE FROM cen_founding_participants WHERE proposal_id = p_proposal_id;

  COMMIT;
  SELECT 1 AS success, NULL AS errorCode, v_enterprise_id AS enterpriseId;
END//

DELIMITER ;


-- BEGIN v0.5.0 CORE MVP OBJECTS
-- v0.5.0 Core MVP: treasury, progression, audit read model and zone control.
-- Apply after migrations 002-005. Back up the database first.

CREATE TABLE IF NOT EXISTS `cen_treasury_transactions` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `enterprise_id` BIGINT UNSIGNED NOT NULL,
  `actor_member_id` BIGINT UNSIGNED NULL,
  `transaction_type` VARCHAR(32) NOT NULL,
  `amount` BIGINT UNSIGNED NOT NULL,
  `balance_after` BIGINT NOT NULL,
  `note` VARCHAR(120) NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cen_treasury_enterprise_time` (`enterprise_id`, `created_at`),
  KEY `idx_cen_treasury_daily_withdraw` (`enterprise_id`, `transaction_type`, `created_at`),
  CONSTRAINT `fk_cen_treasury_enterprise` FOREIGN KEY (`enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_treasury_member` FOREIGN KEY (`actor_member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_xp_events` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `enterprise_id` BIGINT UNSIGNED NOT NULL,
  `actor_member_id` BIGINT UNSIGNED NULL,
  `amount` INT UNSIGNED NOT NULL,
  `reason` VARCHAR(80) NOT NULL,
  `metadata` JSON NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cen_xp_enterprise_time` (`enterprise_id`, `created_at`),
  CONSTRAINT `fk_cen_xp_enterprise` FOREIGN KEY (`enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_xp_member` FOREIGN KEY (`actor_member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_zones` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `zone_type` ENUM('turf','territory') NOT NULL,
  `name` VARCHAR(80) NOT NULL,
  `center_x` DOUBLE NOT NULL,
  `center_y` DOUBLE NOT NULL,
  `center_z` DOUBLE NOT NULL,
  `radius` DOUBLE NOT NULL DEFAULT 65,
  `owner_enterprise_id` BIGINT UNSIGNED NULL,
  `required_level` INT UNSIGNED NOT NULL DEFAULT 1,
  `capture_duration_seconds` INT UNSIGNED NOT NULL DEFAULT 900,
  `cooldown_seconds` INT UNSIGNED NOT NULL DEFAULT 3600,
  `cooldown_until` DATETIME NULL,
  `last_contested_at` DATETIME NULL,
  `status` ENUM('active','disabled') NOT NULL DEFAULT 'active',
  `metadata` JSON NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cen_zone_name` (`name`),
  KEY `idx_cen_zone_type_status` (`zone_type`, `status`),
  KEY `idx_cen_zone_owner` (`owner_enterprise_id`),
  CONSTRAINT `fk_cen_zone_owner` FOREIGN KEY (`owner_enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_zone_contests` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `zone_id` BIGINT UNSIGNED NOT NULL,
  `attacker_enterprise_id` BIGINT UNSIGNED NOT NULL,
  `defender_enterprise_id` BIGINT UNSIGNED NULL,
  `winner_enterprise_id` BIGINT UNSIGNED NULL,
  `created_by_member_id` BIGINT UNSIGNED NULL,
  `attacker_score` INT UNSIGNED NOT NULL DEFAULT 0,
  `defender_score` INT UNSIGNED NOT NULL DEFAULT 0,
  `status` ENUM('active','completed','cancelled') NOT NULL DEFAULT 'active',
  `starts_at` DATETIME NOT NULL,
  `ends_at` DATETIME NOT NULL,
  `completed_at` DATETIME NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cen_contest_zone_status` (`zone_id`, `status`, `ends_at`),
  KEY `idx_cen_contest_attacker` (`attacker_enterprise_id`, `status`),
  KEY `idx_cen_contest_defender` (`defender_enterprise_id`, `status`),
  CONSTRAINT `fk_cen_contest_zone` FOREIGN KEY (`zone_id`)
    REFERENCES `cen_zones` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_contest_attacker` FOREIGN KEY (`attacker_enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_contest_defender` FOREIGN KEY (`defender_enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_cen_contest_winner` FOREIGN KEY (`winner_enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_cen_contest_creator` FOREIGN KEY (`created_by_member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Existing protected default ranks receive only the safe baseline permissions.
UPDATE `cen_ranks`
SET permissions = JSON_ARRAY_APPEND(permissions, '$', 'storage.access')
WHERE is_default = 1 AND JSON_CONTAINS(permissions, JSON_QUOTE('storage.access')) = 0;

UPDATE `cen_ranks`
SET permissions = JSON_ARRAY_APPEND(permissions, '$', 'progression.view')
WHERE is_default = 1 AND JSON_CONTAINS(permissions, JSON_QUOTE('progression.view')) = 0;

DROP PROCEDURE IF EXISTS `cen_treasury_deposit`;
DROP PROCEDURE IF EXISTS `cen_treasury_withdraw`;

DELIMITER //

CREATE PROCEDURE `cen_treasury_deposit`(
  IN p_enterprise_id BIGINT UNSIGNED,
  IN p_member_id BIGINT UNSIGNED,
  IN p_amount BIGINT UNSIGNED,
  IN p_note VARCHAR(120),
  IN p_maximum_balance BIGINT
)
proc: BEGIN
  DECLARE v_balance BIGINT DEFAULT NULL;
  DECLARE v_status VARCHAR(20) DEFAULT NULL;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode, NULL AS balance;
  END;
  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;
  SELECT treasury_balance, status INTO v_balance, v_status
    FROM cen_enterprises WHERE id = p_enterprise_id FOR UPDATE;
  IF v_balance IS NULL OR v_status <> 'active' THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode, NULL AS balance; LEAVE proc;
  END IF;
  IF p_amount < 1 OR v_balance + p_amount > p_maximum_balance THEN
    ROLLBACK; SELECT 0 AS ok, 'treasury_limit' AS errorCode, v_balance AS balance; LEAVE proc;
  END IF;
  SET v_balance = v_balance + p_amount;
  UPDATE cen_enterprises SET treasury_balance = v_balance WHERE id = p_enterprise_id;
  INSERT INTO cen_treasury_transactions
    (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
  VALUES (p_enterprise_id, p_member_id, 'deposit', p_amount, v_balance, p_note);
  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode, v_balance AS balance;
END//

CREATE PROCEDURE `cen_treasury_withdraw`(
  IN p_enterprise_id BIGINT UNSIGNED,
  IN p_member_id BIGINT UNSIGNED,
  IN p_amount BIGINT UNSIGNED,
  IN p_note VARCHAR(120),
  IN p_daily_limit BIGINT
)
proc: BEGIN
  DECLARE v_balance BIGINT DEFAULT NULL;
  DECLARE v_status VARCHAR(20) DEFAULT NULL;
  DECLARE v_withdrawn_today BIGINT DEFAULT 0;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode, NULL AS balance;
  END;
  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;
  SELECT treasury_balance, status INTO v_balance, v_status
    FROM cen_enterprises WHERE id = p_enterprise_id FOR UPDATE;
  IF v_balance IS NULL OR v_status <> 'active' THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode, NULL AS balance; LEAVE proc;
  END IF;
  SELECT COALESCE(SUM(amount), 0) INTO v_withdrawn_today
    FROM cen_treasury_transactions
    WHERE enterprise_id = p_enterprise_id AND transaction_type = 'withdrawal'
      AND created_at >= UTC_DATE();
  IF p_amount < 1 OR v_balance < p_amount THEN
    ROLLBACK; SELECT 0 AS ok, 'insufficient_funds' AS errorCode, v_balance AS balance; LEAVE proc;
  END IF;
  IF p_daily_limit > 0 AND v_withdrawn_today + p_amount > p_daily_limit THEN
    ROLLBACK; SELECT 0 AS ok, 'treasury_limit' AS errorCode, v_balance AS balance; LEAVE proc;
  END IF;
  SET v_balance = v_balance - p_amount;
  UPDATE cen_enterprises SET treasury_balance = v_balance WHERE id = p_enterprise_id;
  INSERT INTO cen_treasury_transactions
    (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
  VALUES (p_enterprise_id, p_member_id, 'withdrawal', p_amount, v_balance, p_note);
  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode, v_balance AS balance;
END//

DELIMITER ;

-- END v0.5.0 CORE MVP OBJECTS


-- v1.0.0 Criminal Operations: facilities, production, wholesale market,
-- street distribution, shipments/airdrops, heat and opt-in corruption contacts.
-- Apply after migrations 002-006. Back up the database first.

ALTER TABLE `cen_enterprises`
  ADD COLUMN IF NOT EXISTS `heat` INT UNSIGNED NOT NULL DEFAULT 0 AFTER `treasury_balance`;

CREATE TABLE IF NOT EXISTS `cen_facilities` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `enterprise_id` BIGINT UNSIGNED NOT NULL,
  `facility_type` ENUM('lab','warehouse','front') NOT NULL,
  `subtype` VARCHAR(40) NOT NULL,
  `name` VARCHAR(80) NOT NULL,
  `center_x` DOUBLE NOT NULL,
  `center_y` DOUBLE NOT NULL,
  `center_z` DOUBLE NOT NULL,
  `radius` DOUBLE NOT NULL DEFAULT 8,
  `level` INT UNSIGNED NOT NULL DEFAULT 1,
  `status` ENUM('active','disabled','raided') NOT NULL DEFAULT 'active',
  `metadata` JSON NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cen_facility_enterprise_status` (`enterprise_id`, `status`),
  CONSTRAINT `fk_cen_facility_enterprise` FOREIGN KEY (`enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_production_jobs` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `facility_id` BIGINT UNSIGNED NOT NULL,
  `enterprise_id` BIGINT UNSIGNED NOT NULL,
  `started_by_member_id` BIGINT UNSIGNED NULL,
  `claimed_by_member_id` BIGINT UNSIGNED NULL,
  `recipe_key` VARCHAR(60) NOT NULL,
  `output_item` VARCHAR(80) NOT NULL,
  `output_count` INT UNSIGNED NOT NULL,
  `quality` TINYINT UNSIGNED NOT NULL DEFAULT 50,
  `batch_id` VARCHAR(40) NOT NULL,
  `status` ENUM('processing','ready','claiming','claimed','cancelled') NOT NULL DEFAULT 'processing',
  `starts_at` DATETIME NOT NULL,
  `ends_at` DATETIME NOT NULL,
  `claimed_at` DATETIME NULL,
  `metadata` JSON NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cen_production_batch` (`batch_id`),
  KEY `idx_cen_production_enterprise_status` (`enterprise_id`, `status`, `ends_at`),
  KEY `idx_cen_production_facility_status` (`facility_id`, `status`),
  CONSTRAINT `fk_cen_production_facility` FOREIGN KEY (`facility_id`)
    REFERENCES `cen_facilities` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_production_enterprise` FOREIGN KEY (`enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_production_started_member` FOREIGN KEY (`started_by_member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_cen_production_claimed_member` FOREIGN KEY (`claimed_by_member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_market_listings` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `seller_enterprise_id` BIGINT UNSIGNED NOT NULL,
  `created_by_member_id` BIGINT UNSIGNED NULL,
  `category` VARCHAR(32) NOT NULL,
  `item_name` VARCHAR(80) NOT NULL,
  `quantity_initial` INT UNSIGNED NOT NULL,
  `quantity_remaining` INT UNSIGNED NOT NULL,
  `unit_price` BIGINT UNSIGNED NOT NULL,
  `quality` TINYINT UNSIGNED NOT NULL DEFAULT 50,
  `batch_id` VARCHAR(40) NULL,
  `status` ENUM('active','sold','cancelled','expired') NOT NULL DEFAULT 'active',
  `metadata` JSON NULL,
  `expires_at` DATETIME NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cen_market_active` (`status`, `category`, `expires_at`),
  KEY `idx_cen_market_seller` (`seller_enterprise_id`, `status`),
  CONSTRAINT `fk_cen_market_seller` FOREIGN KEY (`seller_enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_market_creator` FOREIGN KEY (`created_by_member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_market_sales` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `listing_id` BIGINT UNSIGNED NOT NULL,
  `seller_enterprise_id` BIGINT UNSIGNED NOT NULL,
  `buyer_enterprise_id` BIGINT UNSIGNED NOT NULL,
  `buyer_member_id` BIGINT UNSIGNED NULL,
  `quantity` INT UNSIGNED NOT NULL,
  `total_price` BIGINT UNSIGNED NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cen_market_sale_buyer` (`buyer_enterprise_id`, `created_at`),
  KEY `idx_cen_market_sale_seller` (`seller_enterprise_id`, `created_at`),
  CONSTRAINT `fk_cen_market_sale_listing` FOREIGN KEY (`listing_id`)
    REFERENCES `cen_market_listings` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_cen_market_sale_seller` FOREIGN KEY (`seller_enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_market_sale_buyer` FOREIGN KEY (`buyer_enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_market_sale_member` FOREIGN KEY (`buyer_member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_market_deliveries` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `enterprise_id` BIGINT UNSIGNED NOT NULL,
  `source_type` ENUM('purchase','listing_return') NOT NULL,
  `source_id` BIGINT UNSIGNED NULL,
  `item_name` VARCHAR(80) NOT NULL,
  `quantity` INT UNSIGNED NOT NULL,
  `quality` TINYINT UNSIGNED NOT NULL DEFAULT 50,
  `batch_id` VARCHAR(40) NULL,
  `status` ENUM('pending','claiming','claimed') NOT NULL DEFAULT 'pending',
  `claimed_by_member_id` BIGINT UNSIGNED NULL,
  `metadata` JSON NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `claimed_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  KEY `idx_cen_market_delivery_enterprise` (`enterprise_id`, `status`, `created_at`),
  CONSTRAINT `fk_cen_market_delivery_enterprise` FOREIGN KEY (`enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_market_delivery_member` FOREIGN KEY (`claimed_by_member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_shipments` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `enterprise_id` BIGINT UNSIGNED NOT NULL,
  `requested_by_member_id` BIGINT UNSIGNED NULL,
  `claimed_by_member_id` BIGINT UNSIGNED NULL,
  `catalog_key` VARCHAR(60) NOT NULL,
  `delivery_type` ENUM('dead_drop','airdrop') NOT NULL,
  `item_name` VARCHAR(80) NOT NULL,
  `quantity` INT UNSIGNED NOT NULL,
  `cost` BIGINT UNSIGNED NOT NULL,
  `pickup_x` DOUBLE NOT NULL,
  `pickup_y` DOUBLE NOT NULL,
  `pickup_z` DOUBLE NOT NULL,
  `pickup_label` VARCHAR(100) NOT NULL,
  `status` ENUM('scheduled','ready','claiming','claimed','expired','cancelled') NOT NULL DEFAULT 'scheduled',
  `ready_at` DATETIME NOT NULL,
  `expires_at` DATETIME NOT NULL,
  `claimed_at` DATETIME NULL,
  `metadata` JSON NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cen_shipment_enterprise` (`enterprise_id`, `status`, `ready_at`),
  CONSTRAINT `fk_cen_shipment_enterprise` FOREIGN KEY (`enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_shipment_requester` FOREIGN KEY (`requested_by_member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_cen_shipment_claimer` FOREIGN KEY (`claimed_by_member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_corruption_offers` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `enterprise_id` BIGINT UNSIGNED NOT NULL,
  `created_by_member_id` BIGINT UNSIGNED NULL,
  `officer_identifier` VARCHAR(80) NOT NULL,
  `officer_display_name` VARCHAR(80) NOT NULL,
  `service_key` VARCHAR(60) NOT NULL,
  `fee` BIGINT UNSIGNED NOT NULL,
  `exposure` INT UNSIGNED NOT NULL DEFAULT 0,
  `status` ENUM('pending','accepted','declined','expired','completed','cancelled','failed') NOT NULL DEFAULT 'pending',
  `expires_at` DATETIME NOT NULL,
  `accepted_at` DATETIME NULL,
  `completed_at` DATETIME NULL,
  `metadata` JSON NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cen_corruption_officer` (`officer_identifier`, `status`, `expires_at`),
  KEY `idx_cen_corruption_enterprise` (`enterprise_id`, `status`, `created_at`),
  CONSTRAINT `fk_cen_corruption_enterprise` FOREIGN KEY (`enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_corruption_creator` FOREIGN KEY (`created_by_member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_corruption_contacts` (
  `enterprise_id` BIGINT UNSIGNED NOT NULL,
  `officer_identifier` VARCHAR(80) NOT NULL,
  `officer_display_name` VARCHAR(80) NOT NULL,
  `trust` INT UNSIGNED NOT NULL DEFAULT 0,
  `exposure` INT UNSIGNED NOT NULL DEFAULT 0,
  `total_paid` BIGINT UNSIGNED NOT NULL DEFAULT 0,
  `status` ENUM('active','compromised','blacklisted') NOT NULL DEFAULT 'active',
  `last_service_at` DATETIME NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`enterprise_id`, `officer_identifier`),
  CONSTRAINT `fk_cen_corruption_contact_enterprise` FOREIGN KEY (`enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP PROCEDURE IF EXISTS `cen_market_purchase`;
DROP PROCEDURE IF EXISTS `cen_request_shipment`;
DROP PROCEDURE IF EXISTS `cen_accept_corruption_offer`;

DELIMITER //

CREATE PROCEDURE `cen_market_purchase`(
  IN p_listing_id BIGINT UNSIGNED,
  IN p_buyer_enterprise_id BIGINT UNSIGNED,
  IN p_buyer_member_id BIGINT UNSIGNED,
  IN p_quantity INT UNSIGNED
)
proc: BEGIN
  DECLARE v_seller BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_item VARCHAR(80) DEFAULT NULL;
  DECLARE v_remaining INT UNSIGNED DEFAULT 0;
  DECLARE v_price BIGINT UNSIGNED DEFAULT 0;
  DECLARE v_quality TINYINT UNSIGNED DEFAULT 50;
  DECLARE v_batch VARCHAR(40) DEFAULT NULL;
  DECLARE v_total BIGINT UNSIGNED DEFAULT 0;
  DECLARE v_buyer_balance BIGINT DEFAULT NULL;
  DECLARE v_seller_balance BIGINT DEFAULT NULL;
  DECLARE v_delivery_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode, NULL AS deliveryId;
  END;
  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;
  SELECT seller_enterprise_id, item_name, quantity_remaining, unit_price, quality, batch_id
    INTO v_seller, v_item, v_remaining, v_price, v_quality, v_batch
    FROM cen_market_listings
    WHERE id = p_listing_id AND status = 'active' AND expires_at > UTC_TIMESTAMP()
    FOR UPDATE;
  IF v_seller IS NULL THEN
    ROLLBACK; SELECT 0 AS ok, 'listing_not_found' AS errorCode, NULL AS deliveryId; LEAVE proc;
  END IF;
  IF v_seller = p_buyer_enterprise_id OR p_quantity < 1 OR v_remaining < p_quantity THEN
    ROLLBACK; SELECT 0 AS ok, 'listing_not_allowed' AS errorCode, NULL AS deliveryId; LEAVE proc;
  END IF;
  SELECT treasury_balance INTO v_buyer_balance FROM cen_enterprises
    WHERE id = p_buyer_enterprise_id AND status = 'active' FOR UPDATE;
  SELECT treasury_balance INTO v_seller_balance FROM cen_enterprises
    WHERE id = v_seller AND status = 'active' FOR UPDATE;
  SET v_total = v_price * p_quantity;
  IF v_buyer_balance IS NULL OR v_seller_balance IS NULL OR v_buyer_balance < v_total THEN
    ROLLBACK; SELECT 0 AS ok, 'insufficient_funds' AS errorCode, NULL AS deliveryId; LEAVE proc;
  END IF;
  UPDATE cen_enterprises SET treasury_balance = treasury_balance - v_total
    WHERE id = p_buyer_enterprise_id;
  UPDATE cen_enterprises SET treasury_balance = treasury_balance + v_total
    WHERE id = v_seller;
  UPDATE cen_market_listings
    SET quantity_remaining = v_remaining - p_quantity,
        status = IF(v_remaining - p_quantity = 0, 'sold', 'active')
    WHERE id = p_listing_id;
  INSERT INTO cen_market_sales
    (listing_id, seller_enterprise_id, buyer_enterprise_id, buyer_member_id, quantity, total_price)
    VALUES (p_listing_id, v_seller, p_buyer_enterprise_id, p_buyer_member_id, p_quantity, v_total);
  INSERT INTO cen_market_deliveries
    (enterprise_id, source_type, source_id, item_name, quantity, quality, batch_id, metadata)
    VALUES (p_buyer_enterprise_id, 'purchase', LAST_INSERT_ID(), v_item, p_quantity, v_quality, v_batch,
      JSON_OBJECT('sellerEnterpriseId', v_seller, 'listingId', p_listing_id, 'totalPrice', v_total));
  SET v_delivery_id = LAST_INSERT_ID();
  INSERT INTO cen_treasury_transactions
    (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
    VALUES
      (p_buyer_enterprise_id, p_buyer_member_id, 'market_purchase', v_total, v_buyer_balance - v_total, CONCAT('Listing #', p_listing_id)),
      (v_seller, NULL, 'market_sale', v_total, v_seller_balance + v_total, CONCAT('Listing #', p_listing_id));
  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode, v_delivery_id AS deliveryId, v_total AS totalPrice;
END//

CREATE PROCEDURE `cen_request_shipment`(
  IN p_enterprise_id BIGINT UNSIGNED,
  IN p_member_id BIGINT UNSIGNED,
  IN p_catalog_key VARCHAR(60),
  IN p_delivery_type VARCHAR(20),
  IN p_item_name VARCHAR(80),
  IN p_quantity INT UNSIGNED,
  IN p_cost BIGINT UNSIGNED,
  IN p_x DOUBLE, IN p_y DOUBLE, IN p_z DOUBLE,
  IN p_label VARCHAR(100),
  IN p_ready_seconds INT UNSIGNED,
  IN p_expiry_hours INT UNSIGNED
)
proc: BEGIN
  DECLARE v_balance BIGINT DEFAULT NULL;
  DECLARE v_shipment_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode, NULL AS shipmentId;
  END;
  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;
  SELECT treasury_balance INTO v_balance FROM cen_enterprises
    WHERE id = p_enterprise_id AND status = 'active' FOR UPDATE;
  IF v_balance IS NULL OR v_balance < p_cost THEN
    ROLLBACK; SELECT 0 AS ok, 'insufficient_funds' AS errorCode, NULL AS shipmentId; LEAVE proc;
  END IF;
  UPDATE cen_enterprises SET treasury_balance = treasury_balance - p_cost WHERE id = p_enterprise_id;
  INSERT INTO cen_shipments
    (enterprise_id, requested_by_member_id, catalog_key, delivery_type, item_name, quantity, cost,
     pickup_x, pickup_y, pickup_z, pickup_label, ready_at, expires_at)
    VALUES (p_enterprise_id, p_member_id, p_catalog_key, p_delivery_type, p_item_name, p_quantity, p_cost,
      p_x, p_y, p_z, p_label, DATE_ADD(UTC_TIMESTAMP(), INTERVAL p_ready_seconds SECOND),
      DATE_ADD(DATE_ADD(UTC_TIMESTAMP(), INTERVAL p_ready_seconds SECOND), INTERVAL p_expiry_hours HOUR));
  SET v_shipment_id = LAST_INSERT_ID();
  INSERT INTO cen_treasury_transactions
    (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
    VALUES (p_enterprise_id, p_member_id, 'shipment_purchase', p_cost, v_balance - p_cost, CONCAT('Shipment #', v_shipment_id));
  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode, v_shipment_id AS shipmentId;
END//

CREATE PROCEDURE `cen_accept_corruption_offer`(
  IN p_offer_id BIGINT UNSIGNED,
  IN p_officer_identifier VARCHAR(80)
)
proc: BEGIN
  DECLARE v_enterprise BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_fee BIGINT UNSIGNED DEFAULT 0;
  DECLARE v_exposure INT UNSIGNED DEFAULT 0;
  DECLARE v_name VARCHAR(80) DEFAULT NULL;
  DECLARE v_service VARCHAR(60) DEFAULT NULL;
  DECLARE v_balance BIGINT DEFAULT NULL;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode, NULL AS enterpriseId;
  END;
  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;
  SELECT enterprise_id, fee, exposure, officer_display_name, service_key
    INTO v_enterprise, v_fee, v_exposure, v_name, v_service
    FROM cen_corruption_offers
    WHERE id = p_offer_id AND officer_identifier = p_officer_identifier
      AND status = 'pending' AND expires_at > UTC_TIMESTAMP()
    FOR UPDATE;
  IF v_enterprise IS NULL THEN
    ROLLBACK; SELECT 0 AS ok, 'offer_not_found' AS errorCode, NULL AS enterpriseId; LEAVE proc;
  END IF;
  SELECT treasury_balance INTO v_balance FROM cen_enterprises
    WHERE id = v_enterprise AND status = 'active' FOR UPDATE;
  IF v_balance IS NULL OR v_balance < v_fee THEN
    ROLLBACK; SELECT 0 AS ok, 'insufficient_funds' AS errorCode, v_enterprise AS enterpriseId; LEAVE proc;
  END IF;
  UPDATE cen_enterprises SET treasury_balance = treasury_balance - v_fee WHERE id = v_enterprise;
  UPDATE cen_corruption_offers SET status = 'accepted', accepted_at = UTC_TIMESTAMP()
    WHERE id = p_offer_id;
  INSERT INTO cen_treasury_transactions
    (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
    VALUES (v_enterprise, NULL, 'corruption_payment', v_fee, v_balance - v_fee, CONCAT('Corruption offer #', p_offer_id));
  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode, v_enterprise AS enterpriseId, v_fee AS fee,
    v_exposure AS exposure, v_name AS officerDisplayName, v_service AS serviceKey;
END//

DELIMITER ;


-- Phase 2 v1.1.0 clean-install additions
-- v1.1.0 Phase 2: crews/chapters, diplomacy, wars, fronts, laundering and protection rackets.
-- Apply after migrations 002-007. Back up the database first.

CREATE TABLE IF NOT EXISTS `cen_crews` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `enterprise_id` BIGINT UNSIGNED NOT NULL,
  `name` VARCHAR(60) NOT NULL,
  `leader_member_id` BIGINT UNSIGNED NULL,
  `max_members` INT UNSIGNED NOT NULL DEFAULT 8,
  `status` ENUM('active','disabled') NOT NULL DEFAULT 'active',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cen_crew_name` (`enterprise_id`, `name`),
  KEY `idx_cen_crew_enterprise` (`enterprise_id`, `status`),
  CONSTRAINT `fk_cen_crew_enterprise` FOREIGN KEY (`enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_crew_leader` FOREIGN KEY (`leader_member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_crew_members` (
  `crew_id` BIGINT UNSIGNED NOT NULL,
  `member_id` BIGINT UNSIGNED NOT NULL,
  `role` ENUM('leader','member') NOT NULL DEFAULT 'member',
  `joined_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`crew_id`, `member_id`),
  UNIQUE KEY `uq_cen_member_crew` (`member_id`),
  CONSTRAINT `fk_cen_crew_member_crew` FOREIGN KEY (`crew_id`)
    REFERENCES `cen_crews` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_crew_member_member` FOREIGN KEY (`member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_diplomacy_relations` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `enterprise_low_id` BIGINT UNSIGNED NOT NULL,
  `enterprise_high_id` BIGINT UNSIGNED NOT NULL,
  `relation_type` ENUM('allied','enemy','ceasefire') NOT NULL,
  `established_by` VARCHAR(32) NOT NULL DEFAULT 'agreement',
  `expires_at` DATETIME NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cen_diplomacy_pair` (`enterprise_low_id`, `enterprise_high_id`),
  KEY `idx_cen_diplomacy_type` (`relation_type`, `expires_at`),
  CONSTRAINT `fk_cen_diplomacy_low` FOREIGN KEY (`enterprise_low_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_diplomacy_high` FOREIGN KEY (`enterprise_high_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CHECK (`enterprise_low_id` < `enterprise_high_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_diplomacy_proposals` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `proposer_enterprise_id` BIGINT UNSIGNED NOT NULL,
  `target_enterprise_id` BIGINT UNSIGNED NOT NULL,
  `created_by_member_id` BIGINT UNSIGNED NULL,
  `relation_type` ENUM('allied','ceasefire') NOT NULL,
  `message` VARCHAR(180) NULL,
  `status` ENUM('pending','accepted','declined','cancelled','expired') NOT NULL DEFAULT 'pending',
  `expires_at` DATETIME NOT NULL,
  `responded_at` DATETIME NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cen_diplomacy_proposal_target` (`target_enterprise_id`, `status`, `expires_at`),
  KEY `idx_cen_diplomacy_proposal_proposer` (`proposer_enterprise_id`, `status`),
  CONSTRAINT `fk_cen_diplomacy_proposer` FOREIGN KEY (`proposer_enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_diplomacy_target` FOREIGN KEY (`target_enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_diplomacy_creator` FOREIGN KEY (`created_by_member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_wars` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `attacker_enterprise_id` BIGINT UNSIGNED NOT NULL,
  `defender_enterprise_id` BIGINT UNSIGNED NOT NULL,
  `created_by_member_id` BIGINT UNSIGNED NULL,
  `status` ENUM('proposed','active','completed','declined','cancelled','expired') NOT NULL DEFAULT 'proposed',
  `reason` VARCHAR(180) NULL,
  `target_score` INT UNSIGNED NOT NULL DEFAULT 100,
  `attacker_score` INT UNSIGNED NOT NULL DEFAULT 0,
  `defender_score` INT UNSIGNED NOT NULL DEFAULT 0,
  `attacker_stake` BIGINT UNSIGNED NOT NULL DEFAULT 0,
  `defender_stake` BIGINT UNSIGNED NOT NULL DEFAULT 0,
  `winner_enterprise_id` BIGINT UNSIGNED NULL,
  `proposal_expires_at` DATETIME NOT NULL,
  `starts_at` DATETIME NULL,
  `ends_at` DATETIME NULL,
  `completed_at` DATETIME NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cen_war_attacker_status` (`attacker_enterprise_id`, `status`, `created_at`),
  KEY `idx_cen_war_defender_status` (`defender_enterprise_id`, `status`, `created_at`),
  KEY `idx_cen_war_due` (`status`, `ends_at`),
  CONSTRAINT `fk_cen_war_attacker` FOREIGN KEY (`attacker_enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_war_defender` FOREIGN KEY (`defender_enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_war_creator` FOREIGN KEY (`created_by_member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_cen_war_winner` FOREIGN KEY (`winner_enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_war_events` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `war_id` BIGINT UNSIGNED NOT NULL,
  `scoring_enterprise_id` BIGINT UNSIGNED NOT NULL,
  `event_type` VARCHAR(48) NOT NULL,
  `points` INT UNSIGNED NOT NULL,
  `metadata` JSON NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cen_war_event_war` (`war_id`, `created_at`),
  CONSTRAINT `fk_cen_war_event_war` FOREIGN KEY (`war_id`)
    REFERENCES `cen_wars` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_war_event_enterprise` FOREIGN KEY (`scoring_enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_front_businesses` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `enterprise_id` BIGINT UNSIGNED NOT NULL,
  `created_by_member_id` BIGINT UNSIGNED NULL,
  `business_type` VARCHAR(40) NOT NULL,
  `name` VARCHAR(80) NOT NULL,
  `capacity_per_cycle` BIGINT UNSIGNED NOT NULL,
  `processed_this_cycle` BIGINT UNSIGNED NOT NULL DEFAULT 0,
  `cycle_start` DATE NOT NULL,
  `fee_percent` DECIMAL(5,2) NOT NULL DEFAULT 15.00,
  `security_level` INT UNSIGNED NOT NULL DEFAULT 1,
  `status` ENUM('active','disabled','raided') NOT NULL DEFAULT 'active',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cen_front_name` (`enterprise_id`, `name`),
  KEY `idx_cen_front_enterprise` (`enterprise_id`, `status`),
  CONSTRAINT `fk_cen_front_enterprise` FOREIGN KEY (`enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_front_creator` FOREIGN KEY (`created_by_member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_laundering_jobs` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `enterprise_id` BIGINT UNSIGNED NOT NULL,
  `front_id` BIGINT UNSIGNED NOT NULL,
  `member_id` BIGINT UNSIGNED NULL,
  `dirty_amount` BIGINT UNSIGNED NOT NULL,
  `clean_amount` BIGINT UNSIGNED NOT NULL,
  `fee_amount` BIGINT UNSIGNED NOT NULL,
  `status` ENUM('processing','ready','claiming','claimed','cancelled') NOT NULL DEFAULT 'processing',
  `ready_at` DATETIME NOT NULL,
  `claimed_at` DATETIME NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cen_laundering_enterprise` (`enterprise_id`, `status`, `ready_at`),
  CONSTRAINT `fk_cen_laundering_enterprise` FOREIGN KEY (`enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_laundering_front` FOREIGN KEY (`front_id`)
    REFERENCES `cen_front_businesses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_laundering_member` FOREIGN KEY (`member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_rackets` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `enterprise_id` BIGINT UNSIGNED NOT NULL,
  `zone_id` BIGINT UNSIGNED NOT NULL,
  `created_by_member_id` BIGINT UNSIGNED NULL,
  `racket_type` VARCHAR(40) NOT NULL,
  `payout_amount` BIGINT UNSIGNED NOT NULL,
  `heat` INT UNSIGNED NOT NULL DEFAULT 0,
  `status` ENUM('active','disabled') NOT NULL DEFAULT 'active',
  `last_collected_at` DATETIME NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cen_racket_zone` (`zone_id`),
  KEY `idx_cen_racket_enterprise` (`enterprise_id`, `status`),
  CONSTRAINT `fk_cen_racket_enterprise` FOREIGN KEY (`enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_racket_zone` FOREIGN KEY (`zone_id`)
    REFERENCES `cen_zones` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_racket_creator` FOREIGN KEY (`created_by_member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP PROCEDURE IF EXISTS `cen_propose_war`;
DROP PROCEDURE IF EXISTS `cen_respond_war`;
DROP PROCEDURE IF EXISTS `cen_cancel_war`;
DROP PROCEDURE IF EXISTS `cen_finalize_war`;

DELIMITER //

CREATE PROCEDURE `cen_propose_war`(
  IN p_attacker BIGINT UNSIGNED,
  IN p_defender BIGINT UNSIGNED,
  IN p_member BIGINT UNSIGNED,
  IN p_reason VARCHAR(180),
  IN p_target_score INT UNSIGNED,
  IN p_stake BIGINT UNSIGNED,
  IN p_duration_seconds INT UNSIGNED,
  IN p_expiry_hours INT UNSIGNED
)
proc: BEGIN
  DECLARE v_balance BIGINT DEFAULT NULL;
  DECLARE v_war_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode, NULL AS warId;
  END;
  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;
  IF p_attacker = p_defender OR p_target_score < 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_war' AS errorCode, NULL AS warId; LEAVE proc;
  END IF;
  SELECT treasury_balance INTO v_balance FROM cen_enterprises
    WHERE id = p_attacker AND status = 'active' FOR UPDATE;
  IF v_balance IS NULL OR v_balance < p_stake THEN
    ROLLBACK; SELECT 0 AS ok, 'insufficient_funds' AS errorCode, NULL AS warId; LEAVE proc;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM cen_enterprises WHERE id = p_defender AND status = 'active') THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode, NULL AS warId; LEAVE proc;
  END IF;
  IF EXISTS (SELECT 1 FROM cen_wars WHERE status IN ('proposed','active')
      AND ((attacker_enterprise_id = p_attacker AND defender_enterprise_id = p_defender)
        OR (attacker_enterprise_id = p_defender AND defender_enterprise_id = p_attacker))) THEN
    ROLLBACK; SELECT 0 AS ok, 'war_exists' AS errorCode, NULL AS warId; LEAVE proc;
  END IF;
  UPDATE cen_enterprises SET treasury_balance = treasury_balance - p_stake WHERE id = p_attacker;
  INSERT INTO cen_treasury_transactions
    (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
    SELECT p_attacker, p_member, 'war_escrow', p_stake, treasury_balance, 'War proposal stake'
      FROM cen_enterprises WHERE id = p_attacker;
  INSERT INTO cen_wars
    (attacker_enterprise_id, defender_enterprise_id, created_by_member_id, reason,
     target_score, attacker_stake, defender_stake, proposal_expires_at, ends_at)
    VALUES (p_attacker, p_defender, p_member, p_reason, p_target_score, p_stake, p_stake,
      DATE_ADD(UTC_TIMESTAMP(), INTERVAL p_expiry_hours HOUR),
      DATE_ADD(UTC_TIMESTAMP(), INTERVAL p_duration_seconds SECOND));
  SET v_war_id = LAST_INSERT_ID();
  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode, v_war_id AS warId;
END//

CREATE PROCEDURE `cen_respond_war`(
  IN p_war_id BIGINT UNSIGNED,
  IN p_defender BIGINT UNSIGNED,
  IN p_member BIGINT UNSIGNED,
  IN p_accept TINYINT UNSIGNED,
  IN p_duration_seconds INT UNSIGNED
)
proc: BEGIN
  DECLARE v_attacker BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_expected_defender BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_stake BIGINT UNSIGNED DEFAULT 0;
  DECLARE v_balance BIGINT DEFAULT NULL;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode;
  END;
  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;
  SELECT attacker_enterprise_id, defender_enterprise_id, defender_stake
    INTO v_attacker, v_expected_defender, v_stake
    FROM cen_wars WHERE id = p_war_id AND status = 'proposed'
      AND proposal_expires_at > UTC_TIMESTAMP() FOR UPDATE;
  IF v_attacker IS NULL OR v_expected_defender <> p_defender THEN
    ROLLBACK; SELECT 0 AS ok, 'war_not_found' AS errorCode; LEAVE proc;
  END IF;
  IF p_accept = 0 THEN
    UPDATE cen_enterprises SET treasury_balance = treasury_balance + v_stake WHERE id = v_attacker;
    INSERT INTO cen_treasury_transactions
      (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
      SELECT v_attacker, NULL, 'war_refund', v_stake, treasury_balance, 'Declined war refund'
        FROM cen_enterprises WHERE id = v_attacker;
    UPDATE cen_wars SET status = 'declined', completed_at = UTC_TIMESTAMP() WHERE id = p_war_id;
    COMMIT; SELECT 1 AS ok, NULL AS errorCode; LEAVE proc;
  END IF;
  SELECT treasury_balance INTO v_balance FROM cen_enterprises
    WHERE id = p_defender AND status = 'active' FOR UPDATE;
  IF v_balance IS NULL OR v_balance < v_stake THEN
    ROLLBACK; SELECT 0 AS ok, 'insufficient_funds' AS errorCode; LEAVE proc;
  END IF;
  UPDATE cen_enterprises SET treasury_balance = treasury_balance - v_stake WHERE id = p_defender;
  INSERT INTO cen_treasury_transactions
    (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
    SELECT p_defender, p_member, 'war_escrow', v_stake, treasury_balance, 'War acceptance stake'
      FROM cen_enterprises WHERE id = p_defender;
  UPDATE cen_wars SET status = 'active', starts_at = UTC_TIMESTAMP(),
      ends_at = DATE_ADD(UTC_TIMESTAMP(), INTERVAL p_duration_seconds SECOND)
    WHERE id = p_war_id;
  INSERT INTO cen_diplomacy_relations
    (enterprise_low_id, enterprise_high_id, relation_type, established_by)
    VALUES (LEAST(v_attacker, p_defender), GREATEST(v_attacker, p_defender), 'enemy', 'war')
    ON DUPLICATE KEY UPDATE relation_type = 'enemy', established_by = 'war', expires_at = NULL;
  COMMIT; SELECT 1 AS ok, NULL AS errorCode;
END//

CREATE PROCEDURE `cen_cancel_war`(
  IN p_war_id BIGINT UNSIGNED,
  IN p_attacker BIGINT UNSIGNED
)
proc: BEGIN
  DECLARE v_stake BIGINT UNSIGNED DEFAULT 0;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode;
  END;
  START TRANSACTION;
  SELECT attacker_stake INTO v_stake FROM cen_wars
    WHERE id = p_war_id AND attacker_enterprise_id = p_attacker AND status = 'proposed' FOR UPDATE;
  IF v_stake IS NULL THEN
    ROLLBACK; SELECT 0 AS ok, 'war_not_found' AS errorCode; LEAVE proc;
  END IF;
  UPDATE cen_enterprises SET treasury_balance = treasury_balance + v_stake WHERE id = p_attacker;
  INSERT INTO cen_treasury_transactions
    (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
    SELECT p_attacker, NULL, 'war_refund', v_stake, treasury_balance, 'Cancelled war refund'
      FROM cen_enterprises WHERE id = p_attacker;
  UPDATE cen_wars SET status = 'cancelled', completed_at = UTC_TIMESTAMP() WHERE id = p_war_id;
  COMMIT; SELECT 1 AS ok, NULL AS errorCode;
END//

CREATE PROCEDURE `cen_finalize_war`(
  IN p_war_id BIGINT UNSIGNED,
  IN p_winner BIGINT UNSIGNED
)
proc: BEGIN
  DECLARE v_attacker BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_defender BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_attacker_stake BIGINT UNSIGNED DEFAULT 0;
  DECLARE v_defender_stake BIGINT UNSIGNED DEFAULT 0;
  DECLARE v_pot BIGINT UNSIGNED DEFAULT 0;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode;
  END;
  START TRANSACTION;
  SELECT attacker_enterprise_id, defender_enterprise_id, attacker_stake, defender_stake
    INTO v_attacker, v_defender, v_attacker_stake, v_defender_stake
    FROM cen_wars WHERE id = p_war_id AND status = 'active' FOR UPDATE;
  IF v_attacker IS NULL THEN
    ROLLBACK; SELECT 0 AS ok, 'war_not_found' AS errorCode; LEAVE proc;
  END IF;
  SET v_pot = v_attacker_stake + v_defender_stake;
  IF p_winner = v_attacker OR p_winner = v_defender THEN
    UPDATE cen_enterprises SET treasury_balance = treasury_balance + v_pot WHERE id = p_winner;
    INSERT INTO cen_treasury_transactions
      (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
      SELECT p_winner, NULL, 'war_payout', v_pot, treasury_balance, 'War victory payout'
        FROM cen_enterprises WHERE id = p_winner;
  ELSE
    UPDATE cen_enterprises SET treasury_balance = treasury_balance + v_attacker_stake WHERE id = v_attacker;
    UPDATE cen_enterprises SET treasury_balance = treasury_balance + v_defender_stake WHERE id = v_defender;
    INSERT INTO cen_treasury_transactions
      (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
      SELECT v_attacker, NULL, 'war_refund', v_attacker_stake, treasury_balance, 'War draw refund'
        FROM cen_enterprises WHERE id = v_attacker;
    INSERT INTO cen_treasury_transactions
      (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
      SELECT v_defender, NULL, 'war_refund', v_defender_stake, treasury_balance, 'War draw refund'
        FROM cen_enterprises WHERE id = v_defender;
  END IF;
  UPDATE cen_wars SET status = 'completed', winner_enterprise_id = NULLIF(p_winner, 0),
      completed_at = UTC_TIMESTAMP() WHERE id = p_war_id;
  COMMIT; SELECT 1 AS ok, NULL AS errorCode;
END//

DELIMITER ;
-- v1.1.0 Phase 2 hardening (migration 009)
-- v1.1.0 Phase 2 hardening.
-- Replaces vulnerable multi-statement crew, diplomacy, war, front, laundering,
-- and racket mutations with affected-row-verified transactions.
-- Apply after migration 008. Back up the database first.

-- Clean hidden memberships left by pre-hardening disabled crews.
DELETE cm FROM `cen_crew_members` cm
JOIN `cen_crews` c ON c.id = cm.crew_id
WHERE c.status = 'disabled';

DELETE cm FROM `cen_crew_members` cm
JOIN `cen_members` m ON m.id = cm.member_id
WHERE m.status <> 'active';

UPDATE `cen_crews` c
LEFT JOIN `cen_members` leader
  ON leader.id = c.leader_member_id AND leader.status = 'active'
SET c.leader_member_id = NULL
WHERE c.status = 'active' AND c.leader_member_id IS NOT NULL AND leader.id IS NULL;

DROP PROCEDURE IF EXISTS `cen_remove_enterprise_member`;
DROP PROCEDURE IF EXISTS `cen_soft_disband_enterprise`;
DROP PROCEDURE IF EXISTS `cen_create_crew`;
DROP PROCEDURE IF EXISTS `cen_assign_crew_member`;
DROP PROCEDURE IF EXISTS `cen_remove_crew_member`;
DROP PROCEDURE IF EXISTS `cen_delete_crew`;
DROP PROCEDURE IF EXISTS `cen_set_crew_leader`;
DROP PROCEDURE IF EXISTS `cen_propose_diplomacy`;
DROP PROCEDURE IF EXISTS `cen_respond_diplomacy`;
DROP PROCEDURE IF EXISTS `cen_end_diplomacy`;
DROP PROCEDURE IF EXISTS `cen_cancel_diplomacy`;
DROP PROCEDURE IF EXISTS `cen_propose_war`;
DROP PROCEDURE IF EXISTS `cen_respond_war`;
DROP PROCEDURE IF EXISTS `cen_cancel_war`;
DROP PROCEDURE IF EXISTS `cen_add_war_score`;
DROP PROCEDURE IF EXISTS `cen_finalize_war`;
DROP PROCEDURE IF EXISTS `cen_create_front`;
DROP PROCEDURE IF EXISTS `cen_start_laundering_job`;
DROP PROCEDURE IF EXISTS `cen_claim_laundering_treasury`;
DROP PROCEDURE IF EXISTS `cen_collect_racket`;

DELIMITER //


CREATE PROCEDURE `cen_remove_enterprise_member`(
  IN p_enterprise BIGINT UNSIGNED,
  IN p_member BIGINT UNSIGNED
)
proc: BEGIN
  DECLARE v_owner BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_default_rank BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_status VARCHAR(16) DEFAULT NULL;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;
  SET v_not_found = 0;
  SELECT owner_member_id INTO v_owner FROM cen_enterprises
    WHERE id = p_enterprise AND status = 'active' FOR UPDATE;
  IF v_not_found = 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode; LEAVE proc;
  END IF;
  IF v_owner = p_member THEN
    ROLLBACK; SELECT 0 AS ok, 'cannot_manage_owner' AS errorCode; LEAVE proc;
  END IF;

  SET v_not_found = 0;
  SELECT status INTO v_status FROM cen_members
    WHERE id = p_member AND enterprise_id = p_enterprise FOR UPDATE;
  IF v_not_found = 1 OR v_status <> 'active' THEN
    ROLLBACK; SELECT 0 AS ok, 'target_not_member' AS errorCode; LEAVE proc;
  END IF;

  SET v_not_found = 0;
  SELECT id INTO v_default_rank FROM cen_ranks
    WHERE enterprise_id = p_enterprise AND is_default = 1 LIMIT 1 FOR UPDATE;
  IF v_not_found = 1 OR v_default_rank IS NULL THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_rank' AS errorCode; LEAVE proc;
  END IF;

  UPDATE cen_crews SET leader_member_id = NULL
    WHERE enterprise_id = p_enterprise AND leader_member_id = p_member AND status = 'active';
  DELETE cm FROM cen_crew_members cm
    JOIN cen_crews c ON c.id = cm.crew_id
    WHERE cm.member_id = p_member AND c.enterprise_id = p_enterprise;
  UPDATE cen_members SET status = 'removed', rank_id = v_default_rank,
      updated_at = UTC_TIMESTAMP()
    WHERE id = p_member AND enterprise_id = p_enterprise AND status = 'active';
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode; LEAVE proc;
  END IF;

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode;
END//

CREATE PROCEDURE `cen_soft_disband_enterprise`(
  IN p_enterprise BIGINT UNSIGNED,
  IN p_owner_member BIGINT UNSIGNED,
  IN p_retention TINYINT UNSIGNED
)
proc: BEGIN
  DECLARE v_owner BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_status VARCHAR(16) DEFAULT NULL;
  DECLARE v_retention_status VARCHAR(24) DEFAULT NULL;
  DECLARE v_due DATETIME DEFAULT NULL;
  DECLARE v_default_rank BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;
  SET v_not_found = 0;
  SELECT owner_member_id, status, retention_status, disband_scheduled_at
    INTO v_owner, v_status, v_retention_status, v_due
    FROM cen_enterprises WHERE id = p_enterprise FOR UPDATE;
  IF v_not_found = 1 OR v_status <> 'active' THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode; LEAVE proc;
  END IF;
  IF p_retention = 1 THEN
    IF v_retention_status <> 'pending_disband' OR v_due IS NULL OR v_due > UTC_TIMESTAMP() THEN
      ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode; LEAVE proc;
    END IF;
  ELSEIF v_owner <> p_owner_member THEN
    ROLLBACK; SELECT 0 AS ok, 'owner_only' AS errorCode; LEAVE proc;
  END IF;

  IF EXISTS (SELECT 1 FROM cen_wars
      WHERE status IN ('proposed','active')
        AND (attacker_enterprise_id = p_enterprise OR defender_enterprise_id = p_enterprise)) THEN
    ROLLBACK; SELECT 0 AS ok, 'enterprise_in_conflict' AS errorCode; LEAVE proc;
  END IF;

  SET v_not_found = 0;
  SELECT id INTO v_default_rank FROM cen_ranks
    WHERE enterprise_id = p_enterprise AND is_default = 1 LIMIT 1 FOR UPDATE;
  IF v_not_found = 1 OR v_default_rank IS NULL THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_rank' AS errorCode; LEAVE proc;
  END IF;

  UPDATE cen_enterprises SET status = 'disbanded', retention_status = 'disbanded',
      disbanded_at = UTC_TIMESTAMP(), updated_at = UTC_TIMESTAMP()
    WHERE id = p_enterprise AND status = 'active';
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode; LEAVE proc;
  END IF;
  UPDATE cen_members SET status = 'removed', rank_id = v_default_rank,
      updated_at = UTC_TIMESTAMP()
    WHERE enterprise_id = p_enterprise AND status IN ('active','suspended');
  UPDATE cen_membership_invites SET status = 'cancelled', responded_at = UTC_TIMESTAMP()
    WHERE enterprise_id = p_enterprise AND status = 'pending';
  UPDATE cen_diplomacy_proposals SET status = 'cancelled', responded_at = UTC_TIMESTAMP()
    WHERE status = 'pending'
      AND (proposer_enterprise_id = p_enterprise OR target_enterprise_id = p_enterprise);
  DELETE FROM cen_diplomacy_relations
    WHERE enterprise_low_id = p_enterprise OR enterprise_high_id = p_enterprise;
  UPDATE cen_corruption_offers SET status = 'cancelled'
    WHERE enterprise_id = p_enterprise AND status = 'pending';

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode;
END//

CREATE PROCEDURE `cen_create_crew`(
  IN p_enterprise BIGINT UNSIGNED,
  IN p_name VARCHAR(60),
  IN p_leader BIGINT UNSIGNED,
  IN p_max_members INT UNSIGNED,
  IN p_max_crews INT UNSIGNED
)
proc: BEGIN
  DECLARE v_enterprise_exists INT DEFAULT 0;
  DECLARE v_leader_exists INT DEFAULT 0;
  DECLARE v_crew_count INT DEFAULT 0;
  DECLARE v_crew_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode, NULL AS crewId;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;

  SELECT COUNT(*) INTO v_enterprise_exists
    FROM cen_enterprises WHERE id = p_enterprise AND status = 'active' FOR UPDATE;
  IF v_enterprise_exists <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode, NULL AS crewId; LEAVE proc;
  END IF;

  SELECT COUNT(*) INTO v_leader_exists FROM cen_members
    WHERE id = p_leader AND enterprise_id = p_enterprise AND status = 'active';
  IF v_leader_exists <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'target_not_member' AS errorCode, NULL AS crewId; LEAVE proc;
  END IF;

  SELECT COUNT(*) INTO v_crew_count FROM cen_crews
    WHERE enterprise_id = p_enterprise AND status = 'active';
  IF v_crew_count >= p_max_crews THEN
    ROLLBACK; SELECT 0 AS ok, 'crew_limit_reached' AS errorCode, NULL AS crewId; LEAVE proc;
  END IF;

  IF EXISTS (SELECT 1 FROM cen_crews
      WHERE enterprise_id = p_enterprise AND name = p_name) THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode, NULL AS crewId; LEAVE proc;
  END IF;

  IF EXISTS (SELECT 1 FROM cen_crews
      WHERE enterprise_id = p_enterprise AND status = 'active'
        AND leader_member_id = p_leader) THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode, NULL AS crewId; LEAVE proc;
  END IF;

  DELETE cm FROM cen_crew_members cm
    JOIN cen_crews c ON c.id = cm.crew_id
    WHERE cm.member_id = p_leader AND c.enterprise_id = p_enterprise
      AND c.status = 'active' AND cm.role = 'member';

  INSERT INTO cen_crews (enterprise_id, name, leader_member_id, max_members)
    VALUES (p_enterprise, p_name, p_leader, p_max_members);
  SET v_crew_id = LAST_INSERT_ID();

  INSERT INTO cen_crew_members (crew_id, member_id, role)
    VALUES (v_crew_id, p_leader, 'leader');

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode, v_crew_id AS crewId;
END//

CREATE PROCEDURE `cen_assign_crew_member`(
  IN p_enterprise BIGINT UNSIGNED,
  IN p_crew BIGINT UNSIGNED,
  IN p_member BIGINT UNSIGNED
)
proc: BEGIN
  DECLARE v_max_members INT UNSIGNED DEFAULT NULL;
  DECLARE v_leader BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_member_count INT DEFAULT 0;
  DECLARE v_exists INT DEFAULT 0;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;

  SET v_not_found = 0;
  SELECT max_members, leader_member_id INTO v_max_members, v_leader
    FROM cen_crews WHERE id = p_crew AND enterprise_id = p_enterprise
      AND status = 'active' FOR UPDATE;
  IF v_not_found = 1 OR v_max_members IS NULL THEN
    ROLLBACK; SELECT 0 AS ok, 'crew_not_found' AS errorCode; LEAVE proc;
  END IF;

  SELECT COUNT(*) INTO v_exists FROM cen_members
    WHERE id = p_member AND enterprise_id = p_enterprise AND status = 'active';
  IF v_exists <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'target_not_member' AS errorCode; LEAVE proc;
  END IF;

  IF EXISTS (SELECT 1 FROM cen_crew_members WHERE crew_id = p_crew AND member_id = p_member) THEN
    COMMIT; SELECT 1 AS ok, NULL AS errorCode; LEAVE proc;
  END IF;

  IF EXISTS (SELECT 1 FROM cen_crews
      WHERE enterprise_id = p_enterprise AND status = 'active'
        AND id <> p_crew AND leader_member_id = p_member) THEN
    ROLLBACK; SELECT 0 AS ok, 'forbidden' AS errorCode; LEAVE proc;
  END IF;

  SELECT COUNT(*) INTO v_member_count FROM cen_crew_members WHERE crew_id = p_crew;
  IF v_member_count >= v_max_members THEN
    ROLLBACK; SELECT 0 AS ok, 'crew_full' AS errorCode; LEAVE proc;
  END IF;

  DELETE cm FROM cen_crew_members cm
    JOIN cen_crews c ON c.id = cm.crew_id
    WHERE cm.member_id = p_member AND c.enterprise_id = p_enterprise
      AND c.status = 'active' AND cm.role = 'member';

  INSERT INTO cen_crew_members (crew_id, member_id, role)
    VALUES (p_crew, p_member, IF(v_leader = p_member, 'leader', 'member'));

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode;
END//

CREATE PROCEDURE `cen_remove_crew_member`(
  IN p_enterprise BIGINT UNSIGNED,
  IN p_crew BIGINT UNSIGNED,
  IN p_member BIGINT UNSIGNED
)
proc: BEGIN
  DECLARE v_leader BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode;
  END;

  START TRANSACTION;
  SET v_not_found = 0;
  SELECT leader_member_id INTO v_leader FROM cen_crews
    WHERE id = p_crew AND enterprise_id = p_enterprise AND status = 'active' FOR UPDATE;
  IF v_not_found = 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'crew_not_found' AS errorCode; LEAVE proc;
  END IF;
  IF v_leader = p_member THEN
    ROLLBACK; SELECT 0 AS ok, 'forbidden' AS errorCode; LEAVE proc;
  END IF;

  DELETE FROM cen_crew_members WHERE crew_id = p_crew AND member_id = p_member;
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'target_not_member' AS errorCode; LEAVE proc;
  END IF;

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode;
END//

CREATE PROCEDURE `cen_delete_crew`(
  IN p_enterprise BIGINT UNSIGNED,
  IN p_crew BIGINT UNSIGNED
)
proc: BEGIN
  DECLARE v_exists INT DEFAULT 0;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode;
  END;

  START TRANSACTION;
  SELECT COUNT(*) INTO v_exists FROM cen_crews
    WHERE id = p_crew AND enterprise_id = p_enterprise AND status = 'active' FOR UPDATE;
  IF v_exists <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'crew_not_found' AS errorCode; LEAVE proc;
  END IF;

  DELETE FROM cen_crew_members WHERE crew_id = p_crew;
  UPDATE cen_crews SET status = 'disabled', leader_member_id = NULL
    WHERE id = p_crew AND enterprise_id = p_enterprise AND status = 'active';
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode; LEAVE proc;
  END IF;

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode;
END//


CREATE PROCEDURE `cen_set_crew_leader`(
  IN p_enterprise BIGINT UNSIGNED,
  IN p_crew BIGINT UNSIGNED,
  IN p_member BIGINT UNSIGNED
)
proc: BEGIN
  DECLARE v_old_leader BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_max_members INT UNSIGNED DEFAULT NULL;
  DECLARE v_member_count INT DEFAULT 0;
  DECLARE v_member_exists INT DEFAULT 0;
  DECLARE v_target_in_crew INT DEFAULT 0;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;
  SET v_not_found = 0;
  SELECT leader_member_id, max_members INTO v_old_leader, v_max_members
    FROM cen_crews WHERE id = p_crew AND enterprise_id = p_enterprise
      AND status = 'active' FOR UPDATE;
  IF v_not_found = 1 OR v_max_members IS NULL THEN
    ROLLBACK; SELECT 0 AS ok, 'crew_not_found' AS errorCode; LEAVE proc;
  END IF;
  IF v_old_leader = p_member THEN
    COMMIT; SELECT 1 AS ok, NULL AS errorCode; LEAVE proc;
  END IF;

  SELECT COUNT(*) INTO v_member_exists FROM cen_members
    WHERE id = p_member AND enterprise_id = p_enterprise AND status = 'active';
  IF v_member_exists <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'target_not_member' AS errorCode; LEAVE proc;
  END IF;

  IF EXISTS (SELECT 1 FROM cen_crews WHERE enterprise_id = p_enterprise
      AND id <> p_crew AND leader_member_id = p_member AND status = 'active') THEN
    ROLLBACK; SELECT 0 AS ok, 'forbidden' AS errorCode; LEAVE proc;
  END IF;

  SELECT COUNT(*) INTO v_target_in_crew FROM cen_crew_members
    WHERE crew_id = p_crew AND member_id = p_member;
  SELECT COUNT(*) INTO v_member_count FROM cen_crew_members WHERE crew_id = p_crew;
  IF v_target_in_crew = 0 AND v_member_count >= v_max_members THEN
    ROLLBACK; SELECT 0 AS ok, 'crew_full' AS errorCode; LEAVE proc;
  END IF;

  DELETE cm FROM cen_crew_members cm
    JOIN cen_crews c ON c.id = cm.crew_id
    WHERE cm.member_id = p_member AND c.enterprise_id = p_enterprise
      AND c.id <> p_crew AND c.status = 'active' AND cm.role = 'member';

  IF v_old_leader IS NOT NULL AND v_old_leader <> p_member THEN
    UPDATE cen_crew_members SET role = 'member'
      WHERE crew_id = p_crew AND member_id = v_old_leader;
  END IF;

  INSERT INTO cen_crew_members (crew_id, member_id, role)
    VALUES (p_crew, p_member, 'leader')
    ON DUPLICATE KEY UPDATE role = 'leader';
  UPDATE cen_crews SET leader_member_id = p_member
    WHERE id = p_crew AND enterprise_id = p_enterprise AND status = 'active';
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode; LEAVE proc;
  END IF;

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode;
END//

CREATE PROCEDURE `cen_propose_diplomacy`(
  IN p_proposer BIGINT UNSIGNED,
  IN p_target BIGINT UNSIGNED,
  IN p_member BIGINT UNSIGNED,
  IN p_relation VARCHAR(16),
  IN p_message VARCHAR(180),
  IN p_expiry_hours INT UNSIGNED,
  IN p_cooldown_seconds INT UNSIGNED
)
proc: BEGIN
  DECLARE v_low BIGINT UNSIGNED;
  DECLARE v_high BIGINT UNSIGNED;
  DECLARE v_low_status VARCHAR(24) DEFAULT NULL;
  DECLARE v_high_status VARCHAR(24) DEFAULT NULL;
  DECLARE v_proposal_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode, NULL AS proposalId;
  END;

  IF p_proposer = p_target OR p_relation NOT IN ('allied','ceasefire') THEN
    SELECT 0 AS ok, 'bad_request' AS errorCode, NULL AS proposalId; LEAVE proc;
  END IF;

  SET v_low = LEAST(p_proposer, p_target);
  SET v_high = GREATEST(p_proposer, p_target);
  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;

  SET v_not_found = 0;
  SELECT status INTO v_low_status FROM cen_enterprises WHERE id = v_low FOR UPDATE;
  IF v_not_found = 1 OR v_low_status <> 'active' THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode, NULL AS proposalId; LEAVE proc;
  END IF;
  SET v_not_found = 0;
  SELECT status INTO v_high_status FROM cen_enterprises WHERE id = v_high FOR UPDATE;
  IF v_not_found = 1 OR v_high_status <> 'active' THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode, NULL AS proposalId; LEAVE proc;
  END IF;

  IF EXISTS (SELECT 1 FROM cen_wars WHERE status IN ('proposed','active')
      AND ((attacker_enterprise_id = v_low AND defender_enterprise_id = v_high)
        OR (attacker_enterprise_id = v_high AND defender_enterprise_id = v_low))) THEN
    ROLLBACK; SELECT 0 AS ok, 'war_exists' AS errorCode, NULL AS proposalId; LEAVE proc;
  END IF;

  IF EXISTS (SELECT 1 FROM cen_diplomacy_relations
      WHERE enterprise_low_id = v_low AND enterprise_high_id = v_high
        AND (expires_at IS NULL OR expires_at > UTC_TIMESTAMP())) THEN
    ROLLBACK; SELECT 0 AS ok, 'diplomacy_exists' AS errorCode, NULL AS proposalId; LEAVE proc;
  END IF;

  IF EXISTS (SELECT 1 FROM cen_diplomacy_proposals
      WHERE status = 'pending' AND expires_at > UTC_TIMESTAMP()
        AND ((proposer_enterprise_id = p_proposer AND target_enterprise_id = p_target)
          OR (proposer_enterprise_id = p_target AND target_enterprise_id = p_proposer))) THEN
    ROLLBACK; SELECT 0 AS ok, 'diplomacy_exists' AS errorCode, NULL AS proposalId; LEAVE proc;
  END IF;

  IF p_cooldown_seconds > 0 AND EXISTS (SELECT 1 FROM cen_diplomacy_proposals
      WHERE created_at > DATE_SUB(UTC_TIMESTAMP(), INTERVAL p_cooldown_seconds SECOND)
        AND status IN ('declined','cancelled','expired')
        AND ((proposer_enterprise_id = p_proposer AND target_enterprise_id = p_target)
          OR (proposer_enterprise_id = p_target AND target_enterprise_id = p_proposer))) THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode, NULL AS proposalId; LEAVE proc;
  END IF;

  INSERT INTO cen_diplomacy_proposals
    (proposer_enterprise_id, target_enterprise_id, created_by_member_id,
     relation_type, message, expires_at)
    VALUES (p_proposer, p_target, p_member, p_relation, p_message,
      DATE_ADD(UTC_TIMESTAMP(), INTERVAL p_expiry_hours HOUR));
  SET v_proposal_id = LAST_INSERT_ID();

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode, v_proposal_id AS proposalId;
END//

CREATE PROCEDURE `cen_respond_diplomacy`(
  IN p_proposal BIGINT UNSIGNED,
  IN p_target BIGINT UNSIGNED,
  IN p_accept TINYINT UNSIGNED,
  IN p_ceasefire_hours INT UNSIGNED
)
proc: BEGIN
  DECLARE v_proposer BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_expected_target BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_relation VARCHAR(16) DEFAULT NULL;
  DECLARE v_low BIGINT UNSIGNED;
  DECLARE v_high BIGINT UNSIGNED;
  DECLARE v_status VARCHAR(24) DEFAULT NULL;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;

  SET v_not_found = 0;
  SELECT proposer_enterprise_id, target_enterprise_id, relation_type
    INTO v_proposer, v_expected_target, v_relation
    FROM cen_diplomacy_proposals
    WHERE id = p_proposal AND status = 'pending' AND expires_at > UTC_TIMESTAMP()
    FOR UPDATE;
  IF v_not_found = 1 OR v_expected_target <> p_target THEN
    ROLLBACK; SELECT 0 AS ok, 'diplomacy_not_found' AS errorCode; LEAVE proc;
  END IF;

  IF p_accept = 0 THEN
    UPDATE cen_diplomacy_proposals SET status = 'declined', responded_at = UTC_TIMESTAMP()
      WHERE id = p_proposal AND status = 'pending';
    IF ROW_COUNT() <> 1 THEN
      ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode; LEAVE proc;
    END IF;
    COMMIT; SELECT 1 AS ok, NULL AS errorCode; LEAVE proc;
  END IF;

  SET v_low = LEAST(v_proposer, p_target);
  SET v_high = GREATEST(v_proposer, p_target);

  SET v_not_found = 0;
  SELECT status INTO v_status FROM cen_enterprises WHERE id = v_low FOR UPDATE;
  IF v_not_found = 1 OR v_status <> 'active' THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode; LEAVE proc;
  END IF;
  SET v_not_found = 0;
  SELECT status INTO v_status FROM cen_enterprises WHERE id = v_high FOR UPDATE;
  IF v_not_found = 1 OR v_status <> 'active' THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode; LEAVE proc;
  END IF;

  IF EXISTS (SELECT 1 FROM cen_wars WHERE status IN ('proposed','active')
      AND ((attacker_enterprise_id = v_low AND defender_enterprise_id = v_high)
        OR (attacker_enterprise_id = v_high AND defender_enterprise_id = v_low))) THEN
    ROLLBACK; SELECT 0 AS ok, 'war_exists' AS errorCode; LEAVE proc;
  END IF;

  UPDATE cen_diplomacy_proposals SET status = 'accepted', responded_at = UTC_TIMESTAMP()
    WHERE id = p_proposal AND status = 'pending';
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode; LEAVE proc;
  END IF;

  INSERT INTO cen_diplomacy_relations
    (enterprise_low_id, enterprise_high_id, relation_type, established_by, expires_at)
    VALUES (v_low, v_high, v_relation, 'agreement',
      IF(v_relation = 'ceasefire', DATE_ADD(UTC_TIMESTAMP(), INTERVAL p_ceasefire_hours HOUR), NULL))
    ON DUPLICATE KEY UPDATE relation_type = VALUES(relation_type), established_by = 'agreement',
      expires_at = VALUES(expires_at), updated_at = UTC_TIMESTAMP();

  UPDATE cen_diplomacy_proposals SET status = 'cancelled', responded_at = UTC_TIMESTAMP()
    WHERE id <> p_proposal AND status = 'pending'
      AND ((proposer_enterprise_id = v_low AND target_enterprise_id = v_high)
        OR (proposer_enterprise_id = v_high AND target_enterprise_id = v_low));

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode;
END//

CREATE PROCEDURE `cen_end_diplomacy`(
  IN p_enterprise BIGINT UNSIGNED,
  IN p_relation BIGINT UNSIGNED
)
proc: BEGIN
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode;
  END;
  START TRANSACTION;
  DELETE FROM cen_diplomacy_relations
    WHERE id = p_relation AND established_by <> 'war'
      AND (enterprise_low_id = p_enterprise OR enterprise_high_id = p_enterprise);
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'forbidden' AS errorCode; LEAVE proc;
  END IF;
  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode;
END//


CREATE PROCEDURE `cen_cancel_diplomacy`(
  IN p_proposal BIGINT UNSIGNED,
  IN p_proposer BIGINT UNSIGNED
)
proc: BEGIN
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode;
  END;
  START TRANSACTION;
  UPDATE cen_diplomacy_proposals SET status = 'cancelled', responded_at = UTC_TIMESTAMP()
    WHERE id = p_proposal AND proposer_enterprise_id = p_proposer
      AND status = 'pending' AND expires_at > UTC_TIMESTAMP();
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'diplomacy_not_found' AS errorCode; LEAVE proc;
  END IF;
  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode;
END//

CREATE PROCEDURE `cen_propose_war`(
  IN p_attacker BIGINT UNSIGNED,
  IN p_defender BIGINT UNSIGNED,
  IN p_member BIGINT UNSIGNED,
  IN p_reason VARCHAR(180),
  IN p_target_score INT UNSIGNED,
  IN p_stake BIGINT UNSIGNED,
  IN p_duration_seconds INT UNSIGNED,
  IN p_expiry_hours INT UNSIGNED
)
proc: BEGIN
  DECLARE v_low BIGINT UNSIGNED;
  DECLARE v_high BIGINT UNSIGNED;
  DECLARE v_low_balance BIGINT DEFAULT NULL;
  DECLARE v_high_balance BIGINT DEFAULT NULL;
  DECLARE v_low_status VARCHAR(24) DEFAULT NULL;
  DECLARE v_high_status VARCHAR(24) DEFAULT NULL;
  DECLARE v_attacker_balance BIGINT DEFAULT NULL;
  DECLARE v_war_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode, NULL AS warId;
  END;

  IF p_attacker = p_defender OR p_target_score < 1 THEN
    SELECT 0 AS ok, 'invalid_war' AS errorCode, NULL AS warId; LEAVE proc;
  END IF;

  SET v_low = LEAST(p_attacker, p_defender);
  SET v_high = GREATEST(p_attacker, p_defender);
  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;

  SET v_not_found = 0;
  SELECT treasury_balance, status INTO v_low_balance, v_low_status
    FROM cen_enterprises WHERE id = v_low FOR UPDATE;
  IF v_not_found = 1 OR v_low_status <> 'active' THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode, NULL AS warId; LEAVE proc;
  END IF;
  SET v_not_found = 0;
  SELECT treasury_balance, status INTO v_high_balance, v_high_status
    FROM cen_enterprises WHERE id = v_high FOR UPDATE;
  IF v_not_found = 1 OR v_high_status <> 'active' THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode, NULL AS warId; LEAVE proc;
  END IF;

  SET v_attacker_balance = IF(p_attacker = v_low, v_low_balance, v_high_balance);
  IF v_attacker_balance < p_stake THEN
    ROLLBACK; SELECT 0 AS ok, 'insufficient_funds' AS errorCode, NULL AS warId; LEAVE proc;
  END IF;

  IF EXISTS (SELECT 1 FROM cen_diplomacy_relations
      WHERE enterprise_low_id = v_low AND enterprise_high_id = v_high
        AND relation_type IN ('allied','ceasefire')
        AND (expires_at IS NULL OR expires_at > UTC_TIMESTAMP())) THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_war' AS errorCode, NULL AS warId; LEAVE proc;
  END IF;

  IF EXISTS (SELECT 1 FROM cen_wars WHERE status IN ('proposed','active')
      AND ((attacker_enterprise_id = p_attacker AND defender_enterprise_id = p_defender)
        OR (attacker_enterprise_id = p_defender AND defender_enterprise_id = p_attacker))) THEN
    ROLLBACK; SELECT 0 AS ok, 'war_exists' AS errorCode, NULL AS warId; LEAVE proc;
  END IF;

  UPDATE cen_enterprises SET treasury_balance = treasury_balance - p_stake
    WHERE id = p_attacker AND status = 'active';
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode, NULL AS warId; LEAVE proc;
  END IF;

  INSERT INTO cen_treasury_transactions
    (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
    SELECT p_attacker, p_member, 'war_escrow', p_stake, treasury_balance, 'War proposal stake'
      FROM cen_enterprises WHERE id = p_attacker;

  INSERT INTO cen_wars
    (attacker_enterprise_id, defender_enterprise_id, created_by_member_id, reason,
     target_score, attacker_stake, defender_stake, proposal_expires_at, ends_at)
    VALUES (p_attacker, p_defender, p_member, p_reason, p_target_score, p_stake, p_stake,
      DATE_ADD(UTC_TIMESTAMP(), INTERVAL p_expiry_hours HOUR),
      DATE_ADD(UTC_TIMESTAMP(), INTERVAL p_duration_seconds SECOND));
  SET v_war_id = LAST_INSERT_ID();

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode, v_war_id AS warId;
END//

CREATE PROCEDURE `cen_respond_war`(
  IN p_war_id BIGINT UNSIGNED,
  IN p_defender BIGINT UNSIGNED,
  IN p_member BIGINT UNSIGNED,
  IN p_accept TINYINT UNSIGNED,
  IN p_duration_seconds INT UNSIGNED
)
proc: BEGIN
  DECLARE v_attacker BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_expected_defender BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_stake BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_low BIGINT UNSIGNED;
  DECLARE v_high BIGINT UNSIGNED;
  DECLARE v_low_balance BIGINT DEFAULT NULL;
  DECLARE v_high_balance BIGINT DEFAULT NULL;
  DECLARE v_low_status VARCHAR(24) DEFAULT NULL;
  DECLARE v_high_status VARCHAR(24) DEFAULT NULL;
  DECLARE v_defender_balance BIGINT DEFAULT NULL;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;

  SET v_not_found = 0;
  SELECT attacker_enterprise_id, defender_enterprise_id, defender_stake
    INTO v_attacker, v_expected_defender, v_stake
    FROM cen_wars WHERE id = p_war_id AND status = 'proposed'
      AND proposal_expires_at > UTC_TIMESTAMP() FOR UPDATE;
  IF v_not_found = 1 OR v_expected_defender <> p_defender THEN
    ROLLBACK; SELECT 0 AS ok, 'war_not_found' AS errorCode; LEAVE proc;
  END IF;

  SET v_low = LEAST(v_attacker, p_defender);
  SET v_high = GREATEST(v_attacker, p_defender);

  SET v_not_found = 0;
  SELECT treasury_balance, status INTO v_low_balance, v_low_status
    FROM cen_enterprises WHERE id = v_low FOR UPDATE;
  IF v_not_found = 1 OR v_low_status <> 'active' THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode; LEAVE proc;
  END IF;
  SET v_not_found = 0;
  SELECT treasury_balance, status INTO v_high_balance, v_high_status
    FROM cen_enterprises WHERE id = v_high FOR UPDATE;
  IF v_not_found = 1 OR v_high_status <> 'active' THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode; LEAVE proc;
  END IF;

  IF p_accept = 0 THEN
    UPDATE cen_enterprises SET treasury_balance = treasury_balance + v_stake WHERE id = v_attacker;
    INSERT INTO cen_treasury_transactions
      (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
      SELECT v_attacker, NULL, 'war_refund', v_stake, treasury_balance, 'Declined war refund'
        FROM cen_enterprises WHERE id = v_attacker;
    UPDATE cen_wars SET status = 'declined', completed_at = UTC_TIMESTAMP()
      WHERE id = p_war_id AND status = 'proposed';
    IF ROW_COUNT() <> 1 THEN
      ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode; LEAVE proc;
    END IF;
    COMMIT; SELECT 1 AS ok, NULL AS errorCode; LEAVE proc;
  END IF;

  SET v_defender_balance = IF(p_defender = v_low, v_low_balance, v_high_balance);
  IF v_defender_balance < v_stake THEN
    ROLLBACK; SELECT 0 AS ok, 'insufficient_funds' AS errorCode; LEAVE proc;
  END IF;

  UPDATE cen_enterprises SET treasury_balance = treasury_balance - v_stake
    WHERE id = p_defender AND status = 'active';
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode; LEAVE proc;
  END IF;

  INSERT INTO cen_treasury_transactions
    (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
    SELECT p_defender, p_member, 'war_escrow', v_stake, treasury_balance, 'War acceptance stake'
      FROM cen_enterprises WHERE id = p_defender;

  UPDATE cen_wars SET status = 'active', starts_at = UTC_TIMESTAMP(),
      ends_at = DATE_ADD(UTC_TIMESTAMP(), INTERVAL p_duration_seconds SECOND)
    WHERE id = p_war_id AND status = 'proposed';
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode; LEAVE proc;
  END IF;

  INSERT INTO cen_diplomacy_relations
    (enterprise_low_id, enterprise_high_id, relation_type, established_by)
    VALUES (v_low, v_high, 'enemy', 'war')
    ON DUPLICATE KEY UPDATE relation_type = 'enemy', established_by = 'war',
      expires_at = NULL, updated_at = UTC_TIMESTAMP();

  UPDATE cen_diplomacy_proposals SET status = 'cancelled', responded_at = UTC_TIMESTAMP()
    WHERE status = 'pending'
      AND ((proposer_enterprise_id = v_low AND target_enterprise_id = v_high)
        OR (proposer_enterprise_id = v_high AND target_enterprise_id = v_low));

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode;
END//

CREATE PROCEDURE `cen_cancel_war`(
  IN p_war_id BIGINT UNSIGNED,
  IN p_attacker BIGINT UNSIGNED
)
proc: BEGIN
  DECLARE v_stake BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_balance BIGINT DEFAULT NULL;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode;
  END;

  START TRANSACTION;
  SET v_not_found = 0;
  SELECT attacker_stake INTO v_stake FROM cen_wars
    WHERE id = p_war_id AND attacker_enterprise_id = p_attacker
      AND status = 'proposed' FOR UPDATE;
  IF v_not_found = 1 OR v_stake IS NULL THEN
    ROLLBACK; SELECT 0 AS ok, 'war_not_found' AS errorCode; LEAVE proc;
  END IF;

  SET v_not_found = 0;
  SELECT treasury_balance INTO v_balance FROM cen_enterprises
    WHERE id = p_attacker AND status = 'active' FOR UPDATE;
  IF v_not_found = 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode; LEAVE proc;
  END IF;
  UPDATE cen_enterprises SET treasury_balance = treasury_balance + v_stake WHERE id = p_attacker;
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode; LEAVE proc;
  END IF;

  INSERT INTO cen_treasury_transactions
    (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
    SELECT p_attacker, NULL, 'war_refund', v_stake, treasury_balance, 'Cancelled war refund'
      FROM cen_enterprises WHERE id = p_attacker;
  UPDATE cen_wars SET status = 'cancelled', completed_at = UTC_TIMESTAMP()
    WHERE id = p_war_id AND status = 'proposed';
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode; LEAVE proc;
  END IF;

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode;
END//

CREATE PROCEDURE `cen_add_war_score`(
  IN p_war_id BIGINT UNSIGNED,
  IN p_scoring_enterprise BIGINT UNSIGNED,
  IN p_event_type VARCHAR(48),
  IN p_points INT UNSIGNED,
  IN p_metadata LONGTEXT
)
proc: BEGIN
  DECLARE v_attacker BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_defender BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_attacker_score INT UNSIGNED DEFAULT 0;
  DECLARE v_defender_score INT UNSIGNED DEFAULT 0;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode, NULL AS attackerScore, NULL AS defenderScore;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;
  SET v_not_found = 0;
  SELECT attacker_enterprise_id, defender_enterprise_id, attacker_score, defender_score
    INTO v_attacker, v_defender, v_attacker_score, v_defender_score
    FROM cen_wars WHERE id = p_war_id AND status = 'active'
      AND ends_at > UTC_TIMESTAMP() FOR UPDATE;
  IF v_not_found = 1 OR (p_scoring_enterprise <> v_attacker AND p_scoring_enterprise <> v_defender) THEN
    ROLLBACK; SELECT 0 AS ok, 'war_not_active' AS errorCode, NULL AS attackerScore, NULL AS defenderScore; LEAVE proc;
  END IF;

  IF p_scoring_enterprise = v_attacker THEN
    SET v_attacker_score = v_attacker_score + p_points;
  ELSE
    SET v_defender_score = v_defender_score + p_points;
  END IF;

  UPDATE cen_wars SET attacker_score = v_attacker_score, defender_score = v_defender_score
    WHERE id = p_war_id AND status = 'active';
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode, NULL AS attackerScore, NULL AS defenderScore; LEAVE proc;
  END IF;
  INSERT INTO cen_war_events (war_id, scoring_enterprise_id, event_type, points, metadata)
    VALUES (p_war_id, p_scoring_enterprise, p_event_type, p_points,
      CASE WHEN p_metadata IS NULL OR p_metadata = '' THEN NULL ELSE p_metadata END);

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode,
    v_attacker_score AS attackerScore, v_defender_score AS defenderScore;
END//

CREATE PROCEDURE `cen_finalize_war`(
  IN p_war_id BIGINT UNSIGNED,
  IN p_post_ceasefire_hours INT UNSIGNED
)
proc: BEGIN
  DECLARE v_attacker BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_defender BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_attacker_stake BIGINT UNSIGNED DEFAULT 0;
  DECLARE v_defender_stake BIGINT UNSIGNED DEFAULT 0;
  DECLARE v_attacker_score INT UNSIGNED DEFAULT 0;
  DECLARE v_defender_score INT UNSIGNED DEFAULT 0;
  DECLARE v_target INT UNSIGNED DEFAULT 0;
  DECLARE v_ends DATETIME DEFAULT NULL;
  DECLARE v_winner BIGINT UNSIGNED DEFAULT 0;
  DECLARE v_low BIGINT UNSIGNED;
  DECLARE v_high BIGINT UNSIGNED;
  DECLARE v_pot BIGINT UNSIGNED DEFAULT 0;
  DECLARE v_low_balance BIGINT DEFAULT NULL;
  DECLARE v_high_balance BIGINT DEFAULT NULL;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode, NULL AS winnerEnterpriseId;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;
  SET v_not_found = 0;
  SELECT attacker_enterprise_id, defender_enterprise_id, attacker_stake, defender_stake,
      attacker_score, defender_score, target_score, ends_at
    INTO v_attacker, v_defender, v_attacker_stake, v_defender_stake,
      v_attacker_score, v_defender_score, v_target, v_ends
    FROM cen_wars WHERE id = p_war_id AND status = 'active' FOR UPDATE;
  IF v_not_found = 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'war_not_found' AS errorCode, NULL AS winnerEnterpriseId; LEAVE proc;
  END IF;
  IF v_ends > UTC_TIMESTAMP() AND v_attacker_score < v_target AND v_defender_score < v_target THEN
    ROLLBACK; SELECT 0 AS ok, 'war_not_active' AS errorCode, NULL AS winnerEnterpriseId; LEAVE proc;
  END IF;

  SET v_low = LEAST(v_attacker, v_defender);
  SET v_high = GREATEST(v_attacker, v_defender);
  SET v_not_found = 0;
  SELECT treasury_balance INTO v_low_balance FROM cen_enterprises WHERE id = v_low FOR UPDATE;
  IF v_not_found = 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode, NULL AS winnerEnterpriseId; LEAVE proc;
  END IF;
  SET v_not_found = 0;
  SELECT treasury_balance INTO v_high_balance FROM cen_enterprises WHERE id = v_high FOR UPDATE;
  IF v_not_found = 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode, NULL AS winnerEnterpriseId; LEAVE proc;
  END IF;

  IF v_attacker_score > v_defender_score THEN SET v_winner = v_attacker;
  ELSEIF v_defender_score > v_attacker_score THEN SET v_winner = v_defender;
  ELSE SET v_winner = 0;
  END IF;

  SET v_pot = v_attacker_stake + v_defender_stake;
  IF v_winner <> 0 THEN
    UPDATE cen_enterprises SET treasury_balance = treasury_balance + v_pot WHERE id = v_winner;
    INSERT INTO cen_treasury_transactions
      (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
      SELECT v_winner, NULL, 'war_payout', v_pot, treasury_balance, 'War victory payout'
        FROM cen_enterprises WHERE id = v_winner;
  ELSE
    UPDATE cen_enterprises SET treasury_balance = treasury_balance + v_attacker_stake WHERE id = v_attacker;
    UPDATE cen_enterprises SET treasury_balance = treasury_balance + v_defender_stake WHERE id = v_defender;
    INSERT INTO cen_treasury_transactions
      (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
      SELECT v_attacker, NULL, 'war_refund', v_attacker_stake, treasury_balance, 'War draw refund'
        FROM cen_enterprises WHERE id = v_attacker;
    INSERT INTO cen_treasury_transactions
      (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
      SELECT v_defender, NULL, 'war_refund', v_defender_stake, treasury_balance, 'War draw refund'
        FROM cen_enterprises WHERE id = v_defender;
  END IF;

  UPDATE cen_wars SET status = 'completed', winner_enterprise_id = NULLIF(v_winner, 0),
      completed_at = UTC_TIMESTAMP() WHERE id = p_war_id AND status = 'active';
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode, NULL AS winnerEnterpriseId; LEAVE proc;
  END IF;

  DELETE FROM cen_diplomacy_relations
    WHERE enterprise_low_id = v_low AND enterprise_high_id = v_high
      AND relation_type = 'enemy' AND established_by = 'war';
  IF p_post_ceasefire_hours > 0 THEN
    INSERT INTO cen_diplomacy_relations
      (enterprise_low_id, enterprise_high_id, relation_type, established_by, expires_at)
      VALUES (v_low, v_high, 'ceasefire', 'war_resolution',
        DATE_ADD(UTC_TIMESTAMP(), INTERVAL p_post_ceasefire_hours HOUR))
      ON DUPLICATE KEY UPDATE relation_type = 'ceasefire', established_by = 'war_resolution',
        expires_at = VALUES(expires_at), updated_at = UTC_TIMESTAMP();
  END IF;

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode, NULLIF(v_winner, 0) AS winnerEnterpriseId;
END//

CREATE PROCEDURE `cen_create_front`(
  IN p_enterprise BIGINT UNSIGNED,
  IN p_member BIGINT UNSIGNED,
  IN p_business_type VARCHAR(40),
  IN p_name VARCHAR(80),
  IN p_cost BIGINT UNSIGNED,
  IN p_capacity BIGINT UNSIGNED,
  IN p_fee_percent DECIMAL(5,2),
  IN p_maximum_fronts INT UNSIGNED
)
proc: BEGIN
  DECLARE v_balance BIGINT DEFAULT NULL;
  DECLARE v_front_count INT DEFAULT 0;
  DECLARE v_front_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode, NULL AS frontId;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;
  SET v_not_found = 0;
  SELECT treasury_balance INTO v_balance FROM cen_enterprises
    WHERE id = p_enterprise AND status = 'active' FOR UPDATE;
  IF v_not_found = 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode, NULL AS frontId; LEAVE proc;
  END IF;
  IF v_balance < p_cost THEN
    ROLLBACK; SELECT 0 AS ok, 'insufficient_funds' AS errorCode, NULL AS frontId; LEAVE proc;
  END IF;

  SELECT COUNT(*) INTO v_front_count FROM cen_front_businesses
    WHERE enterprise_id = p_enterprise AND status <> 'disabled';
  IF v_front_count >= p_maximum_fronts THEN
    ROLLBACK; SELECT 0 AS ok, 'front_limit_reached' AS errorCode, NULL AS frontId; LEAVE proc;
  END IF;
  IF EXISTS (SELECT 1 FROM cen_front_businesses
      WHERE enterprise_id = p_enterprise AND name = p_name) THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode, NULL AS frontId; LEAVE proc;
  END IF;

  UPDATE cen_enterprises SET treasury_balance = treasury_balance - p_cost WHERE id = p_enterprise;
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode, NULL AS frontId; LEAVE proc;
  END IF;
  INSERT INTO cen_treasury_transactions
    (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
    SELECT p_enterprise, p_member, 'front_purchase', p_cost, treasury_balance,
      CONCAT('Purchase front: ', p_name) FROM cen_enterprises WHERE id = p_enterprise;

  INSERT INTO cen_front_businesses
    (enterprise_id, created_by_member_id, business_type, name,
     capacity_per_cycle, processed_this_cycle, cycle_start, fee_percent)
    VALUES (p_enterprise, p_member, p_business_type, p_name,
      p_capacity, 0, UTC_DATE(), p_fee_percent);
  SET v_front_id = LAST_INSERT_ID();

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode, v_front_id AS frontId;
END//

CREATE PROCEDURE `cen_start_laundering_job`(
  IN p_front BIGINT UNSIGNED,
  IN p_enterprise BIGINT UNSIGNED,
  IN p_member BIGINT UNSIGNED,
  IN p_dirty BIGINT UNSIGNED,
  IN p_clean BIGINT UNSIGNED,
  IN p_fee BIGINT UNSIGNED,
  IN p_duration_seconds INT UNSIGNED
)
proc: BEGIN
  DECLARE v_capacity BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_processed BIGINT UNSIGNED DEFAULT 0;
  DECLARE v_cycle DATE DEFAULT NULL;
  DECLARE v_status VARCHAR(16) DEFAULT NULL;
  DECLARE v_job_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode, NULL AS jobId;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;
  SET v_not_found = 0;
  SELECT capacity_per_cycle, processed_this_cycle, cycle_start, status
    INTO v_capacity, v_processed, v_cycle, v_status
    FROM cen_front_businesses WHERE id = p_front AND enterprise_id = p_enterprise FOR UPDATE;
  IF v_not_found = 1 OR v_status <> 'active' THEN
    ROLLBACK; SELECT 0 AS ok, 'front_not_found' AS errorCode, NULL AS jobId; LEAVE proc;
  END IF;

  IF v_cycle <> UTC_DATE() THEN
    SET v_processed = 0;
    UPDATE cen_front_businesses SET processed_this_cycle = 0, cycle_start = UTC_DATE()
      WHERE id = p_front AND enterprise_id = p_enterprise;
  END IF;
  IF v_processed + p_dirty > v_capacity THEN
    ROLLBACK; SELECT 0 AS ok, 'front_capacity' AS errorCode, NULL AS jobId; LEAVE proc;
  END IF;

  INSERT INTO cen_laundering_jobs
    (enterprise_id, front_id, member_id, dirty_amount, clean_amount, fee_amount, ready_at)
    VALUES (p_enterprise, p_front, p_member, p_dirty, p_clean, p_fee,
      DATE_ADD(UTC_TIMESTAMP(), INTERVAL p_duration_seconds SECOND));
  SET v_job_id = LAST_INSERT_ID();
  UPDATE cen_front_businesses SET processed_this_cycle = v_processed + p_dirty
    WHERE id = p_front AND enterprise_id = p_enterprise;
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode, NULL AS jobId; LEAVE proc;
  END IF;

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode, v_job_id AS jobId;
END//

CREATE PROCEDURE `cen_claim_laundering_treasury`(
  IN p_job BIGINT UNSIGNED,
  IN p_enterprise BIGINT UNSIGNED,
  IN p_member BIGINT UNSIGNED,
  IN p_maximum_balance BIGINT UNSIGNED
)
proc: BEGIN
  DECLARE v_clean BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_balance BIGINT DEFAULT NULL;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode, NULL AS cleanAmount;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;
  SET v_not_found = 0;
  SELECT clean_amount INTO v_clean FROM cen_laundering_jobs
    WHERE id = p_job AND enterprise_id = p_enterprise
      AND status IN ('processing','ready') AND ready_at <= UTC_TIMESTAMP() FOR UPDATE;
  IF v_not_found = 1 OR v_clean IS NULL THEN
    ROLLBACK; SELECT 0 AS ok, 'laundering_not_ready' AS errorCode, NULL AS cleanAmount; LEAVE proc;
  END IF;

  SET v_not_found = 0;
  SELECT treasury_balance INTO v_balance FROM cen_enterprises
    WHERE id = p_enterprise AND status = 'active' FOR UPDATE;
  IF v_not_found = 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode, NULL AS cleanAmount; LEAVE proc;
  END IF;
  IF v_balance + v_clean > p_maximum_balance THEN
    ROLLBACK; SELECT 0 AS ok, 'treasury_limit' AS errorCode, NULL AS cleanAmount; LEAVE proc;
  END IF;

  UPDATE cen_laundering_jobs SET status = 'claimed', member_id = p_member,
      claimed_at = UTC_TIMESTAMP() WHERE id = p_job AND status IN ('processing','ready');
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode, NULL AS cleanAmount; LEAVE proc;
  END IF;
  UPDATE cen_enterprises SET treasury_balance = treasury_balance + v_clean WHERE id = p_enterprise;
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode, NULL AS cleanAmount; LEAVE proc;
  END IF;
  INSERT INTO cen_treasury_transactions
    (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
    SELECT p_enterprise, p_member, 'laundering_income', v_clean, treasury_balance,
      'Front-business laundering payout' FROM cen_enterprises WHERE id = p_enterprise;

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode, v_clean AS cleanAmount;
END//

CREATE PROCEDURE `cen_collect_racket`(
  IN p_enterprise BIGINT UNSIGNED,
  IN p_racket BIGINT UNSIGNED,
  IN p_interval_seconds INT UNSIGNED,
  IN p_maximum_balance BIGINT UNSIGNED
)
proc: BEGIN
  DECLARE v_payout BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_heat INT UNSIGNED DEFAULT 0;
  DECLARE v_last_collected DATETIME DEFAULT NULL;
  DECLARE v_owner BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_racket_status VARCHAR(16) DEFAULT NULL;
  DECLARE v_balance BIGINT DEFAULT NULL;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode, NULL AS payoutAmount, NULL AS heat;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;
  SET v_not_found = 0;
  SELECT r.payout_amount, r.heat, r.last_collected_at, z.owner_enterprise_id, r.status
    INTO v_payout, v_heat, v_last_collected, v_owner, v_racket_status
    FROM cen_rackets r JOIN cen_zones z ON z.id = r.zone_id
    WHERE r.id = p_racket AND r.enterprise_id = p_enterprise FOR UPDATE;
  IF v_not_found = 1 OR v_racket_status <> 'active' OR v_owner <> p_enterprise THEN
    ROLLBACK; SELECT 0 AS ok, 'racket_not_found' AS errorCode, NULL AS payoutAmount, NULL AS heat; LEAVE proc;
  END IF;
  IF v_last_collected IS NOT NULL
      AND v_last_collected > DATE_SUB(UTC_TIMESTAMP(), INTERVAL p_interval_seconds SECOND) THEN
    ROLLBACK; SELECT 0 AS ok, 'racket_cooldown' AS errorCode, NULL AS payoutAmount, NULL AS heat; LEAVE proc;
  END IF;

  SET v_not_found = 0;
  SELECT treasury_balance INTO v_balance FROM cen_enterprises
    WHERE id = p_enterprise AND status = 'active' FOR UPDATE;
  IF v_not_found = 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode, NULL AS payoutAmount, NULL AS heat; LEAVE proc;
  END IF;
  IF v_balance + v_payout > p_maximum_balance THEN
    ROLLBACK; SELECT 0 AS ok, 'treasury_limit' AS errorCode, NULL AS payoutAmount, NULL AS heat; LEAVE proc;
  END IF;

  UPDATE cen_rackets SET last_collected_at = UTC_TIMESTAMP()
    WHERE id = p_racket AND enterprise_id = p_enterprise;
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode, NULL AS payoutAmount, NULL AS heat; LEAVE proc;
  END IF;
  UPDATE cen_enterprises SET treasury_balance = treasury_balance + v_payout WHERE id = p_enterprise;
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode, NULL AS payoutAmount, NULL AS heat; LEAVE proc;
  END IF;
  INSERT INTO cen_treasury_transactions
    (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
    SELECT p_enterprise, NULL, 'racket_income', v_payout, treasury_balance,
      CONCAT('Racket collection #', p_racket) FROM cen_enterprises WHERE id = p_enterprise;

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode, v_payout AS payoutAmount, v_heat AS heat;
END//

DELIMITER ;
