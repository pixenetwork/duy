-- v1.1.0 Phase 2: crews/chapters, diplomacy, wars, fronts, laundering and protection rackets.
-- Apply after migrations 002-007. Back up the database first.

CREATE TABLE IF NOT EXISTS `cen_crews` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `enterprise_id` BIGINT UNSIGNED NOT NULL,
  `name` VARCHAR(60) NOT NULL,
  `leader_member_id` BIGINT UNSIGNED NULL,
  `max_members` INT UNSIGNED NOT NULL DEFAULT 8,
  `status` ENUM('active','disabled') NOT NULL DEFAULT 'active',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cen_crew_name` (`enterprise_id`, `name`),
  KEY `idx_cen_crew_enterprise` (`enterprise_id`, `status`),
  CONSTRAINT `fk_cen_crew_enterprise` FOREIGN KEY (`enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_crew_leader` FOREIGN KEY (`leader_member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_crew_members` (
  `crew_id` BIGINT UNSIGNED NOT NULL,
  `member_id` BIGINT UNSIGNED NOT NULL,
  `role` ENUM('leader','member') NOT NULL DEFAULT 'member',
  `joined_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`crew_id`, `member_id`),
  UNIQUE KEY `uq_cen_member_crew` (`member_id`),
  CONSTRAINT `fk_cen_crew_member_crew` FOREIGN KEY (`crew_id`)
    REFERENCES `cen_crews` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_crew_member_member` FOREIGN KEY (`member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_diplomacy_relations` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `enterprise_low_id` BIGINT UNSIGNED NOT NULL,
  `enterprise_high_id` BIGINT UNSIGNED NOT NULL,
  `relation_type` ENUM('allied','enemy','ceasefire') NOT NULL,
  `established_by` VARCHAR(32) NOT NULL DEFAULT 'agreement',
  `expires_at` DATETIME NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cen_diplomacy_pair` (`enterprise_low_id`, `enterprise_high_id`),
  KEY `idx_cen_diplomacy_type` (`relation_type`, `expires_at`),
  CONSTRAINT `fk_cen_diplomacy_low` FOREIGN KEY (`enterprise_low_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_diplomacy_high` FOREIGN KEY (`enterprise_high_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CHECK (`enterprise_low_id` < `enterprise_high_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_diplomacy_proposals` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `proposer_enterprise_id` BIGINT UNSIGNED NOT NULL,
  `target_enterprise_id` BIGINT UNSIGNED NOT NULL,
  `created_by_member_id` BIGINT UNSIGNED NULL,
  `relation_type` ENUM('allied','ceasefire') NOT NULL,
  `message` VARCHAR(180) NULL,
  `status` ENUM('pending','accepted','declined','cancelled','expired') NOT NULL DEFAULT 'pending',
  `expires_at` DATETIME NOT NULL,
  `responded_at` DATETIME NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cen_diplomacy_proposal_target` (`target_enterprise_id`, `status`, `expires_at`),
  KEY `idx_cen_diplomacy_proposal_proposer` (`proposer_enterprise_id`, `status`),
  CONSTRAINT `fk_cen_diplomacy_proposer` FOREIGN KEY (`proposer_enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_diplomacy_target` FOREIGN KEY (`target_enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_diplomacy_creator` FOREIGN KEY (`created_by_member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_wars` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `attacker_enterprise_id` BIGINT UNSIGNED NOT NULL,
  `defender_enterprise_id` BIGINT UNSIGNED NOT NULL,
  `created_by_member_id` BIGINT UNSIGNED NULL,
  `status` ENUM('proposed','active','completed','declined','cancelled','expired') NOT NULL DEFAULT 'proposed',
  `reason` VARCHAR(180) NULL,
  `target_score` INT UNSIGNED NOT NULL DEFAULT 100,
  `attacker_score` INT UNSIGNED NOT NULL DEFAULT 0,
  `defender_score` INT UNSIGNED NOT NULL DEFAULT 0,
  `attacker_stake` BIGINT UNSIGNED NOT NULL DEFAULT 0,
  `defender_stake` BIGINT UNSIGNED NOT NULL DEFAULT 0,
  `winner_enterprise_id` BIGINT UNSIGNED NULL,
  `proposal_expires_at` DATETIME NOT NULL,
  `starts_at` DATETIME NULL,
  `ends_at` DATETIME NULL,
  `completed_at` DATETIME NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cen_war_attacker_status` (`attacker_enterprise_id`, `status`, `created_at`),
  KEY `idx_cen_war_defender_status` (`defender_enterprise_id`, `status`, `created_at`),
  KEY `idx_cen_war_due` (`status`, `ends_at`),
  CONSTRAINT `fk_cen_war_attacker` FOREIGN KEY (`attacker_enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_war_defender` FOREIGN KEY (`defender_enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_war_creator` FOREIGN KEY (`created_by_member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_cen_war_winner` FOREIGN KEY (`winner_enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_war_events` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `war_id` BIGINT UNSIGNED NOT NULL,
  `scoring_enterprise_id` BIGINT UNSIGNED NOT NULL,
  `event_type` VARCHAR(48) NOT NULL,
  `points` INT UNSIGNED NOT NULL,
  `metadata` JSON NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cen_war_event_war` (`war_id`, `created_at`),
  CONSTRAINT `fk_cen_war_event_war` FOREIGN KEY (`war_id`)
    REFERENCES `cen_wars` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_war_event_enterprise` FOREIGN KEY (`scoring_enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_front_businesses` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `enterprise_id` BIGINT UNSIGNED NOT NULL,
  `created_by_member_id` BIGINT UNSIGNED NULL,
  `business_type` VARCHAR(40) NOT NULL,
  `name` VARCHAR(80) NOT NULL,
  `capacity_per_cycle` BIGINT UNSIGNED NOT NULL,
  `processed_this_cycle` BIGINT UNSIGNED NOT NULL DEFAULT 0,
  `cycle_start` DATE NOT NULL,
  `fee_percent` DECIMAL(5,2) NOT NULL DEFAULT 15.00,
  `security_level` INT UNSIGNED NOT NULL DEFAULT 1,
  `status` ENUM('active','disabled','raided') NOT NULL DEFAULT 'active',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cen_front_name` (`enterprise_id`, `name`),
  KEY `idx_cen_front_enterprise` (`enterprise_id`, `status`),
  CONSTRAINT `fk_cen_front_enterprise` FOREIGN KEY (`enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_front_creator` FOREIGN KEY (`created_by_member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_laundering_jobs` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `enterprise_id` BIGINT UNSIGNED NOT NULL,
  `front_id` BIGINT UNSIGNED NOT NULL,
  `member_id` BIGINT UNSIGNED NULL,
  `dirty_amount` BIGINT UNSIGNED NOT NULL,
  `clean_amount` BIGINT UNSIGNED NOT NULL,
  `fee_amount` BIGINT UNSIGNED NOT NULL,
  `status` ENUM('processing','ready','claiming','claimed','cancelled') NOT NULL DEFAULT 'processing',
  `ready_at` DATETIME NOT NULL,
  `claimed_at` DATETIME NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cen_laundering_enterprise` (`enterprise_id`, `status`, `ready_at`),
  CONSTRAINT `fk_cen_laundering_enterprise` FOREIGN KEY (`enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_laundering_front` FOREIGN KEY (`front_id`)
    REFERENCES `cen_front_businesses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_laundering_member` FOREIGN KEY (`member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_rackets` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `enterprise_id` BIGINT UNSIGNED NOT NULL,
  `zone_id` BIGINT UNSIGNED NOT NULL,
  `created_by_member_id` BIGINT UNSIGNED NULL,
  `racket_type` VARCHAR(40) NOT NULL,
  `payout_amount` BIGINT UNSIGNED NOT NULL,
  `heat` INT UNSIGNED NOT NULL DEFAULT 0,
  `status` ENUM('active','disabled') NOT NULL DEFAULT 'active',
  `last_collected_at` DATETIME NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cen_racket_zone` (`zone_id`),
  KEY `idx_cen_racket_enterprise` (`enterprise_id`, `status`),
  CONSTRAINT `fk_cen_racket_enterprise` FOREIGN KEY (`enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_racket_zone` FOREIGN KEY (`zone_id`)
    REFERENCES `cen_zones` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_racket_creator` FOREIGN KEY (`created_by_member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP PROCEDURE IF EXISTS `cen_propose_war`;
DROP PROCEDURE IF EXISTS `cen_respond_war`;
DROP PROCEDURE IF EXISTS `cen_cancel_war`;
DROP PROCEDURE IF EXISTS `cen_finalize_war`;

DELIMITER //

CREATE PROCEDURE `cen_propose_war`(
  IN p_attacker BIGINT UNSIGNED,
  IN p_defender BIGINT UNSIGNED,
  IN p_member BIGINT UNSIGNED,
  IN p_reason VARCHAR(180),
  IN p_target_score INT UNSIGNED,
  IN p_stake BIGINT UNSIGNED,
  IN p_duration_seconds INT UNSIGNED,
  IN p_expiry_hours INT UNSIGNED
)
proc: BEGIN
  DECLARE v_balance BIGINT DEFAULT NULL;
  DECLARE v_war_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode, NULL AS warId;
  END;
  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;
  IF p_attacker = p_defender OR p_target_score < 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_war' AS errorCode, NULL AS warId; LEAVE proc;
  END IF;
  SELECT treasury_balance INTO v_balance FROM cen_enterprises
    WHERE id = p_attacker AND status = 'active' FOR UPDATE;
  IF v_balance IS NULL OR v_balance < p_stake THEN
    ROLLBACK; SELECT 0 AS ok, 'insufficient_funds' AS errorCode, NULL AS warId; LEAVE proc;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM cen_enterprises WHERE id = p_defender AND status = 'active') THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode, NULL AS warId; LEAVE proc;
  END IF;
  IF EXISTS (SELECT 1 FROM cen_wars WHERE status IN ('proposed','active')
      AND ((attacker_enterprise_id = p_attacker AND defender_enterprise_id = p_defender)
        OR (attacker_enterprise_id = p_defender AND defender_enterprise_id = p_attacker))) THEN
    ROLLBACK; SELECT 0 AS ok, 'war_exists' AS errorCode, NULL AS warId; LEAVE proc;
  END IF;
  UPDATE cen_enterprises SET treasury_balance = treasury_balance - p_stake WHERE id = p_attacker;
  INSERT INTO cen_treasury_transactions
    (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
    SELECT p_attacker, p_member, 'war_escrow', p_stake, treasury_balance, 'War proposal stake'
      FROM cen_enterprises WHERE id = p_attacker;
  INSERT INTO cen_wars
    (attacker_enterprise_id, defender_enterprise_id, created_by_member_id, reason,
     target_score, attacker_stake, defender_stake, proposal_expires_at, ends_at)
    VALUES (p_attacker, p_defender, p_member, p_reason, p_target_score, p_stake, p_stake,
      DATE_ADD(UTC_TIMESTAMP(), INTERVAL p_expiry_hours HOUR),
      DATE_ADD(UTC_TIMESTAMP(), INTERVAL p_duration_seconds SECOND));
  SET v_war_id = LAST_INSERT_ID();
  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode, v_war_id AS warId;
END//

CREATE PROCEDURE `cen_respond_war`(
  IN p_war_id BIGINT UNSIGNED,
  IN p_defender BIGINT UNSIGNED,
  IN p_member BIGINT UNSIGNED,
  IN p_accept TINYINT UNSIGNED,
  IN p_duration_seconds INT UNSIGNED
)
proc: BEGIN
  DECLARE v_attacker BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_expected_defender BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_stake BIGINT UNSIGNED DEFAULT 0;
  DECLARE v_balance BIGINT DEFAULT NULL;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode;
  END;
  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;
  SELECT attacker_enterprise_id, defender_enterprise_id, defender_stake
    INTO v_attacker, v_expected_defender, v_stake
    FROM cen_wars WHERE id = p_war_id AND status = 'proposed'
      AND proposal_expires_at > UTC_TIMESTAMP() FOR UPDATE;
  IF v_attacker IS NULL OR v_expected_defender <> p_defender THEN
    ROLLBACK; SELECT 0 AS ok, 'war_not_found' AS errorCode; LEAVE proc;
  END IF;
  IF p_accept = 0 THEN
    UPDATE cen_enterprises SET treasury_balance = treasury_balance + v_stake WHERE id = v_attacker;
    INSERT INTO cen_treasury_transactions
      (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
      SELECT v_attacker, NULL, 'war_refund', v_stake, treasury_balance, 'Declined war refund'
        FROM cen_enterprises WHERE id = v_attacker;
    UPDATE cen_wars SET status = 'declined', completed_at = UTC_TIMESTAMP() WHERE id = p_war_id;
    COMMIT; SELECT 1 AS ok, NULL AS errorCode; LEAVE proc;
  END IF;
  SELECT treasury_balance INTO v_balance FROM cen_enterprises
    WHERE id = p_defender AND status = 'active' FOR UPDATE;
  IF v_balance IS NULL OR v_balance < v_stake THEN
    ROLLBACK; SELECT 0 AS ok, 'insufficient_funds' AS errorCode; LEAVE proc;
  END IF;
  UPDATE cen_enterprises SET treasury_balance = treasury_balance - v_stake WHERE id = p_defender;
  INSERT INTO cen_treasury_transactions
    (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
    SELECT p_defender, p_member, 'war_escrow', v_stake, treasury_balance, 'War acceptance stake'
      FROM cen_enterprises WHERE id = p_defender;
  UPDATE cen_wars SET status = 'active', starts_at = UTC_TIMESTAMP(),
      ends_at = DATE_ADD(UTC_TIMESTAMP(), INTERVAL p_duration_seconds SECOND)
    WHERE id = p_war_id;
  INSERT INTO cen_diplomacy_relations
    (enterprise_low_id, enterprise_high_id, relation_type, established_by)
    VALUES (LEAST(v_attacker, p_defender), GREATEST(v_attacker, p_defender), 'enemy', 'war')
    ON DUPLICATE KEY UPDATE relation_type = 'enemy', established_by = 'war', expires_at = NULL;
  COMMIT; SELECT 1 AS ok, NULL AS errorCode;
END//

CREATE PROCEDURE `cen_cancel_war`(
  IN p_war_id BIGINT UNSIGNED,
  IN p_attacker BIGINT UNSIGNED
)
proc: BEGIN
  DECLARE v_stake BIGINT UNSIGNED DEFAULT 0;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode;
  END;
  START TRANSACTION;
  SELECT attacker_stake INTO v_stake FROM cen_wars
    WHERE id = p_war_id AND attacker_enterprise_id = p_attacker AND status = 'proposed' FOR UPDATE;
  IF v_stake IS NULL THEN
    ROLLBACK; SELECT 0 AS ok, 'war_not_found' AS errorCode; LEAVE proc;
  END IF;
  UPDATE cen_enterprises SET treasury_balance = treasury_balance + v_stake WHERE id = p_attacker;
  INSERT INTO cen_treasury_transactions
    (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
    SELECT p_attacker, NULL, 'war_refund', v_stake, treasury_balance, 'Cancelled war refund'
      FROM cen_enterprises WHERE id = p_attacker;
  UPDATE cen_wars SET status = 'cancelled', completed_at = UTC_TIMESTAMP() WHERE id = p_war_id;
  COMMIT; SELECT 1 AS ok, NULL AS errorCode;
END//

CREATE PROCEDURE `cen_finalize_war`(
  IN p_war_id BIGINT UNSIGNED,
  IN p_winner BIGINT UNSIGNED
)
proc: BEGIN
  DECLARE v_attacker BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_defender BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_attacker_stake BIGINT UNSIGNED DEFAULT 0;
  DECLARE v_defender_stake BIGINT UNSIGNED DEFAULT 0;
  DECLARE v_pot BIGINT UNSIGNED DEFAULT 0;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode;
  END;
  START TRANSACTION;
  SELECT attacker_enterprise_id, defender_enterprise_id, attacker_stake, defender_stake
    INTO v_attacker, v_defender, v_attacker_stake, v_defender_stake
    FROM cen_wars WHERE id = p_war_id AND status = 'active' FOR UPDATE;
  IF v_attacker IS NULL THEN
    ROLLBACK; SELECT 0 AS ok, 'war_not_found' AS errorCode; LEAVE proc;
  END IF;
  SET v_pot = v_attacker_stake + v_defender_stake;
  IF p_winner = v_attacker OR p_winner = v_defender THEN
    UPDATE cen_enterprises SET treasury_balance = treasury_balance + v_pot WHERE id = p_winner;
    INSERT INTO cen_treasury_transactions
      (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
      SELECT p_winner, NULL, 'war_payout', v_pot, treasury_balance, 'War victory payout'
        FROM cen_enterprises WHERE id = p_winner;
  ELSE
    UPDATE cen_enterprises SET treasury_balance = treasury_balance + v_attacker_stake WHERE id = v_attacker;
    UPDATE cen_enterprises SET treasury_balance = treasury_balance + v_defender_stake WHERE id = v_defender;
    INSERT INTO cen_treasury_transactions
      (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
      SELECT v_attacker, NULL, 'war_refund', v_attacker_stake, treasury_balance, 'War draw refund'
        FROM cen_enterprises WHERE id = v_attacker;
    INSERT INTO cen_treasury_transactions
      (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
      SELECT v_defender, NULL, 'war_refund', v_defender_stake, treasury_balance, 'War draw refund'
        FROM cen_enterprises WHERE id = v_defender;
  END IF;
  UPDATE cen_wars SET status = 'completed', winner_enterprise_id = NULLIF(p_winner, 0),
      completed_at = UTC_TIMESTAMP() WHERE id = p_war_id;
  COMMIT; SELECT 1 AS ok, NULL AS errorCode;
END//

DELIMITER ;
