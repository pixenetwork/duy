-- v1.1.0 Phase 2 hardening.
-- Replaces vulnerable multi-statement crew, diplomacy, war, front, laundering,
-- and racket mutations with affected-row-verified transactions.
-- Apply after migration 008. Back up the database first.

-- Clean hidden memberships left by pre-hardening disabled crews.
DELETE cm FROM `cen_crew_members` cm
JOIN `cen_crews` c ON c.id = cm.crew_id
WHERE c.status = 'disabled';

DELETE cm FROM `cen_crew_members` cm
JOIN `cen_members` m ON m.id = cm.member_id
WHERE m.status <> 'active';

UPDATE `cen_crews` c
LEFT JOIN `cen_members` leader
  ON leader.id = c.leader_member_id AND leader.status = 'active'
SET c.leader_member_id = NULL
WHERE c.status = 'active' AND c.leader_member_id IS NOT NULL AND leader.id IS NULL;

DROP PROCEDURE IF EXISTS `cen_remove_enterprise_member`;
DROP PROCEDURE IF EXISTS `cen_soft_disband_enterprise`;
DROP PROCEDURE IF EXISTS `cen_create_crew`;
DROP PROCEDURE IF EXISTS `cen_assign_crew_member`;
DROP PROCEDURE IF EXISTS `cen_remove_crew_member`;
DROP PROCEDURE IF EXISTS `cen_delete_crew`;
DROP PROCEDURE IF EXISTS `cen_set_crew_leader`;
DROP PROCEDURE IF EXISTS `cen_propose_diplomacy`;
DROP PROCEDURE IF EXISTS `cen_respond_diplomacy`;
DROP PROCEDURE IF EXISTS `cen_end_diplomacy`;
DROP PROCEDURE IF EXISTS `cen_cancel_diplomacy`;
DROP PROCEDURE IF EXISTS `cen_propose_war`;
DROP PROCEDURE IF EXISTS `cen_respond_war`;
DROP PROCEDURE IF EXISTS `cen_cancel_war`;
DROP PROCEDURE IF EXISTS `cen_add_war_score`;
DROP PROCEDURE IF EXISTS `cen_finalize_war`;
DROP PROCEDURE IF EXISTS `cen_create_front`;
DROP PROCEDURE IF EXISTS `cen_start_laundering_job`;
DROP PROCEDURE IF EXISTS `cen_claim_laundering_treasury`;
DROP PROCEDURE IF EXISTS `cen_collect_racket`;

DELIMITER //


CREATE PROCEDURE `cen_remove_enterprise_member`(
  IN p_enterprise BIGINT UNSIGNED,
  IN p_member BIGINT UNSIGNED
)
proc: BEGIN
  DECLARE v_owner BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_default_rank BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_status VARCHAR(16) DEFAULT NULL;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;
  SET v_not_found = 0;
  SELECT owner_member_id INTO v_owner FROM cen_enterprises
    WHERE id = p_enterprise AND status = 'active' FOR UPDATE;
  IF v_not_found = 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode; LEAVE proc;
  END IF;
  IF v_owner = p_member THEN
    ROLLBACK; SELECT 0 AS ok, 'cannot_manage_owner' AS errorCode; LEAVE proc;
  END IF;

  SET v_not_found = 0;
  SELECT status INTO v_status FROM cen_members
    WHERE id = p_member AND enterprise_id = p_enterprise FOR UPDATE;
  IF v_not_found = 1 OR v_status <> 'active' THEN
    ROLLBACK; SELECT 0 AS ok, 'target_not_member' AS errorCode; LEAVE proc;
  END IF;

  SET v_not_found = 0;
  SELECT id INTO v_default_rank FROM cen_ranks
    WHERE enterprise_id = p_enterprise AND is_default = 1 LIMIT 1 FOR UPDATE;
  IF v_not_found = 1 OR v_default_rank IS NULL THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_rank' AS errorCode; LEAVE proc;
  END IF;

  UPDATE cen_crews SET leader_member_id = NULL
    WHERE enterprise_id = p_enterprise AND leader_member_id = p_member AND status = 'active';
  DELETE cm FROM cen_crew_members cm
    JOIN cen_crews c ON c.id = cm.crew_id
    WHERE cm.member_id = p_member AND c.enterprise_id = p_enterprise;
  UPDATE cen_members SET status = 'removed', rank_id = v_default_rank,
      updated_at = UTC_TIMESTAMP()
    WHERE id = p_member AND enterprise_id = p_enterprise AND status = 'active';
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode; LEAVE proc;
  END IF;

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode;
END//

CREATE PROCEDURE `cen_soft_disband_enterprise`(
  IN p_enterprise BIGINT UNSIGNED,
  IN p_owner_member BIGINT UNSIGNED,
  IN p_retention TINYINT UNSIGNED
)
proc: BEGIN
  DECLARE v_owner BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_status VARCHAR(16) DEFAULT NULL;
  DECLARE v_retention_status VARCHAR(24) DEFAULT NULL;
  DECLARE v_due DATETIME DEFAULT NULL;
  DECLARE v_default_rank BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;
  SET v_not_found = 0;
  SELECT owner_member_id, status, retention_status, disband_scheduled_at
    INTO v_owner, v_status, v_retention_status, v_due
    FROM cen_enterprises WHERE id = p_enterprise FOR UPDATE;
  IF v_not_found = 1 OR v_status <> 'active' THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode; LEAVE proc;
  END IF;
  IF p_retention = 1 THEN
    IF v_retention_status <> 'pending_disband' OR v_due IS NULL OR v_due > UTC_TIMESTAMP() THEN
      ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode; LEAVE proc;
    END IF;
  ELSEIF v_owner <> p_owner_member THEN
    ROLLBACK; SELECT 0 AS ok, 'owner_only' AS errorCode; LEAVE proc;
  END IF;

  IF EXISTS (SELECT 1 FROM cen_wars
      WHERE status IN ('proposed','active')
        AND (attacker_enterprise_id = p_enterprise OR defender_enterprise_id = p_enterprise)) THEN
    ROLLBACK; SELECT 0 AS ok, 'enterprise_in_conflict' AS errorCode; LEAVE proc;
  END IF;

  SET v_not_found = 0;
  SELECT id INTO v_default_rank FROM cen_ranks
    WHERE enterprise_id = p_enterprise AND is_default = 1 LIMIT 1 FOR UPDATE;
  IF v_not_found = 1 OR v_default_rank IS NULL THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_rank' AS errorCode; LEAVE proc;
  END IF;

  UPDATE cen_enterprises SET status = 'disbanded', retention_status = 'disbanded',
      disbanded_at = UTC_TIMESTAMP(), updated_at = UTC_TIMESTAMP()
    WHERE id = p_enterprise AND status = 'active';
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode; LEAVE proc;
  END IF;
  UPDATE cen_members SET status = 'removed', rank_id = v_default_rank,
      updated_at = UTC_TIMESTAMP()
    WHERE enterprise_id = p_enterprise AND status IN ('active','suspended');
  UPDATE cen_membership_invites SET status = 'cancelled', responded_at = UTC_TIMESTAMP()
    WHERE enterprise_id = p_enterprise AND status = 'pending';
  UPDATE cen_diplomacy_proposals SET status = 'cancelled', responded_at = UTC_TIMESTAMP()
    WHERE status = 'pending'
      AND (proposer_enterprise_id = p_enterprise OR target_enterprise_id = p_enterprise);
  DELETE FROM cen_diplomacy_relations
    WHERE enterprise_low_id = p_enterprise OR enterprise_high_id = p_enterprise;
  UPDATE cen_corruption_offers SET status = 'cancelled'
    WHERE enterprise_id = p_enterprise AND status = 'pending';

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode;
END//

CREATE PROCEDURE `cen_create_crew`(
  IN p_enterprise BIGINT UNSIGNED,
  IN p_name VARCHAR(60),
  IN p_leader BIGINT UNSIGNED,
  IN p_max_members INT UNSIGNED,
  IN p_max_crews INT UNSIGNED
)
proc: BEGIN
  DECLARE v_enterprise_exists INT DEFAULT 0;
  DECLARE v_leader_exists INT DEFAULT 0;
  DECLARE v_crew_count INT DEFAULT 0;
  DECLARE v_crew_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode, NULL AS crewId;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;

  SELECT COUNT(*) INTO v_enterprise_exists
    FROM cen_enterprises WHERE id = p_enterprise AND status = 'active' FOR UPDATE;
  IF v_enterprise_exists <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode, NULL AS crewId; LEAVE proc;
  END IF;

  SELECT COUNT(*) INTO v_leader_exists FROM cen_members
    WHERE id = p_leader AND enterprise_id = p_enterprise AND status = 'active';
  IF v_leader_exists <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'target_not_member' AS errorCode, NULL AS crewId; LEAVE proc;
  END IF;

  SELECT COUNT(*) INTO v_crew_count FROM cen_crews
    WHERE enterprise_id = p_enterprise AND status = 'active';
  IF v_crew_count >= p_max_crews THEN
    ROLLBACK; SELECT 0 AS ok, 'crew_limit_reached' AS errorCode, NULL AS crewId; LEAVE proc;
  END IF;

  IF EXISTS (SELECT 1 FROM cen_crews
      WHERE enterprise_id = p_enterprise AND name = p_name) THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode, NULL AS crewId; LEAVE proc;
  END IF;

  IF EXISTS (SELECT 1 FROM cen_crews
      WHERE enterprise_id = p_enterprise AND status = 'active'
        AND leader_member_id = p_leader) THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode, NULL AS crewId; LEAVE proc;
  END IF;

  DELETE cm FROM cen_crew_members cm
    JOIN cen_crews c ON c.id = cm.crew_id
    WHERE cm.member_id = p_leader AND c.enterprise_id = p_enterprise
      AND c.status = 'active' AND cm.role = 'member';

  INSERT INTO cen_crews (enterprise_id, name, leader_member_id, max_members)
    VALUES (p_enterprise, p_name, p_leader, p_max_members);
  SET v_crew_id = LAST_INSERT_ID();

  INSERT INTO cen_crew_members (crew_id, member_id, role)
    VALUES (v_crew_id, p_leader, 'leader');

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode, v_crew_id AS crewId;
END//

CREATE PROCEDURE `cen_assign_crew_member`(
  IN p_enterprise BIGINT UNSIGNED,
  IN p_crew BIGINT UNSIGNED,
  IN p_member BIGINT UNSIGNED
)
proc: BEGIN
  DECLARE v_max_members INT UNSIGNED DEFAULT NULL;
  DECLARE v_leader BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_member_count INT DEFAULT 0;
  DECLARE v_exists INT DEFAULT 0;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;

  SET v_not_found = 0;
  SELECT max_members, leader_member_id INTO v_max_members, v_leader
    FROM cen_crews WHERE id = p_crew AND enterprise_id = p_enterprise
      AND status = 'active' FOR UPDATE;
  IF v_not_found = 1 OR v_max_members IS NULL THEN
    ROLLBACK; SELECT 0 AS ok, 'crew_not_found' AS errorCode; LEAVE proc;
  END IF;

  SELECT COUNT(*) INTO v_exists FROM cen_members
    WHERE id = p_member AND enterprise_id = p_enterprise AND status = 'active';
  IF v_exists <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'target_not_member' AS errorCode; LEAVE proc;
  END IF;

  IF EXISTS (SELECT 1 FROM cen_crew_members WHERE crew_id = p_crew AND member_id = p_member) THEN
    COMMIT; SELECT 1 AS ok, NULL AS errorCode; LEAVE proc;
  END IF;

  IF EXISTS (SELECT 1 FROM cen_crews
      WHERE enterprise_id = p_enterprise AND status = 'active'
        AND id <> p_crew AND leader_member_id = p_member) THEN
    ROLLBACK; SELECT 0 AS ok, 'forbidden' AS errorCode; LEAVE proc;
  END IF;

  SELECT COUNT(*) INTO v_member_count FROM cen_crew_members WHERE crew_id = p_crew;
  IF v_member_count >= v_max_members THEN
    ROLLBACK; SELECT 0 AS ok, 'crew_full' AS errorCode; LEAVE proc;
  END IF;

  DELETE cm FROM cen_crew_members cm
    JOIN cen_crews c ON c.id = cm.crew_id
    WHERE cm.member_id = p_member AND c.enterprise_id = p_enterprise
      AND c.status = 'active' AND cm.role = 'member';

  INSERT INTO cen_crew_members (crew_id, member_id, role)
    VALUES (p_crew, p_member, IF(v_leader = p_member, 'leader', 'member'));

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode;
END//

CREATE PROCEDURE `cen_remove_crew_member`(
  IN p_enterprise BIGINT UNSIGNED,
  IN p_crew BIGINT UNSIGNED,
  IN p_member BIGINT UNSIGNED
)
proc: BEGIN
  DECLARE v_leader BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode;
  END;

  START TRANSACTION;
  SET v_not_found = 0;
  SELECT leader_member_id INTO v_leader FROM cen_crews
    WHERE id = p_crew AND enterprise_id = p_enterprise AND status = 'active' FOR UPDATE;
  IF v_not_found = 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'crew_not_found' AS errorCode; LEAVE proc;
  END IF;
  IF v_leader = p_member THEN
    ROLLBACK; SELECT 0 AS ok, 'forbidden' AS errorCode; LEAVE proc;
  END IF;

  DELETE FROM cen_crew_members WHERE crew_id = p_crew AND member_id = p_member;
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'target_not_member' AS errorCode; LEAVE proc;
  END IF;

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode;
END//

CREATE PROCEDURE `cen_delete_crew`(
  IN p_enterprise BIGINT UNSIGNED,
  IN p_crew BIGINT UNSIGNED
)
proc: BEGIN
  DECLARE v_exists INT DEFAULT 0;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode;
  END;

  START TRANSACTION;
  SELECT COUNT(*) INTO v_exists FROM cen_crews
    WHERE id = p_crew AND enterprise_id = p_enterprise AND status = 'active' FOR UPDATE;
  IF v_exists <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'crew_not_found' AS errorCode; LEAVE proc;
  END IF;

  DELETE FROM cen_crew_members WHERE crew_id = p_crew;
  UPDATE cen_crews SET status = 'disabled', leader_member_id = NULL
    WHERE id = p_crew AND enterprise_id = p_enterprise AND status = 'active';
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode; LEAVE proc;
  END IF;

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode;
END//


CREATE PROCEDURE `cen_set_crew_leader`(
  IN p_enterprise BIGINT UNSIGNED,
  IN p_crew BIGINT UNSIGNED,
  IN p_member BIGINT UNSIGNED
)
proc: BEGIN
  DECLARE v_old_leader BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_max_members INT UNSIGNED DEFAULT NULL;
  DECLARE v_member_count INT DEFAULT 0;
  DECLARE v_member_exists INT DEFAULT 0;
  DECLARE v_target_in_crew INT DEFAULT 0;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;
  SET v_not_found = 0;
  SELECT leader_member_id, max_members INTO v_old_leader, v_max_members
    FROM cen_crews WHERE id = p_crew AND enterprise_id = p_enterprise
      AND status = 'active' FOR UPDATE;
  IF v_not_found = 1 OR v_max_members IS NULL THEN
    ROLLBACK; SELECT 0 AS ok, 'crew_not_found' AS errorCode; LEAVE proc;
  END IF;
  IF v_old_leader = p_member THEN
    COMMIT; SELECT 1 AS ok, NULL AS errorCode; LEAVE proc;
  END IF;

  SELECT COUNT(*) INTO v_member_exists FROM cen_members
    WHERE id = p_member AND enterprise_id = p_enterprise AND status = 'active';
  IF v_member_exists <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'target_not_member' AS errorCode; LEAVE proc;
  END IF;

  IF EXISTS (SELECT 1 FROM cen_crews WHERE enterprise_id = p_enterprise
      AND id <> p_crew AND leader_member_id = p_member AND status = 'active') THEN
    ROLLBACK; SELECT 0 AS ok, 'forbidden' AS errorCode; LEAVE proc;
  END IF;

  SELECT COUNT(*) INTO v_target_in_crew FROM cen_crew_members
    WHERE crew_id = p_crew AND member_id = p_member;
  SELECT COUNT(*) INTO v_member_count FROM cen_crew_members WHERE crew_id = p_crew;
  IF v_target_in_crew = 0 AND v_member_count >= v_max_members THEN
    ROLLBACK; SELECT 0 AS ok, 'crew_full' AS errorCode; LEAVE proc;
  END IF;

  DELETE cm FROM cen_crew_members cm
    JOIN cen_crews c ON c.id = cm.crew_id
    WHERE cm.member_id = p_member AND c.enterprise_id = p_enterprise
      AND c.id <> p_crew AND c.status = 'active' AND cm.role = 'member';

  IF v_old_leader IS NOT NULL AND v_old_leader <> p_member THEN
    UPDATE cen_crew_members SET role = 'member'
      WHERE crew_id = p_crew AND member_id = v_old_leader;
  END IF;

  INSERT INTO cen_crew_members (crew_id, member_id, role)
    VALUES (p_crew, p_member, 'leader')
    ON DUPLICATE KEY UPDATE role = 'leader';
  UPDATE cen_crews SET leader_member_id = p_member
    WHERE id = p_crew AND enterprise_id = p_enterprise AND status = 'active';
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode; LEAVE proc;
  END IF;

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode;
END//

CREATE PROCEDURE `cen_propose_diplomacy`(
  IN p_proposer BIGINT UNSIGNED,
  IN p_target BIGINT UNSIGNED,
  IN p_member BIGINT UNSIGNED,
  IN p_relation VARCHAR(16),
  IN p_message VARCHAR(180),
  IN p_expiry_hours INT UNSIGNED,
  IN p_cooldown_seconds INT UNSIGNED
)
proc: BEGIN
  DECLARE v_low BIGINT UNSIGNED;
  DECLARE v_high BIGINT UNSIGNED;
  DECLARE v_low_status VARCHAR(24) DEFAULT NULL;
  DECLARE v_high_status VARCHAR(24) DEFAULT NULL;
  DECLARE v_proposal_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode, NULL AS proposalId;
  END;

  IF p_proposer = p_target OR p_relation NOT IN ('allied','ceasefire') THEN
    SELECT 0 AS ok, 'bad_request' AS errorCode, NULL AS proposalId; LEAVE proc;
  END IF;

  SET v_low = LEAST(p_proposer, p_target);
  SET v_high = GREATEST(p_proposer, p_target);
  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;

  SET v_not_found = 0;
  SELECT status INTO v_low_status FROM cen_enterprises WHERE id = v_low FOR UPDATE;
  IF v_not_found = 1 OR v_low_status <> 'active' THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode, NULL AS proposalId; LEAVE proc;
  END IF;
  SET v_not_found = 0;
  SELECT status INTO v_high_status FROM cen_enterprises WHERE id = v_high FOR UPDATE;
  IF v_not_found = 1 OR v_high_status <> 'active' THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode, NULL AS proposalId; LEAVE proc;
  END IF;

  IF EXISTS (SELECT 1 FROM cen_wars WHERE status IN ('proposed','active')
      AND ((attacker_enterprise_id = v_low AND defender_enterprise_id = v_high)
        OR (attacker_enterprise_id = v_high AND defender_enterprise_id = v_low))) THEN
    ROLLBACK; SELECT 0 AS ok, 'war_exists' AS errorCode, NULL AS proposalId; LEAVE proc;
  END IF;

  IF EXISTS (SELECT 1 FROM cen_diplomacy_relations
      WHERE enterprise_low_id = v_low AND enterprise_high_id = v_high
        AND (expires_at IS NULL OR expires_at > UTC_TIMESTAMP())) THEN
    ROLLBACK; SELECT 0 AS ok, 'diplomacy_exists' AS errorCode, NULL AS proposalId; LEAVE proc;
  END IF;

  IF EXISTS (SELECT 1 FROM cen_diplomacy_proposals
      WHERE status = 'pending' AND expires_at > UTC_TIMESTAMP()
        AND ((proposer_enterprise_id = p_proposer AND target_enterprise_id = p_target)
          OR (proposer_enterprise_id = p_target AND target_enterprise_id = p_proposer))) THEN
    ROLLBACK; SELECT 0 AS ok, 'diplomacy_exists' AS errorCode, NULL AS proposalId; LEAVE proc;
  END IF;

  IF p_cooldown_seconds > 0 AND EXISTS (SELECT 1 FROM cen_diplomacy_proposals
      WHERE created_at > DATE_SUB(UTC_TIMESTAMP(), INTERVAL p_cooldown_seconds SECOND)
        AND status IN ('declined','cancelled','expired')
        AND ((proposer_enterprise_id = p_proposer AND target_enterprise_id = p_target)
          OR (proposer_enterprise_id = p_target AND target_enterprise_id = p_proposer))) THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode, NULL AS proposalId; LEAVE proc;
  END IF;

  INSERT INTO cen_diplomacy_proposals
    (proposer_enterprise_id, target_enterprise_id, created_by_member_id,
     relation_type, message, expires_at)
    VALUES (p_proposer, p_target, p_member, p_relation, p_message,
      DATE_ADD(UTC_TIMESTAMP(), INTERVAL p_expiry_hours HOUR));
  SET v_proposal_id = LAST_INSERT_ID();

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode, v_proposal_id AS proposalId;
END//

CREATE PROCEDURE `cen_respond_diplomacy`(
  IN p_proposal BIGINT UNSIGNED,
  IN p_target BIGINT UNSIGNED,
  IN p_accept TINYINT UNSIGNED,
  IN p_ceasefire_hours INT UNSIGNED
)
proc: BEGIN
  DECLARE v_proposer BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_expected_target BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_relation VARCHAR(16) DEFAULT NULL;
  DECLARE v_low BIGINT UNSIGNED;
  DECLARE v_high BIGINT UNSIGNED;
  DECLARE v_status VARCHAR(24) DEFAULT NULL;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;

  SET v_not_found = 0;
  SELECT proposer_enterprise_id, target_enterprise_id, relation_type
    INTO v_proposer, v_expected_target, v_relation
    FROM cen_diplomacy_proposals
    WHERE id = p_proposal AND status = 'pending' AND expires_at > UTC_TIMESTAMP()
    FOR UPDATE;
  IF v_not_found = 1 OR v_expected_target <> p_target THEN
    ROLLBACK; SELECT 0 AS ok, 'diplomacy_not_found' AS errorCode; LEAVE proc;
  END IF;

  IF p_accept = 0 THEN
    UPDATE cen_diplomacy_proposals SET status = 'declined', responded_at = UTC_TIMESTAMP()
      WHERE id = p_proposal AND status = 'pending';
    IF ROW_COUNT() <> 1 THEN
      ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode; LEAVE proc;
    END IF;
    COMMIT; SELECT 1 AS ok, NULL AS errorCode; LEAVE proc;
  END IF;

  SET v_low = LEAST(v_proposer, p_target);
  SET v_high = GREATEST(v_proposer, p_target);

  SET v_not_found = 0;
  SELECT status INTO v_status FROM cen_enterprises WHERE id = v_low FOR UPDATE;
  IF v_not_found = 1 OR v_status <> 'active' THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode; LEAVE proc;
  END IF;
  SET v_not_found = 0;
  SELECT status INTO v_status FROM cen_enterprises WHERE id = v_high FOR UPDATE;
  IF v_not_found = 1 OR v_status <> 'active' THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode; LEAVE proc;
  END IF;

  IF EXISTS (SELECT 1 FROM cen_wars WHERE status IN ('proposed','active')
      AND ((attacker_enterprise_id = v_low AND defender_enterprise_id = v_high)
        OR (attacker_enterprise_id = v_high AND defender_enterprise_id = v_low))) THEN
    ROLLBACK; SELECT 0 AS ok, 'war_exists' AS errorCode; LEAVE proc;
  END IF;

  UPDATE cen_diplomacy_proposals SET status = 'accepted', responded_at = UTC_TIMESTAMP()
    WHERE id = p_proposal AND status = 'pending';
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode; LEAVE proc;
  END IF;

  INSERT INTO cen_diplomacy_relations
    (enterprise_low_id, enterprise_high_id, relation_type, established_by, expires_at)
    VALUES (v_low, v_high, v_relation, 'agreement',
      IF(v_relation = 'ceasefire', DATE_ADD(UTC_TIMESTAMP(), INTERVAL p_ceasefire_hours HOUR), NULL))
    ON DUPLICATE KEY UPDATE relation_type = VALUES(relation_type), established_by = 'agreement',
      expires_at = VALUES(expires_at), updated_at = UTC_TIMESTAMP();

  UPDATE cen_diplomacy_proposals SET status = 'cancelled', responded_at = UTC_TIMESTAMP()
    WHERE id <> p_proposal AND status = 'pending'
      AND ((proposer_enterprise_id = v_low AND target_enterprise_id = v_high)
        OR (proposer_enterprise_id = v_high AND target_enterprise_id = v_low));

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode;
END//

CREATE PROCEDURE `cen_end_diplomacy`(
  IN p_enterprise BIGINT UNSIGNED,
  IN p_relation BIGINT UNSIGNED
)
proc: BEGIN
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode;
  END;
  START TRANSACTION;
  DELETE FROM cen_diplomacy_relations
    WHERE id = p_relation AND established_by <> 'war'
      AND (enterprise_low_id = p_enterprise OR enterprise_high_id = p_enterprise);
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'forbidden' AS errorCode; LEAVE proc;
  END IF;
  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode;
END//


CREATE PROCEDURE `cen_cancel_diplomacy`(
  IN p_proposal BIGINT UNSIGNED,
  IN p_proposer BIGINT UNSIGNED
)
proc: BEGIN
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode;
  END;
  START TRANSACTION;
  UPDATE cen_diplomacy_proposals SET status = 'cancelled', responded_at = UTC_TIMESTAMP()
    WHERE id = p_proposal AND proposer_enterprise_id = p_proposer
      AND status = 'pending' AND expires_at > UTC_TIMESTAMP();
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'diplomacy_not_found' AS errorCode; LEAVE proc;
  END IF;
  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode;
END//

CREATE PROCEDURE `cen_propose_war`(
  IN p_attacker BIGINT UNSIGNED,
  IN p_defender BIGINT UNSIGNED,
  IN p_member BIGINT UNSIGNED,
  IN p_reason VARCHAR(180),
  IN p_target_score INT UNSIGNED,
  IN p_stake BIGINT UNSIGNED,
  IN p_duration_seconds INT UNSIGNED,
  IN p_expiry_hours INT UNSIGNED
)
proc: BEGIN
  DECLARE v_low BIGINT UNSIGNED;
  DECLARE v_high BIGINT UNSIGNED;
  DECLARE v_low_balance BIGINT DEFAULT NULL;
  DECLARE v_high_balance BIGINT DEFAULT NULL;
  DECLARE v_low_status VARCHAR(24) DEFAULT NULL;
  DECLARE v_high_status VARCHAR(24) DEFAULT NULL;
  DECLARE v_attacker_balance BIGINT DEFAULT NULL;
  DECLARE v_war_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode, NULL AS warId;
  END;

  IF p_attacker = p_defender OR p_target_score < 1 THEN
    SELECT 0 AS ok, 'invalid_war' AS errorCode, NULL AS warId; LEAVE proc;
  END IF;

  SET v_low = LEAST(p_attacker, p_defender);
  SET v_high = GREATEST(p_attacker, p_defender);
  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;

  SET v_not_found = 0;
  SELECT treasury_balance, status INTO v_low_balance, v_low_status
    FROM cen_enterprises WHERE id = v_low FOR UPDATE;
  IF v_not_found = 1 OR v_low_status <> 'active' THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode, NULL AS warId; LEAVE proc;
  END IF;
  SET v_not_found = 0;
  SELECT treasury_balance, status INTO v_high_balance, v_high_status
    FROM cen_enterprises WHERE id = v_high FOR UPDATE;
  IF v_not_found = 1 OR v_high_status <> 'active' THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode, NULL AS warId; LEAVE proc;
  END IF;

  SET v_attacker_balance = IF(p_attacker = v_low, v_low_balance, v_high_balance);
  IF v_attacker_balance < p_stake THEN
    ROLLBACK; SELECT 0 AS ok, 'insufficient_funds' AS errorCode, NULL AS warId; LEAVE proc;
  END IF;

  IF EXISTS (SELECT 1 FROM cen_diplomacy_relations
      WHERE enterprise_low_id = v_low AND enterprise_high_id = v_high
        AND relation_type IN ('allied','ceasefire')
        AND (expires_at IS NULL OR expires_at > UTC_TIMESTAMP())) THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_war' AS errorCode, NULL AS warId; LEAVE proc;
  END IF;

  IF EXISTS (SELECT 1 FROM cen_wars WHERE status IN ('proposed','active')
      AND ((attacker_enterprise_id = p_attacker AND defender_enterprise_id = p_defender)
        OR (attacker_enterprise_id = p_defender AND defender_enterprise_id = p_attacker))) THEN
    ROLLBACK; SELECT 0 AS ok, 'war_exists' AS errorCode, NULL AS warId; LEAVE proc;
  END IF;

  UPDATE cen_enterprises SET treasury_balance = treasury_balance - p_stake
    WHERE id = p_attacker AND status = 'active';
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode, NULL AS warId; LEAVE proc;
  END IF;

  INSERT INTO cen_treasury_transactions
    (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
    SELECT p_attacker, p_member, 'war_escrow', p_stake, treasury_balance, 'War proposal stake'
      FROM cen_enterprises WHERE id = p_attacker;

  INSERT INTO cen_wars
    (attacker_enterprise_id, defender_enterprise_id, created_by_member_id, reason,
     target_score, attacker_stake, defender_stake, proposal_expires_at, ends_at)
    VALUES (p_attacker, p_defender, p_member, p_reason, p_target_score, p_stake, p_stake,
      DATE_ADD(UTC_TIMESTAMP(), INTERVAL p_expiry_hours HOUR),
      DATE_ADD(UTC_TIMESTAMP(), INTERVAL p_duration_seconds SECOND));
  SET v_war_id = LAST_INSERT_ID();

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode, v_war_id AS warId;
END//

CREATE PROCEDURE `cen_respond_war`(
  IN p_war_id BIGINT UNSIGNED,
  IN p_defender BIGINT UNSIGNED,
  IN p_member BIGINT UNSIGNED,
  IN p_accept TINYINT UNSIGNED,
  IN p_duration_seconds INT UNSIGNED
)
proc: BEGIN
  DECLARE v_attacker BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_expected_defender BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_stake BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_low BIGINT UNSIGNED;
  DECLARE v_high BIGINT UNSIGNED;
  DECLARE v_low_balance BIGINT DEFAULT NULL;
  DECLARE v_high_balance BIGINT DEFAULT NULL;
  DECLARE v_low_status VARCHAR(24) DEFAULT NULL;
  DECLARE v_high_status VARCHAR(24) DEFAULT NULL;
  DECLARE v_defender_balance BIGINT DEFAULT NULL;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;

  SET v_not_found = 0;
  SELECT attacker_enterprise_id, defender_enterprise_id, defender_stake
    INTO v_attacker, v_expected_defender, v_stake
    FROM cen_wars WHERE id = p_war_id AND status = 'proposed'
      AND proposal_expires_at > UTC_TIMESTAMP() FOR UPDATE;
  IF v_not_found = 1 OR v_expected_defender <> p_defender THEN
    ROLLBACK; SELECT 0 AS ok, 'war_not_found' AS errorCode; LEAVE proc;
  END IF;

  SET v_low = LEAST(v_attacker, p_defender);
  SET v_high = GREATEST(v_attacker, p_defender);

  SET v_not_found = 0;
  SELECT treasury_balance, status INTO v_low_balance, v_low_status
    FROM cen_enterprises WHERE id = v_low FOR UPDATE;
  IF v_not_found = 1 OR v_low_status <> 'active' THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode; LEAVE proc;
  END IF;
  SET v_not_found = 0;
  SELECT treasury_balance, status INTO v_high_balance, v_high_status
    FROM cen_enterprises WHERE id = v_high FOR UPDATE;
  IF v_not_found = 1 OR v_high_status <> 'active' THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode; LEAVE proc;
  END IF;

  IF p_accept = 0 THEN
    UPDATE cen_enterprises SET treasury_balance = treasury_balance + v_stake WHERE id = v_attacker;
    INSERT INTO cen_treasury_transactions
      (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
      SELECT v_attacker, NULL, 'war_refund', v_stake, treasury_balance, 'Declined war refund'
        FROM cen_enterprises WHERE id = v_attacker;
    UPDATE cen_wars SET status = 'declined', completed_at = UTC_TIMESTAMP()
      WHERE id = p_war_id AND status = 'proposed';
    IF ROW_COUNT() <> 1 THEN
      ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode; LEAVE proc;
    END IF;
    COMMIT; SELECT 1 AS ok, NULL AS errorCode; LEAVE proc;
  END IF;

  SET v_defender_balance = IF(p_defender = v_low, v_low_balance, v_high_balance);
  IF v_defender_balance < v_stake THEN
    ROLLBACK; SELECT 0 AS ok, 'insufficient_funds' AS errorCode; LEAVE proc;
  END IF;

  UPDATE cen_enterprises SET treasury_balance = treasury_balance - v_stake
    WHERE id = p_defender AND status = 'active';
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode; LEAVE proc;
  END IF;

  INSERT INTO cen_treasury_transactions
    (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
    SELECT p_defender, p_member, 'war_escrow', v_stake, treasury_balance, 'War acceptance stake'
      FROM cen_enterprises WHERE id = p_defender;

  UPDATE cen_wars SET status = 'active', starts_at = UTC_TIMESTAMP(),
      ends_at = DATE_ADD(UTC_TIMESTAMP(), INTERVAL p_duration_seconds SECOND)
    WHERE id = p_war_id AND status = 'proposed';
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode; LEAVE proc;
  END IF;

  INSERT INTO cen_diplomacy_relations
    (enterprise_low_id, enterprise_high_id, relation_type, established_by)
    VALUES (v_low, v_high, 'enemy', 'war')
    ON DUPLICATE KEY UPDATE relation_type = 'enemy', established_by = 'war',
      expires_at = NULL, updated_at = UTC_TIMESTAMP();

  UPDATE cen_diplomacy_proposals SET status = 'cancelled', responded_at = UTC_TIMESTAMP()
    WHERE status = 'pending'
      AND ((proposer_enterprise_id = v_low AND target_enterprise_id = v_high)
        OR (proposer_enterprise_id = v_high AND target_enterprise_id = v_low));

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode;
END//

CREATE PROCEDURE `cen_cancel_war`(
  IN p_war_id BIGINT UNSIGNED,
  IN p_attacker BIGINT UNSIGNED
)
proc: BEGIN
  DECLARE v_stake BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_balance BIGINT DEFAULT NULL;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode;
  END;

  START TRANSACTION;
  SET v_not_found = 0;
  SELECT attacker_stake INTO v_stake FROM cen_wars
    WHERE id = p_war_id AND attacker_enterprise_id = p_attacker
      AND status = 'proposed' FOR UPDATE;
  IF v_not_found = 1 OR v_stake IS NULL THEN
    ROLLBACK; SELECT 0 AS ok, 'war_not_found' AS errorCode; LEAVE proc;
  END IF;

  SET v_not_found = 0;
  SELECT treasury_balance INTO v_balance FROM cen_enterprises
    WHERE id = p_attacker AND status = 'active' FOR UPDATE;
  IF v_not_found = 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode; LEAVE proc;
  END IF;
  UPDATE cen_enterprises SET treasury_balance = treasury_balance + v_stake WHERE id = p_attacker;
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode; LEAVE proc;
  END IF;

  INSERT INTO cen_treasury_transactions
    (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
    SELECT p_attacker, NULL, 'war_refund', v_stake, treasury_balance, 'Cancelled war refund'
      FROM cen_enterprises WHERE id = p_attacker;
  UPDATE cen_wars SET status = 'cancelled', completed_at = UTC_TIMESTAMP()
    WHERE id = p_war_id AND status = 'proposed';
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode; LEAVE proc;
  END IF;

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode;
END//

CREATE PROCEDURE `cen_add_war_score`(
  IN p_war_id BIGINT UNSIGNED,
  IN p_scoring_enterprise BIGINT UNSIGNED,
  IN p_event_type VARCHAR(48),
  IN p_points INT UNSIGNED,
  IN p_metadata LONGTEXT
)
proc: BEGIN
  DECLARE v_attacker BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_defender BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_attacker_score INT UNSIGNED DEFAULT 0;
  DECLARE v_defender_score INT UNSIGNED DEFAULT 0;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode, NULL AS attackerScore, NULL AS defenderScore;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;
  SET v_not_found = 0;
  SELECT attacker_enterprise_id, defender_enterprise_id, attacker_score, defender_score
    INTO v_attacker, v_defender, v_attacker_score, v_defender_score
    FROM cen_wars WHERE id = p_war_id AND status = 'active'
      AND ends_at > UTC_TIMESTAMP() FOR UPDATE;
  IF v_not_found = 1 OR (p_scoring_enterprise <> v_attacker AND p_scoring_enterprise <> v_defender) THEN
    ROLLBACK; SELECT 0 AS ok, 'war_not_active' AS errorCode, NULL AS attackerScore, NULL AS defenderScore; LEAVE proc;
  END IF;

  IF p_scoring_enterprise = v_attacker THEN
    SET v_attacker_score = v_attacker_score + p_points;
  ELSE
    SET v_defender_score = v_defender_score + p_points;
  END IF;

  UPDATE cen_wars SET attacker_score = v_attacker_score, defender_score = v_defender_score
    WHERE id = p_war_id AND status = 'active';
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode, NULL AS attackerScore, NULL AS defenderScore; LEAVE proc;
  END IF;
  INSERT INTO cen_war_events (war_id, scoring_enterprise_id, event_type, points, metadata)
    VALUES (p_war_id, p_scoring_enterprise, p_event_type, p_points,
      CASE WHEN p_metadata IS NULL OR p_metadata = '' THEN NULL ELSE p_metadata END);

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode,
    v_attacker_score AS attackerScore, v_defender_score AS defenderScore;
END//

CREATE PROCEDURE `cen_finalize_war`(
  IN p_war_id BIGINT UNSIGNED,
  IN p_post_ceasefire_hours INT UNSIGNED
)
proc: BEGIN
  DECLARE v_attacker BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_defender BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_attacker_stake BIGINT UNSIGNED DEFAULT 0;
  DECLARE v_defender_stake BIGINT UNSIGNED DEFAULT 0;
  DECLARE v_attacker_score INT UNSIGNED DEFAULT 0;
  DECLARE v_defender_score INT UNSIGNED DEFAULT 0;
  DECLARE v_target INT UNSIGNED DEFAULT 0;
  DECLARE v_ends DATETIME DEFAULT NULL;
  DECLARE v_winner BIGINT UNSIGNED DEFAULT 0;
  DECLARE v_low BIGINT UNSIGNED;
  DECLARE v_high BIGINT UNSIGNED;
  DECLARE v_pot BIGINT UNSIGNED DEFAULT 0;
  DECLARE v_low_balance BIGINT DEFAULT NULL;
  DECLARE v_high_balance BIGINT DEFAULT NULL;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode, NULL AS winnerEnterpriseId;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;
  SET v_not_found = 0;
  SELECT attacker_enterprise_id, defender_enterprise_id, attacker_stake, defender_stake,
      attacker_score, defender_score, target_score, ends_at
    INTO v_attacker, v_defender, v_attacker_stake, v_defender_stake,
      v_attacker_score, v_defender_score, v_target, v_ends
    FROM cen_wars WHERE id = p_war_id AND status = 'active' FOR UPDATE;
  IF v_not_found = 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'war_not_found' AS errorCode, NULL AS winnerEnterpriseId; LEAVE proc;
  END IF;
  IF v_ends > UTC_TIMESTAMP() AND v_attacker_score < v_target AND v_defender_score < v_target THEN
    ROLLBACK; SELECT 0 AS ok, 'war_not_active' AS errorCode, NULL AS winnerEnterpriseId; LEAVE proc;
  END IF;

  SET v_low = LEAST(v_attacker, v_defender);
  SET v_high = GREATEST(v_attacker, v_defender);
  SET v_not_found = 0;
  SELECT treasury_balance INTO v_low_balance FROM cen_enterprises WHERE id = v_low FOR UPDATE;
  IF v_not_found = 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode, NULL AS winnerEnterpriseId; LEAVE proc;
  END IF;
  SET v_not_found = 0;
  SELECT treasury_balance INTO v_high_balance FROM cen_enterprises WHERE id = v_high FOR UPDATE;
  IF v_not_found = 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode, NULL AS winnerEnterpriseId; LEAVE proc;
  END IF;

  IF v_attacker_score > v_defender_score THEN SET v_winner = v_attacker;
  ELSEIF v_defender_score > v_attacker_score THEN SET v_winner = v_defender;
  ELSE SET v_winner = 0;
  END IF;

  SET v_pot = v_attacker_stake + v_defender_stake;
  IF v_winner <> 0 THEN
    UPDATE cen_enterprises SET treasury_balance = treasury_balance + v_pot WHERE id = v_winner;
    INSERT INTO cen_treasury_transactions
      (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
      SELECT v_winner, NULL, 'war_payout', v_pot, treasury_balance, 'War victory payout'
        FROM cen_enterprises WHERE id = v_winner;
  ELSE
    UPDATE cen_enterprises SET treasury_balance = treasury_balance + v_attacker_stake WHERE id = v_attacker;
    UPDATE cen_enterprises SET treasury_balance = treasury_balance + v_defender_stake WHERE id = v_defender;
    INSERT INTO cen_treasury_transactions
      (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
      SELECT v_attacker, NULL, 'war_refund', v_attacker_stake, treasury_balance, 'War draw refund'
        FROM cen_enterprises WHERE id = v_attacker;
    INSERT INTO cen_treasury_transactions
      (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
      SELECT v_defender, NULL, 'war_refund', v_defender_stake, treasury_balance, 'War draw refund'
        FROM cen_enterprises WHERE id = v_defender;
  END IF;

  UPDATE cen_wars SET status = 'completed', winner_enterprise_id = NULLIF(v_winner, 0),
      completed_at = UTC_TIMESTAMP() WHERE id = p_war_id AND status = 'active';
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode, NULL AS winnerEnterpriseId; LEAVE proc;
  END IF;

  DELETE FROM cen_diplomacy_relations
    WHERE enterprise_low_id = v_low AND enterprise_high_id = v_high
      AND relation_type = 'enemy' AND established_by = 'war';
  IF p_post_ceasefire_hours > 0 THEN
    INSERT INTO cen_diplomacy_relations
      (enterprise_low_id, enterprise_high_id, relation_type, established_by, expires_at)
      VALUES (v_low, v_high, 'ceasefire', 'war_resolution',
        DATE_ADD(UTC_TIMESTAMP(), INTERVAL p_post_ceasefire_hours HOUR))
      ON DUPLICATE KEY UPDATE relation_type = 'ceasefire', established_by = 'war_resolution',
        expires_at = VALUES(expires_at), updated_at = UTC_TIMESTAMP();
  END IF;

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode, NULLIF(v_winner, 0) AS winnerEnterpriseId;
END//

CREATE PROCEDURE `cen_create_front`(
  IN p_enterprise BIGINT UNSIGNED,
  IN p_member BIGINT UNSIGNED,
  IN p_business_type VARCHAR(40),
  IN p_name VARCHAR(80),
  IN p_cost BIGINT UNSIGNED,
  IN p_capacity BIGINT UNSIGNED,
  IN p_fee_percent DECIMAL(5,2),
  IN p_maximum_fronts INT UNSIGNED
)
proc: BEGIN
  DECLARE v_balance BIGINT DEFAULT NULL;
  DECLARE v_front_count INT DEFAULT 0;
  DECLARE v_front_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode, NULL AS frontId;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;
  SET v_not_found = 0;
  SELECT treasury_balance INTO v_balance FROM cen_enterprises
    WHERE id = p_enterprise AND status = 'active' FOR UPDATE;
  IF v_not_found = 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode, NULL AS frontId; LEAVE proc;
  END IF;
  IF v_balance < p_cost THEN
    ROLLBACK; SELECT 0 AS ok, 'insufficient_funds' AS errorCode, NULL AS frontId; LEAVE proc;
  END IF;

  SELECT COUNT(*) INTO v_front_count FROM cen_front_businesses
    WHERE enterprise_id = p_enterprise AND status <> 'disabled';
  IF v_front_count >= p_maximum_fronts THEN
    ROLLBACK; SELECT 0 AS ok, 'front_limit_reached' AS errorCode, NULL AS frontId; LEAVE proc;
  END IF;
  IF EXISTS (SELECT 1 FROM cen_front_businesses
      WHERE enterprise_id = p_enterprise AND name = p_name) THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode, NULL AS frontId; LEAVE proc;
  END IF;

  UPDATE cen_enterprises SET treasury_balance = treasury_balance - p_cost WHERE id = p_enterprise;
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode, NULL AS frontId; LEAVE proc;
  END IF;
  INSERT INTO cen_treasury_transactions
    (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
    SELECT p_enterprise, p_member, 'front_purchase', p_cost, treasury_balance,
      CONCAT('Purchase front: ', p_name) FROM cen_enterprises WHERE id = p_enterprise;

  INSERT INTO cen_front_businesses
    (enterprise_id, created_by_member_id, business_type, name,
     capacity_per_cycle, processed_this_cycle, cycle_start, fee_percent)
    VALUES (p_enterprise, p_member, p_business_type, p_name,
      p_capacity, 0, UTC_DATE(), p_fee_percent);
  SET v_front_id = LAST_INSERT_ID();

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode, v_front_id AS frontId;
END//

CREATE PROCEDURE `cen_start_laundering_job`(
  IN p_front BIGINT UNSIGNED,
  IN p_enterprise BIGINT UNSIGNED,
  IN p_member BIGINT UNSIGNED,
  IN p_dirty BIGINT UNSIGNED,
  IN p_clean BIGINT UNSIGNED,
  IN p_fee BIGINT UNSIGNED,
  IN p_duration_seconds INT UNSIGNED
)
proc: BEGIN
  DECLARE v_capacity BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_processed BIGINT UNSIGNED DEFAULT 0;
  DECLARE v_cycle DATE DEFAULT NULL;
  DECLARE v_status VARCHAR(16) DEFAULT NULL;
  DECLARE v_job_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode, NULL AS jobId;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;
  SET v_not_found = 0;
  SELECT capacity_per_cycle, processed_this_cycle, cycle_start, status
    INTO v_capacity, v_processed, v_cycle, v_status
    FROM cen_front_businesses WHERE id = p_front AND enterprise_id = p_enterprise FOR UPDATE;
  IF v_not_found = 1 OR v_status <> 'active' THEN
    ROLLBACK; SELECT 0 AS ok, 'front_not_found' AS errorCode, NULL AS jobId; LEAVE proc;
  END IF;

  IF v_cycle <> UTC_DATE() THEN
    SET v_processed = 0;
    UPDATE cen_front_businesses SET processed_this_cycle = 0, cycle_start = UTC_DATE()
      WHERE id = p_front AND enterprise_id = p_enterprise;
  END IF;
  IF v_processed + p_dirty > v_capacity THEN
    ROLLBACK; SELECT 0 AS ok, 'front_capacity' AS errorCode, NULL AS jobId; LEAVE proc;
  END IF;

  INSERT INTO cen_laundering_jobs
    (enterprise_id, front_id, member_id, dirty_amount, clean_amount, fee_amount, ready_at)
    VALUES (p_enterprise, p_front, p_member, p_dirty, p_clean, p_fee,
      DATE_ADD(UTC_TIMESTAMP(), INTERVAL p_duration_seconds SECOND));
  SET v_job_id = LAST_INSERT_ID();
  UPDATE cen_front_businesses SET processed_this_cycle = v_processed + p_dirty
    WHERE id = p_front AND enterprise_id = p_enterprise;
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode, NULL AS jobId; LEAVE proc;
  END IF;

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode, v_job_id AS jobId;
END//

CREATE PROCEDURE `cen_claim_laundering_treasury`(
  IN p_job BIGINT UNSIGNED,
  IN p_enterprise BIGINT UNSIGNED,
  IN p_member BIGINT UNSIGNED,
  IN p_maximum_balance BIGINT UNSIGNED
)
proc: BEGIN
  DECLARE v_clean BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_balance BIGINT DEFAULT NULL;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode, NULL AS cleanAmount;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;
  SET v_not_found = 0;
  SELECT clean_amount INTO v_clean FROM cen_laundering_jobs
    WHERE id = p_job AND enterprise_id = p_enterprise
      AND status IN ('processing','ready') AND ready_at <= UTC_TIMESTAMP() FOR UPDATE;
  IF v_not_found = 1 OR v_clean IS NULL THEN
    ROLLBACK; SELECT 0 AS ok, 'laundering_not_ready' AS errorCode, NULL AS cleanAmount; LEAVE proc;
  END IF;

  SET v_not_found = 0;
  SELECT treasury_balance INTO v_balance FROM cen_enterprises
    WHERE id = p_enterprise AND status = 'active' FOR UPDATE;
  IF v_not_found = 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode, NULL AS cleanAmount; LEAVE proc;
  END IF;
  IF v_balance + v_clean > p_maximum_balance THEN
    ROLLBACK; SELECT 0 AS ok, 'treasury_limit' AS errorCode, NULL AS cleanAmount; LEAVE proc;
  END IF;

  UPDATE cen_laundering_jobs SET status = 'claimed', member_id = p_member,
      claimed_at = UTC_TIMESTAMP() WHERE id = p_job AND status IN ('processing','ready');
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode, NULL AS cleanAmount; LEAVE proc;
  END IF;
  UPDATE cen_enterprises SET treasury_balance = treasury_balance + v_clean WHERE id = p_enterprise;
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode, NULL AS cleanAmount; LEAVE proc;
  END IF;
  INSERT INTO cen_treasury_transactions
    (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
    SELECT p_enterprise, p_member, 'laundering_income', v_clean, treasury_balance,
      'Front-business laundering payout' FROM cen_enterprises WHERE id = p_enterprise;

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode, v_clean AS cleanAmount;
END//

CREATE PROCEDURE `cen_collect_racket`(
  IN p_enterprise BIGINT UNSIGNED,
  IN p_racket BIGINT UNSIGNED,
  IN p_interval_seconds INT UNSIGNED,
  IN p_maximum_balance BIGINT UNSIGNED
)
proc: BEGIN
  DECLARE v_payout BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_heat INT UNSIGNED DEFAULT 0;
  DECLARE v_last_collected DATETIME DEFAULT NULL;
  DECLARE v_owner BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_racket_status VARCHAR(16) DEFAULT NULL;
  DECLARE v_balance BIGINT DEFAULT NULL;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode, NULL AS payoutAmount, NULL AS heat;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;
  SET v_not_found = 0;
  SELECT r.payout_amount, r.heat, r.last_collected_at, z.owner_enterprise_id, r.status
    INTO v_payout, v_heat, v_last_collected, v_owner, v_racket_status
    FROM cen_rackets r JOIN cen_zones z ON z.id = r.zone_id
    WHERE r.id = p_racket AND r.enterprise_id = p_enterprise FOR UPDATE;
  IF v_not_found = 1 OR v_racket_status <> 'active' OR v_owner <> p_enterprise THEN
    ROLLBACK; SELECT 0 AS ok, 'racket_not_found' AS errorCode, NULL AS payoutAmount, NULL AS heat; LEAVE proc;
  END IF;
  IF v_last_collected IS NOT NULL
      AND v_last_collected > DATE_SUB(UTC_TIMESTAMP(), INTERVAL p_interval_seconds SECOND) THEN
    ROLLBACK; SELECT 0 AS ok, 'racket_cooldown' AS errorCode, NULL AS payoutAmount, NULL AS heat; LEAVE proc;
  END IF;

  SET v_not_found = 0;
  SELECT treasury_balance INTO v_balance FROM cen_enterprises
    WHERE id = p_enterprise AND status = 'active' FOR UPDATE;
  IF v_not_found = 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode, NULL AS payoutAmount, NULL AS heat; LEAVE proc;
  END IF;
  IF v_balance + v_payout > p_maximum_balance THEN
    ROLLBACK; SELECT 0 AS ok, 'treasury_limit' AS errorCode, NULL AS payoutAmount, NULL AS heat; LEAVE proc;
  END IF;

  UPDATE cen_rackets SET last_collected_at = UTC_TIMESTAMP()
    WHERE id = p_racket AND enterprise_id = p_enterprise;
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode, NULL AS payoutAmount, NULL AS heat; LEAVE proc;
  END IF;
  UPDATE cen_enterprises SET treasury_balance = treasury_balance + v_payout WHERE id = p_enterprise;
  IF ROW_COUNT() <> 1 THEN
    ROLLBACK; SELECT 0 AS ok, 'conflict' AS errorCode, NULL AS payoutAmount, NULL AS heat; LEAVE proc;
  END IF;
  INSERT INTO cen_treasury_transactions
    (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
    SELECT p_enterprise, NULL, 'racket_income', v_payout, treasury_balance,
      CONCAT('Racket collection #', p_racket) FROM cen_enterprises WHERE id = p_enterprise;

  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode, v_payout AS payoutAmount, v_heat AS heat;
END//

DELIMITER ;
