-- v0.5.0 Core MVP: treasury, progression, audit read model and zone control.
-- Apply after migrations 002-005. Back up the database first.

CREATE TABLE IF NOT EXISTS `cen_treasury_transactions` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `enterprise_id` BIGINT UNSIGNED NOT NULL,
  `actor_member_id` BIGINT UNSIGNED NULL,
  `transaction_type` VARCHAR(32) NOT NULL,
  `amount` BIGINT UNSIGNED NOT NULL,
  `balance_after` BIGINT NOT NULL,
  `note` VARCHAR(120) NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cen_treasury_enterprise_time` (`enterprise_id`, `created_at`),
  KEY `idx_cen_treasury_daily_withdraw` (`enterprise_id`, `transaction_type`, `created_at`),
  CONSTRAINT `fk_cen_treasury_enterprise` FOREIGN KEY (`enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_treasury_member` FOREIGN KEY (`actor_member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_xp_events` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `enterprise_id` BIGINT UNSIGNED NOT NULL,
  `actor_member_id` BIGINT UNSIGNED NULL,
  `amount` INT UNSIGNED NOT NULL,
  `reason` VARCHAR(80) NOT NULL,
  `metadata` JSON NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cen_xp_enterprise_time` (`enterprise_id`, `created_at`),
  CONSTRAINT `fk_cen_xp_enterprise` FOREIGN KEY (`enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_xp_member` FOREIGN KEY (`actor_member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_zones` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `zone_type` ENUM('turf','territory') NOT NULL,
  `name` VARCHAR(80) NOT NULL,
  `center_x` DOUBLE NOT NULL,
  `center_y` DOUBLE NOT NULL,
  `center_z` DOUBLE NOT NULL,
  `radius` DOUBLE NOT NULL DEFAULT 65,
  `owner_enterprise_id` BIGINT UNSIGNED NULL,
  `required_level` INT UNSIGNED NOT NULL DEFAULT 1,
  `capture_duration_seconds` INT UNSIGNED NOT NULL DEFAULT 900,
  `cooldown_seconds` INT UNSIGNED NOT NULL DEFAULT 3600,
  `cooldown_until` DATETIME NULL,
  `last_contested_at` DATETIME NULL,
  `status` ENUM('active','disabled') NOT NULL DEFAULT 'active',
  `metadata` JSON NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cen_zone_name` (`name`),
  KEY `idx_cen_zone_type_status` (`zone_type`, `status`),
  KEY `idx_cen_zone_owner` (`owner_enterprise_id`),
  CONSTRAINT `fk_cen_zone_owner` FOREIGN KEY (`owner_enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_zone_contests` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `zone_id` BIGINT UNSIGNED NOT NULL,
  `attacker_enterprise_id` BIGINT UNSIGNED NOT NULL,
  `defender_enterprise_id` BIGINT UNSIGNED NULL,
  `winner_enterprise_id` BIGINT UNSIGNED NULL,
  `created_by_member_id` BIGINT UNSIGNED NULL,
  `attacker_score` INT UNSIGNED NOT NULL DEFAULT 0,
  `defender_score` INT UNSIGNED NOT NULL DEFAULT 0,
  `status` ENUM('active','completed','cancelled') NOT NULL DEFAULT 'active',
  `starts_at` DATETIME NOT NULL,
  `ends_at` DATETIME NOT NULL,
  `completed_at` DATETIME NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cen_contest_zone_status` (`zone_id`, `status`, `ends_at`),
  KEY `idx_cen_contest_attacker` (`attacker_enterprise_id`, `status`),
  KEY `idx_cen_contest_defender` (`defender_enterprise_id`, `status`),
  CONSTRAINT `fk_cen_contest_zone` FOREIGN KEY (`zone_id`)
    REFERENCES `cen_zones` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_contest_attacker` FOREIGN KEY (`attacker_enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_contest_defender` FOREIGN KEY (`defender_enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_cen_contest_winner` FOREIGN KEY (`winner_enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_cen_contest_creator` FOREIGN KEY (`created_by_member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Existing protected default ranks receive only the safe baseline permissions.
UPDATE `cen_ranks`
SET permissions = JSON_ARRAY_APPEND(permissions, '$', 'storage.access')
WHERE is_default = 1 AND JSON_CONTAINS(permissions, JSON_QUOTE('storage.access')) = 0;

UPDATE `cen_ranks`
SET permissions = JSON_ARRAY_APPEND(permissions, '$', 'progression.view')
WHERE is_default = 1 AND JSON_CONTAINS(permissions, JSON_QUOTE('progression.view')) = 0;

DROP PROCEDURE IF EXISTS `cen_treasury_deposit`;
DROP PROCEDURE IF EXISTS `cen_treasury_withdraw`;

DELIMITER //

CREATE PROCEDURE `cen_treasury_deposit`(
  IN p_enterprise_id BIGINT UNSIGNED,
  IN p_member_id BIGINT UNSIGNED,
  IN p_amount BIGINT UNSIGNED,
  IN p_note VARCHAR(120),
  IN p_maximum_balance BIGINT
)
proc: BEGIN
  DECLARE v_balance BIGINT DEFAULT NULL;
  DECLARE v_status VARCHAR(20) DEFAULT NULL;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode, NULL AS balance;
  END;
  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;
  SELECT treasury_balance, status INTO v_balance, v_status
    FROM cen_enterprises WHERE id = p_enterprise_id FOR UPDATE;
  IF v_balance IS NULL OR v_status <> 'active' THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode, NULL AS balance; LEAVE proc;
  END IF;
  IF p_amount < 1 OR v_balance + p_amount > p_maximum_balance THEN
    ROLLBACK; SELECT 0 AS ok, 'treasury_limit' AS errorCode, v_balance AS balance; LEAVE proc;
  END IF;
  SET v_balance = v_balance + p_amount;
  UPDATE cen_enterprises SET treasury_balance = v_balance WHERE id = p_enterprise_id;
  INSERT INTO cen_treasury_transactions
    (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
  VALUES (p_enterprise_id, p_member_id, 'deposit', p_amount, v_balance, p_note);
  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode, v_balance AS balance;
END//

CREATE PROCEDURE `cen_treasury_withdraw`(
  IN p_enterprise_id BIGINT UNSIGNED,
  IN p_member_id BIGINT UNSIGNED,
  IN p_amount BIGINT UNSIGNED,
  IN p_note VARCHAR(120),
  IN p_daily_limit BIGINT
)
proc: BEGIN
  DECLARE v_balance BIGINT DEFAULT NULL;
  DECLARE v_status VARCHAR(20) DEFAULT NULL;
  DECLARE v_withdrawn_today BIGINT DEFAULT 0;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode, NULL AS balance;
  END;
  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;
  SELECT treasury_balance, status INTO v_balance, v_status
    FROM cen_enterprises WHERE id = p_enterprise_id FOR UPDATE;
  IF v_balance IS NULL OR v_status <> 'active' THEN
    ROLLBACK; SELECT 0 AS ok, 'invalid_enterprise' AS errorCode, NULL AS balance; LEAVE proc;
  END IF;
  SELECT COALESCE(SUM(amount), 0) INTO v_withdrawn_today
    FROM cen_treasury_transactions
    WHERE enterprise_id = p_enterprise_id AND transaction_type = 'withdrawal'
      AND created_at >= UTC_DATE();
  IF p_amount < 1 OR v_balance < p_amount THEN
    ROLLBACK; SELECT 0 AS ok, 'insufficient_funds' AS errorCode, v_balance AS balance; LEAVE proc;
  END IF;
  IF p_daily_limit > 0 AND v_withdrawn_today + p_amount > p_daily_limit THEN
    ROLLBACK; SELECT 0 AS ok, 'treasury_limit' AS errorCode, v_balance AS balance; LEAVE proc;
  END IF;
  SET v_balance = v_balance - p_amount;
  UPDATE cen_enterprises SET treasury_balance = v_balance WHERE id = p_enterprise_id;
  INSERT INTO cen_treasury_transactions
    (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
  VALUES (p_enterprise_id, p_member_id, 'withdrawal', p_amount, v_balance, p_note);
  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode, v_balance AS balance;
END//

DELIMITER ;
