-- Upgrade v0.2.0 to v0.3.0. Back up the database before running.
ALTER TABLE `cen_enterprises`
  ADD COLUMN `creation_plan` VARCHAR(20) NOT NULL DEFAULT 'admin' AFTER `treasury_balance`,
  ADD COLUMN `base_member_limit` SMALLINT UNSIGNED NOT NULL DEFAULT 12 AFTER `creation_plan`,
  ADD COLUMN `retention_required` TINYINT(1) NOT NULL DEFAULT 0 AFTER `base_member_limit`,
  ADD COLUMN `retention_status` VARCHAR(24) NOT NULL DEFAULT 'exempt' AFTER `retention_required`,
  ADD COLUMN `retention_warning_cycle` DATE NULL AFTER `retention_status`,
  ADD COLUMN `retention_failure_cycle` DATE NULL AFTER `retention_warning_cycle`,
  ADD COLUMN `disband_scheduled_at` DATETIME NULL AFTER `retention_failure_cycle`,
  ADD COLUMN `disbanded_at` DATETIME NULL AFTER `disband_scheduled_at`;

CREATE TABLE IF NOT EXISTS `cen_founding_proposals` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `founder_identifier` VARCHAR(80) NOT NULL,
  `founder_display_name` VARCHAR(80) NOT NULL,
  `name` VARCHAR(80) NOT NULL,
  `slug` VARCHAR(80) NOT NULL,
  `enterprise_type` VARCHAR(40) NOT NULL,
  `creation_plan` VARCHAR(20) NOT NULL DEFAULT 'free',
  `required_acceptances` SMALLINT UNSIGNED NOT NULL DEFAULT 8,
  `status` VARCHAR(24) NOT NULL DEFAULT 'pending',
  `finalized_enterprise_id` BIGINT UNSIGNED NULL,
  `expires_at` DATETIME NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_cen_founding_slug` (`slug`),
  KEY `idx_cen_founding_founder_status` (`founder_identifier`, `status`),
  KEY `idx_cen_founding_expiry` (`status`, `expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_founding_invites` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `proposal_id` BIGINT UNSIGNED NOT NULL,
  `invited_identifier` VARCHAR(80) NOT NULL,
  `invited_display_name` VARCHAR(80) NOT NULL,
  `invited_by_identifier` VARCHAR(80) NOT NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'pending',
  `expires_at` DATETIME NOT NULL,
  `responded_at` DATETIME NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_cen_founding_invite` (`proposal_id`, `invited_identifier`),
  KEY `idx_cen_founding_invitee_status` (`invited_identifier`, `status`),
  CONSTRAINT `fk_cen_founding_invite_proposal` FOREIGN KEY (`proposal_id`)
    REFERENCES `cen_founding_proposals` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_enterprise_entitlements` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `enterprise_id` BIGINT UNSIGNED NOT NULL,
  `entitlement_type` VARCHAR(40) NOT NULL,
  `provider` VARCHAR(30) NOT NULL,
  `package_key` VARCHAR(80) NOT NULL,
  `grant_key` VARCHAR(128) NOT NULL,
  `purchaser_identifier` VARCHAR(100) NULL,
  `quantity` INT NOT NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'active',
  `metadata` JSON NULL,
  `expires_at` DATETIME NULL,
  `revoked_at` DATETIME NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_cen_entitlement_grant` (`grant_key`),
  KEY `idx_cen_entitlement_enterprise` (`enterprise_id`, `entitlement_type`, `status`),
  CONSTRAINT `fk_cen_entitlement_enterprise` FOREIGN KEY (`enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_member_activity` (
  `enterprise_id` BIGINT UNSIGNED NOT NULL,
  `member_id` BIGINT UNSIGNED NOT NULL,
  `activity_cycle` DATE NOT NULL,
  `active_minutes` INT UNSIGNED NOT NULL DEFAULT 0,
  `actions_count` INT UNSIGNED NOT NULL DEFAULT 0,
  `last_seen_at` DATETIME NULL,
  PRIMARY KEY (`enterprise_id`, `member_id`, `activity_cycle`),
  KEY `idx_cen_activity_cycle_minutes` (`enterprise_id`, `activity_cycle`, `active_minutes`),
  CONSTRAINT `fk_cen_activity_enterprise` FOREIGN KEY (`enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_activity_member` FOREIGN KEY (`member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
