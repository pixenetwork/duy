-- Upgrade v0.1.0 to v0.2+ membership/rank security model.
-- Back up the database. This migration performs preflight checks and is re-runnable.

DELIMITER $$
DROP PROCEDURE IF EXISTS `cen_migrate_002`$$
CREATE PROCEDURE `cen_migrate_002`()
BEGIN
  DECLARE duplicate_players INT DEFAULT 0;
  DECLARE ownerless_active INT DEFAULT 0;
  DECLARE has_old_owner_column INT DEFAULT 0;
  DECLARE has_old_unique INT DEFAULT 0;
  DECLARE has_new_unique INT DEFAULT 0;

  SELECT COUNT(*) INTO duplicate_players FROM (
    SELECT player_identifier FROM cen_members
    GROUP BY player_identifier HAVING COUNT(*) > 1
  ) duplicates;

  IF duplicate_players > 0 THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'CEN migration blocked: duplicate player memberships must be resolved first';
  END IF;

  ALTER TABLE `cen_enterprises`
    ADD COLUMN IF NOT EXISTS `owner_member_id` BIGINT UNSIGNED NULL AFTER `treasury_balance`;
  ALTER TABLE `cen_enterprises`
    ADD INDEX IF NOT EXISTS `idx_cen_enterprise_owner` (`owner_member_id`);

  ALTER TABLE `cen_ranks`
    ADD COLUMN IF NOT EXISTS `is_default` TINYINT(1) NOT NULL DEFAULT 0 AFTER `permissions`,
    ADD COLUMN IF NOT EXISTS `is_protected` TINYINT(1) NOT NULL DEFAULT 0 AFTER `is_default`,
    ADD COLUMN IF NOT EXISTS `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
      ON UPDATE CURRENT_TIMESTAMP AFTER `created_at`;
  ALTER TABLE `cen_ranks`
    ADD UNIQUE INDEX IF NOT EXISTS `uq_cen_rank_name` (`enterprise_id`, `name`),
    ADD INDEX IF NOT EXISTS `idx_cen_rank_enterprise_priority` (`enterprise_id`, `priority`);

  ALTER TABLE `cen_members`
    ADD COLUMN IF NOT EXISTS `display_name` VARCHAR(80) NOT NULL DEFAULT 'Unknown' AFTER `player_identifier`,
    ADD COLUMN IF NOT EXISTS `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
      ON UPDATE CURRENT_TIMESTAMP AFTER `joined_at`;

  SELECT COUNT(*) INTO has_old_owner_column
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'cen_members' AND COLUMN_NAME = 'is_owner';

  IF has_old_owner_column = 1 THEN
    SET @sql = 'UPDATE cen_enterprises e JOIN cen_members m ON m.enterprise_id = e.id AND m.is_owner = 1 SET e.owner_member_id = m.id WHERE e.owner_member_id IS NULL';
    PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
  END IF;

  -- Deterministic fallback for legacy rows that had no owner flag.
  UPDATE cen_enterprises e
  SET e.owner_member_id = (
    SELECT m.id
    FROM cen_members m
    JOIN cen_ranks r ON r.id = m.rank_id AND r.enterprise_id = m.enterprise_id
    WHERE m.enterprise_id = e.id AND m.status = 'active'
    ORDER BY r.priority DESC, m.joined_at ASC, m.id ASC
    LIMIT 1
  )
  WHERE e.owner_member_id IS NULL;

  DROP TEMPORARY TABLE IF EXISTS `cen_rank_repair`;
  CREATE TEMPORARY TABLE `cen_rank_repair` AS
  SELECT enterprise_ids.enterprise_id,
    (SELECT r_default.id FROM cen_ranks r_default
      WHERE r_default.enterprise_id = enterprise_ids.enterprise_id
      ORDER BY r_default.priority ASC, r_default.id ASC LIMIT 1) AS default_rank_id,
    (SELECT r_owner.id FROM cen_ranks r_owner
      WHERE r_owner.enterprise_id = enterprise_ids.enterprise_id
      ORDER BY r_owner.priority DESC, r_owner.id ASC LIMIT 1) AS owner_rank_id
  FROM (SELECT DISTINCT enterprise_id FROM cen_ranks) enterprise_ids;

  UPDATE cen_ranks r
  JOIN cen_rank_repair repair ON repair.enterprise_id = r.enterprise_id
  SET r.is_default = CASE WHEN r.id = repair.default_rank_id THEN 1 ELSE 0 END,
      r.is_protected = CASE
        WHEN r.id = repair.default_rank_id OR r.id = repair.owner_rank_id THEN 1
        ELSE r.is_protected
      END;

  UPDATE `cen_members` m
JOIN `cen_ranks` default_rank
  ON default_rank.enterprise_id = m.enterprise_id
 AND default_rank.is_default = 1
SET m.rank_id = default_rank.id,
    m.updated_at = CURRENT_TIMESTAMP
WHERE m.status = 'removed';

DROP TEMPORARY TABLE IF EXISTS `cen_rank_repair`;

  SELECT COUNT(*) INTO has_old_unique
  FROM information_schema.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'cen_members'
    AND INDEX_NAME = 'uq_cen_member_enterprise_player';
  IF has_old_unique > 0 THEN
    ALTER TABLE cen_members DROP INDEX `uq_cen_member_enterprise_player`;
  END IF;

  SELECT COUNT(*) INTO has_new_unique
  FROM information_schema.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'cen_members'
    AND INDEX_NAME = 'uq_cen_member_player';
  IF has_new_unique = 0 THEN
    ALTER TABLE cen_members ADD UNIQUE INDEX `uq_cen_member_player` (`player_identifier`);
  END IF;

  ALTER TABLE cen_members
    ADD INDEX IF NOT EXISTS `idx_cen_member_enterprise_status` (`enterprise_id`, `status`);

  IF has_old_owner_column = 1 THEN
    ALTER TABLE cen_members DROP COLUMN `is_owner`;
  END IF;

  SELECT COUNT(*) INTO ownerless_active
  FROM cen_enterprises e
  WHERE e.status = 'active' AND (
    e.owner_member_id IS NULL OR NOT EXISTS (
      SELECT 1 FROM cen_members m
      WHERE m.id = e.owner_member_id AND m.enterprise_id = e.id AND m.status = 'active'
    )
  );

  IF ownerless_active > 0 THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'CEN migration blocked: one or more active enterprises are ownerless';
  END IF;
END$$
CALL `cen_migrate_002`()$$
DROP PROCEDURE IF EXISTS `cen_migrate_002`$$
DELIMITER ;
