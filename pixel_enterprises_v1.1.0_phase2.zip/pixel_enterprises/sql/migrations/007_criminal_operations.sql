-- v1.0.0 Criminal Operations: facilities, production, wholesale market,
-- street distribution, shipments/airdrops, heat and opt-in corruption contacts.
-- Apply after migrations 002-006. Back up the database first.

ALTER TABLE `cen_enterprises`
  ADD COLUMN IF NOT EXISTS `heat` INT UNSIGNED NOT NULL DEFAULT 0 AFTER `treasury_balance`;

CREATE TABLE IF NOT EXISTS `cen_facilities` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `enterprise_id` BIGINT UNSIGNED NOT NULL,
  `facility_type` ENUM('lab','warehouse','front') NOT NULL,
  `subtype` VARCHAR(40) NOT NULL,
  `name` VARCHAR(80) NOT NULL,
  `center_x` DOUBLE NOT NULL,
  `center_y` DOUBLE NOT NULL,
  `center_z` DOUBLE NOT NULL,
  `radius` DOUBLE NOT NULL DEFAULT 8,
  `level` INT UNSIGNED NOT NULL DEFAULT 1,
  `status` ENUM('active','disabled','raided') NOT NULL DEFAULT 'active',
  `metadata` JSON NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cen_facility_enterprise_status` (`enterprise_id`, `status`),
  CONSTRAINT `fk_cen_facility_enterprise` FOREIGN KEY (`enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_production_jobs` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `facility_id` BIGINT UNSIGNED NOT NULL,
  `enterprise_id` BIGINT UNSIGNED NOT NULL,
  `started_by_member_id` BIGINT UNSIGNED NULL,
  `claimed_by_member_id` BIGINT UNSIGNED NULL,
  `recipe_key` VARCHAR(60) NOT NULL,
  `output_item` VARCHAR(80) NOT NULL,
  `output_count` INT UNSIGNED NOT NULL,
  `quality` TINYINT UNSIGNED NOT NULL DEFAULT 50,
  `batch_id` VARCHAR(40) NOT NULL,
  `status` ENUM('processing','ready','claiming','claimed','cancelled') NOT NULL DEFAULT 'processing',
  `starts_at` DATETIME NOT NULL,
  `ends_at` DATETIME NOT NULL,
  `claimed_at` DATETIME NULL,
  `metadata` JSON NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cen_production_batch` (`batch_id`),
  KEY `idx_cen_production_enterprise_status` (`enterprise_id`, `status`, `ends_at`),
  KEY `idx_cen_production_facility_status` (`facility_id`, `status`),
  CONSTRAINT `fk_cen_production_facility` FOREIGN KEY (`facility_id`)
    REFERENCES `cen_facilities` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_production_enterprise` FOREIGN KEY (`enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_production_started_member` FOREIGN KEY (`started_by_member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_cen_production_claimed_member` FOREIGN KEY (`claimed_by_member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_market_listings` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `seller_enterprise_id` BIGINT UNSIGNED NOT NULL,
  `created_by_member_id` BIGINT UNSIGNED NULL,
  `category` VARCHAR(32) NOT NULL,
  `item_name` VARCHAR(80) NOT NULL,
  `quantity_initial` INT UNSIGNED NOT NULL,
  `quantity_remaining` INT UNSIGNED NOT NULL,
  `unit_price` BIGINT UNSIGNED NOT NULL,
  `quality` TINYINT UNSIGNED NOT NULL DEFAULT 50,
  `batch_id` VARCHAR(40) NULL,
  `status` ENUM('active','sold','cancelled','expired') NOT NULL DEFAULT 'active',
  `metadata` JSON NULL,
  `expires_at` DATETIME NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cen_market_active` (`status`, `category`, `expires_at`),
  KEY `idx_cen_market_seller` (`seller_enterprise_id`, `status`),
  CONSTRAINT `fk_cen_market_seller` FOREIGN KEY (`seller_enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_market_creator` FOREIGN KEY (`created_by_member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_market_sales` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `listing_id` BIGINT UNSIGNED NOT NULL,
  `seller_enterprise_id` BIGINT UNSIGNED NOT NULL,
  `buyer_enterprise_id` BIGINT UNSIGNED NOT NULL,
  `buyer_member_id` BIGINT UNSIGNED NULL,
  `quantity` INT UNSIGNED NOT NULL,
  `total_price` BIGINT UNSIGNED NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cen_market_sale_buyer` (`buyer_enterprise_id`, `created_at`),
  KEY `idx_cen_market_sale_seller` (`seller_enterprise_id`, `created_at`),
  CONSTRAINT `fk_cen_market_sale_listing` FOREIGN KEY (`listing_id`)
    REFERENCES `cen_market_listings` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_cen_market_sale_seller` FOREIGN KEY (`seller_enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_market_sale_buyer` FOREIGN KEY (`buyer_enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_market_sale_member` FOREIGN KEY (`buyer_member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_market_deliveries` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `enterprise_id` BIGINT UNSIGNED NOT NULL,
  `source_type` ENUM('purchase','listing_return') NOT NULL,
  `source_id` BIGINT UNSIGNED NULL,
  `item_name` VARCHAR(80) NOT NULL,
  `quantity` INT UNSIGNED NOT NULL,
  `quality` TINYINT UNSIGNED NOT NULL DEFAULT 50,
  `batch_id` VARCHAR(40) NULL,
  `status` ENUM('pending','claiming','claimed') NOT NULL DEFAULT 'pending',
  `claimed_by_member_id` BIGINT UNSIGNED NULL,
  `metadata` JSON NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `claimed_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  KEY `idx_cen_market_delivery_enterprise` (`enterprise_id`, `status`, `created_at`),
  CONSTRAINT `fk_cen_market_delivery_enterprise` FOREIGN KEY (`enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_market_delivery_member` FOREIGN KEY (`claimed_by_member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_shipments` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `enterprise_id` BIGINT UNSIGNED NOT NULL,
  `requested_by_member_id` BIGINT UNSIGNED NULL,
  `claimed_by_member_id` BIGINT UNSIGNED NULL,
  `catalog_key` VARCHAR(60) NOT NULL,
  `delivery_type` ENUM('dead_drop','airdrop') NOT NULL,
  `item_name` VARCHAR(80) NOT NULL,
  `quantity` INT UNSIGNED NOT NULL,
  `cost` BIGINT UNSIGNED NOT NULL,
  `pickup_x` DOUBLE NOT NULL,
  `pickup_y` DOUBLE NOT NULL,
  `pickup_z` DOUBLE NOT NULL,
  `pickup_label` VARCHAR(100) NOT NULL,
  `status` ENUM('scheduled','ready','claiming','claimed','expired','cancelled') NOT NULL DEFAULT 'scheduled',
  `ready_at` DATETIME NOT NULL,
  `expires_at` DATETIME NOT NULL,
  `claimed_at` DATETIME NULL,
  `metadata` JSON NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cen_shipment_enterprise` (`enterprise_id`, `status`, `ready_at`),
  CONSTRAINT `fk_cen_shipment_enterprise` FOREIGN KEY (`enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_shipment_requester` FOREIGN KEY (`requested_by_member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_cen_shipment_claimer` FOREIGN KEY (`claimed_by_member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_corruption_offers` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `enterprise_id` BIGINT UNSIGNED NOT NULL,
  `created_by_member_id` BIGINT UNSIGNED NULL,
  `officer_identifier` VARCHAR(80) NOT NULL,
  `officer_display_name` VARCHAR(80) NOT NULL,
  `service_key` VARCHAR(60) NOT NULL,
  `fee` BIGINT UNSIGNED NOT NULL,
  `exposure` INT UNSIGNED NOT NULL DEFAULT 0,
  `status` ENUM('pending','accepted','declined','expired','completed','cancelled','failed') NOT NULL DEFAULT 'pending',
  `expires_at` DATETIME NOT NULL,
  `accepted_at` DATETIME NULL,
  `completed_at` DATETIME NULL,
  `metadata` JSON NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cen_corruption_officer` (`officer_identifier`, `status`, `expires_at`),
  KEY `idx_cen_corruption_enterprise` (`enterprise_id`, `status`, `created_at`),
  CONSTRAINT `fk_cen_corruption_enterprise` FOREIGN KEY (`enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_corruption_creator` FOREIGN KEY (`created_by_member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cen_corruption_contacts` (
  `enterprise_id` BIGINT UNSIGNED NOT NULL,
  `officer_identifier` VARCHAR(80) NOT NULL,
  `officer_display_name` VARCHAR(80) NOT NULL,
  `trust` INT UNSIGNED NOT NULL DEFAULT 0,
  `exposure` INT UNSIGNED NOT NULL DEFAULT 0,
  `total_paid` BIGINT UNSIGNED NOT NULL DEFAULT 0,
  `status` ENUM('active','compromised','blacklisted') NOT NULL DEFAULT 'active',
  `last_service_at` DATETIME NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`enterprise_id`, `officer_identifier`),
  CONSTRAINT `fk_cen_corruption_contact_enterprise` FOREIGN KEY (`enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP PROCEDURE IF EXISTS `cen_market_purchase`;
DROP PROCEDURE IF EXISTS `cen_request_shipment`;
DROP PROCEDURE IF EXISTS `cen_accept_corruption_offer`;

DELIMITER //

CREATE PROCEDURE `cen_market_purchase`(
  IN p_listing_id BIGINT UNSIGNED,
  IN p_buyer_enterprise_id BIGINT UNSIGNED,
  IN p_buyer_member_id BIGINT UNSIGNED,
  IN p_quantity INT UNSIGNED
)
proc: BEGIN
  DECLARE v_seller BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_item VARCHAR(80) DEFAULT NULL;
  DECLARE v_remaining INT UNSIGNED DEFAULT 0;
  DECLARE v_price BIGINT UNSIGNED DEFAULT 0;
  DECLARE v_quality TINYINT UNSIGNED DEFAULT 50;
  DECLARE v_batch VARCHAR(40) DEFAULT NULL;
  DECLARE v_total BIGINT UNSIGNED DEFAULT 0;
  DECLARE v_buyer_balance BIGINT DEFAULT NULL;
  DECLARE v_seller_balance BIGINT DEFAULT NULL;
  DECLARE v_delivery_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode, NULL AS deliveryId;
  END;
  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;
  SELECT seller_enterprise_id, item_name, quantity_remaining, unit_price, quality, batch_id
    INTO v_seller, v_item, v_remaining, v_price, v_quality, v_batch
    FROM cen_market_listings
    WHERE id = p_listing_id AND status = 'active' AND expires_at > UTC_TIMESTAMP()
    FOR UPDATE;
  IF v_seller IS NULL THEN
    ROLLBACK; SELECT 0 AS ok, 'listing_not_found' AS errorCode, NULL AS deliveryId; LEAVE proc;
  END IF;
  IF v_seller = p_buyer_enterprise_id OR p_quantity < 1 OR v_remaining < p_quantity THEN
    ROLLBACK; SELECT 0 AS ok, 'listing_not_allowed' AS errorCode, NULL AS deliveryId; LEAVE proc;
  END IF;
  SELECT treasury_balance INTO v_buyer_balance FROM cen_enterprises
    WHERE id = p_buyer_enterprise_id AND status = 'active' FOR UPDATE;
  SELECT treasury_balance INTO v_seller_balance FROM cen_enterprises
    WHERE id = v_seller AND status = 'active' FOR UPDATE;
  SET v_total = v_price * p_quantity;
  IF v_buyer_balance IS NULL OR v_seller_balance IS NULL OR v_buyer_balance < v_total THEN
    ROLLBACK; SELECT 0 AS ok, 'insufficient_funds' AS errorCode, NULL AS deliveryId; LEAVE proc;
  END IF;
  UPDATE cen_enterprises SET treasury_balance = treasury_balance - v_total
    WHERE id = p_buyer_enterprise_id;
  UPDATE cen_enterprises SET treasury_balance = treasury_balance + v_total
    WHERE id = v_seller;
  UPDATE cen_market_listings
    SET quantity_remaining = v_remaining - p_quantity,
        status = IF(v_remaining - p_quantity = 0, 'sold', 'active')
    WHERE id = p_listing_id;
  INSERT INTO cen_market_sales
    (listing_id, seller_enterprise_id, buyer_enterprise_id, buyer_member_id, quantity, total_price)
    VALUES (p_listing_id, v_seller, p_buyer_enterprise_id, p_buyer_member_id, p_quantity, v_total);
  INSERT INTO cen_market_deliveries
    (enterprise_id, source_type, source_id, item_name, quantity, quality, batch_id, metadata)
    VALUES (p_buyer_enterprise_id, 'purchase', LAST_INSERT_ID(), v_item, p_quantity, v_quality, v_batch,
      JSON_OBJECT('sellerEnterpriseId', v_seller, 'listingId', p_listing_id, 'totalPrice', v_total));
  SET v_delivery_id = LAST_INSERT_ID();
  INSERT INTO cen_treasury_transactions
    (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
    VALUES
      (p_buyer_enterprise_id, p_buyer_member_id, 'market_purchase', v_total, v_buyer_balance - v_total, CONCAT('Listing #', p_listing_id)),
      (v_seller, NULL, 'market_sale', v_total, v_seller_balance + v_total, CONCAT('Listing #', p_listing_id));
  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode, v_delivery_id AS deliveryId, v_total AS totalPrice;
END//

CREATE PROCEDURE `cen_request_shipment`(
  IN p_enterprise_id BIGINT UNSIGNED,
  IN p_member_id BIGINT UNSIGNED,
  IN p_catalog_key VARCHAR(60),
  IN p_delivery_type VARCHAR(20),
  IN p_item_name VARCHAR(80),
  IN p_quantity INT UNSIGNED,
  IN p_cost BIGINT UNSIGNED,
  IN p_x DOUBLE, IN p_y DOUBLE, IN p_z DOUBLE,
  IN p_label VARCHAR(100),
  IN p_ready_seconds INT UNSIGNED,
  IN p_expiry_hours INT UNSIGNED
)
proc: BEGIN
  DECLARE v_balance BIGINT DEFAULT NULL;
  DECLARE v_shipment_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode, NULL AS shipmentId;
  END;
  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;
  SELECT treasury_balance INTO v_balance FROM cen_enterprises
    WHERE id = p_enterprise_id AND status = 'active' FOR UPDATE;
  IF v_balance IS NULL OR v_balance < p_cost THEN
    ROLLBACK; SELECT 0 AS ok, 'insufficient_funds' AS errorCode, NULL AS shipmentId; LEAVE proc;
  END IF;
  UPDATE cen_enterprises SET treasury_balance = treasury_balance - p_cost WHERE id = p_enterprise_id;
  INSERT INTO cen_shipments
    (enterprise_id, requested_by_member_id, catalog_key, delivery_type, item_name, quantity, cost,
     pickup_x, pickup_y, pickup_z, pickup_label, ready_at, expires_at)
    VALUES (p_enterprise_id, p_member_id, p_catalog_key, p_delivery_type, p_item_name, p_quantity, p_cost,
      p_x, p_y, p_z, p_label, DATE_ADD(UTC_TIMESTAMP(), INTERVAL p_ready_seconds SECOND),
      DATE_ADD(DATE_ADD(UTC_TIMESTAMP(), INTERVAL p_ready_seconds SECOND), INTERVAL p_expiry_hours HOUR));
  SET v_shipment_id = LAST_INSERT_ID();
  INSERT INTO cen_treasury_transactions
    (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
    VALUES (p_enterprise_id, p_member_id, 'shipment_purchase', p_cost, v_balance - p_cost, CONCAT('Shipment #', v_shipment_id));
  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode, v_shipment_id AS shipmentId;
END//

CREATE PROCEDURE `cen_accept_corruption_offer`(
  IN p_offer_id BIGINT UNSIGNED,
  IN p_officer_identifier VARCHAR(80)
)
proc: BEGIN
  DECLARE v_enterprise BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_fee BIGINT UNSIGNED DEFAULT 0;
  DECLARE v_exposure INT UNSIGNED DEFAULT 0;
  DECLARE v_name VARCHAR(80) DEFAULT NULL;
  DECLARE v_service VARCHAR(60) DEFAULT NULL;
  DECLARE v_balance BIGINT DEFAULT NULL;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS ok, 'database_unavailable' AS errorCode, NULL AS enterpriseId;
  END;
  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;
  SELECT enterprise_id, fee, exposure, officer_display_name, service_key
    INTO v_enterprise, v_fee, v_exposure, v_name, v_service
    FROM cen_corruption_offers
    WHERE id = p_offer_id AND officer_identifier = p_officer_identifier
      AND status = 'pending' AND expires_at > UTC_TIMESTAMP()
    FOR UPDATE;
  IF v_enterprise IS NULL THEN
    ROLLBACK; SELECT 0 AS ok, 'offer_not_found' AS errorCode, NULL AS enterpriseId; LEAVE proc;
  END IF;
  SELECT treasury_balance INTO v_balance FROM cen_enterprises
    WHERE id = v_enterprise AND status = 'active' FOR UPDATE;
  IF v_balance IS NULL OR v_balance < v_fee THEN
    ROLLBACK; SELECT 0 AS ok, 'insufficient_funds' AS errorCode, v_enterprise AS enterpriseId; LEAVE proc;
  END IF;
  UPDATE cen_enterprises SET treasury_balance = treasury_balance - v_fee WHERE id = v_enterprise;
  UPDATE cen_corruption_offers SET status = 'accepted', accepted_at = UTC_TIMESTAMP()
    WHERE id = p_offer_id;
  INSERT INTO cen_treasury_transactions
    (enterprise_id, actor_member_id, transaction_type, amount, balance_after, note)
    VALUES (v_enterprise, NULL, 'corruption_payment', v_fee, v_balance - v_fee, CONCAT('Corruption offer #', p_offer_id));
  COMMIT;
  SELECT 1 AS ok, NULL AS errorCode, v_enterprise AS enterpriseId, v_fee AS fee,
    v_exposure AS exposure, v_name AS officerDisplayName, v_service AS serviceKey;
END//

DELIMITER ;
