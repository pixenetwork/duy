-- Upgrade v0.3.1 to v0.3.2.
-- Adds database-enforced founding participation and atomic procedures for
-- membership acceptance and enterprise creation/finalization.
-- Back up the database before running this migration.

CREATE TABLE IF NOT EXISTS `cen_founding_participants` (
  `identifier` VARCHAR(80) NOT NULL,
  `proposal_id` BIGINT UNSIGNED NOT NULL,
  `role` ENUM('founder','supporter') NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`identifier`),
  KEY `idx_cen_founding_participant_proposal` (`proposal_id`, `role`),
  CONSTRAINT `fk_cen_founding_participant_proposal` FOREIGN KEY (`proposal_id`)
    REFERENCES `cen_founding_proposals` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Rebuild participation rows for non-finalized, non-expired proposals. A server
-- startup check will refuse to run if pre-existing data contains conflicting
-- participation that cannot be represented by the unique identifier key.
DELETE fp FROM `cen_founding_participants` fp
LEFT JOIN `cen_founding_proposals` p ON p.id = fp.proposal_id
WHERE p.id IS NULL OR p.status NOT IN ('pending','ready','awaiting_approval','finalizing')
   OR p.expires_at <= UTC_TIMESTAMP();

INSERT IGNORE INTO `cen_founding_participants` (`identifier`, `proposal_id`, `role`)
SELECT p.founder_identifier, p.id, 'founder'
FROM `cen_founding_proposals` p
WHERE p.status IN ('pending','ready','awaiting_approval','finalizing')
  AND p.expires_at > UTC_TIMESTAMP();

INSERT IGNORE INTO `cen_founding_participants` (`identifier`, `proposal_id`, `role`)
SELECT i.invited_identifier, i.proposal_id, 'supporter'
FROM `cen_founding_invites` i
JOIN `cen_founding_proposals` p ON p.id = i.proposal_id
WHERE i.status = 'accepted'
  AND p.status IN ('pending','ready','awaiting_approval','finalizing')
  AND p.expires_at > UTC_TIMESTAMP();

DROP PROCEDURE IF EXISTS `cen_accept_membership_invite`;
DROP PROCEDURE IF EXISTS `cen_create_founding_proposal`;
DROP PROCEDURE IF EXISTS `cen_accept_founding_invite`;
DROP PROCEDURE IF EXISTS `cen_cancel_founding_proposal`;
DROP PROCEDURE IF EXISTS `cen_create_enterprise_direct`;
DROP PROCEDURE IF EXISTS `cen_finalize_founding_proposal`;

DELIMITER //

CREATE PROCEDURE `cen_accept_membership_invite`(
  IN p_invite_id BIGINT UNSIGNED,
  IN p_identifier VARCHAR(80),
  IN p_display_name VARCHAR(80),
  IN p_absolute_limit INT
)
proc: BEGIN
  DECLARE v_enterprise_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_rank_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_invite_status VARCHAR(20) DEFAULT NULL;
  DECLARE v_expires_at DATETIME DEFAULT NULL;
  DECLARE v_enterprise_status VARCHAR(20) DEFAULT NULL;
  DECLARE v_base_limit INT DEFAULT 0;
  DECLARE v_extra_slots INT DEFAULT 0;
  DECLARE v_current_count INT DEFAULT 0;
  DECLARE v_member_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_member_status VARCHAR(20) DEFAULT NULL;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE v_affected INT DEFAULT 0;

  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS success, 'database_unavailable' AS errorCode, NULL AS enterpriseId;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;

  SET v_not_found = 0;
  SELECT enterprise_id, rank_id, status, expires_at
    INTO v_enterprise_id, v_rank_id, v_invite_status, v_expires_at
  FROM cen_membership_invites
  WHERE id = p_invite_id AND invited_identifier = p_identifier
  FOR UPDATE;

  IF v_not_found = 1 OR v_enterprise_id IS NULL THEN
    ROLLBACK;
    SELECT 0 AS success, 'membership_invite_not_found' AS errorCode, NULL AS enterpriseId;
    LEAVE proc;
  END IF;

  IF v_invite_status <> 'pending' OR v_expires_at <= UTC_TIMESTAMP() THEN
    ROLLBACK;
    SELECT 0 AS success, 'membership_invite_expired' AS errorCode, NULL AS enterpriseId;
    LEAVE proc;
  END IF;

  SET v_not_found = 0;
  SELECT status, base_member_limit
    INTO v_enterprise_status, v_base_limit
  FROM cen_enterprises
  WHERE id = v_enterprise_id
  FOR UPDATE;

  IF v_not_found = 1 OR v_enterprise_status <> 'active' THEN
    ROLLBACK;
    SELECT 0 AS success, 'invalid_enterprise' AS errorCode, NULL AS enterpriseId;
    LEAVE proc;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM cen_ranks
    WHERE id = v_rank_id AND enterprise_id = v_enterprise_id
  ) THEN
    ROLLBACK;
    SELECT 0 AS success, 'invalid_rank' AS errorCode, NULL AS enterpriseId;
    LEAVE proc;
  END IF;

  IF EXISTS (
    SELECT 1 FROM cen_founding_participants fp
    JOIN cen_founding_proposals p ON p.id = fp.proposal_id
    WHERE fp.identifier = p_identifier
      AND p.status IN ('pending','ready','awaiting_approval','finalizing')
      AND p.expires_at > UTC_TIMESTAMP()
  ) THEN
    ROLLBACK;
    SELECT 0 AS success, 'already_supporting_proposal' AS errorCode, NULL AS enterpriseId;
    LEAVE proc;
  END IF;

  SET v_not_found = 0;
  SET v_member_id = NULL;
  SET v_member_status = NULL;
  SELECT id, status INTO v_member_id, v_member_status
  FROM cen_members
  WHERE player_identifier = p_identifier
  LIMIT 1
  FOR UPDATE;
  SET v_not_found = 0;

  IF v_member_id IS NOT NULL AND v_member_status <> 'removed' THEN
    ROLLBACK;
    SELECT 0 AS success, 'target_already_member' AS errorCode, NULL AS enterpriseId;
    LEAVE proc;
  END IF;

  SELECT COUNT(*) INTO v_current_count
  FROM cen_members
  WHERE enterprise_id = v_enterprise_id AND status = 'active';

  SELECT COALESCE(SUM(quantity), 0) INTO v_extra_slots
  FROM cen_enterprise_entitlements
  WHERE enterprise_id = v_enterprise_id
    AND entitlement_type = 'member_slots'
    AND status = 'active'
    AND (expires_at IS NULL OR expires_at > UTC_TIMESTAMP());

  IF v_current_count >= LEAST(v_base_limit + v_extra_slots, p_absolute_limit) THEN
    ROLLBACK;
    SELECT 0 AS success, 'member_limit_reached' AS errorCode, v_enterprise_id AS enterpriseId;
    LEAVE proc;
  END IF;

  IF v_member_id IS NULL THEN
    INSERT INTO cen_members
      (enterprise_id, rank_id, player_identifier, display_name, status, individual_xp, joined_at, updated_at)
    VALUES
      (v_enterprise_id, v_rank_id, p_identifier, p_display_name, 'active', 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);
  ELSE
    UPDATE cen_members
    SET enterprise_id = v_enterprise_id,
        rank_id = v_rank_id,
        display_name = p_display_name,
        status = 'active',
        individual_xp = 0,
        joined_at = CURRENT_TIMESTAMP,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = v_member_id AND status = 'removed';
    SET v_affected = ROW_COUNT();
    IF v_affected <> 1 THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'member_reactivation_failed';
    END IF;
  END IF;

  UPDATE cen_membership_invites
  SET status = 'accepted', responded_at = UTC_TIMESTAMP()
  WHERE id = p_invite_id
    AND invited_identifier = p_identifier
    AND status = 'pending'
    AND expires_at > UTC_TIMESTAMP();
  SET v_affected = ROW_COUNT();
  IF v_affected <> 1 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'invite_accept_guard_failed';
  END IF;

  UPDATE cen_membership_invites
  SET status = 'cancelled', responded_at = UTC_TIMESTAMP()
  WHERE invited_identifier = p_identifier
    AND id <> p_invite_id
    AND status = 'pending';

  COMMIT;
  SELECT 1 AS success, NULL AS errorCode, v_enterprise_id AS enterpriseId;
END//

CREATE PROCEDURE `cen_create_founding_proposal`(
  IN p_founder_identifier VARCHAR(80),
  IN p_founder_display_name VARCHAR(80),
  IN p_name VARCHAR(80),
  IN p_slug VARCHAR(80),
  IN p_enterprise_type VARCHAR(40),
  IN p_creation_plan VARCHAR(20),
  IN p_required_acceptances INT,
  IN p_expiry_hours INT
)
proc: BEGIN
  DECLARE v_proposal_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS success, 'conflict' AS errorCode, NULL AS proposalId;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;

  IF EXISTS (
    SELECT 1 FROM cen_members
    WHERE player_identifier = p_founder_identifier AND status IN ('active','suspended')
  ) OR EXISTS (
    SELECT 1 FROM cen_founding_participants fp
      JOIN cen_founding_proposals active_p ON active_p.id = fp.proposal_id
      WHERE fp.identifier = p_founder_identifier
        AND active_p.status IN ('pending','ready','awaiting_approval','finalizing')
        AND active_p.expires_at > UTC_TIMESTAMP()
  ) THEN
    ROLLBACK;
    SELECT 0 AS success, 'already_has_proposal' AS errorCode, NULL AS proposalId;
    LEAVE proc;
  END IF;

  INSERT INTO cen_founding_proposals
    (founder_identifier, founder_display_name, name, slug, enterprise_type,
     creation_plan, required_acceptances, status, expires_at)
  VALUES
    (p_founder_identifier, p_founder_display_name, p_name, p_slug, p_enterprise_type,
     p_creation_plan, p_required_acceptances, 'pending',
     DATE_ADD(UTC_TIMESTAMP(), INTERVAL p_expiry_hours HOUR));
  SET v_proposal_id = LAST_INSERT_ID();

  INSERT INTO cen_founding_participants (identifier, proposal_id, role)
  VALUES (p_founder_identifier, v_proposal_id, 'founder');

  COMMIT;
  SELECT 1 AS success, NULL AS errorCode, v_proposal_id AS proposalId;
END//

CREATE PROCEDURE `cen_accept_founding_invite`(
  IN p_invite_id BIGINT UNSIGNED,
  IN p_identifier VARCHAR(80)
)
proc: BEGIN
  DECLARE v_proposal_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_invite_status VARCHAR(20) DEFAULT NULL;
  DECLARE v_invite_expiry DATETIME DEFAULT NULL;
  DECLARE v_proposal_status VARCHAR(24) DEFAULT NULL;
  DECLARE v_proposal_expiry DATETIME DEFAULT NULL;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE v_affected INT DEFAULT 0;

  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS success, 'conflict' AS errorCode, NULL AS proposalId;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;

  SET v_not_found = 0;
  SELECT proposal_id, status, expires_at
    INTO v_proposal_id, v_invite_status, v_invite_expiry
  FROM cen_founding_invites
  WHERE id = p_invite_id AND invited_identifier = p_identifier
  FOR UPDATE;

  IF v_not_found = 1 OR v_proposal_id IS NULL THEN
    ROLLBACK;
    SELECT 0 AS success, 'invite_not_found' AS errorCode, NULL AS proposalId;
    LEAVE proc;
  END IF;

  SET v_not_found = 0;
  SELECT status, expires_at INTO v_proposal_status, v_proposal_expiry
  FROM cen_founding_proposals
  WHERE id = v_proposal_id
  FOR UPDATE;

  IF v_not_found = 1
     OR v_invite_status <> 'pending'
     OR v_invite_expiry <= UTC_TIMESTAMP()
     OR v_proposal_status NOT IN ('pending','ready')
     OR v_proposal_expiry <= UTC_TIMESTAMP() THEN
    ROLLBACK;
    SELECT 0 AS success, 'invite_already_responded' AS errorCode, v_proposal_id AS proposalId;
    LEAVE proc;
  END IF;

  IF EXISTS (
    SELECT 1 FROM cen_members
    WHERE player_identifier = p_identifier AND status IN ('active','suspended')
  ) THEN
    ROLLBACK;
    SELECT 0 AS success, 'target_already_member' AS errorCode, v_proposal_id AS proposalId;
    LEAVE proc;
  END IF;

  IF EXISTS (SELECT 1 FROM cen_founding_participants WHERE identifier = p_identifier) THEN
    ROLLBACK;
    SELECT 0 AS success, 'already_supporting_proposal' AS errorCode, v_proposal_id AS proposalId;
    LEAVE proc;
  END IF;

  INSERT INTO cen_founding_participants (identifier, proposal_id, role)
  VALUES (p_identifier, v_proposal_id, 'supporter');

  UPDATE cen_founding_invites
  SET status = 'accepted', responded_at = UTC_TIMESTAMP()
  WHERE id = p_invite_id AND invited_identifier = p_identifier
    AND status = 'pending' AND expires_at > UTC_TIMESTAMP();
  SET v_affected = ROW_COUNT();
  IF v_affected <> 1 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'founding_invite_accept_guard_failed';
  END IF;

  COMMIT;
  SELECT 1 AS success, NULL AS errorCode, v_proposal_id AS proposalId;
END//

CREATE PROCEDURE `cen_cancel_founding_proposal`(
  IN p_proposal_id BIGINT UNSIGNED,
  IN p_founder_identifier VARCHAR(80)
)
proc: BEGIN
  DECLARE v_affected INT DEFAULT 0;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS success, 'database_unavailable' AS errorCode;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;
  UPDATE cen_founding_proposals
  SET status = 'cancelled', updated_at = UTC_TIMESTAMP()
  WHERE id = p_proposal_id AND founder_identifier = p_founder_identifier
    AND status IN ('pending','ready','awaiting_approval');
  SET v_affected = ROW_COUNT();
  IF v_affected <> 1 THEN
    ROLLBACK;
    SELECT 0 AS success, 'proposal_not_found' AS errorCode;
    LEAVE proc;
  END IF;

  DELETE FROM cen_founding_participants WHERE proposal_id = p_proposal_id;
  COMMIT;
  SELECT 1 AS success, NULL AS errorCode;
END//

CREATE PROCEDURE `cen_create_enterprise_direct`(
  IN p_name VARCHAR(80),
  IN p_slug VARCHAR(80),
  IN p_enterprise_type VARCHAR(40),
  IN p_creation_plan VARCHAR(20),
  IN p_base_member_limit INT,
  IN p_retention_required TINYINT,
  IN p_owner_identifier VARCHAR(80),
  IN p_owner_display_name VARCHAR(80)
)
proc: BEGIN
  DECLARE v_enterprise_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_owner_rank_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_owner_member_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_existing_member_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_existing_status VARCHAR(20) DEFAULT NULL;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE v_affected INT DEFAULT 0;

  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS success, 'conflict' AS errorCode, NULL AS enterpriseId;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;

  SET v_not_found = 0;
  SELECT id, status INTO v_existing_member_id, v_existing_status
  FROM cen_members WHERE player_identifier = p_owner_identifier
  LIMIT 1 FOR UPDATE;
  SET v_not_found = 0;

  IF v_existing_member_id IS NOT NULL AND v_existing_status <> 'removed' THEN
    ROLLBACK;
    SELECT 0 AS success, 'target_already_member' AS errorCode, NULL AS enterpriseId;
    LEAVE proc;
  END IF;

  IF EXISTS (SELECT 1 FROM cen_founding_participants fp
      JOIN cen_founding_proposals active_p ON active_p.id = fp.proposal_id
      WHERE fp.identifier = p_owner_identifier
        AND active_p.status IN ('pending','ready','awaiting_approval','finalizing')
        AND active_p.expires_at > UTC_TIMESTAMP()) THEN
    ROLLBACK;
    SELECT 0 AS success, 'already_has_proposal' AS errorCode, NULL AS enterpriseId;
    LEAVE proc;
  END IF;

  INSERT INTO cen_enterprises
    (name, slug, enterprise_type, creation_plan, base_member_limit,
     retention_required, retention_status, status)
  VALUES
    (p_name, p_slug, p_enterprise_type, p_creation_plan, p_base_member_limit,
     p_retention_required, IF(p_retention_required = 1, 'healthy', 'exempt'), 'active');
  SET v_enterprise_id = LAST_INSERT_ID();

  INSERT INTO cen_ranks
    (enterprise_id, name, priority, permissions, is_default, is_protected)
  VALUES (v_enterprise_id, 'Owner', 1000, '[]', 0, 1);
  SET v_owner_rank_id = LAST_INSERT_ID();

  INSERT INTO cen_ranks
    (enterprise_id, name, priority, permissions, is_default, is_protected)
  VALUES (v_enterprise_id, 'Member', 10, '["enterprise.view","storage.access","progression.view"]', 1, 1);

  IF v_existing_member_id IS NULL THEN
    INSERT INTO cen_members
      (enterprise_id, rank_id, player_identifier, display_name, status, individual_xp, joined_at, updated_at)
    VALUES
      (v_enterprise_id, v_owner_rank_id, p_owner_identifier, p_owner_display_name,
       'active', 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);
    SET v_owner_member_id = LAST_INSERT_ID();
  ELSE
    UPDATE cen_members
    SET enterprise_id = v_enterprise_id,
        rank_id = v_owner_rank_id,
        display_name = p_owner_display_name,
        status = 'active',
        individual_xp = 0,
        joined_at = CURRENT_TIMESTAMP,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = v_existing_member_id AND status = 'removed';
    SET v_affected = ROW_COUNT();
    IF v_affected <> 1 THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'owner_reactivation_failed';
    END IF;
    SET v_owner_member_id = v_existing_member_id;
  END IF;

  UPDATE cen_enterprises SET owner_member_id = v_owner_member_id
  WHERE id = v_enterprise_id;
  IF ROW_COUNT() <> 1 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'owner_assignment_failed';
  END IF;

  COMMIT;
  SELECT 1 AS success, NULL AS errorCode, v_enterprise_id AS enterpriseId;
END//

CREATE PROCEDURE `cen_finalize_founding_proposal`(
  IN p_proposal_id BIGINT UNSIGNED,
  IN p_absolute_member_limit INT,
  IN p_base_member_limit INT,
  IN p_retention_required TINYINT
)
proc: BEGIN
  DECLARE v_founder_identifier VARCHAR(80) DEFAULT NULL;
  DECLARE v_founder_display_name VARCHAR(80) DEFAULT NULL;
  DECLARE v_name VARCHAR(80) DEFAULT NULL;
  DECLARE v_slug VARCHAR(80) DEFAULT NULL;
  DECLARE v_enterprise_type VARCHAR(40) DEFAULT NULL;
  DECLARE v_creation_plan VARCHAR(20) DEFAULT NULL;
  DECLARE v_required INT DEFAULT 0;
  DECLARE v_status VARCHAR(24) DEFAULT NULL;
  DECLARE v_expires_at DATETIME DEFAULT NULL;
  DECLARE v_accepted_count INT DEFAULT 0;
  DECLARE v_participant_count INT DEFAULT 0;
  DECLARE v_enterprise_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_owner_rank_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_member_rank_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_owner_member_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_existing_owner_id BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_existing_owner_status VARCHAR(20) DEFAULT NULL;
  DECLARE v_not_found TINYINT DEFAULT 0;
  DECLARE v_affected INT DEFAULT 0;

  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 0 AS success, 'conflict' AS errorCode, NULL AS enterpriseId;
  END;

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  START TRANSACTION;

  SET v_not_found = 0;
  SELECT founder_identifier, founder_display_name, name, slug, enterprise_type,
         creation_plan, required_acceptances, status, expires_at
    INTO v_founder_identifier, v_founder_display_name, v_name, v_slug, v_enterprise_type,
         v_creation_plan, v_required, v_status, v_expires_at
  FROM cen_founding_proposals
  WHERE id = p_proposal_id
  FOR UPDATE;

  IF v_not_found = 1 OR v_founder_identifier IS NULL THEN
    ROLLBACK;
    SELECT 0 AS success, 'proposal_not_found' AS errorCode, NULL AS enterpriseId;
    LEAVE proc;
  END IF;

  IF v_status NOT IN ('pending','ready','awaiting_approval','finalizing')
     OR v_expires_at <= UTC_TIMESTAMP() THEN
    ROLLBACK;
    SELECT 0 AS success, 'proposal_not_ready' AS errorCode, NULL AS enterpriseId;
    LEAVE proc;
  END IF;

  SELECT COUNT(*) INTO v_accepted_count
  FROM cen_founding_invites
  WHERE proposal_id = p_proposal_id AND status = 'accepted';

  SELECT COUNT(*) INTO v_participant_count
  FROM cen_founding_participants
  WHERE proposal_id = p_proposal_id;

  IF v_accepted_count < v_required OR v_participant_count <> v_accepted_count + 1 THEN
    ROLLBACK;
    SELECT 0 AS success, 'founding_acceptances_required' AS errorCode, NULL AS enterpriseId;
    LEAVE proc;
  END IF;

  IF v_participant_count > LEAST(p_base_member_limit, p_absolute_member_limit) THEN
    ROLLBACK;
    SELECT 0 AS success, 'member_limit_reached' AS errorCode, NULL AS enterpriseId;
    LEAVE proc;
  END IF;

  IF EXISTS (
    SELECT 1
    FROM cen_founding_participants fp
    JOIN cen_members m ON m.player_identifier = fp.identifier
    WHERE fp.proposal_id = p_proposal_id AND m.status IN ('active','suspended')
  ) THEN
    ROLLBACK;
    SELECT 0 AS success, 'target_already_member' AS errorCode, NULL AS enterpriseId;
    LEAVE proc;
  END IF;

  INSERT INTO cen_enterprises
    (name, slug, enterprise_type, creation_plan, base_member_limit,
     retention_required, retention_status, status)
  VALUES
    (v_name, v_slug, v_enterprise_type, v_creation_plan, p_base_member_limit,
     p_retention_required, IF(p_retention_required = 1, 'healthy', 'exempt'), 'active');
  SET v_enterprise_id = LAST_INSERT_ID();

  INSERT INTO cen_ranks
    (enterprise_id, name, priority, permissions, is_default, is_protected)
  VALUES (v_enterprise_id, 'Owner', 1000, '[]', 0, 1);
  SET v_owner_rank_id = LAST_INSERT_ID();

  INSERT INTO cen_ranks
    (enterprise_id, name, priority, permissions, is_default, is_protected)
  VALUES (v_enterprise_id, 'Member', 10, '["enterprise.view","storage.access","progression.view"]', 1, 1);
  SET v_member_rank_id = LAST_INSERT_ID();

  SET v_not_found = 0;
  SELECT id, status INTO v_existing_owner_id, v_existing_owner_status
  FROM cen_members WHERE player_identifier = v_founder_identifier
  LIMIT 1 FOR UPDATE;
  SET v_not_found = 0;

  IF v_existing_owner_id IS NULL THEN
    INSERT INTO cen_members
      (enterprise_id, rank_id, player_identifier, display_name, status, individual_xp, joined_at, updated_at)
    VALUES
      (v_enterprise_id, v_owner_rank_id, v_founder_identifier, v_founder_display_name,
       'active', 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);
    SET v_owner_member_id = LAST_INSERT_ID();
  ELSE
    UPDATE cen_members
    SET enterprise_id = v_enterprise_id,
        rank_id = v_owner_rank_id,
        display_name = v_founder_display_name,
        status = 'active',
        individual_xp = 0,
        joined_at = CURRENT_TIMESTAMP,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = v_existing_owner_id AND status = 'removed';
    SET v_affected = ROW_COUNT();
    IF v_affected <> 1 THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'founder_reactivation_failed';
    END IF;
    SET v_owner_member_id = v_existing_owner_id;
  END IF;

  UPDATE cen_members m
  JOIN cen_founding_participants fp
    ON fp.identifier = m.player_identifier
   AND fp.proposal_id = p_proposal_id
   AND fp.role = 'supporter'
  JOIN cen_founding_invites fi
    ON fi.proposal_id = p_proposal_id
   AND fi.invited_identifier = fp.identifier
   AND fi.status = 'accepted'
  SET m.enterprise_id = v_enterprise_id,
      m.rank_id = v_member_rank_id,
      m.display_name = fi.invited_display_name,
      m.status = 'active',
      m.individual_xp = 0,
      m.joined_at = CURRENT_TIMESTAMP,
      m.updated_at = CURRENT_TIMESTAMP
  WHERE m.status = 'removed';

  INSERT INTO cen_members
    (enterprise_id, rank_id, player_identifier, display_name, status, individual_xp, joined_at, updated_at)
  SELECT v_enterprise_id, v_member_rank_id, fp.identifier, fi.invited_display_name,
         'active', 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
  FROM cen_founding_participants fp
  JOIN cen_founding_invites fi
    ON fi.proposal_id = fp.proposal_id
   AND fi.invited_identifier = fp.identifier
   AND fi.status = 'accepted'
  LEFT JOIN cen_members m ON m.player_identifier = fp.identifier
  WHERE fp.proposal_id = p_proposal_id
    AND fp.role = 'supporter'
    AND m.id IS NULL;

  UPDATE cen_enterprises SET owner_member_id = v_owner_member_id
  WHERE id = v_enterprise_id;
  IF ROW_COUNT() <> 1 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'owner_assignment_failed';
  END IF;

  UPDATE cen_founding_proposals
  SET status = 'finalized', finalized_enterprise_id = v_enterprise_id, updated_at = UTC_TIMESTAMP()
  WHERE id = p_proposal_id
    AND status IN ('pending','ready','awaiting_approval','finalizing');
  IF ROW_COUNT() <> 1 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'proposal_finalize_failed';
  END IF;

  DELETE FROM cen_founding_participants WHERE proposal_id = p_proposal_id;

  COMMIT;
  SELECT 1 AS success, NULL AS errorCode, v_enterprise_id AS enterpriseId;
END//

DELIMITER ;
