-- Upgrade v0.3.0 to v0.3.1 security hardening.
-- Back up the database. This migration is intentionally re-runnable.

CREATE TABLE IF NOT EXISTS `cen_membership_invites` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `enterprise_id` BIGINT UNSIGNED NOT NULL,
  `rank_id` BIGINT UNSIGNED NOT NULL,
  `invited_identifier` VARCHAR(80) NOT NULL,
  `invited_display_name` VARCHAR(80) NOT NULL DEFAULT 'Unknown',
  `invited_by_member_id` BIGINT UNSIGNED NULL,
  `status` ENUM('pending','accepted','declined','expired','cancelled') NOT NULL DEFAULT 'pending',
  `expires_at` DATETIME NOT NULL,
  `responded_at` DATETIME NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cen_membership_invitee_status` (`invited_identifier`, `status`, `expires_at`),
  KEY `idx_cen_membership_enterprise_status` (`enterprise_id`, `status`, `expires_at`),
  CONSTRAINT `fk_cen_membership_invite_enterprise` FOREIGN KEY (`enterprise_id`)
    REFERENCES `cen_enterprises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_membership_invite_rank` FOREIGN KEY (`rank_id`)
    REFERENCES `cen_ranks` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cen_membership_invite_inviter` FOREIGN KEY (`invited_by_member_id`)
    REFERENCES `cen_members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `cen_members`
  ADD COLUMN IF NOT EXISTS `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP AFTER `joined_at`;

-- Restore exactly one default rank and protect the default/highest rank.
DROP TEMPORARY TABLE IF EXISTS `cen_rank_repair`;
CREATE TEMPORARY TABLE `cen_rank_repair` AS
SELECT enterprise_ids.enterprise_id,
  (SELECT r_default.id FROM `cen_ranks` r_default
    WHERE r_default.enterprise_id = enterprise_ids.enterprise_id
    ORDER BY r_default.priority ASC, r_default.id ASC LIMIT 1) AS default_rank_id,
  (SELECT r_owner.id FROM `cen_ranks` r_owner
    WHERE r_owner.enterprise_id = enterprise_ids.enterprise_id
    ORDER BY r_owner.priority DESC, r_owner.id ASC LIMIT 1) AS owner_rank_id
FROM (SELECT DISTINCT enterprise_id FROM `cen_ranks`) enterprise_ids;

UPDATE `cen_ranks` r
JOIN `cen_rank_repair` repair ON repair.enterprise_id = r.enterprise_id
SET r.is_default = CASE WHEN r.id = repair.default_rank_id THEN 1 ELSE 0 END,
    r.is_protected = CASE
      WHEN r.id = repair.default_rank_id OR r.id = repair.owner_rank_id THEN 1
      ELSE r.is_protected
    END;

UPDATE `cen_members` m
JOIN `cen_ranks` default_rank
  ON default_rank.enterprise_id = m.enterprise_id
 AND default_rank.is_default = 1
SET m.rank_id = default_rank.id,
    m.updated_at = CURRENT_TIMESTAMP
WHERE m.status = 'removed';

DROP TEMPORARY TABLE IF EXISTS `cen_rank_repair`;

-- Recover an owner deterministically when an old database contains an ownerless enterprise.
UPDATE `cen_enterprises` e
SET e.owner_member_id = (
  SELECT m.id
  FROM `cen_members` m
  JOIN `cen_ranks` r ON r.id = m.rank_id AND r.enterprise_id = m.enterprise_id
  WHERE m.enterprise_id = e.id AND m.status = 'active'
  ORDER BY r.priority DESC, m.joined_at ASC, m.id ASC
  LIMIT 1
)
WHERE e.status = 'active' AND e.owner_member_id IS NULL;

-- The resource startup verifier refuses to run if duplicate player rows remain.
-- Run this diagnostic before restarting:
-- SELECT player_identifier, COUNT(*) FROM cen_members GROUP BY player_identifier HAVING COUNT(*) > 1;
