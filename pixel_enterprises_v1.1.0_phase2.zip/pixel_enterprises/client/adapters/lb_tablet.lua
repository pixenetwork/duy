CENClient = CENClient or {}

local registered = false

local function lbStarted()
    return GetResourceState(Config.Tablet.lbTablet.resource) == 'started'
end

function CENClient.IsLBTabletAvailable()
    return lbStarted()
end

function CENClient.RegisterLBTabletApp()
    if registered or not lbStarted() then return false end

    local success, added, reason = pcall(function()
        return exports[Config.Tablet.lbTablet.resource]:AddCustomApp({
            identifier = Config.Tablet.appIdentifier,
            resource = GetCurrentResourceName(),
            name = Config.Tablet.appName,
            description = 'Encrypted criminal enterprise operations network.',
            developer = 'Pixel Network',
            defaultApp = Config.Tablet.lbTablet.defaultApp,
            ui = ('%s/ui/index.html'):format(GetCurrentResourceName())
        })
    end)

    if not success then
        print(('[pixel_enterprises] LB Tablet registration failed: %s'):format(tostring(added)))
        return false
    end

    if added == false and reason ~= 'APP_ALREADY_EXISTS' then
        print(('[pixel_enterprises] LB Tablet rejected app registration: %s'):format(tostring(reason)))
        return false
    end

    registered = true
    return true
end

function CENClient.SendLBTabletMessage(eventName, payload)
    if not registered or not lbStarted() then return false end

    local success, sent = pcall(function()
        return exports[Config.Tablet.lbTablet.resource]:SendCustomAppMessage(
            Config.Tablet.appIdentifier,
            eventName,
            payload
        )
    end)

    return success and sent ~= false
end

AddEventHandler('onClientResourceStart', function(resourceName)
    if resourceName == Config.Tablet.lbTablet.resource or resourceName == GetCurrentResourceName() then
        Wait(500)
        CENClient.RegisterLBTabletApp()
    end
end)

AddEventHandler('onClientResourceStop', function(resourceName)
    if resourceName == Config.Tablet.lbTablet.resource then
        registered = false
    end
end)
