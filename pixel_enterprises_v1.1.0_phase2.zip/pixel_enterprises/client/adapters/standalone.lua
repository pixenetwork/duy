CENClient = CENClient or {}
local open = false
local opening = false

local function standaloneEnabled()
    if Config.Tablet.standalone.enabled ~= true then return false end
    local mode = Config.Tablet.mode
    if mode == 'standalone' or mode == 'both' then return true end
    return mode == 'auto' and not CENClient.IsLBTabletAvailable()
end

local function notifyMissingTablet()
    BeginTextCommandThefeedPost('STRING')
    AddTextComponentSubstringPlayerName('You do not have access to an enterprise tablet.')
    EndTextCommandThefeedPostTicker(false, false)
end

function CENClient.OpenStandalone()
    if open or opening or not standaloneEnabled() then return false end
    opening = true
    CENClient.EnsureTabletSession('standalone', function(token)
        opening = false
        if not token then notifyMissingTablet() return end
        open = true
        SetNuiFocus(true, true)
        SendNUIMessage({ action = 'open', host = 'standalone' })
    end)
    return true
end

function CENClient.CloseStandalone()
    if not open then return end
    open = false
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'close' })
end

RegisterNUICallback('close', function(_, cb)
    CENClient.CloseStandalone()
    cb({ ok = true })
end)

RegisterCommand(Config.Tablet.standalone.command, function() CENClient.OpenStandalone() end, false)
RegisterKeyMapping(Config.Tablet.standalone.command, 'Open Criminal Enterprise Network', 'keyboard', Config.Tablet.standalone.keybind)

AddEventHandler('onClientResourceStop', function(resourceName)
    if resourceName == GetCurrentResourceName() and open then SetNuiFocus(false, false) end
end)
exports('openTablet', CENClient.OpenStandalone)
