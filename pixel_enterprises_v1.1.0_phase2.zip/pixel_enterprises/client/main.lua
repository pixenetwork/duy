CENClient = CENClient or {}

local pendingRequests = {}
local pendingSessionCallbacks = { ['standalone'] = {}, ['lb-tablet'] = {} }
local sessions = {}
local sessionRequests = {}
local requestSequence = 0

local function nextRequestId(prefix)
    requestSequence = requestSequence + 1
    return ('%s:%s:%s'):format(prefix, GetGameTimer(), requestSequence)
end

function CENClient.GetAccessToken(host)
    local session = sessions[host]
    if not session or session.expiresAt <= GetGameTimer() or session.absoluteExpiresAt <= GetGameTimer() then
        sessions[host] = nil
        return nil
    end
    return session.token
end

function CENClient.EnsureTabletSession(host, callback)
    host = host == 'lb-tablet' and 'lb-tablet' or 'standalone'
    local token = CENClient.GetAccessToken(host)
    if token then callback(token) return end
    local queue = pendingSessionCallbacks[host]
    queue[#queue + 1] = callback
    if sessionRequests[host] then return end
    sessionRequests[host] = true
    TriggerServerEvent('pixel_enterprises:server:requestTabletSession', host)
    SetTimeout(5000, function()
        if not sessionRequests[host] then return end
        sessionRequests[host] = nil
        local waiting = pendingSessionCallbacks[host]
        pendingSessionCallbacks[host] = {}
        for i = 1, #waiting do waiting[i](nil) end
    end)
end

RegisterNetEvent('pixel_enterprises:client:tabletSession', function(payload)
    if type(payload) ~= 'table' then return end
    local host = payload.host == 'lb-tablet' and 'lb-tablet' or 'standalone'
    sessionRequests[host] = nil
    if payload.ok and type(payload.token) == 'string' then
        sessions[host] = {
            token = payload.token,
            expiresAt = GetGameTimer() + math.max(30, tonumber(payload.expiresIn) or 120) * 1000,
            absoluteExpiresAt = GetGameTimer() + math.max(30, tonumber(payload.absoluteExpiresIn) or 900) * 1000
        }
    else
        sessions[host] = nil
    end
    local waiting = pendingSessionCallbacks[host]
    pendingSessionCallbacks[host] = {}
    local token = CENClient.GetAccessToken(host)
    for i = 1, #waiting do waiting[i](token) end
end)

local function requestServer(action, payload, callback, host)
    host = host == 'lb-tablet' and 'lb-tablet' or 'standalone'
    CENClient.EnsureTabletSession(host, function(accessToken)
        if not accessToken then
            callback({ ok = false, error = 'session_required' })
            return
        end
        local requestId = nextRequestId(action)
        pendingRequests[requestId] = callback
        TriggerServerEvent('pixel_enterprises:server:request', {
            requestId = requestId,
            action = action,
            payload = payload or {},
            accessToken = accessToken
        })
        SetTimeout(10000, function()
            local pending = pendingRequests[requestId]
            if not pending then return end
            pendingRequests[requestId] = nil
            pending({ ok = false, error = 'request_timeout' })
        end)
    end)
end

local nuiActions = {
    getBootstrap = 'bootstrap', getRoster = 'getRoster',
    createRank = 'createRank', updateRank = 'updateRank', deleteRank = 'deleteRank',
    inviteMember = 'inviteMember', acceptMembershipInvite = 'acceptMembershipInvite',
    declineMembershipInvite = 'declineMembershipInvite', setMemberRank = 'setMemberRank',
    removeMember = 'removeMember', leaveEnterprise = 'leaveEnterprise',
    disbandEnterprise = 'disbandEnterprise', transferOwnership = 'transferOwnership',
    getCreationContext = 'getCreationContext', startFounding = 'startFounding',
    inviteFoundingMember = 'inviteFoundingMember', acceptFoundingInvite = 'acceptFoundingInvite',
    declineFoundingInvite = 'declineFoundingInvite', cancelFounding = 'cancelFounding',
    getTreasury = 'getTreasury', depositTreasury = 'depositTreasury',
    withdrawTreasury = 'withdrawTreasury', getProgression = 'getProgression',
    getLogs = 'getLogs', openStorage = 'openStorage',
    listZones = 'listZones', startZoneContest = 'startZoneContest',
    listProduction = 'listProduction', startProduction = 'startProduction', claimProduction = 'claimProduction',
    listMarket = 'listMarket', createMarketListing = 'createMarketListing', buyMarketListing = 'buyMarketListing',
    cancelMarketListing = 'cancelMarketListing', claimMarketDelivery = 'claimMarketDelivery',
    sellStreetProduct = 'sellStreetProduct', listShipments = 'listShipments', requestShipment = 'requestShipment',
    claimShipment = 'claimShipment', listCorruption = 'listCorruption', getOfficerOffers = 'getOfficerOffers',
    createCorruptionOffer = 'createCorruptionOffer', acceptCorruptionOffer = 'acceptCorruptionOffer',
    declineCorruptionOffer = 'declineCorruptionOffer',
    listCrews = 'listCrews', createCrew = 'createCrew', assignCrewMember = 'assignCrewMember',
    removeCrewMember = 'removeCrewMember', setCrewLeader = 'setCrewLeader', deleteCrew = 'deleteCrew',
    listDiplomacy = 'listDiplomacy', proposeDiplomacy = 'proposeDiplomacy',
    respondDiplomacy = 'respondDiplomacy', cancelDiplomacy = 'cancelDiplomacy', endDiplomacy = 'endDiplomacy',
    listWars = 'listWars', proposeWar = 'proposeWar', respondWar = 'respondWar', cancelWar = 'cancelWar',
    listFronts = 'listFronts', createFront = 'createFront', startLaundering = 'startLaundering',
    claimLaundering = 'claimLaundering', listRackets = 'listRackets',
    createRacket = 'createRacket', collectRacket = 'collectRacket'
}

for callbackName, action in pairs(nuiActions) do
    RegisterNUICallback(callbackName, function(payload, cb)
        payload = type(payload) == 'table' and payload or {}
        local host = payload.__cenHost == 'lb-tablet' and 'lb-tablet' or 'standalone'
        payload.__cenHost = nil
        requestServer(action, payload, cb, host)
    end)
end

RegisterNetEvent('pixel_enterprises:client:response', function(response)
    if type(response) ~= 'table' then return end
    local callback = response.requestId and pendingRequests[response.requestId]
    if callback then
        pendingRequests[response.requestId] = nil
        callback(response)
        return
    end
    SendNUIMessage({ action = 'serverResponse', payload = response })
    CENClient.SendLBTabletMessage('serverResponse', response)
end)

RegisterNetEvent('pixel_enterprises:client:membershipChanged', function(payload)
    SendNUIMessage({ action = 'membershipChanged', payload = payload })
    CENClient.SendLBTabletMessage('membershipChanged', payload)
end)

CreateThread(function()
    Wait(750)
    local mode = Config.Tablet.mode
    if mode == 'lb-tablet' or mode == 'both' or mode == 'auto' then CENClient.RegisterLBTabletApp() end
end)

RegisterNetEvent('pixel_enterprises:client:notification', function(payload)
    if type(payload) ~= 'table' or type(payload.message) ~= 'string' then return end
    local safe = payload.message:gsub('~', '')
    BeginTextCommandThefeedPost('STRING')
    AddTextComponentSubstringPlayerName(safe)
    EndTextCommandThefeedPostTicker(false, false)
    SendNUIMessage({ action = 'notification', payload = payload })
    CENClient.SendLBTabletMessage('notification', payload)
end)
