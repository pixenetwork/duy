const el = {
  tablet: document.getElementById('tablet'), navigation: document.getElementById('navigation'),
  content: document.getElementById('content'), title: document.getElementById('pageTitle'),
  subtitle: document.getElementById('pageSubtitle'), eyebrow: document.getElementById('eyebrow'),
  notice: document.getElementById('notice'), toast: document.getElementById('toast'),
  close: document.getElementById('close'), refresh: document.getElementById('refresh'),
  connectionText: document.getElementById('connectionText')
};
const isLBTablet = typeof globalThis.fetchNui === 'function';
let host = isLBTablet ? 'lb-tablet' : 'standalone';
let state = { mode: 'loading', active: 'dashboard', bootstrap: null, creation: null, data: {} };

const permission = {
  invite: 'members.invite', remove: 'members.remove', assign: 'members.assign_rank',
  ranks: 'ranks.manage', transfer: 'enterprise.transfer_ownership',
  deposit: 'treasury.deposit', withdraw: 'treasury.withdraw', logs: 'logs.view',
  storage: 'storage.access', turf: 'turfs.contest', territory: 'territories.contest',
  labs: 'labs.manage', claimProduction: 'labs.claim', postMarket: 'wholesale.post', buyMarket: 'wholesale.buy',
  street: 'street.sell', shipment: 'shipments.start', airdrop: 'airdrops.request', corruption: 'corruption.manage',
  crews: 'crews.manage', diplomacy: 'diplomacy.manage', declareWar: 'wars.declare', respondWar: 'wars.respond',
  fronts: 'fronts.manage', launder: 'fronts.launder', rackets: 'rackets.manage', collectRackets: 'rackets.collect'
};
const moduleLabels = {
  dashboard: 'Dashboard', members: 'Members', ranks: 'Ranks', treasury: 'Treasury',
  progression: 'Progression', storage: 'Storage', logs: 'Activity Logs',
  turfs: 'Turfs', territories: 'Territories', production: 'Production', wholesale: 'Wholesale',
  street_distribution: 'Street Sales', shipments: 'Shipments', corruption: 'Crooked Contacts',
  crews: 'Crews', diplomacy: 'Diplomacy', wars: 'Wars', fronts: 'Front Businesses', rackets: 'Rackets'
};

function node(tag, text, className) {
  const item = document.createElement(tag);
  if (text !== undefined && text !== null) item.textContent = String(text);
  if (className) item.className = className;
  return item;
}
function button(text, className, onClick) {
  const item = node('button', text, className || 'secondary');
  item.type = 'button';
  item.addEventListener('click', onClick);
  return item;
}
function input(type, placeholder, value = '') {
  const item = document.createElement('input');
  item.type = type; item.placeholder = placeholder; item.value = value;
  return item;
}
function empty(text) { return node('div', text, 'empty'); }
function money(value) { return `$${Number(value || 0).toLocaleString()}`; }
function notify(message, error = false) {
  el.toast.textContent = String(message || 'Completed');
  el.toast.classList.toggle('error', error); el.toast.classList.remove('hidden');
  clearTimeout(notify.timer); notify.timer = setTimeout(() => el.toast.classList.add('hidden'), 3500);
}
function showNotice(text) {
  el.notice.textContent = text || ''; el.notice.classList.toggle('hidden', !text);
}
function setOpen(open) {
  el.tablet.classList.toggle('hidden', !open);
  el.tablet.setAttribute('aria-hidden', String(!open));
}
async function postNui(name, payload = {}) {
  const body = { ...payload, __cenHost: host };
  if (isLBTablet) return globalThis.fetchNui(name, body);
  const resource = typeof GetParentResourceName === 'function' ? GetParentResourceName() : 'pixel_enterprises';
  const response = await fetch(`https://${resource}/${name}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
  });
  return response.json();
}
async function request(name, payload = {}) {
  const response = await postNui(name, payload);
  if (!response?.ok) throw new Error(response?.error || 'request_failed');
  return response.data;
}
function actor() { return state.bootstrap?.member || null; }
function hasPermission(name) { const member = actor(); return Boolean(member?.isOwner || member?.permissions?.includes(name)); }
function hasModule(name) { return Boolean(state.bootstrap?.modules?.includes(name)); }

function setHeading(eyebrow, title, subtitle = '') {
  el.eyebrow.textContent = eyebrow; el.title.textContent = title; el.subtitle.textContent = subtitle;
}
function summaryCard(label, value, className = '') {
  const card = node('article', null, `summary-card ${className}`.trim());
  card.append(node('small', label), node('strong', value)); return card;
}
function sectionHead(title, subtitle, action) {
  const wrap = node('div', null, 'section-head');
  const copy = node('div'); copy.append(node('h2', title), node('p', subtitle, 'muted'));
  wrap.append(copy); if (action) wrap.append(action); return wrap;
}
function renderNavigation(items) {
  el.navigation.replaceChildren();
  items.forEach(([key, label]) => {
    const item = button(label, key === state.active ? 'active' : '', () => navigate(key));
    el.navigation.append(item);
  });
}
async function navigate(key) {
  state.active = key;
  if (state.mode === 'guest') { renderGuest(); return; }
  renderMemberNavigation();
  try {
    if (key === 'dashboard') renderDashboard();
    else if (key === 'members') renderMembers();
    else if (key === 'ranks') renderRanks();
    else if (key === 'treasury') { state.data.treasury = await request('getTreasury'); renderTreasury(); }
    else if (key === 'progression') { state.data.progression = await request('getProgression'); renderProgression(); }
    else if (key === 'storage') renderStorage();
    else if (key === 'logs') { state.data.logs = await request('getLogs'); renderLogs(); }
    else if (key === 'turfs' || key === 'territories') { state.data.zones = await request('listZones'); renderZones(key); }
    else if (key === 'production') { state.data.production = await request('listProduction'); renderProduction(); }
    else if (key === 'wholesale') { state.data.market = await request('listMarket'); renderMarket(); }
    else if (key === 'street_distribution') renderStreetSales();
    else if (key === 'shipments') { state.data.shipments = await request('listShipments'); renderShipments(); }
    else if (key === 'corruption') { state.data.corruption = await request('listCorruption'); renderCorruption(); }
    else if (key === 'crews') { state.data.crews = await request('listCrews'); renderCrews(); }
    else if (key === 'diplomacy') { state.data.diplomacy = await request('listDiplomacy'); renderDiplomacy(); }
    else if (key === 'wars') { state.data.wars = await request('listWars'); renderWars(); }
    else if (key === 'fronts') { state.data.fronts = await request('listFronts'); renderFronts(); }
    else if (key === 'rackets') { state.data.rackets = await request('listRackets'); renderRackets(); }
  } catch (error) { notify(error.message, true); }
}

function renderMemberNavigation() {
  const modules = state.bootstrap?.modules || [];
  const items = [];
  const add = (key, label, allowed = true) => { if (allowed) items.push([key, label]); };
  add('dashboard', 'Dashboard');
  add('members', 'Members', modules.includes('members'));
  add('ranks', 'Ranks', modules.includes('ranks'));
  add('treasury', 'Treasury', modules.includes('treasury'));
  add('progression', 'Progression', modules.includes('progression'));
  add('crews', 'Crews', modules.includes('crews'));
  add('diplomacy', 'Diplomacy', modules.includes('diplomacy'));
  add('wars', 'Wars', modules.includes('wars'));
  add('fronts', 'Front Businesses', modules.includes('fronts'));
  add('rackets', 'Rackets', modules.includes('rackets'));
  add('storage', 'Storage', modules.includes('storage') && hasPermission(permission.storage));
  add('production', 'Production', modules.includes('labs') || modules.includes('arms'));
  add('wholesale', 'Wholesale', modules.includes('wholesale'));
  add('street_distribution', 'Street Sales', modules.includes('street_distribution'));
  add('shipments', 'Shipments', modules.includes('smuggling') || modules.includes('airdrops') || modules.includes('arms'));
  add('turfs', 'Turfs', modules.includes('turfs'));
  add('territories', 'Territories', modules.includes('territories'));
  add('corruption', 'Crooked Contacts', modules.includes('corruption'));
  add('logs', 'Activity Logs', modules.includes('logs') && hasPermission(permission.logs));
  renderNavigation(items);
}
function roster() { return state.bootstrap?.roster || { members: [], ranks: [], permissionCatalog: [] }; }

function renderDashboard() {
  const member = actor(); const data = roster();
  setHeading('ENTERPRISE OVERVIEW', member.enterpriseName, `${state.bootstrap.enterpriseType.label} · Tier ${state.bootstrap.enterpriseType.tier}`);
  const grid = node('div', null, 'grid summary-grid');
  const online = data.members.filter((m) => m.online).length;
  grid.append(
    summaryCard('Enterprise level', member.level), summaryCard('Enterprise XP', Number(member.xp || 0).toLocaleString()),
    summaryCard('Members', `${data.members.length} / ${data.memberLimit}`), summaryCard('Online now', online),
    summaryCard('Paid slots', data.paidExtraMemberSlots || 0), summaryCard('Your rank', member.isOwner ? 'Owner' : member.rankName),
    summaryCard('Criminal heat', member.heat || 0)
  );
  const content = node('div', null, 'stack'); content.append(grid);
  const retention = state.bootstrap.retention;
  if (retention?.retentionRequired) {
    const card = node('article', null, `card retention ${retention.retentionStatus === 'pending_disband' ? 'danger-state' : ''}`);
    card.append(node('h3', 'Monthly gang activity requirement'));
    card.append(node('p', `${retention.qualifiedActiveMembers}/${retention.minimumActiveMembers} members have reached ${retention.minimumMinutesPerMember} active minutes this month.`));
    if (retention.disbandScheduledAt) card.append(node('small', `Enforcement scheduled: ${retention.disbandScheduledAt}`, 'muted'));
    content.append(card);
  }
  const quick = node('article', null, 'card'); quick.append(node('h3', 'Operations status'));
  quick.append(node('p', 'Treasury, progression, secure storage, turf control, territories, founding, Tebex slots, retention and audit records are online.', 'muted'));
  content.append(quick); el.content.replaceChildren(content);
}

function rankOptions(selected) {
  const select = document.createElement('select');
  roster().ranks.filter((rank) => actor().isOwner || Number(rank.priority) < Number(actor().rankPriority)).forEach((rank) => {
    const option = node('option', `${rank.name} (${rank.priority})`); option.value = rank.rankId;
    option.selected = Number(selected) === Number(rank.rankId); select.append(option);
  });
  return select;
}
function renderMembers() {
  setHeading('ORGANIZATION', 'Members', 'Manage invitations, hierarchy and ownership.');
  const wrapper = node('div', null, 'stack');
  let inviteForm;
  if (hasPermission(permission.invite)) {
    inviteForm = node('form', null, 'inline-form card');
    const serverId = input('number', 'Nearby player server ID'); const ranks = rankOptions();
    inviteForm.append(serverId, ranks, button('Send invitation', 'primary', () => inviteForm.requestSubmit()));
    inviteForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      try {
        state.bootstrap.roster = await request('inviteMember', { targetServerId: Number(serverId.value), rankId: Number(ranks.value) });
        notify('Invitation sent. The player must accept it.'); renderMembers();
      } catch (error) { notify(error.message, true); }
    });
    wrapper.append(inviteForm);
  }
  const list = node('div', null, 'stack');
  roster().members.forEach((member) => {
    const row = node('article', null, 'row'); const main = node('div', null, 'row-main');
    const name = node('strong', member.displayName || `Member ${member.memberId}`);
    if (member.isOwner) name.append(node('span', 'OWNER', 'badge'));
    main.append(name, node('small', `${member.rankName} · ${member.online ? 'Online' : 'Offline'}`, member.online ? 'online' : 'offline'));
    const actions = node('div', null, 'actions');
    const self = Number(member.memberId) === Number(actor().memberId);
    const manageable = !self && !member.isOwner && (actor().isOwner || Number(actor().rankPriority) > Number(member.rankPriority));
    if (manageable && hasPermission(permission.assign)) {
      const select = rankOptions(member.rankId);
      actions.append(select, button('Save', 'secondary', async () => {
        try { state.bootstrap.roster = await request('setMemberRank', { memberId: member.memberId, rankId: Number(select.value) }); notify('Rank updated.'); renderMembers(); }
        catch (error) { notify(error.message, true); }
      }));
    }
    if (manageable && hasPermission(permission.remove)) actions.append(button('Remove', 'danger', async () => {
      if (!confirm(`Remove ${member.displayName}?`)) return;
      try { state.bootstrap.roster = await request('removeMember', { memberId: member.memberId }); notify('Member removed.'); renderMembers(); }
      catch (error) { notify(error.message, true); }
    }));
    if (actor().isOwner && manageable) actions.append(button('Make owner', 'gold', async () => {
      if (!confirm(`Transfer ownership to ${member.displayName}?`)) return;
      try { state.bootstrap.roster = await request('transferOwnership', { memberId: member.memberId }); await load(); notify('Ownership transferred.'); }
      catch (error) { notify(error.message, true); }
    }));
    row.append(main, actions); list.append(row);
  });
  wrapper.append(list);
  const exit = node('article', null, 'card');
  if (actor().isOwner) {
    const confirmName = input('text', `Type ${actor().enterpriseName} to disband`);
    exit.append(node('h3', 'Disband enterprise'), node('p', 'This performs a reversible soft disband and preserves paid entitlement records.', 'muted'), confirmName,
      button('Disband', 'danger', async () => { try { await request('disbandEnterprise', { confirm: confirmName.value }); notify('Enterprise disbanded.'); await load(); } catch (error) { notify(error.message, true); } }));
  } else {
    exit.append(node('h3', 'Leave enterprise'), button('Leave', 'danger', async () => { if (!confirm('Leave this enterprise?')) return; try { await request('leaveEnterprise'); await load(); } catch (error) { notify(error.message, true); } }));
  }
  wrapper.append(exit); el.content.replaceChildren(wrapper);
}

function permissionChecks(selected = []) {
  const wrap = node('div', null, 'permission-grid');
  roster().permissionCatalog.forEach((entry) => {
    const label = node('label', null, 'check'); const check = document.createElement('input'); check.type = 'checkbox';
    check.value = entry.permission; check.checked = selected.includes(entry.permission); check.disabled = !entry.canGrant;
    label.append(check, node('span', entry.label)); wrap.append(label);
  });
  return wrap;
}
function selectedPermissions(container) { return [...container.querySelectorAll('input[type=checkbox]:checked')].map((item) => item.value); }
function renderRanks() {
  setHeading('ACCESS CONTROL', 'Ranks & Permissions', 'Lower numeric priority means less authority.');
  const wrapper = node('div', null, 'stack');
  if (hasPermission(permission.ranks)) {
    const form = node('form', null, 'card'); const fields = node('div', null, 'inline-form');
    const name = input('text', 'Rank name'); const priority = input('number', 'Priority'); const checks = permissionChecks();
    fields.append(name, priority, button('Create rank', 'primary', () => form.requestSubmit())); form.append(fields, checks);
    form.addEventListener('submit', async (event) => { event.preventDefault(); try { state.bootstrap.roster = await request('createRank', { name: name.value, priority: Number(priority.value), permissions: selectedPermissions(checks) }); notify('Rank created.'); renderRanks(); } catch (error) { notify(error.message, true); } });
    wrapper.append(form);
  }
  roster().ranks.forEach((rank) => {
    const card = node('article', null, 'card'); const head = sectionHead(rank.name, `Priority ${rank.priority} · ${rank.memberCount || 0} members${rank.isProtected ? ' · Protected' : ''}`);
    card.append(head);
    const tags = node('p', rank.permissions?.join(' · ') || 'No permissions', 'muted'); card.append(tags);
    const canEdit = hasPermission(permission.ranks) && !rank.isProtected && (actor().isOwner || Number(rank.priority) < Number(actor().rankPriority));
    if (canEdit) {
      const form = node('div', null, 'stack'); const fields = node('div', null, 'inline-form');
      const name = input('text', 'Rank name', rank.name); const priority = input('number', 'Priority', rank.priority); const checks = permissionChecks(rank.permissions || []);
      fields.append(name, priority, button('Save', 'secondary', async () => { try { state.bootstrap.roster = await request('updateRank', { rankId: rank.rankId, name: name.value, priority: Number(priority.value), permissions: selectedPermissions(checks) }); notify('Rank saved.'); renderRanks(); } catch (error) { notify(error.message, true); } }),
        button('Delete', 'danger', async () => { if (!confirm(`Delete ${rank.name}?`)) return; try { state.bootstrap.roster = await request('deleteRank', { rankId: rank.rankId }); renderRanks(); } catch (error) { notify(error.message, true); } }));
      form.append(fields, checks); card.append(form);
    }
    wrapper.append(card);
  });
  el.content.replaceChildren(wrapper);
}

function renderTreasury() {
  const data = state.data.treasury;
  setHeading('ENTERPRISE FINANCE', 'Treasury', 'Deposits and withdrawals are logged server-side.');
  const wrapper = node('div', null, 'stack');
  const grid = node('div', null, 'grid summary-grid'); grid.append(summaryCard('Treasury balance', money(data.balance), 'money'), summaryCard('Withdrawn today', money(data.withdrawnToday)), summaryCard('Daily limit', money(data.dailyWithdrawalLimit)));
  wrapper.append(grid);
  const forms = node('div', null, 'split');
  [['Deposit', data.canDeposit, 'depositTreasury'], ['Withdraw', data.canWithdraw, 'withdrawTreasury']].forEach(([label, allowed, action]) => {
    if (!allowed) return;
    const form = node('form', null, 'card'); const amount = input('number', 'Amount'); const note = input('text', 'Optional note');
    form.append(node('h3', label), amount, note, button(label, label === 'Withdraw' ? 'gold' : 'primary', () => form.requestSubmit()));
    form.addEventListener('submit', async (event) => { event.preventDefault(); try { state.data.treasury = await request(action, { amount: Number(amount.value), note: note.value }); notify(`${label} completed.`); renderTreasury(); } catch (error) { notify(error.message, true); } });
    forms.append(form);
  });
  wrapper.append(forms, sectionHead('Transactions', 'Latest enterprise treasury activity'));
  const table = node('table', null, 'table'); const header = node('tr'); ['Type', 'Amount', 'Balance', 'Member', 'Time'].forEach((v) => header.append(node('th', v))); const thead = node('thead'); thead.append(header); table.append(thead); const body = node('tbody');
  (data.transactions || []).forEach((tx) => { const row = node('tr'); [tx.transactionType, money(tx.amount), money(tx.balanceAfter), tx.actorDisplayName, tx.createdAt].forEach((v) => row.append(node('td', v))); body.append(row); }); table.append(body); wrapper.append(data.transactions?.length ? table : empty('No treasury transactions yet.')); el.content.replaceChildren(wrapper);
}

function renderProgression() {
  const data = state.data.progression;
  setHeading('ENTERPRISE GROWTH', 'Progression', 'Organization XP unlocks future operational capacity without increasing free member slots.');
  const wrapper = node('div', null, 'stack'); const grid = node('div', null, 'grid summary-grid');
  grid.append(summaryCard('Current level', data.level), summaryCard('Total XP', Number(data.xp).toLocaleString()), summaryCard('Next level', data.nextLevelXp ? Number(data.nextLevelXp).toLocaleString() : 'MAX'));
  const progress = node('article', null, 'card'); progress.append(node('h3', 'Level progress')); const track = node('div', null, 'progress-track'); const bar = node('div', null, 'progress-bar'); bar.style.width = `${Math.round((data.progress || 0) * 100)}%`; track.append(bar); progress.append(track, node('p', `${Math.round((data.progress || 0) * 100)}%`, 'muted'));
  wrapper.append(grid, progress, sectionHead('Recent XP', 'Server-authoritative progression events'));
  const list = node('div', null, 'stack'); (data.events || []).forEach((event) => { const row = node('div', null, 'row'); const main = node('div', null, 'row-main'); main.append(node('strong', event.reason), node('small', `${event.actorDisplayName} · ${event.createdAt}`)); row.append(main, node('strong', `+${event.amount} XP`)); list.append(row); }); wrapper.append(data.events?.length ? list : empty('No progression events yet.')); el.content.replaceChildren(wrapper);
}

function renderStorage() {
  setHeading('SECURE ASSETS', 'Enterprise Storage', 'Access is checked by the server before ox_inventory is opened.');
  const card = node('article', null, 'card'); card.append(node('h2', 'Shared enterprise stash'), node('p', 'Use this storage for organization assets. Inventory actions remain governed by ox_inventory.', 'muted'));
  card.append(button('Open secure storage', 'primary', async () => { try { await request('openStorage'); notify('Storage opened.'); } catch (error) { notify(error.message, true); } })); el.content.replaceChildren(card);
}

function renderZones(kind) {
  const wanted = kind === 'turfs' ? 'turf' : 'territory';
  setHeading('CONTROL NETWORK', kind === 'turfs' ? 'Street Turfs' : 'Strategic Territories', kind === 'turfs' ? 'Control street distribution and neighborhood influence.' : 'Control strategic routes, resources and infrastructure.');
  const list = node('div', null, 'zone-list'); const data = state.data.zones;
  (data.zones || []).filter((z) => z.zoneType === wanted).forEach((zone) => {
    const card = node('article', null, 'card zone-card'); card.append(node('h3', zone.name), node('p', `Owner: ${zone.ownerName || 'Unclaimed'} · Required level ${zone.requiredLevel}`, 'muted'));
    if (zone.activeContestId) {
      card.append(node('div', null, 'zone-score'));
      card.lastChild.append(node('span', `Attack ${zone.attackerScore}`), node('span', `Defense ${zone.defenderScore}`));
      card.append(node('small', `Contest ends: ${zone.contestEndsAt}`, 'muted'));
    } else if (Number(zone.ownerEnterpriseId) !== Number(data.enterpriseId)) {
      const allowed = wanted === 'turf' ? hasPermission(permission.turf) : hasPermission(permission.territory);
      if (allowed) card.append(button('Start contest', 'primary', async () => { if (!confirm(`Contest ${zone.name}? You must be physically inside the zone.`)) return; try { state.data.zones = await request('startZoneContest', { zoneId: zone.zoneId }); notify('Contest started.'); renderZones(kind); } catch (error) { notify(error.message, true); } }));
    } else card.append(node('span', 'CONTROLLED', 'badge'));
    list.append(card);
  });
  el.content.replaceChildren(list.childElementCount ? list : empty(`No ${kind} have been configured by an administrator.`));
}

function renderLogs() {
  const logs = state.data.logs?.logs || [];
  setHeading('AUDIT TRAIL', 'Activity Logs', 'Sensitive identifiers are removed from the tablet read model.');
  const list = node('div', null, 'stack');
  logs.forEach((log) => { const row = node('article', null, 'row'); const main = node('div', null, 'row-main'); main.append(node('strong', log.eventName), node('small', `${log.actorDisplayName} · ${log.createdAt}`)); const details = node('small', Object.entries(log.payload || {}).map(([k, v]) => `${k}: ${typeof v === 'object' ? '[data]' : v}`).join(' · '), 'muted'); row.append(main, details); list.append(row); });
  el.content.replaceChildren(logs.length ? list : empty('No activity logs available.'));
}


function renderProduction() {
  const data = state.data.production || { facilities: [], jobs: [], recipes: [] };
  setHeading('PRODUCTION NETWORK', 'Labs & Workshops', 'Process materials into traceable batches. You must be near the assigned facility.');
  const wrapper = node('div', null, 'stack');
  if (data.facilities.length && data.recipes.length) {
    const form = node('form', null, 'card inline-form');
    const facility = document.createElement('select'); data.facilities.filter((f) => f.status === 'active').forEach((f) => { const o = node('option', `${f.name} · ${f.subtype}`); o.value = f.facilityId; facility.append(o); });
    const recipe = document.createElement('select'); data.recipes.forEach((r) => { const o = node('option', `${r.label} → ${r.outputCount} ${r.outputItem}`); o.value = r.key; recipe.append(o); });
    form.append(facility, recipe, button('Start production', 'primary', () => form.requestSubmit()));
    form.addEventListener('submit', async (event) => { event.preventDefault(); try { state.data.production = await request('startProduction', { facilityId: Number(facility.value), recipeKey: recipe.value }); notify('Production started.'); renderProduction(); } catch (error) { notify(error.message, true); } });
    wrapper.append(form);
  } else wrapper.append(empty('No active facility or unlocked recipe. An administrator must place a lab/workshop.'));
  wrapper.append(sectionHead('Production queue', 'Outputs retain batch, quality and producer metadata.'));
  const jobs = node('div', null, 'stack');
  data.jobs.forEach((job) => { const row = node('article', null, 'row'); const main = node('div', null, 'row-main'); main.append(node('strong', `${job.outputCount} × ${job.outputItem}`), node('small', `${job.facilityName} · Quality ${job.quality} · ${job.status} · Ready ${job.endsAt}`)); row.append(main); if (job.status === 'ready') row.append(button('Claim', 'primary', async () => { try { state.data.production = await request('claimProduction', { jobId: job.jobId }); notify('Batch claimed.'); renderProduction(); } catch (error) { notify(error.message, true); } })); jobs.append(row); });
  wrapper.append(data.jobs.length ? jobs : empty('No production jobs.')); el.content.replaceChildren(wrapper);
}

function renderMarket() {
  const data = state.data.market || { listings: [], deliveries: [], ownListings: [] };
  setHeading('UNDERGROUND EXCHANGE', 'Wholesale Market', 'Street gangs may only buy finished drugs from approved higher-tier suppliers.');
  const wrapper = node('div', null, 'stack');
  if (data.canPost) {
    const form = node('form', null, 'card grid'); const category = document.createElement('select');
    (data.categories || []).forEach((c) => { const o = node('option', c.replaceAll('_', ' ')); o.value = c; category.append(o); });
    const item = input('text', 'Configured item name'); const quantity = input('number', 'Quantity'); const price = input('number', 'Unit price'); const quality = input('number', 'Quality 1-100', '50');
    form.append(category, item, quantity, price, quality, button('Post listing', 'primary', () => form.requestSubmit()));
    form.addEventListener('submit', async (event) => { event.preventDefault(); try { state.data.market = await request('createMarketListing', { category: category.value, itemName: item.value, quantity: Number(quantity.value), unitPrice: Number(price.value), quality: Number(quality.value) }); notify('Listing posted.'); renderMarket(); } catch (error) { notify(error.message, true); } });
    wrapper.append(form);
  }
  wrapper.append(sectionHead('Available listings', 'Purchases are delivered to a secure claim queue.'));
  const listings = node('div', null, 'stack');
  data.listings.forEach((listing) => { const row = node('article', null, 'row'); const main = node('div', null, 'row-main'); main.append(node('strong', `${listing.itemName} · ${listing.sellerName}`), node('small', `${listing.category} · ${listing.quantityRemaining} available · ${money(listing.unitPrice)} each · Quality ${listing.quality}`)); row.append(main); if (data.canBuy && Number(listing.sellerEnterpriseId) !== Number(actor().enterpriseId)) { const q = input('number', 'Qty', '1'); q.className = 'compact'; row.append(q, button('Buy', 'primary', async () => { try { state.data.market = await request('buyMarketListing', { listingId: listing.listingId, quantity: Number(q.value) }); notify('Purchase completed. Claim the delivery below.'); renderMarket(); } catch (error) { notify(error.message, true); } })); } listings.append(row); });
  wrapper.append(data.listings.length ? listings : empty('No active listings.'));
  wrapper.append(sectionHead('Claimable deliveries', 'Inventory capacity is checked when claimed.'));
  const deliveries = node('div', null, 'stack'); data.deliveries.forEach((d) => { const row = node('article', null, 'row'); const main = node('div', null, 'row-main'); main.append(node('strong', `${d.quantity} × ${d.itemName}`), node('small', `${d.sourceType} · Quality ${d.quality} · ${d.createdAt}`)); row.append(main, button('Claim', 'primary', async () => { try { state.data.market = await request('claimMarketDelivery', { deliveryId: d.deliveryId }); notify('Delivery claimed.'); renderMarket(); } catch (error) { notify(error.message, true); } })); deliveries.append(row); }); wrapper.append(data.deliveries.length ? deliveries : empty('No pending deliveries.'));
  if (data.ownListings?.length) { wrapper.append(sectionHead('Your listings', 'Cancel active listings to move remaining stock into deliveries.')); const own = node('div', null, 'stack'); data.ownListings.forEach((l) => { const row = node('article', null, 'row'); const main = node('div', null, 'row-main'); main.append(node('strong', l.itemName), node('small', `${l.quantityRemaining} remaining · ${money(l.unitPrice)} · ${l.status}`)); row.append(main); if (l.status === 'active') row.append(button('Cancel', 'danger', async () => { try { state.data.market = await request('cancelMarketListing', { listingId: l.listingId }); notify('Listing cancelled.'); renderMarket(); } catch (error) { notify(error.message, true); } })); own.append(row); }); wrapper.append(own); }
  el.content.replaceChildren(wrapper);
}

function renderStreetSales() {
  setHeading('STREET DISTRIBUTION', 'Street Sales', 'Sell finished product inside a configured turf. Controlled turfs pay more.');
  const wrapper = node('div', null, 'stack');
  const products = ['cocaine_baggy', 'meth_baggy', 'weed_brick'];
  products.forEach((itemName) => { const card = node('article', null, 'row'); const main = node('div', null, 'row-main'); main.append(node('strong', itemName.replaceAll('_', ' ')), node('small', 'One unit per sale · server cooldown and heat apply')); card.append(main, button('Sell one', 'primary', async () => { try { const result = await request('sellStreetProduct', { itemName }); notify(`Sold for ${money(result.payout)} in ${result.turf}.`); } catch (error) { notify(error.message, true); } })); wrapper.append(card); });
  el.content.replaceChildren(wrapper);
}

function renderShipments() {
  const data = state.data.shipments || { shipments: [], catalog: [] };
  setHeading('LOGISTICS NETWORK', 'Shipments & Airdrops', 'Import components and contraband through timed dead drops or high-risk airdrops.');
  const wrapper = node('div', null, 'stack');
  wrapper.append(sectionHead('Available contracts', `Enterprise level ${data.enterpriseLevel}`));
  const catalog = node('div', null, 'grid'); data.catalog.forEach((entry) => { const card = node('article', null, 'card'); card.append(node('h3', entry.label), node('p', `${entry.quantity} × ${entry.item} · ${money(entry.cost)} · ${entry.delivery} · Level ${entry.minimumLevel}`, 'muted')); if (entry.unlocked && ((entry.delivery === 'airdrop' && data.canAirdrop) || (entry.delivery !== 'airdrop' && data.canStart))) card.append(button('Request', 'primary', async () => { if (!confirm(`Spend ${money(entry.cost)} on this shipment?`)) return; try { state.data.shipments = await request('requestShipment', { catalogKey: entry.key }); notify('Shipment scheduled.'); renderShipments(); } catch (error) { notify(error.message, true); } })); catalog.append(card); }); wrapper.append(catalog.childElementCount ? catalog : empty('No shipment contracts for this enterprise type.'));
  wrapper.append(sectionHead('Active and past shipments', 'Claim at the listed coordinates after the ready time.'));
  const rows = node('div', null, 'stack'); data.shipments.forEach((shipment) => { const row = node('article', null, 'row'); const main = node('div', null, 'row-main'); main.append(node('strong', `${shipment.itemName} · ${shipment.deliveryType}`), node('small', `${shipment.status} · ${shipment.pickupLabel} (${shipment.pickupX.toFixed(1)}, ${shipment.pickupY.toFixed(1)}) · Ready ${shipment.readyAt}`)); row.append(main); if (shipment.status === 'ready') row.append(button('Claim nearby', 'primary', async () => { try { state.data.shipments = await request('claimShipment', { shipmentId: shipment.shipmentId }); notify('Shipment claimed.'); renderShipments(); } catch (error) { notify(error.message, true); } })); rows.append(row); }); wrapper.append(data.shipments.length ? rows : empty('No shipments.')); el.content.replaceChildren(wrapper);
}

function renderCorruption() {
  const data = state.data.corruption || { offers: [], contacts: [], services: [] };
  setHeading('CORRUPTION NETWORK', 'Crooked Contacts', 'Offers are opt-in for authorized police characters and create exposure.');
  const wrapper = node('div', null, 'stack');
  if (data.canManage) { const form = node('form', null, 'card inline-form'); const target = input('number', 'Nearby officer server ID'); const service = document.createElement('select'); data.services.forEach((s) => { const o = node('option', `${s.label} · min ${money(s.minimumFee)}`); o.value = s.key; service.append(o); }); const fee = input('number', 'Offer fee'); form.append(target, service, fee, button('Send discreet offer', 'primary', () => form.requestSubmit())); form.addEventListener('submit', async (event) => { event.preventDefault(); try { state.data.corruption = await request('createCorruptionOffer', { targetServerId: Number(target.value), serviceKey: service.value, fee: Number(fee.value) }); notify('Offer sent.'); renderCorruption(); } catch (error) { notify(error.message, true); } }); wrapper.append(form); }
  wrapper.append(sectionHead('Offers', 'Pending and completed contact services.')); const offers = node('div', null, 'stack'); data.offers.forEach((o) => { const row = node('article', null, 'row'); const main = node('div', null, 'row-main'); main.append(node('strong', `${o.officerDisplayName} · ${o.serviceKey}`), node('small', `${money(o.fee)} · Exposure ${o.exposure} · ${o.status}`)); row.append(main); offers.append(row); }); wrapper.append(data.offers.length ? offers : empty('No corruption offers.'));
  wrapper.append(sectionHead('Contacts', 'Trust grows with completed services; exposure creates risk.')); const contacts = node('div', null, 'stack'); data.contacts.forEach((c) => { const row = node('article', null, 'row'); const main = node('div', null, 'row-main'); main.append(node('strong', c.officerDisplayName), node('small', `Trust ${c.trust} · Exposure ${c.exposure} · Paid ${money(c.totalPaid)} · ${c.status}`)); row.append(main); contacts.append(row); }); wrapper.append(data.contacts.length ? contacts : empty('No established contacts.')); el.content.replaceChildren(wrapper);
}


function renderCrews() {
  const data = state.data.crews || { crews: [], canManage: false, maximumCrews: 0 };
  setHeading('INTERNAL STRUCTURE', 'Crews & Chapters', 'Organize members into operational teams without changing enterprise ranks.');
  const wrapper = node('div', null, 'stack');
  if (data.canManage && data.crews.length < data.maximumCrews) {
    const form = node('form', null, 'card inline-form'); const name = input('text', 'Crew or chapter name');
    const leader = document.createElement('select'); roster().members.forEach((m) => { const o = node('option', m.displayName); o.value = m.memberId; leader.append(o); });
    const maxMembers = input('number', 'Max members', data.defaultMaximumMembers || 8);
    form.append(name, leader, maxMembers, button('Create crew', 'primary', () => form.requestSubmit()));
    form.addEventListener('submit', async (event) => { event.preventDefault(); try { state.data.crews = await request('createCrew', { name: name.value, leaderMemberId: Number(leader.value), maxMembers: Number(maxMembers.value) }); notify('Crew created.'); renderCrews(); } catch (error) { notify(error.message, true); } });
    wrapper.append(form);
  }
  wrapper.append(sectionHead('Active crews', `${data.crews.length}/${data.maximumCrews} available`));
  data.crews.forEach((crew) => {
    const card = node('article', null, 'card'); card.append(node('h3', crew.name), node('p', `${crew.memberCount}/${crew.maxMembers} members · Leader: ${crew.leaderDisplayName}`, 'muted'));
    const memberRows = node('div', null, 'stack compact'); crew.members.forEach((m) => { const row = node('div', null, 'row'); row.append(node('span', `${m.displayName} · ${m.rankName}${m.role === 'leader' ? ' · Leader' : ''}`)); if (data.canManage && m.role !== 'leader') row.append(button('Remove', 'danger small', async () => { try { state.data.crews = await request('removeCrewMember', { crewId: crew.crewId, memberId: m.memberId }); renderCrews(); } catch (error) { notify(error.message, true); } })); memberRows.append(row); }); card.append(memberRows);
    if (data.canManage) { const controls = node('div', null, 'inline-form'); const select = document.createElement('select'); roster().members.filter((m) => !crew.members.some((cm) => cm.memberId === m.memberId)).forEach((m) => { const o = node('option', m.displayName); o.value = m.memberId; select.append(o); }); if (select.options.length) controls.append(select, button('Assign', 'secondary', async () => { try { state.data.crews = await request('assignCrewMember', { crewId: crew.crewId, memberId: Number(select.value) }); renderCrews(); } catch (error) { notify(error.message, true); } })); const leader = document.createElement('select'); roster().members.forEach((m) => { const o = node('option', `Leader: ${m.displayName}`); o.value = m.memberId; if (m.memberId === crew.leaderMemberId) o.selected = true; leader.append(o); }); controls.append(leader, button('Set leader', 'secondary', async () => { try { state.data.crews = await request('setCrewLeader', { crewId: crew.crewId, memberId: Number(leader.value) }); notify('Crew leader updated.'); renderCrews(); } catch (error) { notify(error.message, true); } }), button('Delete crew', 'danger', async () => { if (!confirm(`Delete ${crew.name}?`)) return; try { state.data.crews = await request('deleteCrew', { crewId: crew.crewId }); renderCrews(); } catch (error) { notify(error.message, true); } })); card.append(controls); }
    wrapper.append(card);
  });
  if (!data.crews.length) wrapper.append(empty('No crews or chapters have been created.'));
  el.content.replaceChildren(wrapper);
}

function renderDiplomacy() {
  const data = state.data.diplomacy || { relations: [], proposals: [], directory: [], canManage: false };
  setHeading('EXTERNAL RELATIONS', 'Diplomacy', 'Negotiate alliances and ceasefires. Active wars enforce enemy status.');
  const wrapper = node('div', null, 'stack');
  if (data.canManage && data.directory.length) {
    const form = node('form', null, 'card inline-form'); const target = document.createElement('select'); data.directory.forEach((e) => { const o = node('option', `${e.name} · Tier ${e.tier} · Level ${e.level}`); o.value = e.enterpriseId; target.append(o); }); const type = document.createElement('select'); [['allied','Alliance'],['ceasefire','Ceasefire']].forEach(([v,l]) => { const o=node('option',l); o.value=v; type.append(o); }); const message = input('text', 'Optional message'); form.append(target, type, message, button('Send proposal', 'primary', () => form.requestSubmit())); form.addEventListener('submit', async (event) => { event.preventDefault(); try { state.data.diplomacy = await request('proposeDiplomacy', { targetEnterpriseId: Number(target.value), relationType: type.value, message: message.value }); notify('Diplomatic proposal sent.'); renderDiplomacy(); } catch (error) { notify(error.message, true); } }); wrapper.append(form);
  }
  wrapper.append(sectionHead('Relations', 'Current alliances, enemies and ceasefires.'));
  const relations = node('div', null, 'stack'); data.relations.forEach((r) => { const row = node('article', null, 'row'); const main = node('div', null, 'row-main'); main.append(node('strong', r.otherEnterpriseName), node('small', `${r.relationType} · ${r.establishedBy}${r.expiresAt ? ` · Until ${r.expiresAt}` : ''}`)); row.append(main); if (data.canManage && r.establishedBy !== 'war') row.append(button('End relation', 'danger', async () => { try { state.data.diplomacy = await request('endDiplomacy', { relationId: r.relationId }); renderDiplomacy(); } catch (error) { notify(error.message, true); } })); relations.append(row); }); wrapper.append(data.relations.length ? relations : empty('No active relationships.'));
  wrapper.append(sectionHead('Pending proposals', 'Incoming proposals require an authorized response.'));
  const proposals = node('div', null, 'stack'); data.proposals.forEach((p) => { const incoming = p.targetEnterpriseId === data.enterpriseId; const row = node('article', null, 'row'); const main = node('div', null, 'row-main'); main.append(node('strong', `${p.proposerName} → ${p.targetName}`), node('small', `${p.relationType} · ${p.message || 'No message'} · Expires ${p.expiresAt}`)); row.append(main); if (incoming && data.canManage) { const actions=node('div',null,'actions'); actions.append(button('Accept','primary',async()=>{ try { state.data.diplomacy=await request('respondDiplomacy',{proposalId:p.proposalId,accepted:true}); renderDiplomacy(); } catch(error){ notify(error.message,true); }}),button('Decline','danger',async()=>{ try { state.data.diplomacy=await request('respondDiplomacy',{proposalId:p.proposalId,accepted:false}); renderDiplomacy(); } catch(error){ notify(error.message,true); }})); row.append(actions); } else if (!incoming && data.canManage) { row.append(button('Cancel','danger',async()=>{ try { state.data.diplomacy=await request('cancelDiplomacy',{proposalId:p.proposalId}); renderDiplomacy(); } catch(error){ notify(error.message,true); }})); } proposals.append(row); }); wrapper.append(data.proposals.length ? proposals : empty('No pending diplomatic proposals.')); el.content.replaceChildren(wrapper);
}

function renderWars() {
  const data = state.data.wars || { wars: [], directory: [], config: {} };
  setHeading('ORGANIZED CONFLICT', 'War Contracts', 'Formal wars use matched treasury stakes, timed scoring and automatic payouts.');
  const wrapper = node('div', null, 'stack');
  if (data.canDeclare && Number(data.enterpriseLevel) >= Number(data.config.minimumLevel) && data.directory.length) {
    const form = node('form', null, 'card inline-form'); const target = document.createElement('select'); data.directory.forEach((e) => { const o=node('option',`${e.name} · Level ${e.level}`); o.value=e.enterpriseId; target.append(o); }); const stake=input('number','Matched stake',data.config.minimumStake||0); const score=input('number','Target score',data.config.defaultTargetScore||100); const reason=input('text','Reason or terms'); form.append(target,stake,score,reason,button('Propose war','danger',()=>form.requestSubmit())); form.addEventListener('submit',async(event)=>{event.preventDefault(); if(!confirm('Place the stake into escrow and send this war proposal?')) return; try { state.data.wars=await request('proposeWar',{targetEnterpriseId:Number(target.value),stake:Number(stake.value),targetScore:Number(score.value),reason:reason.value}); notify('War proposal sent.'); renderWars(); } catch(error){notify(error.message,true);} }); wrapper.append(form);
  }
  data.wars.forEach((w) => { const row=node('article',null,`card war ${w.status}`); row.append(node('h3',`${w.attackerName} vs ${w.defenderName}`),node('p',`${w.attackerScore}/${w.targetScore} — ${w.defenderScore}/${w.targetScore} · ${w.status}`,'muted'),node('p',`Stake: ${money(w.attackerStake)} each · ${w.reason || 'No terms supplied'}`,'muted')); const incoming=w.defenderEnterpriseId===data.enterpriseId&&w.status==='proposed'; const outgoing=w.attackerEnterpriseId===data.enterpriseId&&w.status==='proposed'; if(incoming&&data.canRespond){const actions=node('div',null,'actions');actions.append(button('Accept & match stake','primary',async()=>{if(!confirm(`Match ${money(w.defenderStake)} and start the war?`))return;try{state.data.wars=await request('respondWar',{warId:w.warId,accepted:true});renderWars();}catch(error){notify(error.message,true);}}),button('Decline','danger',async()=>{try{state.data.wars=await request('respondWar',{warId:w.warId,accepted:false});renderWars();}catch(error){notify(error.message,true);}}));row.append(actions);} if(outgoing&&data.canDeclare)row.append(button('Cancel proposal','danger',async()=>{try{state.data.wars=await request('cancelWar',{warId:w.warId});renderWars();}catch(error){notify(error.message,true);}})); wrapper.append(row); }); if(!data.wars.length)wrapper.append(empty('No war contracts.')); el.content.replaceChildren(wrapper);
}

function renderFronts() {
  const data = state.data.fronts || { fronts: [], jobs: [], businessTypes: [] };
  setHeading('FINANCIAL FRONTS', 'Front Businesses', 'Purchase legitimate fronts and process dirty funds over time.');
  const wrapper=node('div',null,'stack');
  if(data.canManage){wrapper.append(sectionHead('Available fronts','Purchased with enterprise treasury.'));const grid=node('div',null,'grid');data.businessTypes.forEach((t)=>{const card=node('article',null,'card');card.append(node('h3',t.label),node('p',`${money(t.cost)} · Capacity ${money(t.capacity)} · Fee ${t.feePercent}% · Level ${t.minimumLevel}`,'muted'));if(t.allowed&&data.fronts.length<(data.maximumPerEnterprise||3)){const name=input('text',`${t.label} name`);card.append(name,button('Purchase','primary',async()=>{if(!confirm(`Purchase for ${money(t.cost)}?`))return;try{state.data.fronts=await request('createFront',{businessType:t.key,name:name.value});renderFronts();}catch(error){notify(error.message,true);}}));}grid.append(card);});wrapper.append(grid);}
  wrapper.append(sectionHead('Owned fronts',`Monthly capacity resets on the database cycle. Payout: ${(data.payoutDestination||'enterprise_treasury').replaceAll('_',' ')}.`));data.fronts.forEach((f)=>{const card=node('article',null,'card');card.append(node('h3',f.name),node('p',`${f.businessType} · ${money(f.processedThisCycle)}/${money(f.capacityPerCycle)} processed · Fee ${f.feePercent}%`,'muted'));if(data.canLaunder){const amount=input('number','Dirty amount');card.append(amount,button('Start laundering','primary',async()=>{try{state.data.fronts=await request('startLaundering',{frontId:f.frontId,amount:Number(amount.value)});notify('Laundering job started.');renderFronts();}catch(error){notify(error.message,true);}}));}wrapper.append(card);});if(!data.fronts.length)wrapper.append(empty('No front businesses.'));
  wrapper.append(sectionHead('Laundering jobs','Claim clean funds after processing completes.'));const jobs=node('div',null,'stack');data.jobs.forEach((j)=>{const row=node('article',null,'row');const main=node('div',null,'row-main');main.append(node('strong',`${j.frontName} · ${money(j.dirtyAmount)} → ${money(j.cleanAmount)}`),node('small',`${j.status} · Fee ${money(j.feeAmount)} · Ready ${j.readyAt}`));row.append(main);if(j.status==='ready'&&data.canLaunder)row.append(button('Claim','primary',async()=>{try{state.data.fronts=await request('claimLaundering',{jobId:j.jobId});notify('Clean funds claimed.');renderFronts();}catch(error){notify(error.message,true);}}));jobs.append(row);});wrapper.append(data.jobs.length?jobs:empty('No laundering jobs.'));el.content.replaceChildren(wrapper);
}

function renderRackets() {
  const data=state.data.rackets||{rackets:[],ownedZones:[],types:[]};setHeading('LOCAL CONTROL','Protection Rackets','Turn controlled zones into recurring criminal income with heat and cooldowns.');const wrapper=node('div',null,'stack');
  if(data.canManage&&data.ownedZones.length){const form=node('form',null,'card inline-form');const zone=document.createElement('select');data.ownedZones.forEach((z)=>{const o=node('option',`${z.name} · ${z.zoneType}`);o.value=z.zoneId;zone.append(o);});const type=document.createElement('select');data.types.filter((t)=>t.allowed).forEach((t)=>{const o=node('option',`${t.label} · ${money(t.payout)}`);o.value=t.key;type.append(o);});form.append(zone,type,button('Establish racket','primary',()=>form.requestSubmit()));form.addEventListener('submit',async(event)=>{event.preventDefault();try{state.data.rackets=await request('createRacket',{zoneId:Number(zone.value),racketType:type.value});renderRackets();}catch(error){notify(error.message,true);}});wrapper.append(form);}
  data.rackets.forEach((r)=>{const row=node('article',null,'row');const main=node('div',null,'row-main');main.append(node('strong',`${r.zoneName} · ${r.racketType}`),node('small',`${money(r.payoutAmount)} per collection · Heat ${r.heat} · Last ${r.lastCollectedAt||'Never'}`));row.append(main);if(data.canCollect)row.append(button('Collect','primary',async()=>{try{state.data.rackets=await request('collectRacket',{racketId:r.racketId});notify('Racket income added to treasury.');renderRackets();}catch(error){notify(error.message,true);}}));wrapper.append(row);});if(!data.rackets.length)wrapper.append(empty('No active rackets.'));el.content.replaceChildren(wrapper);
}

function renderOfficerOffers() {
  setHeading('DISCREET OFFERS', 'Officer Contacts', 'Accepting is voluntary and all services create exposure and an administrative audit trail.');
  const wrapper = node('div', null, 'stack'); const offers = state.creation.officerOffers || [];
  offers.forEach((offer) => { const row = node('article', null, 'row'); const main = node('div', null, 'row-main'); main.append(node('strong', `${offer.enterpriseName} · ${offer.serviceKey}`), node('small', `${money(offer.fee)} · Exposure ${offer.exposure} · Expires ${offer.expiresAt}`)); const actions = node('div', null, 'actions'); actions.append(button('Accept', 'primary', async () => { try { const result = await request('acceptCorruptionOffer', { offerId: offer.offerId }); state.creation.officerOffers = result.offers || []; notify('Service accepted and paid.'); renderOfficerOffers(); } catch (error) { notify(error.message, true); } }), button('Decline', 'danger', async () => { try { const result = await request('declineCorruptionOffer', { offerId: offer.offerId }); state.creation.officerOffers = result.offers || []; renderOfficerOffers(); } catch (error) { notify(error.message, true); } })); row.append(main, actions); wrapper.append(row); }); el.content.replaceChildren(offers.length ? wrapper : empty('No discreet offers.'));
}

function renderGuestNavigation() { const items = [['founding', 'Create a Gang'], ['invitations', 'Invitations']]; if (state.creation?.officerOffers?.length) items.push(['officer_offers', 'Discreet Offers']); renderNavigation(items); }
function renderGuest() {
  renderGuestNavigation();
  if (state.active === 'invitations') renderGuestInvitations(); else if (state.active === 'officer_offers') renderOfficerOffers(); else renderFounding();
}
function renderFounding() {
  const context = state.creation;
  setHeading('FOUNDING NETWORK', 'Create a Criminal Enterprise', 'Free street gangs require eight other players to accept.');
  const wrapper = node('div', null, 'stack');
  if (context.proposal) {
    const p = context.proposal; const card = node('article', null, 'card proposal');
    card.append(node('h2', p.name), node('p', `${p.acceptedCount}/${p.requiredAcceptances} accepted supporters · ${p.status}`, 'muted'));
    const track = node('div', null, 'progress-track'); const bar = node('div', null, 'progress-bar'); bar.style.width = `${Math.min(100, p.acceptedCount / p.requiredAcceptances * 100)}%`; track.append(bar); card.append(track);
    const form = node('form', null, 'inline-form'); const serverId = input('number', 'Nearby player server ID'); form.append(serverId, button('Invite supporter', 'primary', () => form.requestSubmit()));
    form.addEventListener('submit', async (event) => { event.preventDefault(); try { context.proposal = await request('inviteFoundingMember', { targetServerId: Number(serverId.value) }); notify('Founding invitation sent.'); renderFounding(); } catch (error) { notify(error.message, true); } }); card.append(form, button('Cancel proposal', 'danger', async () => { if (!confirm('Cancel this proposal?')) return; try { await request('cancelFounding', { proposalId: p.proposalId }); await load(); } catch (error) { notify(error.message, true); } })); wrapper.append(card);
  } else {
    const form = node('form', null, 'card'); const name = input('text', 'Gang or enterprise name'); const type = document.createElement('select');
    Object.entries(context.typePolicies || {}).forEach(([key, policy]) => { if (policy === 'disabled' || policy === 'admin_only') return; const option = node('option', key.replaceAll('_', ' ')); option.value = key; type.append(option); });
    form.append(node('h2', 'Start a founding proposal'), node('p', `Free gangs begin with ${context.baseMemberLimit} slots and require ${context.requiredAcceptances} accepted supporters.`, 'muted'), name, type, button('Create proposal', 'primary', () => form.requestSubmit()));
    form.addEventListener('submit', async (event) => { event.preventDefault(); try { context.proposal = await request('startFounding', { name: name.value, enterpriseType: type.value }); notify('Proposal created.'); renderFounding(); } catch (error) { notify(error.message, true); } }); wrapper.append(form);
  }
  wrapper.append(node('article', null, 'card')); wrapper.lastChild.append(node('h3', 'Free gang retention'), node('p', 'A free gang must maintain five qualified active members each complete calendar month. The leader receives a warning in week three before a reversible soft disband is scheduled.', 'muted'));
  el.content.replaceChildren(wrapper);
}
function renderGuestInvitations() {
  setHeading('PENDING ACCESS', 'Invitations', 'Accept a gang membership invitation or support a founding proposal.');
  const wrapper = node('div', null, 'stack');
  const membership = state.creation.pendingMembershipInvites || [];
  wrapper.append(sectionHead('Membership invitations', 'Joining is always consent-based.'));
  membership.forEach((invite) => { const row = node('article', null, 'row'); const main = node('div', null, 'row-main'); main.append(node('strong', invite.enterpriseName), node('small', `Rank: ${invite.rankName} · Expires ${invite.expiresAt}`)); const actions = node('div', null, 'actions'); actions.append(button('Accept', 'primary', async () => { try { await request('acceptMembershipInvite', { inviteId: invite.inviteId }); await load(); } catch (error) { notify(error.message, true); } }), button('Decline', 'danger', async () => { try { await request('declineMembershipInvite', { inviteId: invite.inviteId }); await load(); } catch (error) { notify(error.message, true); } })); row.append(main, actions); wrapper.append(row); });
  if (!membership.length) wrapper.append(empty('No membership invitations.'));
  const founding = state.creation.pendingInvites || [];
  wrapper.append(sectionHead('Founding invitations', 'Your acceptance counts toward the eight-person requirement.'));
  founding.forEach((invite) => { const row = node('article', null, 'row'); const main = node('div', null, 'row-main'); main.append(node('strong', invite.enterpriseName || invite.proposalName || invite.name || `Proposal #${invite.proposalId}`), node('small', `Founder: ${invite.founderDisplayName || 'Unknown'} · Expires ${invite.expiresAt}`)); const actions = node('div', null, 'actions'); actions.append(button('Support', 'primary', async () => { try { await request('acceptFoundingInvite', { proposalId: invite.proposalId }); await load(); } catch (error) { notify(error.message, true); } }), button('Decline', 'danger', async () => { try { await request('declineFoundingInvite', { proposalId: invite.proposalId }); await load(); } catch (error) { notify(error.message, true); } })); row.append(main, actions); wrapper.append(row); });
  if (!founding.length) wrapper.append(empty('No founding invitations.'));
  el.content.replaceChildren(wrapper);
}

async function load() {
  showNotice(''); state.data = {}; el.connectionText.textContent = `${host} · encrypted`;
  try {
    state.bootstrap = await request('getBootstrap'); state.mode = 'member'; state.active = 'dashboard';
    renderMemberNavigation(); renderDashboard();
  } catch (error) {
    if (!['not_member', 'invalid_enterprise'].includes(error.message)) { showNotice(`Access error: ${error.message}`); throw error; }
    state.creation = await request('getCreationContext');
    try { const officer = await request('getOfficerOffers'); state.creation.officerOffers = officer.offers || []; } catch (_) { state.creation.officerOffers = []; }
    state.mode = 'guest'; state.active = 'founding'; renderGuest();
  }
}

el.close.addEventListener('click', async () => { if (!isLBTablet) await postNui('close'); else setOpen(false); });
el.refresh.addEventListener('click', () => load().catch((error) => notify(error.message, true)));
window.addEventListener('message', (event) => {
  if (!event.data || typeof event.data !== 'object') return;
  if (event.data.action === 'open') { host = event.data.host === 'lb-tablet' ? 'lb-tablet' : 'standalone'; setOpen(true); load().catch((error) => notify(error.message, true)); }
  if (event.data.action === 'close') setOpen(false);
  if (event.data.action === 'membershipChanged') load().catch(() => {});
  if (event.data.action === 'notification' && event.data.payload?.message) notify(event.data.payload.message, event.data.payload.kind === 'error');
});

if (isLBTablet) { setOpen(true); load().catch((error) => notify(error.message, true)); }
